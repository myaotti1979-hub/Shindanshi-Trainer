# 使い方: python3 sec.py 科目 細目ID... → 原稿（図の名前つき）と、図の中の文字を表示
import sys, json, re, glob, importlib.util, html
s = sys.argv[1]; ids = sys.argv[2:]
T = {}
for f in sorted(glob.glob('text/%s_p*.py' % s)):
    if 'before' in f: continue
    sp = importlib.util.spec_from_file_location('m', f); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    T.update(m.T)
d = json.load(open('pwa/data/t_%s.json' % s))
C = {}
for ch in d['chapters']:
    for x in ch['sections']:
        C[x['id']] = x['content']
for i in ids:
    title, src = T[i]
    svgs = re.findall(r'<svg.*?</svg>', C[i], flags=re.S)
    k = [0]
    def rep(mm):
        n = k[0]; k[0] += 1
        tx = ''
        if n < len(svgs):
            tt = [html.unescape(re.sub(r'<[^>]+>', '', t)) for t in re.findall(r'<text[^>]*>.*?</text>', svgs[n], flags=re.S)]
            tx = ' | '.join(t for t in tt if t.strip())
        return '[[図:%s]] {%s}' % (mm.group(1), tx[:int(__import__("os").environ.get("FT","900"))])
    out = re.sub(r'\[\[図:([^\]]+)\]\]', rep, src)
    print('=' * 10, i, title)
    print(out)
