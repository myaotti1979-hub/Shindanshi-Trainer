# 図の名前と見出しの一覧（模擬試験・演習の解説に、テキストの図を名前で使うため）
# python3 figlist.py keizai        … keizai. で始まる図
# python3 figlist.py keizai IS      … 見出しに IS を含むもの
import sys, os, glob, re, importlib.util
B = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(B, 'text'))
pre = sys.argv[1] if len(sys.argv) > 1 else ''
kw = sys.argv[2] if len(sys.argv) > 2 else ''
FIG = {}
for f in sorted(glob.glob(os.path.join(B, 'text', 'fig_*.py'))):
    spec = importlib.util.spec_from_file_location(os.path.basename(f)[:-3], f); m = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(m)
    except Exception as e:   # 作成中の図のファイルが壊れていても、ほかの一覧は出す
        print('読めない:', os.path.basename(f), e, file=sys.stderr); continue
    for k, v in m.FIG.items():
        FIG[k] = (os.path.basename(f), v)
for k in sorted(FIG):
    if not k.startswith(pre):
        continue
    f, v = FIG[k]
    t = re.search(r'aria-label="([^"]*)"', v)
    title = t.group(1) if t else ''
    if kw and kw not in title and kw not in k:
        continue
    print('%-34s %-22s %s' % (k, f, title[:70]))
