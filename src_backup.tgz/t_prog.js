// 演習の進み具合の画面を確かめる。何問か解いた状態を作ってから、演習タブ・論点表・問題の一覧・演習・結果を撮る
// node t_prog.js <名前> [light|dark]
const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
const URL='http://127.0.0.1:8765/';
const name=process.argv[2]||'prog', scheme=process.argv[3]||'light';
(async()=>{
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:400,height:860},deviceScaleFactor:2,locale:'ja-JP',timezoneId:'Asia/Tokyo',colorScheme:scheme});
  const page=await ctx.newPage();
  await page.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  const errs=[];page.on('pageerror',e=>errs.push('PAGEERR '+e.message));
  // 何問か解いた記録を、アプリが読み込む前に入れておく（企業経営理論の最初の46問と、財務・会計の12問）
  const fs=require('fs');
  const j=JSON.parse(fs.readFileSync(B+'/pwa/data/q_kigyo.json','utf8')),z=JSON.parse(fs.readFileSync(B+'/pwa/data/q_zaimu.json','utf8'));
  const now=Date.now(),D=864e5,srs={};
  j.questions.slice().sort((a,b)=>(a.n||0)-(b.n||0)).slice(0,46).forEach((q,i)=>{const ok=i%4!==1;srs[q.id]={st:ok?3.7:0.4,df:5,last:now-2*D,due:ok?now+3*D:now-2*D+600000,reps:1,lapses:0,att:1,cor:ok?1:0,cw:0,lc:'sure'};});
  z.questions.slice(0,12).forEach((q,i)=>{const ok=i%3!==0;srs[q.id]={st:3,df:5,last:now-D,due:ok?now+2*D:now-D+600000,reps:1,lapses:0,att:1,cor:ok?1:0,cw:0,lc:'unsure'};});
  const state={v:1,settings:{wdMin:60,weMin:180,newPerDay:15,exam1:'2027-08-07',exam2:'2027-10-24',active:['kigyo','unei','zaimu'],start:'2026-11-09'},srs:srs,days:{},past:[],flags:{},timer:null};
  await ctx.addInitScript(st=>{try{if(!sessionStorage.getItem('inj')){localStorage.setItem('shindan1',JSON.stringify(st));localStorage.setItem('shindan1-tab','drill');sessionStorage.setItem('inj','1');}}catch(e){}},state);
  await page.goto(URL+'index.html');await page.waitForTimeout(900);
  const ovf=async()=>page.evaluate(()=>{const d=document.documentElement;const bad=[];document.querySelectorAll('body *').forEach(el=>{const r=el.getBoundingClientRect();if(r.width>0&&r.right>d.clientWidth+1&&!el.closest('.chartbox')&&!el.closest('.pgrid')&&!el.closest('.fig'))bad.push((el.className||el.tagName)+':'+Math.round(r.right));});return {sw:d.scrollWidth,cw:d.clientWidth,bad:bad.slice(0,6)};});
  const out={};
  const full=async(f)=>{const h=await page.evaluate(()=>{const m=document.querySelector('main');return m?m.scrollHeight+140:1600;});await page.setViewportSize({width:400,height:Math.min(5000,Math.max(860,h))});await page.waitForTimeout(150);await page.screenshot({path:B+'/shots/'+f});await page.setViewportSize({width:400,height:860});};
  await full(name+'-1-drill.png');out.drill=await ovf();
  await page.click('[data-act=open-syl][data-s=kigyo]');await page.waitForTimeout(200);
  // 最初の論点の一覧を開く
  await page.evaluate(()=>{const d=document.querySelector('.grp details');if(d)d.open=true;});
  await full(name+'-2-syl.png');out.syl=await ovf();
  // 一覧の問題を押して演習を始める
  const qb=await page.$('[data-act=drill-q]');
  if(qb){await qb.click();await page.waitForTimeout(200);await page.screenshot({path:B+'/shots/'+name+'-3-sess.png'});out.sess=await ovf();
    for(let i=0;i<40;i++){if(await page.$('[data-act=s-done]'))break;if(await page.$('[data-act=next]')){await page.click('[data-act=next]');continue;}const p=await page.$('[data-act=pick]');if(!p)break;await p.click();await page.click('[data-act=conf][data-c=unsure]');}
    await page.waitForTimeout(200);await page.screenshot({path:B+'/shots/'+name+'-4-done.png'});out.done=await ovf();
    await page.click('[data-act=s-done]');await page.waitForTimeout(200);
    await full(name+'-5-syl-after.png');out.sylAfter=await ovf();
  } else out.noQ=true;
  await page.click('[data-act=tab][data-tab=today]');await page.waitForTimeout(200);
  await page.screenshot({path:B+'/shots/'+name+'-6-today.png'});out.today=await ovf();
  out.errs=errs;
  console.log(JSON.stringify(out));
  await browser.close();
})();
