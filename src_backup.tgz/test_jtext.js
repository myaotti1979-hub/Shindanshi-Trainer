const http = require('http'), fs = require('fs'), path = require('path');
const srv = http.createServer((q,r)=>{
  let f = path.join('.', q.url==='/'?'index.html':q.url);
  try{const d=fs.readFileSync(f);const t=f.endsWith('.json')?'application/json':f.endsWith('.js')?'text/javascript':'text/html';r.writeHead(200,{'Content-Type':t+'; charset=utf-8'});r.end(d);}
  catch(e){r.writeHead(404);r.end('Not found');}
});
srv.listen(0, async()=>{
  const port = srv.address().port;
  const {chromium} = require('playwright');
  const b = await chromium.launch();
  const p = await b.newPage({viewport:{width:390,height:844},deviceScaleFactor:2});
  const SS = '/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/';

  await p.goto('http://localhost:'+port+'/');
  await p.waitForTimeout(2000);
  // Go to 2次
  await p.click('[data-stage="s2"]');
  await p.waitForTimeout(1500);
  await p.screenshot({path: SS+'v35_text_toc.png'});

  // Scroll down to see more
  await p.evaluate(()=>window.scrollBy(0,500));
  await p.waitForTimeout(300);
  await p.screenshot({path: SS+'v35_text_toc2.png'});

  // Click first section
  await p.click('[data-act="jt-sec"]');
  await p.waitForTimeout(500);
  await p.screenshot({path: SS+'v35_text_sec1.png'});

  // Scroll to see SVG
  await p.evaluate(()=>window.scrollBy(0,400));
  await p.waitForTimeout(300);
  await p.screenshot({path: SS+'v35_text_sec1b.png'});

  // Click next
  const nextBtn = await p.locator('text=次 →').first();
  if(await nextBtn.count()) {
    await nextBtn.click();
    await p.waitForTimeout(500);
    await p.screenshot({path: SS+'v35_text_sec2.png'});
    await p.evaluate(()=>window.scrollBy(0,400));
    await p.waitForTimeout(300);
    await p.screenshot({path: SS+'v35_text_sec2b.png'});
  }

  await b.close();
  srv.close();
  console.log('Done');
});
