// 事例Ⅳドリル（本番形式）の画面を撮り、正解を入れて答え合わせが全欄「正解」になるかを確かめる
// 使い方：node niji/t_d4.js <pwa のフォルダ> <id,id,…|all> [撮った画面の置き場所]
//   ・pwa のフォルダを自分で配信する（ポートは空いているものを使う）。本物の pwa ではなく、写しの pwa を渡すこと
//   ・撮るもの：<id>_q.png（解く前）、<id>_a.png（答え合わせのあと）、<id>_a_dark.png（同じ、ダーク）。幅 390px
//   ・出力：問題ごとに、全欄正解になったか・はみ出し・ページのエラー
const http = require('http'), fs = require('fs'), path = require('path');
const [, , PWA, IDS, OUTD] = process.argv;
if (!PWA || !IDS) { console.error('使い方：node niji/t_d4.js <pwa のフォルダ> <id,…|all> [置き場所]'); process.exit(2); }
const ROOT = path.resolve(PWA), OUT = path.resolve(OUTD || path.join(ROOT, '..', 'shots_d4'));
fs.mkdirSync(OUT, { recursive: true });
const D = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', 'j4_drill.json'), 'utf8'));
const NEW = D.problems.filter(p => p.fmt !== 'mc');
const want = IDS === 'all' ? NEW.map(p => p.id) : IDS.split(',').map(s => s.trim()).filter(Boolean);
const srv = http.createServer((q, r) => {
  const u = decodeURIComponent(q.url.split('?')[0]), f = path.join(ROOT, u === '/' ? 'index.html' : u);
  if (!f.startsWith(ROOT)) { r.writeHead(403); return r.end(); }
  try { const d = fs.readFileSync(f); const t = f.endsWith('.json') ? 'application/json' : f.endsWith('.js') ? 'text/javascript' : f.endsWith('.png') ? 'image/png' : 'text/html'; r.writeHead(200, { 'Content-Type': t + '; charset=utf-8' }); r.end(d); }
  catch (e) { r.writeHead(404); r.end('nf'); }
});
const fmt = v => String(v);
srv.listen(0, '127.0.0.1', async () => {
  const URL0 = 'http://127.0.0.1:' + srv.address().port + '/';
  const { chromium } = require('playwright');
  const b = await chromium.launch();
  const results = [];
  for (const id of want) {
    const p = D.problems.find(x => x.id === id);
    if (!p) { results.push({ id, err: 'j4_drill.json にない（DRAFT=1 でビルドしたか）' }); continue; }
    const list = D.problems.filter(x => x.cat === p.cat), idx = list.findIndex(x => x.id === id);
    const res = { id, title: p.title };
    for (const scheme of ['light', 'dark']) {
      const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, colorScheme: scheme, serviceWorkers: 'block' });
      await ctx.addInitScript(() => { try { localStorage.setItem('shindan1-stage', 's2'); } catch (e) {} });
      const pg = await ctx.newPage(), errs = [];
      pg.on('pageerror', e => errs.push(e.message));
      await pg.goto(URL0); await pg.waitForTimeout(800);
      await pg.click('[data-tab="j4drill"]'); await pg.waitForTimeout(400);
      await pg.click(`[data-act="j4-cat"][data-cat="${p.cat}"]`); await pg.waitForTimeout(200);
      await pg.click(`[data-act="j4-pick"][data-i="${idx}"]`); await pg.waitForTimeout(300);
      const shot = async (name) => {
        const h = await pg.evaluate(() => document.getElementById('main').scrollHeight + 200);
        await pg.setViewportSize({ width: 390, height: Math.min(h, 12000) }); await pg.waitForTimeout(150);
        await pg.screenshot({ path: path.join(OUT, name) });
        await pg.setViewportSize({ width: 390, height: 844 });
      };
      if (scheme === 'light') await shot(id + '_q.png');
      // 正解を入れる
      let nAuto = 0;
      for (const pt of p.parts) for (const f of pt.fields) {
        const sel = k => `[data-d4="${id}"][data-k="${k}"]`;
        if (f.type === 'num') { nAuto++; await pg.fill(sel(f.k), fmt(f.ans)); }
        else if (f.type === 'ind') { nAuto++; const nm = Object.keys(f.accept)[0]; await pg.selectOption(sel(f.k + '_n'), nm); await pg.fill(sel(f.k + '_v'), fmt(f.accept[nm].v)); }
        else if (f.type === 'choice') { nAuto++; await pg.selectOption(sel(f.k), f.ans); }
        else if (f.type === 'text') { await pg.fill(sel(f.k), f.model); }
        else if (f.type === 'proc') { await pg.fill(sel(f.k), (pt.steps || []).join('\n')); }
      }
      await pg.click('[data-act="d4-check"]'); await pg.waitForTimeout(300);
      const head = (await pg.locator('.res-h').first().textContent().catch(() => '')) || '';
      const over = await pg.evaluate(() => { const m = document.getElementById('main'); return Math.max(document.documentElement.scrollWidth, m.scrollWidth) > window.innerWidth + 1; });
      const ngs = await pg.locator('.d4-mk.ng').allTextContents();
      if (scheme === 'light') { res.check = head.trim(); res.allOk = head.includes(nAuto + ' / ' + nAuto) && !ngs.length; res.ng = ngs; await shot(id + '_a.png'); }
      else await shot(id + '_a_dark.png');
      res['overflow_' + scheme] = over;
      if (errs.length) res['errors_' + scheme] = errs.filter(e => !/ERR_FAILED|fonts/.test(e));
      await ctx.close();
    }
    results.push(res);
  }
  await b.close(); srv.close();
  console.log(JSON.stringify({ out: OUT, results }, null, 1));
});
