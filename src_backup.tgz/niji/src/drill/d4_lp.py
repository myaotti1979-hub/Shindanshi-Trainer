# 事例Ⅳドリル（本番形式）：線形計画法（cat='lp'。制約のもとでの最適な製品の組み合わせ）
# 手本：令和元〜6年度の事例Ⅳで、制約のもとでの製品の組み合わせを問うた設問（論点と問い方だけ。会社の設定と数値は新しく作った）。
#   協会の問題のPDF（令和元〜6年度の事例Ⅳ）と令和6年度の出題の趣旨で確かめた範囲で、この分野に当たるのは次の設問：
#     令和4年度 第2問 設問1：製品2つ、制約は直接作業時間の1つ（需要の上限なし。材料費と直接労務費〈賃率×時間〉が変動費、共通固定費は利益から差し引く）。
#                          利益が最大となる組み合わせと利益（計算過程も示す）。作業時間1時間当たりの限界利益の大きい製品だけを作る形。
#              設問2：設問1に材料（アルミニウム）の消費量の上限を加えた、制約2つの組み合わせ。2つの制約の交点で両方の製品を作る形。→ 01
#     令和6年度 第2問 設問1：取引先2社向けの製品、直接作業時間と機械運転時間の上限、両社の需要の上限のもとで、営業利益が最大となる生産量と営業利益
#                          （計算過程も示す。出題の趣旨は「線形計画法を用いて最適な生産数量を算出する能力」）。最適解は機械運転時間と一方の需要の上限の交点。
#              設問2：一方の取引先が最低数量を希望し、価格の引き上げに応じる。販売価格を決めた後に営業利益が最大となる生産量を決める方針のもとで、
#                    希望を満たすための販売価格の下限（計算過程も示す）。→ 02
#   令和元・2・3・5年度には、この分野に当たる設問はない（令和3年度第3問は1品目で最大の養殖量の範囲の目標利益、令和5年度第2問設問2は製品の販売中止の判断）。
#   03（制約の資源を増やす価値＝外部の能力を借りる判断）と 04（取引先との約束による需要の下限、全部原価で赤字に見える製品との取引をやめる判断）は、
#     令和元〜6年度に出ていないが、令和4・6年度の型（2つの制約の最適化）を、判断と記述を伴う形に広げた出うる型の備え。
#   重なりを避けるもの：制約1つで、特別注文のために減産する製品を時間当たりの限界利益で選ぶ形は d4-cost-02、セールスミックスの損益分岐点は d4-cvp-04、
#     製品の販売中止の判断（回避できる個別固定費）は seg。どの問題も「1時間当たりの限界利益の順」だけで終わらないようにした。
# 業種は、公開済みの mgmt・cvp・inv・cf・cost の問題、作成中の seg の問題、令和元〜6年度の事例Ⅳのどれとも重ならないものにした。
# 表の数値・答え・よくある誤りの値は、すべて下の Python の値から作る（表と答えが食い違わないように）。
# 最適解は、実行可能な端点をすべて調べて確かめる（lp_best）。最適解は整数の端点で一つに決まり、ほかの端点と同じ利益にならないことを assert で確かめる。
import sys, os
from fractions import Fraction as _F
from itertools import combinations as _comb
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', 'text'))
from vis import grid, T, L, _svg, _c, _esc

# ================================================================ 共通の道具


def up(x):
    """切り上げ（正の値）"""
    x = _F(x)
    assert x >= 0
    return -((-x.numerator) // x.denominator)


def dn(x):
    """切り捨て（正の値）"""
    x = _F(x)
    assert x >= 0
    return x.numerator // x.denominator


def _dec(x, k):
    """10^k 倍で整数になる値を、桁区切りつき・小数第 k 位までの文字列に。負は △"""
    n = _F(x) * 10 ** k
    assert n.denominator == 1, ('桁が足りない', x, k)
    n = int(n)
    ip, fp = divmod(abs(n), 10 ** k)
    return ('△' if n < 0 else '') + f'{ip:,}' + ('.' + str(fp).zfill(k) if k else '')


def dx(x):
    """割り切れる値を、必要な桁までそのまま書く（負は △）"""
    x = _F(x)
    k = 0
    while (x * 10 ** k).denominator != 1:
        k += 1
        assert k <= 8, ('割り切れない', x)
    return _dec(x, k)


def n_(v):
    """桁区切り（整数。負は △）"""
    return _dec(v, 0)


def d1(x):
    """小数第1位まで（2.0 のように、整数でも小数第1位を書く）"""
    return _dec(x, 1)


def d2(x):
    """小数第2位まで（0.30 のように書く）"""
    return _dec(x, 2)


def tr(x, k=1):
    """割り切れないかもしれない値（小数第 k 位まで書き、割り切れないときは「…」を付ける）"""
    x = _F(x)
    if (x * 10 ** k).denominator == 1:
        return dx(x)
    a = abs(x) * 10 ** k
    a = a.numerator // a.denominator
    ip, fp = divmod(a, 10 ** k)
    return ('△' if x < 0 else '') + f'{ip:,}.' + str(fp).zfill(k) + '…'


def iv(v):
    """整数であることを確かめて int にする（答えの欄に入れる値）"""
    v = _F(v)
    assert v.denominator == 1, ('整数でない', v)
    return int(v)


def _farT(x):
    """切り上げで答える値：端数が整数から0.1以上離れているか（途中の丸めで答えが動かない）"""
    x = _F(x)
    fr = x - (x.numerator // x.denominator)
    return _F(1, 10) <= fr <= _F(9, 10)


def _lim(s, n):
    assert len(s) <= n, ('字数を超える', len(s), n, s)
    return s


def _uniq(name, ans, wrong):
    """よくある誤りの値が、正解とも互いとも重ならないか（重なると原因を言い分けられない）"""
    vals = [ans] + list(wrong)
    assert len(vals) == len(set(vals)), ('よくある誤りの値が重なる', name, vals)


GAP = '<div style="height:12px"></div>'   # 解説の図を並べるときの間


def cap(s):
    """図の見出し（画面に出す。vis の title は読み上げ用で画面には出ない）"""
    return '<div style="font-size:12.5px;font-weight:700;color:var(--ink-2);margin:0 2px 6px;line-height:1.5">%s</div>' % s


# ---------------------------------------------------------------- 2変数の線形計画（端点の総当たり）
def lp_verts(cons):
    """cons：[(a, b, c, 向き)]（a×x＋b×y が c 以下 '<=' か以上 '>='）。x≧0・y≧0 は自動で足す。実行可能な端点の一覧"""
    allc = [tuple(_F(v) for v in k[:3]) + (k[3],) for k in cons] + [(_F(1), _F(0), _F(0), '>='), (_F(0), _F(1), _F(0), '>=')]
    pts = set()
    for (a1, b1, c1, _), (a2, b2, c2, _) in _comb(allc, 2):
        det = a1 * b2 - a2 * b1
        if det == 0:
            continue
        x = (c1 * b2 - c2 * b1) / det
        y = (a1 * c2 - a2 * c1) / det
        if all((a * x + b * y <= c) if s == '<=' else (a * x + b * y >= c) for a, b, c, s in allc):
            pts.add((x, y))
    return sorted(pts)


def lp_best(cons, cx, cy):
    """端点ごとの目的（限界利益の合計）を大きい順に。[(値, (x, y)), …]"""
    return sorted(((_F(cx) * x + _F(cy) * y, (x, y)) for x, y in lp_verts(cons)), reverse=True)


def lp_opt(cons, cx, cy, name):
    """最適な端点が一つに決まり（2番目と同じ値にならない）、整数であることを確かめて返す"""
    sc = lp_best(cons, cx, cy)
    assert len(sc) >= 2 and sc[0][0] > sc[1][0], ('最適解が一つに決まらない', name, sc[:3])
    x, y = sc[0][1]
    assert x.denominator == 1 and y.denominator == 1, ('最適解が整数でない', name, x, y)
    return int(x), int(y), sc


def feas(cons, x, y):
    """(x, y) がすべての制約を満たすか"""
    return x >= 0 and y >= 0 and all((_F(a) * x + _F(b) * y <= c) if s == '<=' else (_F(a) * x + _F(b) * y >= c) for a, b, c, s in cons)


def greedy(first, res, caps):
    """1つの製品を先に需要の上限（または資源の限り）まで作り、残りの資源でもう1つを作る（よくある誤りの計算に使う）。
    first：0 なら x が先、1 なら y が先。res：[(a, b, 上限)]。caps：(x の上限, y の上限)。整数で返す"""
    q = [0, 0]
    o = 1 - first
    q[first] = min([caps[first]] + [dn(_F(r[2]) / _F(r[first])) for r in res if r[first] > 0])
    q[o] = min([caps[o]] + [dn((_F(r[2]) - _F(r[first]) * q[first]) / _F(r[o])) for r in res if r[o] > 0])
    return tuple(q)


def seg_in_box(a, b, c, xm, ym):
    """直線 a×x＋b×y＝c のうち、0≦x≦xm・0≦y≦ym に入る部分の両端"""
    a, b, c = _F(a), _F(b), _F(c)
    pts = []
    if b:
        for x in (_F(0), _F(xm)):
            y = (c - a * x) / b
            if 0 <= y <= ym:
                pts.append((x, y))
    if a:
        for y in (_F(0), _F(ym)):
            x = (c - b * y) / a
            if 0 <= x <= xm:
                pts.append((x, y))
    pts = sorted(set(pts))
    assert len(pts) >= 2, ('線が図の範囲に入らない', a, b, c)
    return pts[0], pts[-1]


def TH(x, y, s, anc='start', col='main', size=10.5, bold=True, rot=None):
    """縁取りつきの文字（線の上に重なっても読める。縁の色は図の地の色）。rot＝(角度, 中心x, 中心y) で回す"""
    a = ' text-anchor="%s"' % anc if anc != 'start' else ''
    b = ' font-weight="bold"' if bold else ''
    t = ' transform="rotate(%s %s %s)"' % (round(rot[0], 2), round(rot[1], 1), round(rot[2], 1)) if rot else ''
    return ('<text x="%s" y="%s"%s%s%s font-size="%s" style="fill:%s;stroke:var(--sheet);stroke-width:3.4px;paint-order:stroke;stroke-linejoin:round">%s</text>'
            % (round(x, 1), round(y, 1), a, b, t, size, _c(col), _esc(s)))


def lpchart(xm, ym, xt, yt, xlab, ylab, polys=(), lines=(), dots=(), texts=(), rtexts=(), arrows=(), w=360, h=290, title='図'):
    """2変数の線形計画の図（横軸 x・縦軸 y の数量）。
    polys：[(端点のリスト, 色, 濃さ)] 実行可能領域。lines：[(a, b, c, 色, 点線か, 太さ)] 制約の直線 a×x＋b×y＝c。
    dots：[(x, y, 色, 半径, 白抜きか)]。texts：[(x, y, 文字, 揃え, 色, 大きさ, 右へ px, 下へ px)]。
    rtexts：[(a, b, c, x0, 文字, 色, 大きさ, 線からの距離 px（負は線の上）)] 直線に沿って傾けた文字（x0 の位置から右へ）。arrows：[(x1, y1, x2, y2, 色)]"""
    import math
    L0, R0, T0, B0 = 48, 14, 28, 40
    pw, ph = w - L0 - R0, h - T0 - B0
    X = lambda v: L0 + float(v) / xm * pw
    Y = lambda v: T0 + ph - float(v) / ym * ph
    o = []
    for pts, col, op in polys:
        o.append('<path d="M%s Z" style="fill:%s;fill-opacity:%s;stroke:none"/>' % (' L'.join('%.1f %.1f' % (X(a), Y(b)) for a, b in pts), _c(col), op))
    o.append(L(X(0), Y(0), X(xm) + 2, Y(0), col='main', sw=1.3))
    o.append(L(X(0), Y(0), X(0), T0 - 6, col='main', sw=1.3))
    o.append(T(X(0) - 5, Y(0) + 14, '0', 'end', size=10.5))
    for v, s in xt:
        o.append(L(X(v), Y(0), X(v), Y(0) + 3, col='main', sw=1))
        o.append(T(X(v), Y(0) + 15, s, 'middle', size=10.5))
    for v, s in yt:
        o.append(L(X(0) - 3, Y(v), X(0), Y(v), col='main', sw=1))
        o.append(T(X(0) - 6, Y(v) + 4, s, 'end', size=10.5))
    o.append(T(X(xm), Y(0) + 33, xlab, 'end', size=11))
    o.append(T(4, 14, ylab, 'start', size=11))
    for a, b, c, col, dash, sw in lines:
        (x1, y1), (x2, y2) = seg_in_box(a, b, c, xm, ym)
        o.append(L(X(x1), Y(y1), X(x2), Y(y2), col=col, sw=sw, dash=('5 4' if dash else None)))
    for x1, y1, x2, y2, col in arrows:
        X1, Y1, X2, Y2 = X(x1), Y(y1), X(x2), Y(y2)
        ang = math.atan2(Y2 - Y1, X2 - X1)
        hd = 7
        p1 = (X2 - hd * math.cos(ang - 0.45), Y2 - hd * math.sin(ang - 0.45))
        p2 = (X2 - hd * math.cos(ang + 0.45), Y2 - hd * math.sin(ang + 0.45))
        o.append('<path d="M%.1f %.1fL%.1f %.1f" style="stroke:%s" stroke-width="1.8" fill="none"/>' % (X1, Y1, X2, Y2, _c(col)))
        o.append('<path d="M%.1f %.1fL%.1f %.1fL%.1f %.1fZ" style="fill:%s;stroke:none"/>' % (X2, Y2, p1[0], p1[1], p2[0], p2[1], _c(col)))
    for x, y, col, r, hollow in dots:
        if hollow:
            o.append('<circle cx="%.1f" cy="%.1f" r="%s" style="fill:var(--sheet);stroke:%s" stroke-width="1.8"/>' % (X(x), Y(y), r, _c(col)))
        else:
            o.append('<circle cx="%.1f" cy="%.1f" r="%s" style="fill:%s"/>' % (X(x), Y(y), r, _c(col)))
    for x, y, s, anc, col, size, ddx, ddy in texts:
        o.append(TH(X(x) + ddx, Y(y) + ddy, s, anc, col, size))
    for a, b, c, x0, s, col, size, off in rtexts:
        a, b, c = _F(a), _F(b), _F(c)
        y0 = (c - a * _F(x0)) / b
        ang = math.degrees(math.atan2(float(a / b) * ph / ym, pw / xm))
        px, py = X(x0), Y(y0)
        o.append(TH(px, py + off, s, 'start', col, size, rot=(ang, px, py)))
    return _svg(w, h, o, title)


def lnchart(xm, ymin, ymax, xt, yt, xlab, ylab, series=(), dots=(), texts=(), vlines=(), w=360, h=230, title='図'):
    """折れ線の図（負の値も描ける）。series：[(点のリスト, 色, 点線か)]。dots：[(x, y, 色)]。texts：lpchart と同じ。vlines：[x]"""
    L0, R0, T0, B0 = 56, 14, 24, 40
    pw, ph = w - L0 - R0, h - T0 - B0
    X = lambda v: L0 + float(v) / xm * pw
    Y = lambda v: T0 + ph - (float(v) - ymin) / (ymax - ymin) * ph
    o = []
    o.append(L(X(0), Y(0), X(xm) + 2, Y(0), col='main', sw=1.3))
    o.append(L(X(0), Y(ymin), X(0), T0 - 6, col='main', sw=1.3))
    for v, s in xt:
        o.append(L(X(v), Y(0), X(v), Y(0) + 3, col='main', sw=1))
        o.append(T(X(v), Y(0) + 15, s, 'middle', size=10.5))
    for v, s in yt:
        o.append(L(X(0) - 3, Y(v), X(0), Y(v), col='main', sw=1))
        o.append(T(X(0) - 6, Y(v) + 4, s, 'end', size=10.5))
    o.append(T(X(xm), Y(0) + 33, xlab, 'end', size=11))
    o.append(T(4, 14, ylab, 'start', size=11))
    for x in vlines:
        o.append(L(X(x), T0 - 2, X(x), Y(ymin), dash='3 3', sw=0.8))
    for pts, col, dash in series:
        d = 'M' + ' L'.join('%.1f %.1f' % (X(a), Y(b)) for a, b in pts)
        o.append('<path d="%s" fill="none" style="stroke:%s" stroke-width="2.2"%s stroke-linejoin="round"/>' % (d, _c(col), ' stroke-dasharray="6 4"' if dash else ''))
    for x, y, col in dots:
        o.append('<circle cx="%.1f" cy="%.1f" r="3.6" style="fill:%s"/>' % (X(x), Y(y), _c(col)))
    for x, y, s, anc, col, size, ddx, ddy in texts:
        o.append(TH(X(x) + ddx, Y(y) + ddy, s, anc, col, size))
    return _svg(w, h, o, title)


KANA = 'アイウエオカキク'
P = []

# ================================================================ 01 無垢材の家具：作業時間の制約から、木材の制約が加わった組み合わせへ（円。月）
H1 = 1600                                     # 職人の作業時間の上限（10人×160時間）
WPR1 = 150000                                 # 木材の単価（1m³当たり）
FIX1 = 6000000                                # 固定費（職人の給与・工房の賃借料・減価償却費など）
PR1 = [dict(n='本棚', p=58000, w=_F(12, 100), o=10000, l=6, d=120),
       dict(n='テーブル', p=160000, w=_F(30, 100), o=25000, l=20, d=56)]
W1 = 27                                       # 設問2：仕入れられる木材の上限（m³）

for r in PR1:
    r['wc'] = r['w'] * WPR1                   # 木材費
    r['cm'] = r['p'] - r['wc'] - r['o']       # 1台当たりの限界利益
    r['cmh'] = _F(r['cm'], r['l'])            # 作業時間1時間当たり
    r['cmw'] = r['cm'] / r['w']               # 木材1m³当たり
A1, B1 = PR1
assert A1['cm'] == 30000 and B1['cm'] == 90000 and all(r['wc'].denominator == 1 for r in PR1)
assert A1['cm'] < B1['cm'] and A1['cmh'] > B1['cmh'] and A1['cmw'] < B1['cmw']   # 1台・時間・木材で順位が入れ替わる
CAP1 = [(1, 0, A1['d'], '<='), (0, 1, B1['d'], '<=')]
LAB1 = (A1['l'], B1['l'], H1, '<=')
WOOD1 = (A1['w'], B1['w'], W1, '<=')
# 設問1：作業時間だけ
x1a, y1a, sc1a = lp_opt([LAB1] + CAP1, A1['cm'], B1['cm'], '01 設問1')
assert (x1a, y1a) == (A1['d'], (H1 - A1['l'] * A1['d']) // B1['l']) and y1a < B1['d']
cm1a = A1['cm'] * x1a + B1['cm'] * y1a
op1a = cm1a - FIX1
wood1a = A1['w'] * x1a + B1['w'] * y1a       # 設問1の組み合わせの木材の使用量（27.6）
assert wood1a > W1
# 設問2：作業時間と木材
x1b, y1b, sc1b = lp_opt([LAB1, WOOD1] + CAP1, A1['cm'], B1['cm'], '01 設問2')
cm1b = A1['cm'] * x1b + B1['cm'] * y1b
op1b = cm1b - FIX1
assert A1['l'] * x1b + B1['l'] * y1b == H1 and A1['w'] * x1b + B1['w'] * y1b == W1 and x1b < A1['d'] and y1b < B1['d']   # 2つの制約の交点
V1 = [p for _, p in sc1b]                     # 設問2の端点
# よくある誤り（設問1）
g1_unit = greedy(1, [(A1['l'], B1['l'], H1)], (A1['d'], B1['d']))        # 1台当たりの限界利益の大きいテーブルを先に
assert g1_unit == (80, 56)
e1a_unit = A1['cm'] * g1_unit[0] + B1['cm'] * g1_unit[1] - FIX1
e1a_nocap_q = dn(_F(H1, A1['l']))                                         # 需要の上限を忘れ、本棚だけを作る
e1a_nocap = A1['cm'] * e1a_nocap_q - FIX1
e1a_nofix = cm1a
_uniq('01 op1', op1a, [e1a_unit, e1a_nocap, e1a_nofix])
# よくある誤り（設問2）
g1_lab = greedy(0, [(A1['l'], B1['l'], H1), (A1['w'], B1['w'], W1)], (A1['d'], B1['d']))    # 作業時間当たりの大きい本棚を先に
g1_wood = greedy(1, [(A1['l'], B1['l'], H1), (A1['w'], B1['w'], W1)], (A1['d'], B1['d']))   # 木材当たりの大きいテーブルを先に
assert g1_lab == (120, 42) and g1_wood == (80, 56)
assert feas([LAB1, WOOD1] + CAP1, *g1_lab) and feas([LAB1, WOOD1] + CAP1, *g1_wood) and not feas([LAB1, WOOD1] + CAP1, x1a, y1a)
e1b_lab = A1['cm'] * g1_lab[0] + B1['cm'] * g1_lab[1] - FIX1
e1b_wood = A1['cm'] * g1_wood[0] + B1['cm'] * g1_wood[1] - FIX1
e1b_old = op1a                                                            # 木材の制約を入れず、設問1のまま
e1b_nofix = cm1b
_uniq('01 op2', op1b, [e1b_lab, e1b_wood, e1b_old, e1b_nofix])
assert e1b_lab < e1b_wood < op1b
loss1 = op1b - e1b_lab                                                    # 社長の考え（本棚を優先）で失う営業利益

T1 = _lim('木材当たりでは限界利益の順位が逆で、本棚優先では木材が先に尽き作業時間が余る。営業利益は最適より%s円少ない。' % n_(loss1), 60)


def _x01():
    g = grid(['1台当たり', A1['n'], B1['n'], '大きい方'],
             [['限界利益', n_(A1['cm']) + '円', n_(B1['cm']) + '円', B1['n']],
              ['作業時間当たり', n_(A1['cmh']) + '円', n_(B1['cmh']) + '円', A1['n']],
              ['木材1m³当たり', n_(A1['cmw']) + '円', n_(B1['cmw']) + '円', B1['n']]],
             [108, 86, 86, 80], align=['l', 'r', 'r', 'c'], size=11.5, hl_rows=(1, 2),
             tcol={A1['n']: 'b', B1['n']: 'a'}, title='何当たりで比べるかで、順位が入れ替わる')
    xm, ym = 150, 100
    poly = [(0, 0), (A1['d'], 0), g1_lab, (x1b, y1b), g1_wood, (0, B1['d'])]
    lines = [(A1['l'], B1['l'], H1, 'a', False, 2.2), (A1['w'], B1['w'], W1, 'c', False, 2.2),
             (1, 0, A1['d'], 'sub', True, 1.2), (0, 1, B1['d'], 'sub', True, 1.2)]
    dots = [(g1_lab[0], g1_lab[1], 'main', 3.4, False), (g1_wood[0], g1_wood[1], 'main', 3.4, False),
            (x1b, y1b, 'b', 5, False), (x1a, y1a, 'a', 3.6, True)]
    texts = [(A1['d'], ym, '本棚の上限 %s' % n_(A1['d']), 'middle', 'sub', 10, 0, -8),
             (xm, B1['d'], 'テーブルの上限 %s' % n_(B1['d']), 'end', 'sub', 10, -2, -5),
             (x1b, y1b, 'イ 最適', 'end', 'b', 11.5, -9, 15),
             (g1_lab[0], g1_lab[1], 'ア', 'end', 'main', 11.5, -6, 15),
             (g1_wood[0], g1_wood[1], 'ウ', 'start', 'main', 11.5, 5, -9),
             (x1a, y1a, '設問1', 'start', 'a', 10.5, 7, -5),
             (12, 18, '設問2で作れる範囲', 'start', 'b', 11, 0, 0)]
    rtexts = [(A1['l'], B1['l'], H1, 5, '作業時間 %s時間' % n_(H1), 'a', 10.5, 14),
              (A1['w'], B1['w'], W1, 5, '木材 %sm³' % n_(W1), 'c', 10.5, -5)]
    c = lpchart(xm, ym, [(50, '50'), (100, '100'), (150, '150')], [(20, '20'), (40, '40'), (60, '60'), (80, '80'), (100, '100')],
                '本棚（台）', 'テーブル（台）', polys=[(poly, 'b', 0.14)], lines=lines, dots=dots, texts=texts, rtexts=rtexts,
                title='設問2の制約と作れる範囲')
    vrow = []
    why = {g1_lab: '本棚を優先（木材が先に尽きる）', (x1b, y1b): '作業時間と木材の交点', g1_wood: 'テーブルを優先（作業時間が尽きる）'}
    for i, p in enumerate([g1_lab, (x1b, y1b), g1_wood]):
        vrow.append(['ア' if i == 0 else 'イ' if i == 1 else 'ウ', n_(p[0]), n_(p[1]), n_(A1['cm'] * p[0] + B1['cm'] * p[1] - FIX1), why[p]])
    g2 = grid(['端点', '本棚', 'テーブル', '営業利益', 'どう決まるか'], vrow, [36, 42, 52, 84, 146], align=['c', 'r', 'r', 'r', 'l'],
              size=11, hl_rows=(1,), title='設問2の端点ごとの営業利益')
    return (cap('1台当たりの限界利益と、制約となる資源1単位当たりの限界利益') + g + GAP
            + cap('設問2の制約と作れる範囲（緑の部分。点線は需要の上限）。白抜きの点は設問1の最適（木材が%sm³必要で、%sm³を超える）'
                  % (dx(wood1a), n_(W1))) + c + GAP
            + cap('設問2の端点ごとの営業利益（単位：円。原点などほかの端点は利益が小さい）') + g2)


P.append(dict(
    id='d4-lp-01', cat='lp', lv=2, min=18,
    src='R4-第2問（設問1：制約1つ〈直接作業時間〉の組み合わせ、設問2：材料の消費量の上限を加えた制約2つの組み合わせ。利益と計算過程）',
    title='無垢材の家具：作業時間の制約に、木材の制約が加わった組み合わせ',
    lead='D社は、地方都市で無垢材の家具を作る工房で、職人が仕上げた本棚とダイニングテーブル（以下、テーブル）を、家具店と自社のウェブサイトで販売している。'
         '職人は正社員の10人で、作業時間は月%s時間（1人160時間）が上限である。職人の給与は固定費で、残業はしない。\n'
         '製品のデータは次の表のとおりである。需要の上限は、家具店からの受注と自社サイトでの販売の見込みを合わせた月間の販売可能な数量で、これを超えて作っても売れない。'
         '木材は乾燥済みの国産の広葉樹で、1m³当たり%s円で仕入れている。固定費（職人の給与、工房の賃借料、減価償却費など）は月%s円で、生産量によって変わらない。'
         % (n_(H1), n_(WPR1), n_(FIX1)),
    tables=[dict(cap='製品のデータ（1台当たり）', unit='', head=['項目', A1['n'], B1['n']],
                 rows=[['販売価格（円）', n_(A1['p']), n_(B1['p'])], ['木材の使用量（m³）', d2(A1['w']), d2(B1['w'])],
                       ['その他の変動費（円）', n_(A1['o']), n_(B1['o'])], ['職人の作業時間（時間）', n_(A1['l']), n_(B1['l'])],
                       ['月間の需要の上限（台）', n_(A1['d']), n_(B1['d'])]],
                 note='その他の変動費は、金具・塗料・梱包材・配送の費用である。作ったものは、需要の上限までならすべて販売できる。')],
    parts=[
        dict(h='設問1',
             q='木材は必要なだけ仕入れられるものとする。営業利益が最大となる本棚とテーブルの月間の生産・販売量と、そのときの営業利益（円）を求めよ。'
               '生産・販売量は整数とする。計算過程も示すこと。',
             fields=[dict(k='x1', type='num', label='本棚の生産・販売量', unit='台', dp=0, ans=x1a),
                     dict(k='y1', type='num', label='テーブルの生産・販売量', unit='台', dp=0, ans=y1a),
                     dict(k='op1', type='num', label='営業利益', unit='円', dp=0, ans=iv(op1a)),
                     dict(k='p1', type='proc', label='計算過程')],
             steps=['1台当たりの限界利益：本棚＝%s−木材%s×%s−%s＝%s円、テーブル＝%s−%s×%s−%s＝%s円'
                    % (n_(A1['p']), d2(A1['w']), n_(WPR1), n_(A1['o']), n_(A1['cm']), n_(B1['p']), d2(B1['w']), n_(WPR1), n_(B1['o']), n_(B1['cm'])),
                    '制約は作業時間だけなので、作業時間1時間当たりの限界利益で順位を決める：本棚%s÷%s＝%s円＞テーブル%s÷%s＝%s円 → 本棚を優先'
                    % (n_(A1['cm']), n_(A1['l']), n_(A1['cmh']), n_(B1['cm']), n_(B1['l']), n_(B1['cmh'])),
                    '本棚を需要の上限%s台まで作る（作業時間%s時間）。残り%s−%s＝%s時間でテーブルを%s÷%s＝%s台（需要の上限%s台以内）'
                    % (n_(A1['d']), n_(A1['l'] * A1['d']), n_(H1), n_(A1['l'] * A1['d']), n_(H1 - A1['l'] * A1['d']),
                       n_(H1 - A1['l'] * A1['d']), n_(B1['l']), n_(y1a), n_(B1['d'])),
                    '営業利益＝%s×%s＋%s×%s−固定費%s＝%s＋%s−%s＝%s円'
                    % (n_(A1['cm']), n_(x1a), n_(B1['cm']), n_(y1a), n_(FIX1), n_(A1['cm'] * x1a), n_(B1['cm'] * y1a), n_(FIX1), n_(op1a))]),
        dict(h='設問2',
             q='今期は、木材の産地で伐採が減ったため、D社が仕入れられる木材は月%sm³に限られることになった。そのほかの条件は設問1と同じとする。'
               '営業利益が最大となる本棚とテーブルの月間の生産・販売量と、そのときの営業利益（円）を求めよ。生産・販売量は整数とする。計算過程も示すこと。' % n_(W1),
             fields=[dict(k='x2', type='num', label='本棚の生産・販売量', unit='台', dp=0, ans=x1b),
                     dict(k='y2', type='num', label='テーブルの生産・販売量', unit='台', dp=0, ans=y1b),
                     dict(k='op2', type='num', label='営業利益', unit='円', dp=0, ans=iv(op1b)),
                     dict(k='p2', type='proc', label='計算過程')],
             steps=['設問1の組み合わせ（本棚%s台・テーブル%s台）では、木材が%s×%s＋%s×%s＝%sm³必要で、%sm³を超えるので作れない'
                    % (n_(x1a), n_(y1a), d2(A1['w']), n_(x1a), d2(B1['w']), n_(y1a), dx(wood1a), n_(W1)),
                    '本棚をx台、テーブルをy台とする。制約：作業時間 %sx＋%sy≦%s、木材 %sx＋%sy≦%s、x≦%s、y≦%s'
                    % (n_(A1['l']), n_(B1['l']), n_(H1), d2(A1['w']), d2(B1['w']), n_(W1), n_(A1['d']), n_(B1['d'])),
                    '作業時間と木材の交点：木材の式を%s倍すると%sx＋%sy＝%s。作業時間の式から引くと%sy＝%s → y＝%s、x＝（%s−%s×%s）÷%s＝%s（需要の上限以内）'
                    % (n_(A1['l'] / A1['w']), n_(A1['l']), n_(B1['w'] * A1['l'] / A1['w']), n_(W1 * A1['l'] / A1['w']),
                       n_(B1['l'] - B1['w'] * A1['l'] / A1['w']), n_(H1 - W1 * A1['l'] / A1['w']), n_(y1b), n_(H1), n_(B1['l']), n_(y1b), n_(A1['l']), n_(x1b)),
                    'ほかの端点：木材と本棚の上限の交点（x＝%s、y＝（%s−%s×%s）÷%s＝%s）、作業時間とテーブルの上限の交点（y＝%s、x＝（%s−%s×%s）÷%s＝%s）'
                    % (n_(A1['d']), n_(W1), d2(A1['w']), n_(A1['d']), d2(B1['w']), n_(g1_lab[1]), n_(B1['d']), n_(H1), n_(B1['l']), n_(B1['d']), n_(A1['l']), n_(g1_wood[0])),
                    '限界利益の合計：（%s, %s）%s円、（%s, %s）%s円、（%s, %s）%s円 → 交点（%s台, %s台）が最大'
                    % (n_(x1b), n_(y1b), n_(cm1b), n_(g1_lab[0]), n_(g1_lab[1]), n_(A1['cm'] * g1_lab[0] + B1['cm'] * g1_lab[1]),
                       n_(g1_wood[0]), n_(g1_wood[1]), n_(A1['cm'] * g1_wood[0] + B1['cm'] * g1_wood[1]), n_(x1b), n_(y1b)),
                    '営業利益＝%s−%s＝%s円' % (n_(cm1b), n_(FIX1), n_(op1b))]),
        dict(h='設問3',
             q='社長は、「木材が足りない今期も、作業時間1時間当たりの限界利益が大きい本棚を優先して作り、残りでテーブルを作ればよい」と考えている。'
               '設問1・2の結果を踏まえ、この考えの問題点を60字以内で述べよ。',
             fields=[dict(k='t3', type='text', label='解答', limit=60, model=T1,
                          points=['木材1m³当たりでは限界利益の順位が逆になり、作業時間当たりの順では決まらない（端点を比べる）',
                                  '本棚を優先すると木材が先に尽き、作業時間が余る（本棚%s台・テーブル%s台）' % (n_(g1_lab[0]), n_(g1_lab[1])),
                                  '営業利益が最適（本棚%s台・テーブル%s台）より%s円少ない' % (n_(x1b), n_(y1b), n_(loss1))])]),
    ],
    ce={'x1': 'よくある誤り：%s台は、1台当たりの限界利益が大きいテーブルを先に需要の上限まで作った場合（営業利益%s円）。制約が1つのときは、制約の資源（作業時間）1時間当たりの限界利益で順位を決める。'
              '%s台は、需要の上限を忘れて本棚だけを作った場合で、本棚は%s台しか売れない。' % (n_(g1_unit[0]), n_(e1a_unit), n_(e1a_nocap_q), n_(A1['d'])),
        'y1': 'よくある誤り：%s台は、テーブルを先に需要の上限まで作った場合。テーブルは1台当たりの限界利益は大きいが、作業時間1時間当たりでは本棚より小さい。' % n_(g1_unit[1]),
        'op1': 'よくある誤り：%s円は、テーブルを先に作った場合。%s円は、需要の上限を忘れて本棚を%s台作った場合。%s円は、固定費を差し引いていない（限界利益の合計）。'
               % (n_(e1a_unit), n_(e1a_nocap), n_(e1a_nocap_q), n_(e1a_nofix)),
        'x2': 'よくある誤り：%s台は、設問1と同じく作業時間当たりの限界利益が大きい本棚を優先した場合（テーブル%s台。木材が先に尽き、作業時間が%s時間余る）。'
              '%s台は、木材1m³当たりの限界利益が大きいテーブルを優先した場合（テーブル%s台）。制約が2つのときは、どちらの順でも決まらないので端点を比べる。'
              % (n_(g1_lab[0]), n_(g1_lab[1]), n_(H1 - A1['l'] * g1_lab[0] - B1['l'] * g1_lab[1]), n_(g1_wood[0]), n_(g1_wood[1])),
        'y2': 'よくある誤り：%s台は本棚を優先した場合、%s台はテーブルを優先した場合、%s台は設問1のまま（木材が%sm³必要で作れない）。'
              % (n_(g1_lab[1]), n_(g1_wood[1]), n_(y1a), dx(wood1a)),
        'op2': 'よくある誤り：%s円は本棚を優先した場合、%s円はテーブルを優先した場合で、どちらも最適より小さい。%s円は木材の制約を入れていない（設問1のまま）。'
               '%s円は、固定費を差し引いていない。' % (n_(e1b_lab), n_(e1b_wood), n_(e1b_old), n_(e1b_nofix))},
    e='【考え方】資源の制約が1つなら、その資源1単位当たりの限界利益が大きい製品から、需要の上限まで作る（1台当たりの限界利益の順ではない）。'
      '制約が2つになると、資源ごとの順位が食い違うことがあり、どちらの順でも決まらない。その場合は、制約の直線が作る範囲の角（端点）の限界利益を比べる（線形計画法）。'
      '固定費は組み合わせによって変わらないので、組み合わせは限界利益で決め、最後に固定費を差し引いて営業利益を出す。\n'
      + '【設問1】作業時間1時間当たりの限界利益は本棚%s円・テーブル%s円で、本棚を上限の%s台まで作り、残りの%s時間でテーブル%s台。営業利益は%s円。'
        '1台当たりの限界利益の大きいテーブルを先に作ると、営業利益は%s円に下がる。\n'
      % (n_(A1['cmh']), n_(B1['cmh']), n_(A1['d']), n_(H1 - A1['l'] * A1['d']), n_(y1a), n_(op1a), n_(e1a_unit))
      + '【設問2】木材1m³当たりの限界利益はテーブル（%s円）が本棚（%s円）より大きく、作業時間当たりとは順位が逆になる。'
        '本棚を優先すると（ア）木材が先に尽きて作業時間が%s時間余り、テーブルを優先すると（ウ）作業時間が先に尽きる。'
        '作業時間と木材の両方を使い切る交点（イ：本棚%s台・テーブル%s台）が最大で、営業利益は%s円。\n'
      % (n_(B1['cmw']), n_(A1['cmw']), n_(H1 - A1['l'] * g1_lab[0] - B1['l'] * g1_lab[1]), n_(x1b), n_(y1b), n_(op1b))
      + '【設問3】社長の考え（本棚を優先）はアの組み合わせで、営業利益は%s円と、最適より%s円少ない。制約が2つのときは、1つの資源当たりの順で決めず、端点を比べることを、計算結果を添えて書く。\n'
      % (n_(e1b_lab), n_(loss1))
      + '【本試験での注意】令和4年度第2問は、設問1で直接作業時間だけの制約（作業時間当たりの限界利益の大きい製品だけを作る）、設問2で材料の消費量の上限を加えた2つの制約の組み合わせを、'
        '利益と計算過程とともに問うた（共通固定費は利益から差し引く）。計算過程では、制約の式、端点の数量、端点ごとの利益を順に示す。'
        '2本の制約の式の交点は、一方の式を何倍かして引くと速く求まる。最適な数量が端点で整数になるかも確かめる。\n'
      + '【図】上は、1台・作業時間・木材のどれ当たりで比べるかで順位が入れ替わること。中は、設問2の制約の直線と作れる範囲（緑）で、角のア・イ・ウのうちイが最適。'
        '白抜きの点（設問1の最適）は、木材の線の外にあり作れない。下は、端点ごとの営業利益。',
    x=_x01(),
))


# ================================================================ 02 電子機器の受託製造：2つの資源と需要の上限、取引先の最低数量の希望を満たす価格（円。月）
RATE2 = 1500                                  # パートタイマーの賃金（作業時間1時間当たり。変動費）
PR2 = [dict(n='X社向け', g='基板ユニット', p=8000, m=5100, l=_F(4, 10), k=_F(8, 10), d=3500),
       dict(n='Y社向け', g='制御ボックス', p=16000, m=9400, l=_F(2), k=_F(15, 10), d=1500)]
HL2, HK2 = 3200, 3400                         # 作業時間、実装ラインの稼働時間の上限（月）
FIX2 = 7000000
REQ2 = 1000                                   # 設問2：Y社の要望（月の最低数量）

for r in PR2:
    r['wg'] = r['l'] * RATE2                  # 賃金（1台当たり）
    r['cm'] = r['p'] - r['m'] - r['wg']
    r['cml'] = r['cm'] / r['l']               # 作業時間1時間当たり
    r['cmk'] = r['cm'] / r['k']               # 実装ライン1時間当たり
A2, B2 = PR2
assert A2['cm'] == 2300 and B2['cm'] == 3600
assert A2['cm'] < B2['cm'] and A2['cml'] > B2['cml'] and A2['cmk'] > B2['cmk']   # 1台当たりはY、資源当たりはどちらもX
LAB2 = (A2['l'], B2['l'], HL2, '<=')
LIN2 = (A2['k'], B2['k'], HK2, '<=')
CAP2 = [(1, 0, A2['d'], '<='), (0, 1, B2['d'], '<=')]
C2 = [LAB2, LIN2] + CAP2
x2a, y2a, sc2a = lp_opt(C2, A2['cm'], B2['cm'], '02 設問1')
cm2a = A2['cm'] * x2a + B2['cm'] * y2a
op2a = cm2a - FIX2
assert x2a == A2['d'] and A2['k'] * x2a + B2['k'] * y2a == HK2 and A2['l'] * x2a + B2['l'] * y2a < HL2   # 実装ラインとX社の上限の交点（作業時間は余る）
# 2つの資源の交点
det2 = A2['l'] * B2['k'] - A2['k'] * B2['l']
xv2 = (HL2 * B2['k'] - HK2 * B2['l']) / det2
yv2 = (A2['l'] * HK2 - A2['k'] * HL2) / det2
assert (xv2, yv2) == (2000, 1200) and y2a < REQ2 <= yv2 < B2['d']
xv2, yv2 = int(xv2), int(yv2)
# 設問2：実装ラインの線上で、Y社向けの限界利益÷実装ライン時間がX社向けを上回ると交点に移る
cmY2x = A2['cm'] * B2['k'] / A2['k']          # Y社向けの限界利益の境目（4,312.5）
pr2x = B2['m'] + B2['wg'] + cmY2x             # 価格の境目（正確な値）
pr2 = up(pr2x)
assert _farT(pr2x) and pr2 > B2['p']
x2b, y2b, sc2b = lp_opt(C2, A2['cm'], pr2 - B2['m'] - B2['wg'], '02 設問2')
assert (x2b, y2b) == (xv2, yv2) and y2b >= REQ2
x2c, y2c, _ = lp_opt(C2, A2['cm'], pr2 - 1 - B2['m'] - B2['wg'], '02 設問2 1円下')
assert (x2c, y2c) == (x2a, y2a)               # 1円低いと、Y社向けは要望に届かない
op2b = A2['cm'] * x2b + (pr2 - B2['m'] - B2['wg']) * y2b - FIX2
op2b_old = A2['cm'] * x2a + (pr2 - B2['m'] - B2['wg']) * y2a - FIX2     # 同じ価格で、設問1の組み合わせのままの場合
cmY2n = A2['cm'] * B2['l'] / A2['l']          # 次の境目（作業時間の線。ここを超えると Y社向けの上限の端点へ）
pr2n = B2['m'] + B2['wg'] + cmY2n
assert pr2n > pr2 + 1000
# よくある誤り（設問1）
g2_unit = greedy(1, [(A2['l'], B2['l'], HL2), (A2['k'], B2['k'], HK2)], (A2['d'], B2['d']))   # 1台当たりの大きいY社向けを先に
assert g2_unit == (500, 1500)
e2a_unit = A2['cm'] * g2_unit[0] + B2['cm'] * g2_unit[1] - FIX2
e2a_cross = A2['cm'] * xv2 + B2['cm'] * yv2 - FIX2                                           # 2つの資源の交点を最適とした
g2_nolin = greedy(0, [(A2['l'], B2['l'], HL2)], (A2['d'], B2['d']))                           # 実装ラインの制約を忘れた
assert not feas(C2, *g2_nolin)
e2a_nolin = A2['cm'] * g2_nolin[0] + B2['cm'] * g2_nolin[1] - FIX2
x2n, y2n, _ = lp_opt([LAB2, LIN2], A2['cm'], B2['cm'], '02 需要の上限なし')                    # 需要の上限を忘れた
e2a_nocap = A2['cm'] * x2n + B2['cm'] * y2n - FIX2
e2a_nofix = cm2a
_uniq('02 op1', op2a, [e2a_unit, e2a_cross, e2a_nolin, e2a_nocap, e2a_nofix])
_uniq('02 x1', x2a, [g2_unit[0], xv2, x2n])
_uniq('02 y1', y2a, [g2_unit[1], yv2, g2_nolin[1]])
# よくある誤り（設問2）
xf2 = (HK2 - B2['k'] * REQ2) / A2['k']                                   # 要望を条件として入れた場合の端点（実装ラインと Y＝1,000）
assert xf2.denominator == 1 and feas(C2, xf2, REQ2)
xf2 = int(xf2)
lossf2 = cm2a - (A2['cm'] * xf2 + B2['cm'] * REQ2)                       # 要望を条件にしたときに減る限界利益
e2p_comp = up(B2['p'] + _F(lossf2, REQ2))                                # 減る分を1,000台で割った値上げ幅（方針と違う考え方）
e2p_lab = up(B2['m'] + B2['wg'] + cmY2n)                                 # 作業時間の線の傾きで比べた
e2p_down = pr2 - 1                                                       # 切り捨て
e2p_nowg = up(B2['m'] + (A2['cm'] + A2['wg']) * B2['k'] / A2['k'])      # 賃金を変動費に入れない
_uniq('02 price', pr2, [e2p_comp, e2p_lab, e2p_down, e2p_nowg])
assert x2a == x2a and lp_opt(C2, A2['cm'], e2p_comp - B2['m'] - B2['wg'], '02 補償の価格')[:2] == (x2a, y2a)   # 補償の価格では要望を満たさない
_uniq('02 x2', x2b, [x2a, xf2, g2_unit[0]])
_uniq('02 y2', y2b, [y2a, REQ2, g2_unit[1]])


def _x02():
    newcm = pr2 - B2['m'] - B2['wg']
    g = grid(['1台当たり', A2['n'], B2['n'], '大きい方'],
             [['限界利益', n_(A2['cm']) + '円', n_(B2['cm']) + '円', B2['n']],
              ['作業時間当たり', n_(A2['cml']) + '円', n_(B2['cml']) + '円', A2['n']],
              ['実装ライン当たり', n_(A2['cmk']) + '円', n_(B2['cmk']) + '円', A2['n']],
              ['実装ライン当たり（%s円）' % n_(pr2), n_(A2['cmk']) + '円', tr(newcm / B2['k']) + '円', B2['n']]],
             [118, 82, 84, 76], align=['l', 'r', 'r', 'c'], size=11.5, hl_rows=(2, 3),
             tcol={A2['n']: 'b', B2['n']: 'a'}, title='資源1時間当たりの限界利益')
    xm, ym = 4000, 1700
    poly = [(0, 0), (A2['d'], 0), (x2a, y2a), (xv2, yv2), g2_unit, (0, B2['d'])]
    lines = [(A2['l'], B2['l'], HL2, 'a', False, 2.2), (A2['k'], B2['k'], HK2, 'c', False, 2.2),
             (1, 0, A2['d'], 'sub', True, 1.2), (0, 1, B2['d'], 'sub', True, 1.2), (0, 1, REQ2, 'b', True, 1.4)]
    dots = [(x2a, y2a, 'b', 5, False), (xv2, yv2, 'a', 5, False), (g2_unit[0], g2_unit[1], 'main', 3.4, False)]
    texts = [(A2['d'], ym, 'X社の上限 %s' % n_(A2['d']), 'middle', 'sub', 10, -8, -8),
             (xm, B2['d'], 'Y社の上限 %s' % n_(B2['d']), 'end', 'sub', 10, -2, -5),
             (0, REQ2, 'Y社の要望 %s' % n_(REQ2), 'start', 'b', 10, 6, -5),
             (x2a, y2a, 'ア 設問1', 'end', 'b', 11.5, -8, 16),
             (xv2, yv2, 'イ 設問2', 'end', 'a', 11.5, -8, 16),
             (g2_unit[0], g2_unit[1], 'ウ', 'start', 'main', 11.5, 4, 17),
             (300, 300, '作れる範囲', 'start', 'b', 11, 0, 0)]
    rtexts = [(A2['l'], B2['l'], HL2, 2250, '作業時間 %s時間' % n_(HL2), 'a', 10.5, -6),
              (A2['k'], B2['k'], HK2, 1120, '実装ライン %s' % n_(HK2), 'c', 10.5, -6)]
    c = lpchart(xm, ym, [(1000, '1,000'), (2000, '2,000'), (3000, '3,000'), (4000, '4,000')],
                [(500, '500'), (1000, '1,000'), (1500, '1,500')], 'X社向け（台）', 'Y社向け（台）',
                polys=[(poly, 'b', 0.14)], lines=lines, dots=dots, texts=texts, rtexts=rtexts, title='制約と作れる範囲')
    rows = []
    for nm, p in (('ア', (x2a, y2a)), ('イ', (xv2, yv2)), ('ウ', g2_unit)):
        rows.append([nm, n_(p[0]), n_(p[1]), n_(A2['cm'] * p[0] + B2['cm'] * p[1] - FIX2), n_(A2['cm'] * p[0] + newcm * p[1] - FIX2)])
    g2 = grid(['端点', A2['n'], B2['n'], '今の価格', '%s円' % n_(pr2)], rows, [36, 66, 62, 98, 98], align=['c', 'r', 'r', 'r', 'r'],
              size=11, hl_rows=(), title='端点ごとの営業利益')
    return (cap('1台当たりと、資源1時間当たりの限界利益（設問1の価格では、どちらの資源でもX社向けが大きい）') + g + GAP
            + cap('制約と作れる範囲（緑の部分。灰色の点線は需要の上限、緑の点線はY社の要望。実装ラインの上限は%s時間）。アは実装ラインとX社の上限の交点、イは2つの資源の交点'
                  % n_(HK2)) + c + GAP
            + cap('端点ごとの営業利益（単位：円。右の2列は、Y社向けの価格が今の%s円の場合と%s円の場合）' % (n_(B2['p']), n_(pr2))) + g2)


P.append(dict(
    id='d4-lp-02', cat='lp', lv=3, min=20,
    src='R6-第2問（直接作業時間と機械運転時間の上限と需要の上限のもとで営業利益が最大となる生産量〈設問1〉、取引先の最低数量の希望を満たす販売価格の下限〈設問2〉。どちらも計算過程）',
    title='電子機器の受託製造：2つの資源と需要の上限、要望を満たす価格',
    lead='D社は、地方都市にある電子機器の受託製造の会社で、表面実装ライン（以下、実装ライン）で電子部品を基板に取り付け、パートタイマーが組立と検査を行っている。'
         '主な取引先は2社で、X社（計測器メーカー）向けには%s、Y社（産業機械メーカー）向けには、基板を組み込んで配線と検査まで済ませた%sを製造している。\n'
         % (A2['g'], B2['g'])
         + 'パートタイマーの作業時間は月%s時間、実装ラインの稼働時間は月%s時間が上限である。パートタイマーの賃金は作業時間1時間当たり%s円で、作業した時間に応じて支払う（変動費）。'
           '固定費は月%s円で、生産量によって変わらない。\n' % (n_(HL2), n_(HK2), n_(RATE2), n_(FIX2))
         + 'X社・Y社とも、表の月間の需要の上限の範囲で、D社が提示した数量をそのまま発注することで合意している。製品のデータは次の表のとおりである。',
    tables=[dict(cap='製品のデータ（1台当たり）', unit='', head=['項目', A2['n'], B2['n']],
                 rows=[['販売価格（円）', n_(A2['p']), n_(B2['p'])], ['部品・材料費（円）', n_(A2['m']), n_(B2['m'])],
                       ['パートタイマーの作業時間（時間）', d1(A2['l']), d1(B2['l'])], ['実装ラインの稼働時間（時間）', d1(A2['k']), d1(B2['k'])],
                       ['月間の需要の上限（台）', n_(A2['d']), n_(B2['d'])]],
                 note='%sは%s、%sは%sである。部品・材料費とパートタイマーの賃金のほかに、生産量に応じて発生する費用はない。'
                      % (A2['n'], A2['g'], B2['n'], B2['g']))],
    parts=[
        dict(h='設問1',
             q='営業利益が最大となるX社向けとY社向けの月間の生産・販売量と、そのときの営業利益（円）を求めよ。生産・販売量は整数とする。計算過程も示すこと。',
             fields=[dict(k='x1', type='num', label='X社向けの生産・販売量', unit='台', dp=0, ans=x2a),
                     dict(k='y1', type='num', label='Y社向けの生産・販売量', unit='台', dp=0, ans=y2a),
                     dict(k='op1', type='num', label='営業利益', unit='円', dp=0, ans=iv(op2a)),
                     dict(k='p1', type='proc', label='計算過程')],
             steps=['1台当たりの限界利益：X社向け＝%s−%s−賃金%s×%s＝%s円、Y社向け＝%s−%s−%s×%s＝%s円'
                    % (n_(A2['p']), n_(A2['m']), d1(A2['l']), n_(RATE2), n_(A2['cm']), n_(B2['p']), n_(B2['m']), d1(B2['l']), n_(RATE2), n_(B2['cm'])),
                    '資源1時間当たりの限界利益：作業時間 X社向け%s円・Y社向け%s円、実装ライン X社向け%s円・Y社向け%s円 → どちらの資源でもX社向けが大きい'
                    % (n_(A2['cml']), n_(B2['cml']), n_(A2['cmk']), n_(B2['cmk'])),
                    'X社向けをx台、Y社向けをy台とする。制約：作業時間 %sx＋%sy≦%s、実装ライン %sx＋%sy≦%s、x≦%s、y≦%s'
                    % (d1(A2['l']), d1(B2['l']), n_(HL2), d1(A2['k']), d1(B2['k']), n_(HK2), n_(A2['d']), n_(B2['d'])),
                    'X社向けを需要の上限%s台まで作ると、作業時間%s時間・実装ライン%s時間。残りでY社向けは、作業時間（%s−%s）÷%s＝%s台、実装ライン（%s−%s）÷%s＝%s台 → %s台（実装ラインが先に尽きる）'
                    % (n_(A2['d']), n_(A2['l'] * A2['d']), n_(A2['k'] * A2['d']), n_(HL2), n_(A2['l'] * A2['d']), d1(B2['l']), n_((HL2 - A2['l'] * A2['d']) / B2['l']),
                       n_(HK2), n_(A2['k'] * A2['d']), d1(B2['k']), n_((HK2 - A2['k'] * A2['d']) / B2['k']), n_(y2a)),
                    '端点の確認（限界利益の合計）：（%s, %s）%s円、2つの資源の交点（%s, %s）%s円、作業時間とY社の上限の交点（%s, %s）%s円 → （%s, %s）が最大'
                    % (n_(x2a), n_(y2a), n_(cm2a), n_(xv2), n_(yv2), n_(A2['cm'] * xv2 + B2['cm'] * yv2), n_(g2_unit[0]), n_(g2_unit[1]),
                       n_(A2['cm'] * g2_unit[0] + B2['cm'] * g2_unit[1]), n_(x2a), n_(y2a)),
                    '営業利益＝%s×%s＋%s×%s−%s＝%s＋%s−%s＝%s円'
                    % (n_(A2['cm']), n_(x2a), n_(B2['cm']), n_(y2a), n_(FIX2), n_(A2['cm'] * x2a), n_(B2['cm'] * y2a), n_(FIX2), n_(op2a))]),
        dict(h='設問2',
             q='Y社から、来月以降は%sを毎月%s台以上納めてほしいとの要望があった。Y社は、その代わりに%sの販売価格の引き上げに応じるとしている。'
               'D社は、まず販売価格を決め、そのうえで設問1と同じ条件（需要の上限を含む）のもとで営業利益が最大となる生産・販売量を選ぶ方針であり、'
               'この方針で選ばれる生産・販売量がY社の要望を満たすようにしたい。X社向けの価格など、そのほかの条件は設問1と同じとする。\n'
               % (B2['g'], n_(REQ2), B2['g'])
               + '(1) %sの販売価格を1台何円以上にする必要があるか。計算の途中では端数を処理せず、円未満の端数は切り上げること。計算過程も示すこと。\n' % B2['g']
               + '(2) (1)で求めた価格のときに、営業利益が最大となるX社向けとY社向けの月間の生産・販売量を求めよ。',
             fields=[dict(k='pr', type='num', label='(1) %sの販売価格' % B2['g'], unit='円', dp=0, ans=pr2),
                     dict(k='p2', type='proc', label='(1) 計算過程'),
                     dict(k='x2', type='num', label='(2) X社向けの生産・販売量', unit='台', dp=0, ans=x2b),
                     dict(k='y2', type='num', label='(2) Y社向けの生産・販売量', unit='台', dp=0, ans=y2b)],
             steps=['設問1の組み合わせ（Y社向け%s台）は要望の%s台に届かない。Y社向けを増やすには、実装ラインの線の上で、X社向けを減らしてY社向けを増やすことになる'
                    % (n_(y2a), n_(REQ2)),
                    '実装ラインの線の上を進むと、作業時間の線との交点（X社向け%s台・Y社向け%s台。要望を満たす）に着く。交点は、%sx＋%sy＝%s と %sx＋%sy＝%s を解いて求める'
                    % (n_(xv2), n_(yv2), d1(A2['l']), d1(B2['l']), n_(HL2), d1(A2['k']), d1(B2['k']), n_(HK2)),
                    'そちらへ移るのが有利になるのは、実装ライン1時間当たりの限界利益で、Y社向けがX社向け（%s÷%s＝%s円）を上回るとき：Y社向けの限界利益÷%s＞%s → Y社向けの限界利益＞%s円'
                    % (n_(A2['cm']), d1(A2['k']), n_(A2['cmk']), d1(B2['k']), n_(A2['cmk']), dx(cmY2x)),
                    '(1) 販売価格＞部品・材料費%s＋賃金%s＋%s＝%s円 → %s円以上（切り上げ）'
                    % (n_(B2['m']), n_(B2['wg']), dx(cmY2x), dx(pr2x), n_(pr2)),
                    '検算：%s円（限界利益%s円）なら、交点（%s, %s）の限界利益の合計%s円＞（%s, %s）の%s円。%s円では%s円＜%s円で、設問1の組み合わせのまま'
                    % (n_(pr2), n_(pr2 - B2['m'] - B2['wg']), n_(xv2), n_(yv2), n_(op2b + FIX2), n_(x2a), n_(y2a), n_(op2b_old + FIX2),
                       n_(pr2 - 1), n_(A2['cm'] * xv2 + (pr2 - 1 - B2['m'] - B2['wg']) * yv2), n_(A2['cm'] * x2a + (pr2 - 1 - B2['m'] - B2['wg']) * y2a)),
                    '(2) X社向け%s台、Y社向け%s台（営業利益は%s円）。この組み合わせは、価格が%s円を超えるまで最適のまま'
                    % (n_(x2b), n_(y2b), n_(op2b), dx(pr2n))]),
    ],
    ce={'x1': 'よくある誤り：%s台は、1台当たりの限界利益が大きいY社向けを先に上限まで作った場合（営業利益%s円）。%s台は、2つの資源の交点を最適とした場合（営業利益%s円）。'
              '%s台は、需要の上限を忘れた場合（X社は%s台までしか発注しない）。' % (n_(g2_unit[0]), n_(e2a_unit), n_(xv2), n_(e2a_cross), n_(x2n), n_(A2['d'])),
        'y1': 'よくある誤り：%s台はY社向けを先に作った場合、%s台は2つの資源の交点とした場合、%s台は実装ラインの制約を忘れ、作業時間だけで残りを計算した場合（実装ラインが%s時間必要になり、上限を超える）。'
              % (n_(g2_unit[1]), n_(yv2), n_(g2_nolin[1]), n_(A2['k'] * g2_nolin[0] + B2['k'] * g2_nolin[1])),
        'op1': 'よくある誤り：%s円はY社向けを先に作った場合、%s円は2つの資源の交点とした場合、%s円は実装ラインの制約を忘れた場合、%s円は需要の上限を忘れた場合、%s円は固定費を差し引いていない。'
               % (n_(e2a_unit), n_(e2a_cross), n_(e2a_nolin), n_(e2a_nocap), n_(e2a_nofix)),
        'pr': 'よくある誤り：%s円は、要望を条件として入れた場合（X社向け%s台・Y社向け%s台）に減る限界利益%s円を%s台で割り、今の価格に足した値。'
              'この価格では、方針どおりに営業利益が最大となる生産量を選ぶと、Y社向けは%s台のままで要望を満たさない。'
              '%s円は、作業時間の線の傾きで比べた値（設問1の最適では、作業時間は余っている）。%s円（切り捨て）では、設問1の組み合わせのほうが有利で、要望を満たさない。'
              '%s円は、賃金を変動費に入れずに限界利益を計算した値。'
              % (n_(e2p_comp), n_(xf2), n_(REQ2), n_(lossf2), n_(REQ2), n_(y2a), n_(e2p_lab), n_(e2p_down), n_(e2p_nowg)),
        'x2': 'よくある誤り：%s台は、価格を上げても設問1の組み合わせのままとした場合。%s台は、Y社向けを要望ちょうどの%s台にした場合で、価格を上げた後は、交点まで移るほうが営業利益が大きい。'
              % (n_(x2a), n_(xf2), n_(REQ2)),
        'y2': 'よくある誤り：%s台は設問1のまま、%s台は要望ちょうど、%s台はY社向けを上限まで作った場合（この価格では、作業時間の線の上では、まだX社向けの方が1時間当たりの限界利益が大きい）。'
              % (n_(y2a), n_(REQ2), n_(g2_unit[1]))},
    e='【考え方】制約が2つあるときも、まず資源ごとに1時間当たりの限界利益を比べる。どちらの資源でも同じ製品が大きいなら、その製品を需要の上限まで作り、残りでもう一方を作る。'
      'ただし、残りを計算するときは、すべての資源で何台作れるかを調べ、最も少ない台数にする（先に尽きる資源が効く）。最後に端点の限界利益を比べて確かめる。\n'
      + '【設問1】X社向けは1台当たりの限界利益（%s円）はY社向け（%s円）より小さいが、作業時間当たりでも実装ライン当たりでも大きい。'
        'X社向けを上限の%s台まで作ると、残りの実装ラインでY社向けは%s台しか作れない（作業時間は%s時間余る）。営業利益は%s円。'
        '2つの資源の交点（イ）は、作業時間を使い切るが、営業利益は%s円で小さい。\n'
      % (n_(A2['cm']), n_(B2['cm']), n_(A2['d']), n_(y2a), n_(HL2 - A2['l'] * x2a - B2['l'] * y2a), n_(op2a), n_(e2a_cross))
      + '【設問2】最適な組み合わせは、価格が変わって、限界利益の比が、効いている制約の線の傾きの比を超えたときに、隣の端点へ移る。'
        'アからイへの辺は実装ラインの線なので、実装ライン1時間当たりの限界利益で、Y社向けがX社向けの%s円を上回る必要がある。'
        'Y社向けの限界利益は%s×%s＝%s円を超える必要があり、価格は%s円以上（切り上げ）。そのとき最適な組み合わせはイ（X社向け%s台・Y社向け%s台）で、要望を満たす。\n'
      % (n_(A2['cmk']), n_(A2['cmk']), d1(B2['k']), dx(cmY2x), n_(pr2), n_(x2b), n_(y2b))
      + '【注意】要望を条件にして（Y社向け%s台以上）今の価格で最適化すると、営業利益は%s円減る。これを%s台で割って値上げしても（%s円）、方針どおりに生産量を選ぶと、'
        'Y社向けは%s台のままになる。問われているのが「選ばれる生産量が要望を満たす価格」なのか「要望を受けても営業利益が減らない価格」なのかを、問題文で確かめる。\n'
      % (n_(REQ2), n_(lossf2), n_(REQ2), n_(e2p_comp), n_(y2a))
      + '【本試験での注意】令和6年度第2問は、直接作業時間と機械運転時間の上限と両社の需要の上限のもとで、営業利益が最大となる生産量と営業利益を、計算過程とともに問い（設問1）、'
        '一方の取引先の最低数量の希望を満たすための販売価格の下限を問うた（設問2）。出題の趣旨は「線形計画法を用いて最適な生産数量を算出する能力」。'
        '効いていない制約（ここでは作業時間）があることも、端点の確認で分かる。\n'
      + '【図】上は、1台当たりと資源1時間当たりの限界利益。中は、制約と作れる範囲で、設問1の最適はア、設問2の価格ではイに移る。下は、端点ごとの営業利益を、2つの価格で比べたもの。',
    x=_x02(),
))


# ================================================================ 03 自転車：2つの制約が効くときの、制約の資源を増やす価値（ブースを借りる判断。円。月）
PR3 = [dict(n='子ども用自転車', p=45000, v=25000, l=2, b=1, d=400),
       dict(n='フレーム', p=98000, v=57000, l=5, b=1, d=300)]
HL3, HB3 = 1600, 500                          # 溶接・組立の作業時間、塗装ブースの稼働時間の上限（月）
FIX3 = 10000000
RENT3, MAXR3 = 4000, 80                       # 設問2：外部のブースの借り賃（1時間当たり）、借りられる上限（時間）

for r in PR3:
    r['cm'] = r['p'] - r['v']
    r['cml'] = _F(r['cm'], r['l'])
    r['cmb'] = _F(r['cm'], r['b'])
A3, B3 = PR3
assert A3['cm'] == 20000 and B3['cm'] == 41000
assert A3['cm'] < B3['cm'] and A3['cml'] > B3['cml'] and A3['cmb'] < B3['cmb']   # 作業時間当たりは完成車、ブース当たりはフレーム


def C3(t=0):
    return [(A3['l'], B3['l'], HL3, '<='), (A3['b'], B3['b'], HB3 + t, '<='), (1, 0, A3['d'], '<='), (0, 1, B3['d'], '<=')]


x3a, y3a, sc3a = lp_opt(C3(), A3['cm'], B3['cm'], '03 設問1')
cm3a = A3['cm'] * x3a + B3['cm'] * y3a
op3a = cm3a - FIX3
assert A3['l'] * x3a + B3['l'] * y3a == HL3 and A3['b'] * x3a + B3['b'] * y3a == HB3 and x3a < A3['d'] and y3a < B3['d']   # 2つの資源の交点
# 資源1時間当たりの価値（2つの制約が効く交点で、ブースを1時間増やしたときの限界利益の増加）
det3 = _F(A3['l'] * B3['b'] - B3['l'] * A3['b'])
dxt3 = _F(-B3['l'], det3)                     # ブース1時間当たりの x の増加（5/3）
dyt3 = _F(A3['l'], det3)                      # y の増加（−2/3）
sp3 = A3['cm'] * dxt3 + B3['cm'] * dyt3       # ブース1時間の価値（6,000）
spl3 = (B3['cm'] * A3['b'] - A3['cm'] * B3['b']) / det3 * -1   # 作業時間1時間の価値（参考）
assert dxt3 == _F(5, 3) and dyt3 == _F(-2, 3) and sp3 == 6000 and spl3 == 7000
tb3 = (A3['d'] - x3a) / dxt3                  # 完成車が需要の上限に達するまでの時間（60）
assert tb3.denominator == 1 and 0 < tb3 < MAXR3
tb3 = int(tb3)
x3b, y3b = A3['d'], int(y3a + dyt3 * tb3)


def vint3(t):
    """整数の生産量で、ブースを t 時間増やしたときの限界利益の合計の最大（総当たり）"""
    best = None
    for x in range(A3['d'] + 1):
        y = min(B3['d'], (HL3 - A3['l'] * x) // B3['l'], (HB3 + t - A3['b'] * x) // B3['b'])
        if y < 0:
            continue
        v = A3['cm'] * x + B3['cm'] * y
        best = v if best is None or v > best else best
    return best


net3 = {t: vint3(t) - vint3(0) - RENT3 * t for t in range(MAXR3 + 1)}
best3 = max(net3.values())
assert [t for t, v in net3.items() if v == best3] == [tb3]                     # 借りる時間は60時間で一つに決まる
assert lp_opt(C3(tb3), A3['cm'], B3['cm'], '03 60時間')[:2] == (x3b, y3b)
inc3 = net3[tb3]
assert inc3 == (sp3 - RENT3) * tb3 and vint3(MAXR3) == vint3(tb3)
# 借り賃の上限：6,000円なら増減0（減らない）、1円でも上回ると、借りれば減る
assert max(vint3(t) - vint3(0) - sp3 * t for t in range(MAXR3 + 1)) == 0
assert all(vint3(t) - vint3(0) - (sp3 + 1) * t < 0 for t in range(1, MAXR3 + 1))
op3b = op3a + inc3
# よくある誤り（設問1）
g3_unit = greedy(1, [(A3['l'], B3['l'], HL3), (A3['b'], B3['b'], HB3)], (A3['d'], B3['d']))   # 1台当たり・ブース当たりの大きいフレームを先に
g3_lab = greedy(0, [(A3['l'], B3['l'], HL3), (A3['b'], B3['b'], HB3)], (A3['d'], B3['d']))    # 作業時間当たりの大きい完成車を先に
assert g3_unit == (50, 300) and g3_lab == (400, 100)
e3a_unit = A3['cm'] * g3_unit[0] + B3['cm'] * g3_unit[1] - FIX3
e3a_lab = A3['cm'] * g3_lab[0] + B3['cm'] * g3_lab[1] - FIX3
e3a_nofix = cm3a
_uniq('03 op1', op3a, [e3a_unit, e3a_lab, e3a_nofix])
_uniq('03 x1', x3a, [g3_unit[0], g3_lab[0]])
_uniq('03 y1', y3a, [g3_unit[1], g3_lab[1]])
# よくある誤り（設問2）
e3_all = net3[MAXR3]                                         # 80時間すべて借りる
e3_norent = sp3 * tb3                                        # 借り賃を引き忘れる
e3_frame = B3['cm'] * MAXR3 - RENT3 * MAXR3                  # 借りた時間でフレームを80台増やせるとした（作業時間を見ていない）
e3_bike = A3['cm'] * MAXR3 - RENT3 * MAXR3                   # 完成車を80台増やせるとした
_uniq('03 inc', inc3, [e3_all, e3_norent, e3_frame, e3_bike])
_uniq('03 hours', tb3, [MAXR3, 0])
e3r_frame, e3r_bike = B3['cmb'], A3['cmb']                   # 1台のブース1時間当たりの限界利益で考えた
e3r_gross = dn(A3['cm'] * dxt3)                              # 完成車の増加分だけ見て、フレームの減少を忘れた
_uniq('03 rent', sp3, [e3r_frame, e3r_bike, e3r_gross])

T3 = _lim('作業時間も上限でフレームは増やせず、完成車を増やしフレームを減らすしかない。その価値は1時間%s円で%s時間まで。' % (n_(sp3), n_(tb3)), 60)


def _x03():
    xm, ym = 450, 350
    poly = [(0, 0), (A3['d'], 0), g3_lab, (x3a, y3a), g3_unit, (0, B3['d'])]
    lines = [(A3['l'], B3['l'], HL3, 'a', False, 2.2), (A3['b'], B3['b'], HB3, 'c', False, 2.2), (A3['b'], B3['b'], HB3 + tb3, 'c', True, 1.6),
             (1, 0, A3['d'], 'sub', True, 1.2), (0, 1, B3['d'], 'sub', True, 1.2)]
    dots = [(x3a, y3a, 'b', 5, False), (x3b, y3b, 'a', 5, False), (g3_unit[0], g3_unit[1], 'main', 3.4, False), (g3_lab[0], g3_lab[1], 'main', 3.4, False)]
    texts = [(A3['d'], ym, '完成車の上限 %s' % n_(A3['d']), 'middle', 'sub', 10, -10, -8),
             (xm, B3['d'], 'フレームの上限 %s' % n_(B3['d']), 'end', 'sub', 10, -2, -5),
             (x3a, y3a, 'ア 今の最適', 'end', 'b', 11.5, -8, 16),
             (x3b, y3b, 'イ', 'start', 'a', 11.5, 6, -7),
             (g3_unit[0], g3_unit[1], 'ウ', 'start', 'main', 11.5, 5, 16),
             (g3_lab[0], g3_lab[1], 'エ', 'end', 'main', 11.5, -6, 14),
             (40, 60, '今の作れる範囲', 'start', 'b', 11, 0, 0)]
    rtexts = [(A3['l'], B3['l'], HL3, 100, '作業時間 %s時間' % n_(HL3), 'a', 10.5, 14),
              (A3['b'], B3['b'], HB3, 162, 'ブース %s時間' % n_(HB3), 'c', 10.5, -6),
              (A3['b'], B3['b'], HB3 + tb3, 226, '%s時間（借りた後）' % n_(HB3 + tb3), 'c', 10.5, -6)]
    c = lpchart(xm, ym, [(100, '100'), (200, '200'), (300, '300'), (400, '400')], [(100, '100'), (200, '200'), (300, '300')],
                '子ども用自転車＝完成車（台）', 'フレーム（台）', polys=[(poly, 'b', 0.14)], lines=lines, dots=dots, texts=texts, rtexts=rtexts,
                arrows=[(x3a + 8, y3a - _F(16, 5), x3b - 8, y3b + _F(16, 5), 'a')], title='制約と、ブースを借りたときの最適な組み合わせの動き')
    K = 1000
    gross = [(0, 0), (tb3, sp3 * tb3 / K), (MAXR3, sp3 * tb3 / K)]
    rent = [(0, 0), (MAXR3, RENT3 * MAXR3 / K)]
    ln = lnchart(MAXR3, 0, 400, [(20, '20'), (40, '40'), (60, '60'), (80, '80')], [(100, '100'), (200, '200'), (300, '300'), (400, '400')],
                 '借りる時間（時間）', '千円', series=[(gross, 'b', False), (rent, 'a', True)],
                 dots=[(tb3, sp3 * tb3 / K, 'b'), (tb3, RENT3 * tb3 / K, 'a'), (MAXR3, RENT3 * MAXR3 / K, 'a')],
                 texts=[(2, 330, '限界利益の増加（1時間%s円）' % n_(sp3), 'start', 'b', 10.5, 0, 0),
                        (28, 50, '借り賃（1時間%s円）' % n_(RENT3), 'start', 'a', 10.5, 0, 0),
                        (tb3, 285, '差 %s' % n_(inc3 // K), 'start', 'main', 11, 5, 0),
                        (MAXR3, 335, '差 %s' % n_(e3_all // K), 'end', 'main', 11, -3, 0)],
                 vlines=[tb3], title='借りる時間と営業利益の増加')
    rows = [[A3['n'], n_(A3['cm']) + '円', n_(A3['cml']) + '円', n_(A3['cmb']) + '円', '＋5/3台'],
            [B3['n'], n_(B3['cm']) + '円', n_(B3['cml']) + '円', n_(B3['cmb']) + '円', '−2/3台']]
    g = grid(['製品', '1台当たり', '作業時間\n当たり', 'ブース\n当たり', 'ブースを\n1時間足す'], rows, [92, 66, 68, 66, 68], align=['l', 'r', 'r', 'r', 'r'],
             size=11, title='限界利益と、ブース1時間を足したときの生産の変化')
    return (cap('限界利益（1台当たり・資源1時間当たり）と、ブースを1時間足したときの生産の変化（右の列。作業時間は増やせないので組み替えになる）') + g + GAP
            + cap('制約と作れる範囲（緑の部分）。ブースを%s時間借りると、アから作業時間の線の上をイ（完成車%s台・フレーム%s台）まで動く。'
                  'ウはフレーム、エは完成車を優先した場合' % (n_(tb3), n_(x3b), n_(y3b))) + c + GAP
            + cap('借りる時間と、限界利益の増加（緑）・借り賃（赤の点線）。単位：千円。差が営業利益の増加で、%s時間で最大の%s千円' % (n_(tb3), n_(inc3 // K))) + ln)


P.append(dict(
    id='d4-lp-03', cat='lp', lv=3, min=22,
    src='R6-第2問・R4-第2問設問2（2つの制約の最適な組み合わせ）を発展。制約の資源を増やす価値は R1〜R6 に出題なし（外部の能力を借りるかの判断と記述）',
    title='自転車：2つの制約が効くときの、ブースを借りる価値',
    lead='D社は、地方都市で自転車を製造している。製品は、子ども用自転車（完成車）と、ロードバイクのオーダーメイドのフレーム（以下、フレーム）である。'
         'どちらも、溶接・組立の工程と塗装の工程を通る。溶接・組立は正社員の職人が行い、作業時間は月%s時間が上限である。'
         '塗装は自社の塗装ブースで行い、ブースの稼働時間は月%s時間が上限である。職人の給与や工場の経費などの固定費は月%s円で、生産量によって変わらない。\n'
         '製品のデータは次の表のとおりである。' % (n_(HL3), n_(HB3), n_(FIX3)),
    tables=[dict(cap='製品のデータ（1台当たり）', unit='', head=['項目', A3['n'], B3['n']],
                 rows=[['販売価格（円）', n_(A3['p']), n_(B3['p'])], ['変動費（円）', n_(A3['v']), n_(B3['v'])],
                       ['溶接・組立の作業時間（時間）', n_(A3['l']), n_(B3['l'])], ['塗装ブースの稼働時間（時間）', n_(A3['b']), n_(B3['b'])],
                       ['月間の需要の上限（台）', n_(A3['d']), n_(B3['d'])]],
                 note='変動費は、部品・材料・塗料などの費用である。')],
    parts=[
        dict(h='設問1',
             q='営業利益が最大となる完成車とフレームの月間の生産・販売量と、そのときの営業利益（円）を求めよ。生産・販売量は整数とする。計算過程も示すこと。',
             fields=[dict(k='x1', type='num', label='完成車の生産・販売量', unit='台', dp=0, ans=x3a),
                     dict(k='y1', type='num', label='フレームの生産・販売量', unit='台', dp=0, ans=y3a),
                     dict(k='op1', type='num', label='営業利益', unit='円', dp=0, ans=iv(op3a)),
                     dict(k='p1', type='proc', label='計算過程')],
             steps=['1台当たりの限界利益：完成車%s円、フレーム%s円。作業時間当たりは完成車%s円＞フレーム%s円、ブース当たりはフレーム%s円＞完成車%s円で、順位が食い違う'
                    % (n_(A3['cm']), n_(B3['cm']), n_(A3['cml']), n_(B3['cml']), n_(B3['cmb']), n_(A3['cmb'])),
                    '完成車をx台、フレームをy台とする。制約：作業時間 %sx＋%sy≦%s、ブース x＋y≦%s、x≦%s、y≦%s'
                    % (n_(A3['l']), n_(B3['l']), n_(HL3), n_(HB3), n_(A3['d']), n_(B3['d'])),
                    '作業時間とブースの交点：ブースの式を%s倍して作業時間の式から引くと%sy＝%s → y＝%s、x＝%s−%s＝%s'
                    % (n_(A3['l']), n_(B3['l'] - A3['l']), n_(HL3 - A3['l'] * HB3), n_(y3a), n_(HB3), n_(y3a), n_(x3a)),
                    '端点の限界利益の合計：交点（%s, %s）%s円、フレームを優先（%s, %s）%s円、完成車を優先（%s, %s）%s円 → 交点が最大'
                    % (n_(x3a), n_(y3a), n_(cm3a), n_(g3_unit[0]), n_(g3_unit[1]), n_(e3a_unit + FIX3), n_(g3_lab[0]), n_(g3_lab[1]), n_(e3a_lab + FIX3)),
                    '営業利益＝%s×%s＋%s×%s−%s＝%s円' % (n_(A3['cm']), n_(x3a), n_(B3['cm']), n_(y3a), n_(FIX3), n_(op3a))]),
        dict(h='設問2',
             q='近くの塗装会社から、塗装ブースを1時間%s円（運搬費を含む）で、月%s時間まで（1時間単位で）貸すとの申し出があった。借りたブースでも、自社のブースと同じ時間・品質で塗装できる。'
               '借り賃のほかに増える固定費はなく、そのほかの条件は設問1と同じとする。\n' % (n_(RENT3), n_(MAXR3))
               + '(1) 営業利益を最大にするには、ブースを月何時間借りればよいか。また、そのときの営業利益の増加額（借り賃を差し引いた後の、設問1と比べた額）を求めよ。'
                 '生産・販売量は整数とする。計算過程も示すこと。\n'
               + '(2) ブースの借り賃が1時間当たり何円を超えると、何時間借りても、借りない場合より営業利益が小さくなるか。',
             fields=[dict(k='hr', type='num', label='(1) 借りる時間', unit='時間', dp=0, ans=tb3),
                     dict(k='inc', type='num', label='(1) 営業利益の増加額', unit='円', dp=0, ans=iv(inc3)),
                     dict(k='p2', type='proc', label='(1) 計算過程'),
                     dict(k='rent', type='num', label='(2) 借り賃の境目（1時間当たり）', unit='円', dp=0, ans=iv(sp3))],
             steps=['作業時間もブースも上限まで使っているので、借りたブースでフレームを増やすことはできない（フレームを1台増やすには作業時間が%s時間要る）。'
                    '作業時間を変えずにブースの時間を使うには、完成車を増やしフレームを減らす組み替えになる' % n_(B3['l']),
                    'ブースをt時間借りると、交点は %sx＋%sy＝%s、x＋y＝%s＋t → x＝%s＋5t/3、y＝%s−2t/3'
                    % (n_(A3['l']), n_(B3['l']), n_(HL3), n_(HB3), n_(x3a), n_(y3a)),
                    'ブース1時間当たりの限界利益の増加＝%s×5/3−%s×2/3＝（%s−%s）÷3＝%s円'
                    % (n_(A3['cm']), n_(B3['cm']), n_(A3['cm'] * 5), n_(B3['cm'] * 2), n_(sp3)),
                    '完成車が需要の上限%s台に達するのは、%s＋5t/3＝%s → t＝%s時間（フレーム%s台）。それより多く借りても、完成車は増やせず、フレームは作業時間が足りず増やせない'
                    % (n_(A3['d']), n_(x3a), n_(A3['d']), n_(tb3), n_(y3b)),
                    '(1) %s円＞借り賃%s円なので、%s時間借りる。営業利益の増加＝（%s−%s）×%s＝%s円（%s時間すべて借りると%s×%s−%s×%s＝%s円にとどまる）'
                    % (n_(sp3), n_(RENT3), n_(tb3), n_(sp3), n_(RENT3), n_(tb3), n_(inc3), n_(MAXR3), n_(sp3), n_(tb3), n_(RENT3), n_(MAXR3), n_(e3_all)),
                    '(2) ブース1時間の価値は%s円なので、借り賃が%s円を超えると、何時間借りても借りない場合より営業利益が小さくなる（%s円ちょうどなら、%s時間借りても増減0）'
                    % (n_(sp3), n_(sp3), n_(sp3), n_(tb3))]),
        dict(h='設問3',
             q='社長は、「フレームは塗装ブース1時間当たりの限界利益が%s円もあるので、借り賃が%s円なら、%s時間すべて借りてフレームを増やすべきだ」と考えている。'
               '設問2の結果を踏まえ、この考えの誤りを60字以内で述べよ。' % (n_(B3['cmb']), n_(RENT3), n_(MAXR3)),
             fields=[dict(k='t3', type='text', label='解答', limit=60, model=T3,
                          points=['作業時間も上限なので、借りた時間でフレームは増やせない',
                                  '借りた時間は、完成車を増やしフレームを減らす組み替えに使われる',
                                  'ブース1時間の価値は%s円で、%s時間（完成車の需要の上限）を超える分は使えない' % (n_(sp3), n_(tb3))])]),
    ],
    ce={'x1': 'よくある誤り：%s台は、1台当たり・ブース1時間当たりの限界利益が大きいフレームを先に上限まで作った場合（営業利益%s円）。'
              '%s台は、作業時間1時間当たりの限界利益が大きい完成車を先に上限まで作った場合（営業利益%s円）。2つの資源で順位が食い違うので、端点を比べる。'
              % (n_(g3_unit[0]), n_(e3a_unit), n_(g3_lab[0]), n_(e3a_lab)),
        'y1': 'よくある誤り：%s台はフレームを優先した場合、%s台は完成車を優先した場合。' % (n_(g3_unit[1]), n_(g3_lab[1])),
        'op1': 'よくある誤り：%s円はフレームを優先した場合、%s円は完成車を優先した場合、%s円は固定費を差し引いていない。' % (n_(e3a_unit), n_(e3a_lab), n_(e3a_nofix)),
        'hr': 'よくある誤り：%s時間（すべて借りる）では、%s時間を超える分は使えず、借り賃だけがかかる（営業利益の増加は%s円）。'
              '%s時間（借りない）は、ブース1時間の価値（%s円）が借り賃を上回ることを見落としている。' % (n_(MAXR3), n_(tb3), n_(e3_all), 0, n_(sp3)),
        'inc': 'よくある誤り：%s円は、%s時間すべて借りた場合。%s円は、借り賃を差し引いていない。%s円は、借りた時間でフレームを%s台増やせるとした場合で、'
               '作業時間が足りないことを見落としている。%s円は、完成車を%s台増やせるとした場合（同じく作業時間が足りない）。'
               % (n_(e3_all), n_(MAXR3), n_(e3_norent), n_(e3_frame), n_(MAXR3), n_(e3_bike), n_(MAXR3)),
        'rent': 'よくある誤り：%s円はフレームの、%s円は完成車の、ブース1時間当たりの限界利益。作業時間が上限なので、どちらか一方だけを増やすことはできない。'
                '%s円は、完成車の増加（5/3台）だけを見て、フレームの減少（2/3台）を忘れた値。' % (n_(e3r_frame), n_(e3r_bike), n_(e3r_gross))},
    e='【考え方】制約の資源を外から足す（ブースを借りる、残業する、外注する）価値は、その資源1時間で最適な組み合わせがどう変わり、限界利益がいくら増えるかで決まる。'
      'ほかの制約（ここでは作業時間）も効いているときは、足した資源でどちらかの製品を単純に増やすことはできず、作業時間を変えない組み替えになる。'
      'その価値が借りる費用を上回れば借りる。ただし、組み替えが需要の上限などに当たると、それ以上は価値がなくなる。\n'
      + '【設問1】作業時間当たりでは完成車（%s円）、ブース当たりではフレーム（%s円）が大きく、順位が食い違う。端点を比べると、作業時間とブースの交点（完成車%s台・フレーム%s台）が最大で、'
        '営業利益は%s円。フレームを優先すると%s円、完成車を優先すると%s円にとどまる。\n'
      % (n_(A3['cml']), n_(B3['cmb']), n_(x3a), n_(y3a), n_(op3a), n_(e3a_unit), n_(e3a_lab))
      + '【設問2】ブースを1時間足すと、作業時間の線の上で、完成車が5/3台増え、フレームが2/3台減る。限界利益は%s×5/3−%s×2/3＝%s円増える（ブース1時間の価値）。'
        '完成車が上限の%s台に達する%s時間までがこの価値で、それを超えると価値は0になる。借り賃%s円との差%s円×%s時間＝%s円の増益。すべての%s時間を借りると%s円に減る。'
        '借り賃が%s円を超えるなら借りない。\n'
      % (n_(A3['cm']), n_(B3['cm']), n_(sp3), n_(A3['d']), n_(tb3), n_(RENT3), n_(sp3 - RENT3), n_(tb3), n_(inc3), n_(MAXR3), n_(e3_all), n_(sp3))
      + '【設問3】社長の考えは、ブース1時間でフレームが1台増えると見ている。フレームは作業時間を%s時間使うので、作業時間が上限のままでは増やせない。'
        '借りた時間の価値は、組み替えで生じる%s円で、%s時間を超える分は使えないことを書く。参考に、作業時間を1時間足せる場合の価値は%s円（フレームを増やし完成車を減らす組み替え）。\n'
      % (n_(B3['l']), n_(sp3), n_(tb3), n_(spl3))
      + '【本試験での注意】令和元〜6年度に、制約の資源を増やす価値を問う設問はない。令和4・6年度の2つの制約の最適化を解いたうえで、'
        '「残業・外注・設備の借用で能力を増やすべきか」「いくらまでなら払えるか」を問う形は、計算のあとに判断を伴う設問として出うる。'
        '資源を増やしたら、もう一度端点を求め直し（交点が動く）、需要の上限などに当たる点で区切って計算する。\n'
      + '【図】上は、限界利益と、ブースを1時間足したときの生産の変化。中は、制約と作れる範囲で、ブースを借りるとアからイへ作業時間の線の上を動く（ウ・エは一方の製品を優先した場合）。'
        '下は、借りる時間と、限界利益の増加・借り賃の関係で、差（営業利益の増加）は%s時間で最大になる。' % n_(tb3),
    x=_x03(),
))


# ================================================================ 04 陶磁器の窯元：取引先との約束（需要の下限）と、全部原価で赤字に見える製品（円。月）
PR4 = [dict(n='業務用の皿', u='枚', p=1400, v=600, a=_F(1, 4), b=_F(1, 20), lo=2000, d=2400),
       dict(n='作家物の器', u='個', p=8000, v=3000, a=_F(1), b=_F(1), d=1000)]
HA4, HB4 = 1200, 900                          # 成形・絵付けの作業時間の上限（月。それぞれ専任の職人）
FIX4 = 4200000
RATE4 = _F(FIX4, HA4)                         # 固定費の配賦率（成形の作業時間1時間当たり）

A4, B4 = PR4
for r in PR4:
    r['cm'] = r['p'] - r['v']
    r['al'] = r['a'] * RATE4                  # 固定費の配賦額
    r['full'] = r['v'] + r['al']              # 製造原価
    r['pl'] = r['p'] - r['full']              # 1個当たりの損益（全部原価）
    r['cma'] = r['cm'] / r['a']               # 成形1時間当たり
    r['cmb'] = r['cm'] / r['b']               # 絵付け1時間当たり
assert RATE4 == 3500 and all(r['al'].denominator == 1 for r in PR4)
assert A4['pl'] < 0 < A4['cm'] and B4['pl'] > 0                       # 皿は全部原価では赤字に見えるが、限界利益はプラス
assert A4['cma'] < B4['cma'] and A4['cmb'] > B4['cmb']                 # 成形当たりは器、絵付け当たりは皿
RES4 = [(A4['a'], B4['a'], HA4, '<='), (A4['b'], B4['b'], HB4, '<=')]
C4 = RES4 + [(1, 0, A4['d'], '<='), (1, 0, A4['lo'], '>='), (0, 1, B4['d'], '<=')]   # 契約あり（下限と上限）
C4n = RES4 + [(1, 0, A4['d'], '<='), (0, 1, B4['d'], '<=')]                          # 下限がない場合（参考）
C4e = RES4 + [(1, 0, 0, '<='), (0, 1, B4['d'], '<=')]                                # 契約をやめる（皿は0）
x4a, y4a, sc4a = lp_opt(C4, A4['cm'], B4['cm'], '04 設問1')
cm4a = A4['cm'] * x4a + B4['cm'] * y4a
op4a = cm4a - FIX4
assert x4a == A4['lo'] and A4['a'] * x4a + B4['a'] * y4a == HA4           # 下限と成形の交点
x4e, y4e, sc4e = lp_opt(C4e, A4['cm'], B4['cm'], '04 設問2')
op4e = B4['cm'] * y4e - FIX4
assert x4e == 0 and B4['b'] * y4e == HB4 and y4e < B4['d'] and op4e < op4a   # 絵付けが先に尽き、契約をやめると減益
x4v, y4v, sc4v = lp_opt(C4n, A4['cm'], B4['cm'], '04 下限なし')
op4v = A4['cm'] * x4v + B4['cm'] * y4v - FIX4
assert (x4v, y4v) == (1500, 825) and x4v < A4['lo']                       # 下限がなければ皿は1,500枚（下限が効いている）
cost4 = B4['cm'] * A4['a'] / B4['a'] - A4['cm']                          # 下限を超える皿1枚の減益（器を成形の時間で置き換える）
assert cost4 == 450 and op4v - op4a == cost4 * (A4['lo'] - x4v)
# よくある誤り（設問1）
e4a_nolo = op4v                                                          # 下限を入れていない
x4f = A4['lo']
y4f = (HB4 - A4['b'] * x4f) / B4['b']                                    # 成形の制約を見落とし、絵付けだけで器を決めた
assert not feas(C4, x4f, y4f)
y4f = int(y4f)
e4a_noform = A4['cm'] * x4f + B4['cm'] * y4f - FIX4
y4m = (HA4 - A4['a'] * A4['d']) / B4['a']                                # 皿を上限まで納めた
y4m = int(y4m)
e4a_max = A4['cm'] * A4['d'] + B4['cm'] * y4m - FIX4
e4a_nofix = cm4a
_uniq('04 op1', op4a, [e4a_nolo, e4a_noform, e4a_max, e4a_nofix])
_uniq('04 x1', x4a, [x4v, A4['d']])
_uniq('04 y1', y4a, [y4v, y4f, y4m])
# よくある誤り（設問2）
e4e_full = op4a - A4['pl'] * x4a                                         # 皿の「赤字」がなくなるとした（配賦された固定費も消えると考えた）
e4e_nopaint = B4['cm'] * B4['d'] - FIX4                                  # 絵付けの制約を見落とし、器を需要の上限まで作るとした
e4e_nobowl = op4a - A4['cm'] * x4a                                       # 器を増やせることを見落とした
e4e_nofix = B4['cm'] * y4e
_uniq('04 op2', op4e, [e4e_full, e4e_nopaint, e4e_nobowl, e4e_nofix])
assert e4e_full > op4a                                                   # 全部原価で考えると、やめるほうが有利に見える

T4 = _lim('下限を%s枚以下に下げるよう求める。%s枚を超える皿は成形の時間を器から奪い、1枚%s円の減益になるため。' % (n_(x4v), n_(x4v), n_(cost4)), 60)


def _x04():
    g = grid(['1個当たり', A4['n'], B4['n']],
             [['販売価格', n_(A4['p']), n_(B4['p'])], ['変動費', n_(A4['v']), n_(B4['v'])], ['限界利益', n_(A4['cm']), n_(B4['cm'])],
              ['固定費の配賦額', n_(A4['al']), n_(B4['al'])], ['損益（全部原価）', n_(A4['pl']), n_(B4['pl'])],
              ['成形1時間当たりの限界利益', n_(A4['cma']), n_(B4['cma'])], ['絵付け1時間当たりの限界利益', n_(A4['cmb']), n_(B4['cmb'])]],
             [176, 92, 92], align=['l', 'r', 'r'], size=11.5, hl_rows=(2,), total_rows=(2,), title='1個当たりの損益と限界利益')
    xm, ym = 2600, 1300
    poly_n = [(0, 0), (A4['d'], 0), (A4['d'], y4m), (x4v, y4v), (0, y4e)]
    poly_c = [(A4['lo'], 0), (A4['d'], 0), (A4['d'], y4m), (x4a, y4a)]
    lines = [(A4['a'], B4['a'], HA4, 'a', False, 2.2), (A4['b'], B4['b'], HB4, 'c', False, 2.2),
             (1, 0, A4['lo'], 'b', True, 1.6), (1, 0, A4['d'], 'sub', True, 1.2), (0, 1, B4['d'], 'sub', True, 1.2)]
    dots = [(x4a, y4a, 'b', 5, False), (0, y4e, 'a', 5, False), (x4v, y4v, 'main', 4, True), (A4['d'], y4m, 'main', 3.4, False)]
    texts = [(A4['lo'], ym, '下限 %s' % n_(A4['lo']), 'end', 'b', 10, -3, -8),
             (A4['d'], ym, '上限', 'middle', 'sub', 10, 0, -8),
             (xm, B4['d'], '器の需要の上限 %s' % n_(B4['d']), 'end', 'sub', 10, -2, -5),
             (x4a, y4a, 'イ 契約あり', 'end', 'b', 11.5, -8, 16),
             (0, y4e, 'ウ', 'start', 'a', 11.5, 6, -6),
             (x4v, y4v, 'ア 下限なし', 'end', 'main', 11, -8, 17),
             (A4['d'], y4m, 'エ', 'start', 'main', 11.5, 5, -6),
             (A4['lo'] + 30, 330, '契約の', 'start', 'b', 10.5, 0, 0),
             (A4['lo'] + 30, 200, '範囲', 'start', 'b', 10.5, 0, 0),
             (120, 260, '下限がない場合の範囲', 'start', 'sub', 10.5, 0, 0)]
    rtexts = [(A4['a'], B4['a'], HA4, 60, '成形 %s時間' % n_(HA4), 'a', 10.5, -6),
              (A4['b'], B4['b'], HB4, 150, '絵付け %s時間' % n_(HB4), 'c', 10.5, 14)]
    c = lpchart(xm, ym, [(500, '500'), (1000, '1,000'), (1500, '1,500'), (2000, '2,000'), (2500, '2,500')],
                [(250, '250'), (500, '500'), (750, '750'), (1000, '1,000'), (1250, '1,250')], '業務用の皿（枚）', '作家物の器（個）',
                polys=[(poly_n, 'sub', 0.12), (poly_c, 'b', 0.24)], lines=lines, dots=dots, texts=texts, rtexts=rtexts,
                title='制約と、契約のもとで作れる範囲')
    g2 = grid(['案', '皿', '器', '営業利益'],
              [['イ 契約を続ける（下限%s枚）' % n_(A4['lo']), n_(x4a), n_(y4a), n_(op4a)],
               ['ウ 契約をやめる', n_(x4e), n_(y4e), n_(op4e)],
               ['ア（参考）下限がない', n_(x4v), n_(y4v), n_(op4v)]],
              [154, 54, 50, 102], align=['l', 'r', 'r', 'r'], size=11, hl_rows=(0,), title='案ごとの営業利益')
    return (cap('1個当たりの損益（全部原価）と限界利益（単位：円）。皿は配賦額を含めると赤字に見えるが、限界利益はプラス') + g + GAP
            + cap('制約と作れる範囲（灰色は下限がない場合、緑は契約の下限%s枚以上・上限%s枚以下のとき）。イが契約のもとでの最適、ウは契約をやめた場合、エは皿を上限まで納めた場合'
                  % (n_(A4['lo']), n_(A4['d']))) + c + GAP
            + cap('案ごとの営業利益（単位：円。皿は枚、器は個）') + g2)


P.append(dict(
    id='d4-lp-04', cat='lp', lv=2, min=20,
    src='R6-第2問設問2（取引先の最低数量）・R4-第2問（共通固定費を配賦しない組み合わせ）を発展。取引先との約束による需要の下限は R1〜R6 に出題なし',
    title='陶磁器の窯元：取引先との約束（需要の下限）と、赤字に見える製品',
    lead='D社は、陶磁器の産地にある窯元で、ろくろで成形した器に絵付けをして焼き上げている。製品は、ホテルチェーンに納める業務用の皿（以下、皿）と、'
         '百貨店や器の専門店で販売する作家物の器（以下、器）である。成形と絵付けはそれぞれ専任の職人が行い、作業時間の上限は成形が月%s時間、絵付けが月%s時間である。'
         '窯の能力には余裕がある。\n' % (n_(HA4), n_(HB4))
         + 'ホテルチェーンとは年間契約を結んでおり、皿を毎月%s枚以上納める約束である。ホテルチェーンは、月%s枚までなら、D社が納める枚数をそのまま引き取る。'
           '器の月間の需要の上限は%s個である。\n' % (n_(A4['lo']), n_(A4['d']), n_(B4['d']))
         + 'D社は、固定費（職人の給与、窯の減価償却費など月%s円）を、成形の作業時間1時間当たり%s円で製品に配賦しており、製品のデータは次の表のとおりである。'
           % (n_(FIX4), n_(RATE4)),
    tables=[dict(cap='製品のデータ（1枚・1個当たり）', unit='', head=['項目', A4['n'], B4['n']],
                 rows=[['販売価格（円）', n_(A4['p']), n_(B4['p'])], ['変動費（円）', n_(A4['v']), n_(B4['v'])],
                       ['固定費の配賦額（円）', n_(A4['al']), n_(B4['al'])], ['全部原価（円）', n_(A4['full']), n_(B4['full'])],
                       ['1枚・1個当たりの損益（円）', n_(A4['pl']), n_(B4['pl'])],
                       ['成形の作業時間（時間）', d2(A4['a']), d2(B4['a'])], ['絵付けの作業時間（時間）', d2(A4['b']), d2(B4['b'])]],
                 note='変動費は、粘土・釉薬・窯の燃料・包装材などの費用である。販売費及び一般管理費は、固定費に含めている。')],
    parts=[
        dict(h='設問1',
             q='ホテルチェーンとの契約の条件のもとで、営業利益が最大となる皿と器の月間の生産・販売量と、そのときの営業利益（円）を求めよ。'
               '生産・販売量は整数とする。計算過程も示すこと。',
             fields=[dict(k='x1', type='num', label='皿の生産・販売量', unit='枚', dp=0, ans=x4a),
                     dict(k='y1', type='num', label='器の生産・販売量', unit='個', dp=0, ans=y4a),
                     dict(k='op1', type='num', label='営業利益', unit='円', dp=0, ans=iv(op4a)),
                     dict(k='p1', type='proc', label='計算過程')],
             steps=['1個当たりの限界利益：皿＝%s−%s＝%s円、器＝%s−%s＝%s円（固定費の配賦額は、生産量を変えても固定費の総額が変わらないので含めない）'
                    % (n_(A4['p']), n_(A4['v']), n_(A4['cm']), n_(B4['p']), n_(B4['v']), n_(B4['cm'])),
                    '皿をx枚、器をy個とする。制約：成形 %sx＋y≦%s、絵付け %sx＋y≦%s、%s≦x≦%s（契約）、y≦%s'
                    % (dx(A4['a']), n_(HA4), dx(A4['b']), n_(HB4), n_(A4['lo']), n_(A4['d']), n_(B4['d'])),
                    '成形1時間当たりの限界利益は器%s円＞皿%s円。皿を増やすほど成形の時間が器から奪われるので、皿は下限の%s枚にする'
                    % (n_(B4['cma']), n_(A4['cma']), n_(A4['lo'])),
                    'x＝%sのとき、器（1個に成形・絵付けとも1時間）は、成形の残り%s−%s×%s＝%s時間で%s個、絵付けの残り%s−%s×%s＝%s時間で%s個、需要の上限%s個 → %s個（成形が先に尽きる）'
                    % (n_(A4['lo']), n_(HA4), dx(A4['a']), n_(A4['lo']), n_(y4a), n_(y4a), n_(HB4), dx(A4['b']), n_(A4['lo']), n_(y4f), n_(y4f), n_(B4['d']), n_(y4a)),
                    '端点の確認：（%s, %s）の限界利益%s円、皿を上限まで納める（%s, %s）%s円 → （%s, %s）が最大'
                    % (n_(x4a), n_(y4a), n_(cm4a), n_(A4['d']), n_(y4m), n_(e4a_max + FIX4), n_(x4a), n_(y4a)),
                    '営業利益＝%s×%s＋%s×%s−%s＝%s＋%s−%s＝%s円'
                    % (n_(A4['cm']), n_(x4a), n_(B4['cm']), n_(y4a), n_(FIX4), n_(A4['cm'] * x4a), n_(B4['cm'] * y4a), n_(FIX4), n_(op4a))]),
        dict(h='設問2',
             q='社長は、表のとおり皿は1枚当たり%s円の赤字であるとして、ホテルチェーンとの契約をやめ、器に集中することを考えている。契約をやめると皿の販売はなくなり、'
               '職人の人数は変えないので、固定費の総額は変わらない。\n' % n_(-A4['pl'])
               + '(1) 契約をやめた場合に、営業利益が最大となる生産・販売量のもとでの営業利益（円）を求めよ。\n'
               + '(2) D社は営業利益が大きくなる方を選ぶ方針である。契約を続けるべきかを答えよ。',
             fields=[dict(k='op2', type='num', label='(1) 契約をやめた場合の営業利益', unit='円', dp=0, ans=iv(op4e)),
                     dict(k='ch', type='choice', label='(2) 契約', opts=['続けるべきである', 'やめるべきである'], ans='続けるべきである')],
             steps=['契約をやめると x＝0。器は、成形%s時間で%s個、絵付け%s時間で%s個、需要の上限%s個 → %s個（絵付けが先に尽きる）'
                    % (n_(HA4), n_(HA4 / B4['a']), n_(HB4), n_(HB4 / B4['b']), n_(B4['d']), n_(y4e)),
                    '(1) 営業利益＝%s×%s−%s＝%s円' % (n_(B4['cm']), n_(y4e), n_(FIX4), n_(op4e)),
                    '(2) 契約を続ける場合（%s円）より%s円少ない → 続けるべきである' % (n_(op4a), n_(op4a - op4e)),
                    '皿の「1枚%s円の赤字」は、配賦された固定費%s円を含めた損益。固定費は契約をやめても減らず、皿の限界利益%s円×%s枚＝%s円は固定費の回収に役立っている。'
                    'やめると器は%s個から%s個に増えるが、絵付けの時間が足りず、増える限界利益は%s円にとどまる'
                    % (n_(-A4['pl']), n_(A4['al']), n_(A4['cm']), n_(x4a), n_(A4['cm'] * x4a), n_(y4a), n_(y4e), n_(B4['cm'] * (y4e - y4a)))]),
        dict(h='設問3',
             q='D社が契約を続ける場合に、次の契約の更新でホテルチェーンに求めるべき条件とその理由を、契約の下限がない場合の最適な組み合わせと比べて60字以内で述べよ。',
             fields=[dict(k='t3', type='text', label='解答', limit=60, model=T4,
                          points=['皿の下限の引き下げ（%s枚以下。下限がなければ最適は皿%s枚・器%s個）' % (n_(x4v), n_(x4v), n_(y4v)),
                                  '%s枚を超える皿は、制約である成形の時間を器から奪う（器が減る）' % n_(x4v),
                                  '超える皿1枚当たり%s円の減益（今の下限%s枚では月%s円）'
                                  % (n_(cost4), n_(A4['lo']), n_(op4v - op4a))])]),
    ],
    ce={'x1': 'よくある誤り：%s枚は、契約の下限を入れずに最適化した場合（営業利益%s円）。契約で%s枚以上を納める約束なので、下限を制約に入れる。'
              '%s枚は、上限まで納めた場合（器は%s個に減る）。' % (n_(x4v), n_(e4a_nolo), n_(A4['lo']), n_(A4['d']), n_(y4m)),
        'y1': 'よくある誤り：%s個は下限を入れない場合、%s個は成形の制約を見落とし、絵付けだけで器の数を決めた場合（成形が%s時間必要になり、上限を超える）、%s個は皿を上限まで納めた場合。'
              % (n_(y4v), n_(y4f), n_(A4['a'] * x4f + B4['a'] * y4f), n_(y4m)),
        'op1': 'よくある誤り：%s円は下限を入れていない、%s円は成形の制約を見落とした、%s円は皿を上限まで納めた場合、%s円は固定費を差し引いていない。'
               % (n_(e4a_nolo), n_(e4a_noform), n_(e4a_max), n_(e4a_nofix)),
        'op2': 'よくある誤り：%s円は、皿の赤字（1枚%s円×%s枚）がなくなるとした値。配賦された固定費は契約をやめても減らない。'
               '%s円は、絵付けの制約を見落とし、器を需要の上限%s個まで作るとした値。%s円は、器を増やせることを見落とし、皿の限界利益だけが減るとした値。%s円は、固定費を差し引いていない。'
               % (n_(e4e_full), n_(-A4['pl']), n_(x4a), n_(e4e_nopaint), n_(B4['d']), n_(e4e_nobowl), n_(e4e_nofix)),
        'ch': 'よくある誤り：やめるべきとする。全部原価の損益では皿は赤字だが、限界利益は1枚%s円のプラスで、契約をやめると営業利益は%s円から%s円に減る。'
              % (n_(A4['cm']), n_(op4a), n_(op4e))},
    e='【考え方】取引先との約束による最低数量（需要の下限）は、「x≧下限」という制約として加える。下限の線より左は作れなくなり、作れる範囲の角（端点）が変わる。'
      '製品の採否や組み合わせは、全部原価の損益（配賦された固定費を含む）ではなく、限界利益と制約の資源で判断する。固定費の配賦額は、生産量を変えても固定費の総額が変わらないので、判断には入れない。\n'
      + '【設問1】成形1時間当たりの限界利益は器（%s円）が皿（%s円）より大きい。成形が効いているので、皿を増やすほど器が減る。皿は下限の%s枚にし、残りの成形の時間で器を%s個作る（イ）。'
        '営業利益は%s円。\n'
      % (n_(B4['cma']), n_(A4['cma']), n_(A4['lo']), n_(y4a), n_(op4a))
      + '【設問2】契約をやめると、器は絵付けの時間（%s時間）の限りの%s個までしか増えない（ウ）。皿の限界利益%s円を失い、器の限界利益は%s円しか増えないので、営業利益は%s円に減る。'
        '皿の「1枚%s円の赤字」は配賦額%s円を含めた見かけの損益で、契約をやめても固定費は減らない。全部原価で考えると、営業利益が%s円に増えるように見えて、判断を誤る。\n'
      % (n_(HB4), n_(y4e), n_(A4['cm'] * x4a), n_(B4['cm'] * (y4e - y4a)), n_(op4e), n_(-A4['pl']), n_(A4['al']), n_(e4e_full))
      + '【設問3】下限がなければ、最適は成形と絵付けの交点（ア：皿%s枚・器%s個。営業利益%s円）。下限の%s枚までの%s枚は、成形の時間を器から奪う。'
        '皿1枚で成形%s時間を使い、器%s個分（限界利益%s円）を失うので、1枚当たり%s−%s＝%s円の減益で、月%s円になる。'
        '契約を続けるなら、下限を%s枚以下に下げるか、その枚数を超える分の単価を%s円以上上げるよう求める（解答はどちらか一方を、理由とともに書けばよい）。\n'
      % (n_(x4v), n_(y4v), n_(op4v), n_(A4['lo']), n_(A4['lo'] - x4v), dx(A4['a']), dx(A4['a'] / B4['a']), n_(B4['cm'] * A4['a'] / B4['a']),
         n_(B4['cm'] * A4['a'] / B4['a']), n_(A4['cm']), n_(cost4), n_(op4v - op4a), n_(x4v), n_(cost4))
      + '【本試験での注意】令和元〜6年度に、需要の下限を制約として入れる設問はないが、令和6年度第2問設問2は、取引先の最低数量の希望を価格で満たす形で問うた（この分野の2問目と同じ型）。'
        '下限は「≧」の制約で、作れる範囲を狭める。令和4年度第2問のように、共通固定費は製品に配賦せず、限界利益で組み合わせを決めてから差し引く。'
        '表に配賦後の損益があっても、意思決定には限界利益を使う。\n'
      + '【図】上は、1個当たりの損益（全部原価）と限界利益。中は、制約と作れる範囲で、緑が契約のもとで作れる範囲（イが最適）、ウは契約をやめた場合、アは下限がない場合。下は、案ごとの営業利益。',
    x=_x04(),
))
