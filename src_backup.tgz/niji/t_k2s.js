// 過去問の事例を開いて撮る（解く画面と見直しの画面、明暗）。はみ出し・ページのエラー・解説の2次/1次テキストへのボタンの数を確かめる
// 使い方：node niji/t_k2s.js <pwa のフォルダ> <事例のid,…（k2-r06-1 など）|all> [撮った画面の置き場所]
//   ・DRAFT=1 でビルドした写しの pwa を渡す（本物の pwa は渡さない）
//   ・撮るもの：<id>_solve.png、<id>_review.png、<id>_review_dark.png（幅 390px、画面の全体。長いときは _2、_3 … に分けて撮る）
//   ・見直しの画面は、解答例を答えに写して開く（マス目と自己採点の表示も確かめる）
const http = require('http'), fs = require('fs'), path = require('path');
const [, , PWA, IDS, OUTD] = process.argv;
if (!PWA || !IDS) { console.error('使い方：node niji/t_k2s.js <pwa のフォルダ> <事例のid,…|all> [置き場所]'); process.exit(2); }
const ROOT = path.resolve(PWA), OUT = path.resolve(OUTD || path.join(ROOT, '..', 'shots_k2s'));
fs.mkdirSync(OUT, { recursive: true });
const idx = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', 'k2.json'), 'utf8')).cases;
const want = (IDS === 'all' ? idx.filter(c => c.has).map(c => c.id) : IDS.split(',').map(s => s.trim()));
const srv = http.createServer((q, r) => {
  const u = decodeURIComponent(q.url.split('?')[0]), f = path.join(ROOT, u === '/' ? 'index.html' : u);
  if (!f.startsWith(ROOT)) { r.writeHead(403); return r.end(); }
  try { const d = fs.readFileSync(f); const t = f.endsWith('.json') ? 'application/json' : f.endsWith('.js') ? 'text/javascript' : 'text/html'; r.writeHead(200, { 'Content-Type': t + '; charset=utf-8' }); r.end(d); }
  catch (e) { r.writeHead(404); r.end('nf'); }
});
srv.listen(0, '127.0.0.1', async () => {
  const URL0 = 'http://127.0.0.1:' + srv.address().port + '/';
  const { chromium } = require('playwright');
  const b = await chromium.launch();
  const results = [];
  for (const id of want) {
    const meta = idx.find(c => c.id === id);
    if (!meta || !meta.has) { results.push({ id, err: '中身がない（DRAFT=1 でビルドしたか、id が正しいか）' }); continue; }
    const c = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', id + '.json'), 'utf8'));
    // 解答例を答えに写す（事例Ⅰ〜Ⅲ：大問ごとの欄の通し番号のキー。事例Ⅳ：欄の k）
    const ans = {}, cnt = {};
    for (const q of c.qs) {
      if (c.j <= 3) for (const f of q.fields) { const n = cnt[q.dai] || 0; cnt[q.dai] = n + 1; ans[q.dai + '-' + n] = q.model[f.k]; }
      else for (const pt of q.parts) for (const f of pt.fields) {
        if (f.type === 'num') ans[f.k] = String(f.ans);
        else if (f.type === 'text') ans[f.k] = f.model;
        else if (f.type === 'choice') ans[f.k] = f.ans;
        else if (f.type === 'ind') { const nm = Object.keys(f.accept)[0]; ans[f.k + '_n'] = nm; ans[f.k + '_v'] = String(f.accept[nm].v); }
      }
    }
    const res = { id };
    for (const mode of ['solve', 'review', 'review_dark']) {
      const dark = mode === 'review_dark';
      const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, colorScheme: dark ? 'dark' : 'light', serviceWorkers: 'block' });
      await ctx.addInitScript(([cid, a, rev]) => {
        try {
          localStorage.setItem('shindan1-stage', 's2');
          if (rev) localStorage.setItem('shindan2', JSON.stringify({ k2: { [cid]: { a, m: {}, t: { s: 0, e: 4200000 }, done: Date.now(), sc: {}, ai: {}, at: Date.now() } } }));
        } catch (e) {}
      }, [id, ans, mode !== 'solve']);
      const pg = await ctx.newPage(), errs = [];
      pg.on('pageerror', e => errs.push(e.message));
      await pg.goto(URL0); await pg.waitForTimeout(900);
      await pg.click('[data-tab="jkako"]'); await pg.waitForTimeout(400);
      await pg.click(`[data-act="k2-open"][data-id="${id}"]`); await pg.waitForTimeout(900);
      const info = await pg.evaluate(() => {
        const m = document.getElementById('main');
        return {
          over: Math.max(document.documentElement.scrollWidth, m.scrollWidth) > window.innerWidth + 1,
          figOver: [...document.querySelectorAll('.k2-e svg, .tx-sec svg')].filter(s => s.getBoundingClientRect().right > window.innerWidth + 1).length,
          links2: document.querySelectorAll('[data-act="k2-jt"]').length, links1: document.querySelectorAll('[data-act="jt-1ji"]').length,
          dead: [...document.querySelectorAll('.k2-e .fine')].filter(p => /^[12]次テキスト：/.test(p.textContent)).map(p => p.textContent),
          okMarks: document.querySelectorAll('.d4-mk.ok').length, ngMarks: document.querySelectorAll('.d4-mk.ng').length,
          overCount: document.querySelectorAll('.ex-count.over').length,
        };
      });
      // 画面が長いときは、#main を送りながら分けて撮る（1枚は高さ 14000px まで。2枚目からは <id>_<mode>_2.png …）
      const h = await pg.evaluate(() => document.getElementById('main').scrollHeight + 260);
      const H = Math.min(h, 14000);
      await pg.setViewportSize({ width: 390, height: H }); await pg.waitForTimeout(150);
      await pg.screenshot({ path: path.join(OUT, id + '_' + mode + '.png') });
      const vis = await pg.evaluate(() => document.getElementById('main').clientHeight);
      for (let k = 2, top = vis - 200; h > H && top < h - 400; k++, top += vis - 200) {
        await pg.evaluate((t) => { document.getElementById('main').scrollTop = t; }, top); await pg.waitForTimeout(120);
        await pg.screenshot({ path: path.join(OUT, id + '_' + mode + '_' + k + '.png') });
      }
      res[mode] = info;
      const e2 = errs.filter(e => !/ERR_FAILED|fonts/.test(e)); if (e2.length) res['errors_' + mode] = e2;
      await ctx.close();
    }
    const rv = res.review;
    res.ok = !res.solve.over && !rv.over && !res.review_dark.over && !rv.figOver && !rv.dead.length && !rv.ngMarks && !rv.overCount && !res.errors_solve && !res.errors_review && !res.errors_review_dark;
    results.push(res);
  }
  await b.close(); srv.close();
  console.log(JSON.stringify({ out: OUT, results }, null, 1));
});
