// 2次のテキストの節を開いて撮る（明暗）。はみ出し・ページのエラー・1次のテキストへのボタンの数を確かめる
// 使い方：node niji/t_jt.js <pwa のフォルダ> <節のid,…|all|名前（j_common など）> [撮った画面の置き場所]
//   ・pwa のフォルダを自分で配信する。本物の pwa ではなく、写しの pwa を渡すこと
//   ・撮るもの：<節のid>.png（明るい）、<節のid>_dark.png（暗い）。幅 390px、節の全体
const http = require('http'), fs = require('fs'), path = require('path');
const [, , PWA, IDS, OUTD] = process.argv;
if (!PWA || !IDS) { console.error('使い方：node niji/t_jt.js <pwa のフォルダ> <節のid,…|all|j_common など> [置き場所]'); process.exit(2); }
const ROOT = path.resolve(PWA), OUT = path.resolve(OUTD || path.join(ROOT, '..', 'shots_jt'));
fs.mkdirSync(OUT, { recursive: true });
const FILES = ['j_common', 'j1', 'j2', 'j3', 'j4_text'];
const all = [];
for (const f of FILES) {
  const d = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', f + '.json'), 'utf8'));
  for (const c of d.chapters) for (const s of c.sections) all.push({ f, id: s.id, links: (s.content.match(/^【1次】/mg) || []).length });
}
const want = IDS === 'all' ? all : FILES.includes(IDS) ? all.filter(x => x.f === IDS) : IDS.split(',').map(i => all.find(x => x.id === i.trim()) || { id: i.trim(), missing: true });
const srv = http.createServer((q, r) => {
  const u = decodeURIComponent(q.url.split('?')[0]), f = path.join(ROOT, u === '/' ? 'index.html' : u);
  if (!f.startsWith(ROOT)) { r.writeHead(403); return r.end(); }
  try { const d = fs.readFileSync(f); const t = f.endsWith('.json') ? 'application/json' : f.endsWith('.js') ? 'text/javascript' : f.endsWith('.png') ? 'image/png' : 'text/html'; r.writeHead(200, { 'Content-Type': t + '; charset=utf-8' }); r.end(d); }
  catch (e) { r.writeHead(404); r.end('nf'); }
});
srv.listen(0, '127.0.0.1', async () => {
  const URL0 = 'http://127.0.0.1:' + srv.address().port + '/';
  const { chromium } = require('playwright');
  const b = await chromium.launch();
  const results = [];
  for (const x of want) {
    if (x.missing) { results.push({ id: x.id, err: 'データにない（DRAFT=1 でビルドしたか）' }); continue; }
    const res = { id: x.id };
    for (const scheme of ['light', 'dark']) {
      const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, colorScheme: scheme, serviceWorkers: 'block' });
      await ctx.addInitScript(() => { try { localStorage.setItem('shindan1-stage', 's2'); } catch (e) {} });
      const pg = await ctx.newPage(), errs = [];
      pg.on('pageerror', e => errs.push(e.message));
      await pg.goto(URL0); await pg.waitForTimeout(1000);
      await pg.click('[data-tab="jtext"]'); await pg.waitForTimeout(300);
      await pg.click(`[data-act="jt-sec"][data-sec="${x.id}"]`); await pg.waitForTimeout(300);
      const info = await pg.evaluate(() => {
        const m = document.getElementById('main'), sec = document.querySelector('.tx-sec');
        const over = Math.max(document.documentElement.scrollWidth, m.scrollWidth) > window.innerWidth + 1;
        const figs = [...document.querySelectorAll('.tx-sec svg')];
        const figOver = figs.filter(s => s.getBoundingClientRect().width > sec.getBoundingClientRect().width + 1).length;
        return { over, figs: figs.length, figOver, links: document.querySelectorAll('.tx-sec .tx-link').length, deadLinks: [...document.querySelectorAll('.tx-sec .fine')].filter(p => /^1次テキスト：/.test(p.textContent)).length };
      });
      const h = await pg.evaluate(() => document.getElementById('main').scrollHeight + 200);
      await pg.setViewportSize({ width: 390, height: Math.min(h, 14000) }); await pg.waitForTimeout(150);
      await pg.screenshot({ path: path.join(OUT, x.id + (scheme === 'dark' ? '_dark' : '') + '.png') });
      res['overflow_' + scheme] = info.over;
      if (scheme === 'light') { res.figs = info.figs; res.figOver = info.figOver; res.links = info.links; res.deadLinks = info.deadLinks; res.linkLines = x.links; }
      const e2 = errs.filter(e => !/ERR_FAILED|fonts/.test(e)); if (e2.length) res['errors_' + scheme] = e2;
      await ctx.close();
    }
    res.ok = !res.overflow_light && !res.overflow_dark && !res.figOver && !res.deadLinks && !res.errors_light && !res.errors_dark;
    results.push(res);
  }
  await b.close(); srv.close();
  console.log(JSON.stringify({ out: OUT, results }, null, 1));
});
