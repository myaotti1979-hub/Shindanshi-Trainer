#!/usr/bin/env python3
"""2次の中身（テキスト・記述式演習・事例Ⅳドリル）を pwa/data/ に書き出す。

・元のデータは niji/src/ にある。検証が済んだ id（niji/verified.json）だけを書き出す。
  DRAFT=1 のときは、検証前のものも含めてすべて書き出す（写しの中で画面を確かめる用。公開には使わない）。
・書き出し先は、このファイルの場所から見た ../pwa/data（写しの中で実行すれば、写しに書く）。リポジトリには書かない。
・事例Ⅳドリルの本番形式の問題（niji/src/drill/d4_*.py の P）は、形を確かめてから書き出す。形の誤りがあれば止まる。

使い方：python3 niji/build.py        （公開用）
        DRAFT=1 python3 niji/build.py（検証前のものも含める）
"""
import json, os, glob, sys, re, importlib.util

N = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.normpath(os.path.join(N, '..', 'pwa', 'data'))
DRAFT = os.environ.get('DRAFT') == '1'

def load(p):
    with open(p, encoding='utf-8') as f:
        return json.load(f)

OUTS = {}
def dump(obj, name):
    if DRAFT:
        obj['draft'] = True   # 下書きの印。publish_sync.sh は、この印のあるファイルを公開しない
    OUTS[name] = obj   # 書き出すのは最後（形の誤りがなければ。DRAFT=1 のときは誤りがあっても書く）

V = load(os.path.join(N, 'verified.json'))
def ok(kind, i):
    return DRAFT or i in set(V.get(kind, []))

errs = []
ERRS_ALL = errs   # chk_new が足す先（過去問の事例Ⅳでは、足した分を事例ごとの一覧へ移す）
summary = []

# ---------- テキスト ----------
# 元のデータは niji/src/text/<name>.py（CH：章のリスト、FIG：その本文の図）があればそれを、なければ <name>.json を使う。
# 本文の独立した行「[[図:名前]]」は、FIG（なければ text/fig_*.py の図）の SVG に置き換える。
# 「【1次】<節のid>|<見出し>」の行は、1次のテキスト（pwa/data/t_<科目>.json）にその節があるかを確かめる。
sys.path.insert(0, os.path.normpath(os.path.join(N, '..', 'text')))
_GFIG = None
def gfig():
    global _GFIG
    if _GFIG is None:
        _GFIG = {}
        for f in sorted(glob.glob(os.path.normpath(os.path.join(N, '..', 'text', 'fig_*.py')))):
            if os.path.basename(f).startswith('fig_mk_'):
                continue
            spec = importlib.util.spec_from_file_location('nijifig_' + os.path.basename(f)[:-3], f)
            m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
            _GFIG.update(getattr(m, 'FIG', {}))
    return _GFIG
_T1 = {}
def t1(subj):
    if subj not in _T1:
        p1 = os.path.join(OUT, 't_%s.json' % subj)
        ids = set()
        if os.path.exists(p1):
            for c in load(p1)['chapters']:
                for x in c['sections']:
                    ids.add(x['id'])
        _T1[subj] = ids
    return _T1[subj]
FIG_RE = re.compile(r'^\[\[図:([^\]]+)\]\]$')
LINK_RE = re.compile(r'^【1次】([a-z]+)(\.[0-9.]+)\|(.+)$')
TEXT_IDS = set()   # 実際に使った元のデータ（.py か .json）の節の id
for name in ['j_common', 'j1', 'j2', 'j3', 'j4_text']:
    py = os.path.join(N, 'src', 'text', name + '.py')
    js = os.path.join(N, 'src', 'text', name + '.json')
    LFIG = {}
    d = None
    if os.path.exists(py):
        spec = importlib.util.spec_from_file_location('nijitext_' + name, py)
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        d = {'chapters': json.loads(json.dumps(m.CH, ensure_ascii=False))}
        LFIG = getattr(m, 'FIG', {})
        # 新しい版（.py）の節が1つも検証されていないうちは、公開用では前の版（.json）を出す（検証が済むまで、今の公開の中身を残す）
        if not DRAFT and os.path.exists(js) and not any(ok('text', x['id']) for c in d['chapters'] for x in c['sections']):
            summary.append('テキスト %-8s 新しい版（.py）は検証前なので、前の版（.json）を出す' % name)
            d = None
            LFIG = {}
    if d is None:
        d = load(js)
    for ch in d['chapters']:
        for sx in ch['sections']:
            lines = []
            for ln in str(sx.get('content', '')).split('\n'):
                mm = FIG_RE.match(ln.strip())
                if mm:
                    nm = mm.group(1)
                    svg = LFIG.get(nm) or gfig().get(nm)
                    if not svg:
                        errs.append('テキスト %s：図「%s」がない（%s）' % (name, nm, sx.get('id')))
                        continue
                    lines.append(svg.replace('\n', ''))
                    continue
                lk = LINK_RE.match(ln.strip())
                if lk and (lk.group(1) + lk.group(2)) not in t1(lk.group(1)):
                    errs.append('テキスト %s：1次のテキストに節 %s がない（%s）' % (name, lk.group(1) + lk.group(2), sx.get('id')))
                lines.append(ln)
            sx['content'] = '\n'.join(lines)
    chs = []
    tot = pub = 0
    for ch in d['chapters']:
        secs = []
        for s in ch['sections']:
            TEXT_IDS.add(s.get('id'))
            tot += 1
            for k in ('id', 'title', 'content'):
                if not s.get(k):
                    errs.append('テキスト %s：%s がない（%s）' % (name, k, s.get('id')))
            if ok('text', s['id']):
                secs.append(s); pub += 1
        if secs:
            chs.append(dict(ch, sections=secs))
    dump({'chapters': chs}, name + '.json')
    summary.append('テキスト %-8s %d/%d 節' % (name, pub, tot))

# ---------- 記述式演習 ----------
d = load(os.path.join(N, 'src', 'ex', 'j_exercise.json'))
cases = [c for c in d['cases'] if ok('ex', c['id'])]
for c in d['cases']:
    for q in c.get('questions', []):
        if len(q.get('model', [])) != q.get('count', 1):
            errs.append('演習 %s 第%s問：模範解答の数が count と合わない' % (c['id'], q.get('no')))
        for m in q.get('model', []):
            if len(m) > q.get('limit', 0):
                errs.append('演習 %s 第%s問：模範解答が %d 字で、%d 字を超える' % (c['id'], q.get('no'), len(m), q.get('limit')))
dump({'label': d.get('label', '2次 記述式演習'), 'cases': cases}, 'j_exercise.json')
summary.append('記述式演習      %d/%d 事例' % (len(cases), len(d['cases'])))

# ---------- 事例Ⅳドリル ----------
cd = load(os.path.join(N, 'src', 'drill', 'cats.json'))
catk = [c['k'] for c in cd['categories']]
RETIRE = set(cd.get('retire_mc', []))   # 本番形式の問題がそろった分野：旧形式（4択）を書き出さない
inds = cd.get('inds', [])
probs = []
for p in load(os.path.join(N, 'src', 'drill', 'j4_old.json'))['problems']:
    probs.append(p)
# 本番形式の問題：niji/src/drill/d4_<分野>.py の P（dict のリスト）。図は text/vis.py の関数で作れる
sys.path.insert(0, os.path.normpath(os.path.join(N, '..', 'text')))
for f in sorted(glob.glob(os.path.join(N, 'src', 'drill', 'd4_*.py'))):
    spec = importlib.util.spec_from_file_location('niji_' + os.path.basename(f)[:-3], f)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    for p in m.P:
        p = json.loads(json.dumps(p, ensure_ascii=False))   # JSON にできる形だけ（数値・文字列・リスト・dict）
        p['_file'] = os.path.basename(f)
        probs.append(p)

NUM_RE = re.compile(r'^-?\d+(\.\d+)?$')
def chk_new(p):
    """本番形式の問題の形を確かめる"""
    pid = p.get('id', '?')
    def e(msg): errs.append('ドリル %s：%s' % (pid, msg))
    for k in ('id', 'cat', 'lv', 'title', 'parts', 'e', 'src', 'min'):
        if k not in p: e(k + ' がない')
    if p.get('lv') not in (1, 2, 3): e('lv は 1〜3')
    if not isinstance(p.get('min'), int) or not 1 <= p.get('min', 0) <= 40: e('min（目安の分）は 1〜40 の整数')
    for t in p.get('tables', []):
        if not t.get('head') or not isinstance(t.get('rows'), list): e('表に head・rows がない')
        for r in t.get('rows', []):
            if len(r) != len(t.get('head', [])): e('表「%s」の行の列の数が見出しと合わない：%s' % (t.get('cap', ''), r))
    keys = set()
    for pi, part in enumerate(p.get('parts', [])):
        if not part.get('q'): e('設問 %d に q がない' % (pi + 1))
        auto = 0
        for fd in part.get('fields', []):
            k, ty = fd.get('k'), fd.get('type')
            if not k or k in keys: e('欄の k がない・重なる：%s' % k)
            keys.add(k)
            if not fd.get('label'): e('欄 %s に label がない' % k)
            if ty == 'num':
                auto += 1
                if not isinstance(fd.get('ans'), (int, float)): e('欄 %s：ans は数値' % k)
                if not isinstance(fd.get('dp'), int): e('欄 %s：dp（小数の桁）は整数' % k)
                for a in fd.get('alt', []):
                    if not isinstance(a, (int, float)): e('欄 %s：alt は数値' % k)
            elif ty == 'ind':
                auto += 1
                if 'grp' in fd and not fd['grp']: e('欄 %s：grp が空' % k)
                acc = fd.get('accept') or {}
                if not acc: e('欄 %s：accept（正解の指標と値）がない' % k)
                for nm, av in acc.items():
                    if inds and nm not in inds: e('欄 %s：指標「%s」が指標の一覧（cats.json の inds）にない' % (k, nm))
                    if not isinstance(av.get('v'), (int, float)) or not av.get('u'): e('欄 %s：「%s」の v（値）と u（単位）' % (k, nm))
                    for z in av.get('alt', []):
                        if not isinstance(z, (int, float)): e('欄 %s：「%s」の alt（定義の違いで割れる値）は数値' % (k, nm))
                if not isinstance(fd.get('dp'), int): e('欄 %s：dp は整数' % k)
            elif ty == 'choice':
                auto += 1
                if not fd.get('opts') or fd.get('ans') not in fd.get('opts', []): e('欄 %s：ans が opts にない' % k)
                for a in fd.get('alt', []):
                    if a not in fd.get('opts', []) or a == fd.get('ans'): e('欄 %s：alt（もう一つの正解）は ans 以外の opts の中から' % k)
            elif ty == 'text':
                lim = fd.get('limit')
                if not isinstance(lim, int) or lim <= 0: e('欄 %s：limit（字数）は正の整数' % k)
                m = fd.get('model', '')
                if not m: e('欄 %s：model（模範解答）がない' % k)
                elif isinstance(lim, int) and len(m) > lim: e('欄 %s：模範解答が %d 字で、%d 字を超える' % (k, len(m), lim))
                if not fd.get('points'): e('欄 %s：points（採点の観点）がない' % k)
            elif ty == 'proc':
                pass
            else:
                e('欄 %s：type が不明（%s）' % (k, ty))
        if auto and not part.get('steps'): e('設問 %d：計算の手順（steps）がない' % (pi + 1))
        for fd in part.get('fields', []):
            if fd.get('grp') and fd.get('type') != 'ind': e('欄 %s：grp は ind の欄だけに付ける' % fd.get('k'))
        gs = [fd['grp'] for fd in part.get('fields', []) if fd.get('grp')]
        for g in set(gs):
            if gs.count(g) < 2: e('設問 %d：grp「%s」の欄が1つしかない' % (pi + 1, g))

ids = set()
out = []
for p in probs:
    pid = p.get('id')
    if pid in ids: errs.append('ドリル %s：id が重なる' % pid)
    ids.add(pid)
    if p.get('cat') not in catk: errs.append('ドリル %s：分野 %s が cats.json にない' % (pid, p.get('cat')))
    if p.get('fmt') != 'mc':
        chk_new(p)
    if p.get('fmt') == 'mc' and p.get('cat') in RETIRE:
        continue
    if ok('drill', pid):
        q = {k: v for k, v in p.items() if not k.startswith('_')}
        out.append(q)
order = {k: i for i, k in enumerate(catk)}
out.sort(key=lambda p: (order.get(p['cat'], 99), 0 if p.get('fmt') != 'mc' else 1, p['id']))
dump({'label': cd.get('label', '事例Ⅳドリル'), 'categories': cd['categories'], 'inds': inds, 'problems': out}, 'j4_drill.json')
nn = sum(1 for p in out if p.get('fmt') != 'mc')
summary.append('事例Ⅳドリル    %d/%d 問（本番形式 %d・旧形式 %d。旧形式を外した分野：%s）' % (len(out), len(probs), nn, len(out) - nn, '・'.join(sorted(RETIRE)) or 'なし'))

# ---------- 過去問（令和元〜6年度の24事例） ----------
# 一覧（k2.json）：24事例すべて。大問・解答欄の字数・配点は、検証済みの共通編（niji/src/text/j_common.py の Q・D4）から。
# 中身（k2-r0Y-J.json：解答例・解説・採点の観点）は niji/src/kako/k2_r0Y_J.py の C。検証済み（verified.json の kako）だけ書き出す。
# 与件・設問・出題の趣旨の文章は載せない（問題PDFと出題の趣旨のPDFへのリンクだけ）。
_spec = importlib.util.spec_from_file_location('niji_jc_q', os.path.join(N, 'src', 'text', 'j_common.py'))
_jc = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(_jc)
JQ, JD4 = _jc.Q, _jc.D4
ROMAN = {1: 'Ⅰ', 2: 'Ⅱ', 3: 'Ⅲ', 4: 'Ⅳ'}
LINK2_RE = re.compile(r'^【2次】([a-z0-9_.]+)\|(.+)$')
def k2_pdf(y, j):
    yy = 2018 + y
    return 'https://www.jf-cmca.jp/attach/test/shikenmondai/2ji%d/%s' % (yy, ('%s2JI%d.pdf' % ('ABCD'[j - 1], yy)) if y >= 5 else ('%s2ji%d.pdf' % ('abcd'[j - 1], yy)))
def k2_shushi(y, j):
    if y == 1:
        return 'https://www.jf-cmca.jp/attach/test/h31/h31_2ji_shushi/r01_2ji_shushi_jirei%d.pdf' % j
    return 'https://www.jf-cmca.jp/attach/test/r%02d/2ji_shushi/r%02d_2ji_shushi_jirei%d.pdf' % (y, y, j)
def k2_lines(cid, where, txt, figs):
    """解説の行：[[図:名前]] を SVG に、【1次】【2次】のつなぎ先を確かめる"""
    out = []
    for ln in str(txt or '').split('\n'):
        mm = FIG_RE.match(ln.strip())
        if mm:
            svg = figs.get(mm.group(1)) or gfig().get(mm.group(1))
            if not svg:
                errs.append('過去問 %s %s：図「%s」がない' % (cid, where, mm.group(1))); continue
            out.append(svg.replace('\n', '')); continue
        lk = LINK_RE.match(ln.strip())
        if lk and (lk.group(1) + lk.group(2)) not in t1(lk.group(1)):
            errs.append('過去問 %s %s：1次のテキストに節 %s がない' % (cid, where, lk.group(1) + lk.group(2)))
        l2 = LINK2_RE.match(ln.strip())
        if l2 and l2.group(1) not in TEXT_IDS:
            errs.append('過去問 %s %s：2次のテキストに節 %s がない' % (cid, where, l2.group(1)))
        out.append(ln)
    return '\n'.join(out)
def chk_kako(c, cid, y, j, errs):
    def e(msg): errs.append('過去問 %s：%s' % (cid, msg))
    if c.get('id') != cid or c.get('y') != y or c.get('j') != j: e('id・y・j がファイル名と合わない')
    for k in ('theme', 'gist', 'lesson', 'qs'):
        if not c.get(k): e(k + ' がない')
    if len(str(c.get('theme', ''))) > 30: e('theme は30字まで')
    gist = c.get('gist', [])
    for g in gist:
        if len(g) > 25: e('gist の見出しは25字まで：%s' % g)
    qk = set()
    bydai = {}
    K4SEEN = set()
    for q in c.get('qs', []):
        k = q.get('k')
        if not k or k in qk: e('qs の k がない・重なる：%s' % k)
        qk.add(k)
        for x in ('h', 'dai', 'pts', 'ask', 'shushi', 'e'):
            if x not in q or q[x] in ('', None): e('%s：%s がない' % (k, x))
        if not isinstance(q.get('pts'), int) or q.get('pts', 0) <= 0: e('%s：pts は正の整数' % k)
        if len(str(q.get('shushi', ''))) > 80: e('%s：shushi は80字まで' % k)
        for b in q.get('basis', []):
            if not (isinstance(b, list) and len(b) == 2 and isinstance(b[0], int) and 1 <= b[0] <= len(gist) and b[1]):
                e('%s：basis は [gist の番号, 要点]：%s' % (k, b))
        if not q.get('basis'): e('%s：basis（与件の根拠）がない' % k)
        d = bydai.setdefault(q.get('dai'), {'pts': 0, 'lim': []})
        d['pts'] += q.get('pts', 0) if isinstance(q.get('pts'), int) else 0
        if j <= 3:
            fk = set()
            model = q.get('model') or {}
            wsum = 0
            for fd in q.get('fields', []):
                f = fd.get('k')
                if not f or f in fk: e('%s：欄の k がない・重なる：%s' % (k, f))
                fk.add(f)
                lim = fd.get('limit')
                if not isinstance(lim, int) or lim <= 0: e('%s：欄 %s の limit' % (k, f))
                if not fd.get('label'): e('%s：欄 %s に label がない' % (k, f))
                d['lim'].append(lim)
                m = model.get(f, '')
                if not m: e('%s：欄 %s の解答例がない' % (k, f))
                elif isinstance(lim, int) and len(m) > lim: e('%s：欄 %s の解答例が %d 字で、%d 字を超える' % (k, f, len(m), lim))
                elif isinstance(lim, int) and len(m) < lim * 0.7: e('%s：欄 %s の解答例が %d 字（%d 字の7割に届かない）' % (k, f, len(m), lim))
            if not q.get('fields'): e('%s：fields がない' % k)
            if set(model) - fk: e('%s：model に欄にない k：%s' % (k, sorted(set(model) - fk)))
            for pt in q.get('points', []):
                if pt.get('f') not in fk: e('%s：観点の f が欄にない：%s' % (k, pt))
                if not pt.get('t') or len(pt.get('t', '')) > 20: e('%s：観点の t は1〜20字：%s' % (k, pt.get('t')))
                if not isinstance(pt.get('w'), int) or pt.get('w', 0) <= 0: e('%s：観点の w は正の整数' % k)
                else: wsum += pt['w']
            for f in fk:
                if not any(pt.get('f') == f for pt in q.get('points', [])): e('%s：欄 %s に観点がない' % (k, f))
            if wsum != q.get('pts'): e('%s：観点の w の合計 %d が pts %s と合わない' % (k, wsum, q.get('pts')))
        else:
            # 事例Ⅳ：ドリルと同じ形の parts（chk_new で確かめる）。記述の欄の字数を集める
            # アプリは答えを欄の k で事例ごとに保存するので、k は事例の中で重ならないこと（大問をまたいでも）
            for p in q.get('parts', []):
                for fd in p.get('fields', []):
                    fk4 = fd.get('k')
                    if fk4 in K4SEEN: e('%s：欄の k「%s」がほかの大問と重なる（答えが上書きし合う）' % (k, fk4))
                    K4SEEN.add(fk4)
            pp = dict(id=cid + '/' + str(k), cat='desc', lv=2, title='-', parts=q.get('parts', []), e=q.get('e'), src='-', min=10)
            if not q.get('parts'): e('%s：parts がない' % k)
            n0 = len(ERRS_ALL)
            chk_new(pp)
            moved = ERRS_ALL[n0:]; del ERRS_ALL[n0:]; errs.extend(moved)   # errs が ERRS_ALL と同じでも、違っても正しく移る
            ps = [p.get('pts') for p in q.get('parts', []) if 'pts' in p]
            if ps and (len(ps) != len(q.get('parts', [])) or sum(ps) != q.get('pts')): e('%s：part の pts は、全部に書いて合計を大問の pts にする' % k)
            for p in q.get('parts', []):
                for fd in p.get('fields', []):
                    if fd.get('type') == 'text': d['lim'].append(fd.get('limit'))
    # 共通編の Q・D4（協会の問題PDFで数えた）と照らす
    if j <= 3:
        want = {n: (p, lims) for n, lims, p in JQ[ROMAN[j]][y]}
        for n, (p, lims) in want.items():
            got = bydai.get(n)
            if not got: e('第%d問がない' % n); continue
            if got['pts'] != p: e('第%d問：配点の合計 %d が共通編の %d と合わない' % (n, got['pts'], p))
            if got['lim'] != lims: e('第%d問：解答欄の字数 %s が共通編の %s と合わない' % (n, got['lim'], lims))
    else:
        pts4, lims4 = JD4[y]
        for n, p in enumerate(pts4, 1):
            got = bydai.get(n)
            if not got: e('第%d問がない' % n); continue
            if got['pts'] != p: e('第%d問：配点 %d が共通編の %d と合わない' % (n, got['pts'], p))
        alll = [x for n in sorted(k for k in bydai if isinstance(k, int)) for x in bydai[n]['lim']]
        if alll != lims4: e('記述の欄の字数 %s が共通編の %s と合わない' % (alll, lims4))
    extra = [n for n in bydai if not (isinstance(n, int) and 1 <= n <= (len(JQ[ROMAN[j]][y]) if j <= 3 else 4))]
    if extra: e('dai が問題にない：%s' % extra)
    if sum(q.get('pts', 0) for q in c.get('qs', []) if isinstance(q.get('pts'), int)) != 100: e('配点の合計が100でない')

KAKO_IDS = set()
kcases = []
kpub = kall = 0
for y in range(1, 7):
    for j in range(1, 5):
        cid = 'k2-r%02d-%d' % (y, j)
        meta = dict(id=cid, y=y, j=j, pdf=k2_pdf(y, j), shushi=k2_shushi(y, j))
        if j <= 3:
            meta['dai'] = [dict(no=n, pts=p, lim=lims) for n, lims, p in JQ[ROMAN[j]][y]]
        else:
            meta['dai'] = [dict(no=n, pts=p) for n, p in enumerate(JD4[y][0], 1)]
        f = os.path.join(N, 'src', 'kako', 'k2_r%02d_%d.py' % (y, j))
        if os.path.exists(f):
            kall += 1
            KAKO_IDS.add(cid)
            # 検証前の事例（公開用のとき）は、形の誤りがあっても止めずに知らせるだけ（作成中のファイルで、ほかの公開を止めない）
            kerr = errs if (DRAFT or ok('kako', cid)) else []
            try:
                spec = importlib.util.spec_from_file_location('niji_k2_%02d_%d' % (y, j), f)
                m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
                c = json.loads(json.dumps(m.C, ensure_ascii=False))
                figs = getattr(m, 'FIG', {})
            except Exception as ex:
                kerr.append('過去問 %s：ファイルが読めない（%s）' % (cid, ex))
                if kerr is not errs: summary.append('過去問 %s（検証前）：%s' % (cid, kerr[-1]))
                kcases.append(meta); continue
            chk_kako(c, cid, y, j, kerr)
            n0 = len(errs)
            for q in c.get('qs', []):
                q['e'] = k2_lines(cid, q.get('k'), q.get('e'), figs)
            if kerr is not errs:
                kerr.extend(errs[n0:]); del errs[n0:]
                if kerr: summary.append('過去問 %s（検証前・公開しない）：形の誤り %d 件' % (cid, len(kerr)))
            if ok('kako', cid):
                kpub += 1
                meta['has'] = True
                meta['theme'] = c.get('theme', '')
                dump(c, cid + '.json')
        kcases.append(meta)
dump({'cases': kcases}, 'k2.json')
summary.append('過去問          中身 %d/%d 事例（一覧は24事例。中身のファイルがあるのは %d）' % (kpub, kall, kall))

# 検証済みの一覧に、元のデータにない id があれば知らせる（消した問題の id が残っている）
known = {'text': TEXT_IDS, 'ex': {c['id'] for c in d['cases']}, 'drill': ids, 'kako': KAKO_IDS}
for kind in ('text', 'ex', 'drill', 'kako'):
    for i in V.get(kind, []):
        if i not in known[kind]:
            errs.append('verified.json の %s に、元のデータにない id：%s' % (kind, i))

if DRAFT or not errs:
    for name, obj in OUTS.items():
        with open(os.path.join(OUT, name), 'w', encoding='utf-8') as f:
            json.dump(obj, f, ensure_ascii=False, indent=1)
print(('【下書きを含む】' if DRAFT else '【公開用】') + ' 書き出し先：' + OUT + ('' if (DRAFT or not errs) else '（形の誤りがあるので書き出していない）'))
for s in summary:
    print('  ' + s)
if errs:
    print('形の誤り %d 件：' % len(errs))
    for x in errs:
        print('  - ' + x)
    sys.exit(1)
print('形の誤り：なし')
