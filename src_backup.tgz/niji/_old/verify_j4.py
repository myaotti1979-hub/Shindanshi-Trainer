raise SystemExit("使わない：2次のデータは niji/build.py で作る（このスクリプトはリポジトリに直接書き込んでいた）")
#!/usr/bin/env python3
"""Verify all j4_drill.json problems: check that answers are self-consistent."""
import json

d = json.load(open('/home/claude/shindanshi-trainer/data/j4_drill.json'))
errs = []
for p in d['problems']:
    pid = p['id']
    # Basic checks
    if p['a'] < 0 or p['a'] >= len(p['ch']):
        errs.append(f"{pid}: answer index {p['a']} out of range (choices={len(p['ch'])})")
    if len(p['ce']) != len(p['ch']):
        errs.append(f"{pid}: ce length {len(p['ce'])} != ch length {len(p['ch'])}")
    # Check that the correct answer's ce starts with ○
    if p['ce'][p['a']] and not p['ce'][p['a']].startswith('○'):
        errs.append(f"{pid}: correct answer ce doesn't start with ○: {p['ce'][p['a']][:50]}")
    # Check no other ce starts with ○
    for i, ce in enumerate(p['ce']):
        if i != p['a'] and ce.startswith('○'):
            errs.append(f"{pid}: wrong answer {i} ce starts with ○")
    # Check explanation doesn't mention problems
    if '選択肢に不備' in p['e'] or '合わない' in p['e'] or '見直す' in p['e'] or '修正' in p['e'] or '再計算' in p['e']:
        errs.append(f"{pid}: explanation mentions inconsistency: check manually")

for e in errs:
    print('ERROR:', e)
if not errs:
    print('All basic checks passed')
print(f'\nTotal: {len(d["problems"])} problems, {len(errs)} errors')
