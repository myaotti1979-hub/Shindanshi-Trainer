raise SystemExit("使わない：2次のデータは niji/build.py で作る（このスクリプトはリポジトリに直接書き込んでいた）")
#!/usr/bin/env python3
"""Build 2次試験テキスト JSON files."""
import json

def svg_table(title, headers, rows, w=400):
    """Generate SVG table."""
    rh = 24  # row height
    hdr_h = 28
    top = 30
    h = top + hdr_h + len(rows) * rh + 10
    col_w = w // len(headers)

    s = f"<svg viewBox='0 0 {w} {h}' xmlns='http://www.w3.org/2000/svg' style='font-family:Noto Sans JP,sans-serif'>"
    s += f"<text x='{w//2}' y='18' text-anchor='middle' font-size='13' font-weight='700' fill='currentColor'>{title}</text>"
    s += f"<line x1='10' y1='{top}' x2='{w-10}' y2='{top}' stroke='currentColor' stroke-width='1'/>"

    # Headers
    for i, h_text in enumerate(headers):
        x = 10 + col_w * i + col_w // 2
        s += f"<text x='{x}' y='{top + 18}' text-anchor='middle' font-size='11' font-weight='700' fill='var(--drop)'>{h_text}</text>"
    s += f"<line x1='10' y1='{top + hdr_h}' x2='{w-10}' y2='{top + hdr_h}' stroke='currentColor' stroke-width='0.5'/>"

    # Rows
    for ri, row in enumerate(rows):
        y = top + hdr_h + ri * rh + 17
        for ci, cell in enumerate(row):
            x = 10 + col_w * ci + (8 if ci == 0 else col_w // 2)
            anchor = 'start' if ci == 0 else 'middle'
            fw = ' font-weight="700"' if ci == 0 else ''
            s += f"<text x='{x}' y='{y}' text-anchor='{anchor}' font-size='11'{fw} fill='currentColor'>{cell}</text>"
        if ri < len(rows) - 1:
            ly = top + hdr_h + (ri + 1) * rh
            s += f"<line x1='10' y1='{ly}' x2='{w-10}' y2='{ly}' stroke='currentColor' stroke-width='0.3' stroke-dasharray='3 3'/>"

    s += "</svg>"
    return s


def svg_flow(title, boxes, w=400):
    """Generate horizontal flow diagram."""
    n = len(boxes)
    bw = min(90, (w - 20 - (n-1)*30) // n)
    bh = 50
    gap = 30
    total_w = n * bw + (n-1) * gap
    start_x = (w - total_w) // 2
    h = bh + 50

    s = f"<svg viewBox='0 0 {w} {h}' xmlns='http://www.w3.org/2000/svg' style='font-family:Noto Sans JP,sans-serif'>"
    s += f"<text x='{w//2}' y='16' text-anchor='middle' font-size='12' font-weight='700' fill='currentColor'>{title}</text>"

    for i, (label, sub) in enumerate(boxes):
        x = start_x + i * (bw + gap)
        y = 28
        s += f"<rect x='{x}' y='{y}' width='{bw}' height='{bh}' rx='8' fill='var(--guide-soft)' stroke='var(--guide)' stroke-width='1.5'/>"
        s += f"<text x='{x + bw//2}' y='{y + 20}' text-anchor='middle' font-size='12' font-weight='700' fill='currentColor'>{label}</text>"
        if sub:
            s += f"<text x='{x + bw//2}' y='{y + 36}' text-anchor='middle' font-size='9' fill='var(--ink-2)'>{sub}</text>"
        if i < n - 1:
            ax = x + bw + 4
            ay = y + bh // 2
            s += f"<path d='M{ax},{ay} L{ax+gap-8},{ay}' stroke='var(--drop)' stroke-width='2' fill='none'/>"
            s += f"<path d='M{ax+gap-12},{ay-4} L{ax+gap-6},{ay} L{ax+gap-12},{ay+4}' fill='var(--drop)'/>"

    s += "</svg>"
    return s


# ========== 共通テキスト ==========
common = {
    "chapters": [
        {
            "id": "j.common",
            "title": "2次試験の解き方（共通）",
            "sections": [
                {
                    "id": "j.common.process",
                    "title": "80分の解答プロセス",
                    "content": svg_flow("80分の解答プロセス", [
                        ("①設問解釈", "5〜8分"),
                        ("②与件マーク", "12〜15分"),
                        ("③骨子づくり", "15〜20分"),
                        ("④記述", "35〜40分")
                    ])
                    + "\n\n**①設問解釈**（5〜8分）\n与件文より先に設問を読む。聞かれていること、制約条件（「○○の観点から」等）、解答の型（理由・助言・課題）を整理する。\n\n**②与件文マーキング**（12〜15分）\n強み(S)＝赤線、弱み(W)＝青線、機会(O)＝赤丸、脅威(T)＝青丸でマーク。該当箇所に設問番号を振り、どの情報をどの設問に使うか対応づける。\n\n**③骨子づくり**（15〜20分）\n設問ごとに「使う与件の箇所」と「フレームの要素」を箇条書きにし、全設問の方向を決める。ここで書き始めると後戻りがなくなる。\n\n**④記述**（35〜40分）\n骨子を文章化する。1問100字なら7〜8分が目安。見直しは誤字と字数だけ。"
                },
                {
                    "id": "j.common.answer",
                    "title": "解答の書き方の原則",
                    "content": svg_table("解答の基本ルール", ["ルール", "内容", "悪い例"],
                        [
                            ["与件の言葉を使う", "与件文のキーワードをそのまま引用", "自分の言葉で言い換え"],
                            ["因果でつなぐ", "原因→施策→効果の流れ", "施策の羅列だけ"],
                            ["制約を守る", "「〜の観点から」を必ず反映", "制約を無視して自由記述"],
                            ["要素数を意識", "100字→2〜3要素が目安", "1要素で100字埋める"],
                            ["事例の枠内で書く", "事例Ⅰなら組織人事の切り口", "マーケティング施策を書く"],
                        ])
                    + "\n\n100字の解答で3要素を入れるなら「①…、②…。これにより③…。」の型が使いやすい。200字なら4〜5要素。字数の8割は必ず使い切る。"
                },
                {
                    "id": "j.common.swot",
                    "title": "SWOT分析の読み取り方",
                    "content": "<svg viewBox='0 0 400 200' xmlns='http://www.w3.org/2000/svg' style='font-family:Noto Sans JP,sans-serif'>"
                    + "<text x='200' y='18' text-anchor='middle' font-size='13' font-weight='700' fill='currentColor'>SWOT分析マトリクス</text>"
                    + "<rect x='120' y='30' width='130' height='30' rx='4' fill='var(--good-soft)' stroke='var(--good)' stroke-width='1'/>"
                    + "<text x='185' y='50' text-anchor='middle' font-size='11' font-weight='700' fill='var(--good)'>プラス要因</text>"
                    + "<rect x='260' y='30' width='130' height='30' rx='4' fill='var(--bad-soft)' stroke='var(--bad)' stroke-width='1'/>"
                    + "<text x='325' y='50' text-anchor='middle' font-size='11' font-weight='700' fill='var(--bad)'>マイナス要因</text>"
                    + "<rect x='10' y='70' width='100' height='50' rx='4' fill='var(--guide-soft)' stroke='var(--guide)' stroke-width='1'/>"
                    + "<text x='60' y='92' text-anchor='middle' font-size='11' font-weight='700' fill='currentColor'>内部環境</text>"
                    + "<text x='60' y='108' text-anchor='middle' font-size='9' fill='var(--ink-2)'>自社でコントロール可</text>"
                    + "<rect x='120' y='70' width='130' height='50' rx='8' fill='var(--good-soft)' stroke='var(--good)' stroke-width='1.5'/>"
                    + "<text x='185' y='95' text-anchor='middle' font-size='14' font-weight='900' fill='var(--good)'>S：強み</text>"
                    + "<text x='185' y='112' text-anchor='middle' font-size='9' fill='var(--ink-2)'>技術力、ブランド、人材</text>"
                    + "<rect x='260' y='70' width='130' height='50' rx='8' fill='var(--bad-soft)' stroke='var(--bad)' stroke-width='1.5'/>"
                    + "<text x='325' y='95' text-anchor='middle' font-size='14' font-weight='900' fill='var(--bad)'>W：弱み</text>"
                    + "<text x='325' y='112' text-anchor='middle' font-size='9' fill='var(--ink-2)'>資金不足、属人化</text>"
                    + "<rect x='10' y='130' width='100' height='50' rx='4' fill='var(--guide-soft)' stroke='var(--guide)' stroke-width='1'/>"
                    + "<text x='60' y='152' text-anchor='middle' font-size='11' font-weight='700' fill='currentColor'>外部環境</text>"
                    + "<text x='60' y='168' text-anchor='middle' font-size='9' fill='var(--ink-2)'>自社でコントロール不可</text>"
                    + "<rect x='120' y='130' width='130' height='50' rx='8' fill='var(--good-soft)' stroke='var(--good)' stroke-width='1.5'/>"
                    + "<text x='185' y='155' text-anchor='middle' font-size='14' font-weight='900' fill='var(--good)'>O：機会</text>"
                    + "<text x='185' y='172' text-anchor='middle' font-size='9' fill='var(--ink-2)'>市場拡大、規制緩和</text>"
                    + "<rect x='260' y='130' width='130' height='50' rx='8' fill='var(--bad-soft)' stroke='var(--bad)' stroke-width='1.5'/>"
                    + "<text x='325' y='155' text-anchor='middle' font-size='14' font-weight='900' fill='var(--bad)'>T：脅威</text>"
                    + "<text x='325' y='172' text-anchor='middle' font-size='9' fill='var(--ink-2)'>競合参入、原材料高騰</text>"
                    + "</svg>"
                    + "\n\n与件文の読み方：\n- 「〜に定評がある」「長年の〜」→ 強み(S)\n- 「〜ができていない」「〜が不足」→ 弱み(W)\n- 「〜の需要が増加」「〜が注目」→ 機会(O)\n- 「〜の参入が相次ぐ」「〜が高騰」→ 脅威(T)"
                }
            ]
        }
    ]
}

# ========== 事例Ⅰ ==========
jirei1 = {
    "chapters": [
        {
            "id": "j1.framework",
            "title": "事例Ⅰの解法フレームワーク",
            "sections": [
                {
                    "id": "j1.framework.overview",
                    "title": "事例Ⅰの全体像",
                    "content": "事例Ⅰは**組織（人事を含む）を中心とした経営の戦略及び管理に関する事例**。対象は従業員100名前後の中小企業が多い。すべての解答を「組織・人事」の切り口で書くことが最重要ルール。マーケティングや生産の施策は事例Ⅱ・Ⅲの領域であり、事例Ⅰでは加点されない。\n\n"
                    + svg_table("事例Ⅰの設問パターン", ["パターン", "問われること", "解答の方向"],
                        [
                            ["過去の分析", "成功・失敗の要因", "与件文から根拠を引用"],
                            ["現在の分析", "強み・弱み、課題", "過去→現在の変化を読む"],
                            ["将来の助言", "組織・人事の対策", "問題→施策→効果の型"],
                        ])
                },
                {
                    "id": "j1.framework.sachinohimo",
                    "title": "「さちのひもけぶかいねこ」フレームワーク",
                    "content": svg_table("さちのひもけぶかいねこ", ["記号", "人事施策", "典型的な提案"],
                        [
                            ["さ", "採用・配置", "中途採用、適材適所の配置転換"],
                            ["ち", "賃金・報酬", "成果連動報酬、インセンティブ制度"],
                            ["の", "能力開発", "OJT、OFF-JT、資格取得支援"],
                            ["ひ", "評価", "明確な評価基準、目標管理制度（MBO）"],
                            ["も", "モチベーション", "権限委譲、表彰制度、キャリアパス"],
                        ], w=420)
                    + "\n"
                    + svg_table("", ["記号", "組織施策", "典型的な提案"],
                        [
                            ["け", "権限委譲", "部門長への意思決定権限の移譲"],
                            ["ぶ", "部門", "事業部制、プロジェクトチーム編成"],
                            ["かい", "階層", "フラット化、ミドル層の育成"],
                            ["ね", "ネットワーク", "部門横断の情報共有の仕組み"],
                            ["こ", "コミュニケーション", "定例会議、ジョブローテーション"],
                        ], w=420)
                    + "\n\n使い方：設問を読んだら全10要素を当てはめ、与件に根拠がある要素だけを解答に使う。根拠のない要素は書かない。"
                },
                {
                    "id": "j1.framework.patterns",
                    "title": "頻出の「問題→施策→効果」パターン",
                    "content": svg_table("事例Ⅰ 頻出パターン", ["問題", "施策", "効果"],
                        [
                            ["経営者への権限集中", "部門長に権限委譲", "迅速な意思決定、経営者の負担軽減"],
                            ["部門間の連携不足", "ジョブローテーション導入", "相互理解の促進、組織の一体感"],
                            ["技術・ノウハウの属人化", "マニュアル化＋OJT体制", "技術承継、組織知識の共有化"],
                            ["社員のモチベーション低下", "明確な評価基準＋成果報酬", "士気向上、優秀人材の定着"],
                            ["新規事業の推進力不足", "プロジェクトチーム編成", "部門横断で迅速に推進"],
                            ["後継者不在・経営層薄い", "次世代リーダーの計画的育成", "事業承継の円滑化"],
                        ], w=440)
                }
            ]
        }
    ]
}

# ========== 事例Ⅱ ==========
jirei2 = {
    "chapters": [
        {
            "id": "j2.framework",
            "title": "事例Ⅱの解法フレームワーク",
            "sections": [
                {
                    "id": "j2.framework.overview",
                    "title": "事例Ⅱの全体像",
                    "content": "事例Ⅱは**マーケティング・流通を中心とした経営の戦略及び管理に関する事例**。対象は従業員10名未満の小規模企業（小売・サービス業）が多い。与件文は4科目中最も長く、末尾に統計データや図表が付くことがある。\n\n"
                    + svg_flow("事例Ⅱの解答フレーム「ダナドコ」", [
                        ("誰に", "ターゲット"),
                        ("何を", "強み×価値"),
                        ("どのように", "施策"),
                        ("効果", "売上・関係性"),
                    ])
                    + "\n\nターゲットの選定を誤ると後続の解答が全て崩れる。与件文の顧客属性（年齢・地域・ニーズ）を丁寧に読み取ることが最重要。"
                },
                {
                    "id": "j2.framework.danadoko",
                    "title": "「ダナドコ」フレームワーク詳細",
                    "content": svg_table("ダナドコの各要素", ["要素", "内容", "与件文での探し方"],
                        [
                            ["誰に（ダ）", "ターゲット顧客の特定", "人口構成、来店客の属性、ニーズの記述"],
                            ["何を（ナ）", "提供する価値・商品", "企業の強み×顧客ニーズの交点"],
                            ["どのように（ド）", "具体的な施策", "プロモーション、チャネル、連携"],
                            ["効果（コ）", "売上向上・関係性強化", "施策の帰結を明示する"],
                        ], w=440)
                    + "\n\n注意点：\n- 小規模企業は経営資源が限られるため、大企業のような大規模施策は提案しない\n- 「地域密着」「顧客との関係性強化」「口コミ」が定番の方向性\n- SNSやWebの活用は近年の頻出テーマだが、与件に根拠があるときだけ書く"
                },
                {
                    "id": "j2.framework.patterns",
                    "title": "頻出の施策パターン",
                    "content": svg_table("事例Ⅱ 頻出施策", ["施策", "内容", "与件のヒント"],
                        [
                            ["ターゲット絞り込み", "ジオ・デモ・サイコで顧客層を特定", "「〜が増加」「〜のニーズ」"],
                            ["品揃え・メニュー拡充", "強みを活かした高付加価値化", "「〜に定評」「〜の技術」"],
                            ["顧客関係性の強化", "ポイントカード、会員制度、DM", "「リピーターが多い」「固定客」"],
                            ["地域連携", "商店街・観光協会・農家等との協業", "「地域の〜」「近隣の〜」"],
                            ["Web・SNS活用", "HP、Instagram、口コミ促進", "「若年層」「情報発信が不足」"],
                            ["体験型サービス", "ワークショップ、試食、イベント", "「〜の体験」「交流」"],
                        ], w=440)
                }
            ]
        }
    ]
}

# ========== 事例Ⅲ ==========
jirei3 = {
    "chapters": [
        {
            "id": "j3.framework",
            "title": "事例Ⅲの解法フレームワーク",
            "sections": [
                {
                    "id": "j3.framework.overview",
                    "title": "事例Ⅲの全体像",
                    "content": "事例Ⅲは**生産・技術を中心とした経営の戦略及び管理に関する事例**。対象はメーカー（製造業）が中心。設問は「強み弱み」「問題と対応策」「今後の戦略」の3パターンがほぼ毎年出る。与件の「〜していない」「〜が属人化」は改善提案の根拠になる。\n\n"
                    + svg_table("事例Ⅲの設問パターン", ["パターン", "配点目安", "解答の方向"],
                        [
                            ["強み・弱み", "15〜20点", "与件から技術力・設備・人材を抽出"],
                            ["問題点と対応策", "30〜40点", "QCD改善の具体策を提案"],
                            ["今後の戦略", "20〜30点", "強みを活かした新規展開の助言"],
                        ])
                },
                {
                    "id": "j3.framework.drink",
                    "title": "DRINK（IT・情報活用フレームワーク）",
                    "content": svg_table("DRINK", ["記号", "施策", "具体例"],
                        [
                            ["D", "データベース化", "顧客・受注・在庫情報のDB構築"],
                            ["R", "リアルタイム化", "生産進捗・在庫のリアルタイム把握"],
                            ["I", "一元管理", "受注〜出荷の情報を一元管理"],
                            ["N", "ネットワーク化", "部門間・取引先とのネットワーク共有"],
                            ["K", "共有化", "ベテランのノウハウ・技術の共有"],
                        ])
                    + "\n\nIT化の設問では「導入するシステム名」ではなく「何をどう改善するか」を書く。与件に具体的なシステムの記載があればそれを使う。"
                },
                {
                    "id": "j3.framework.production",
                    "title": "生産改善の定番パターン",
                    "content": svg_table("生産改善パターン", ["課題", "対応策", "効果"],
                        [
                            ["生産計画が場当たり的", "全工程の一貫した計画策定", "納期遵守率向上"],
                            ["段取り替えに時間がかかる", "内段取りの外段取り化", "稼働率向上、リードタイム短縮"],
                            ["作業が属人化している", "標準化・マニュアル化＋OJT", "品質安定、多能工化"],
                            ["不良率が高い", "QC活動・小集団活動の導入", "歩留まり向上、コスト削減"],
                            ["在庫が過大", "生産計画の短サイクル化", "在庫削減、キャッシュフロー改善"],
                            ["レイアウトが非効率", "SLP（体系的レイアウト計画）", "動線短縮、生産性向上"],
                        ], w=440)
                    + "\n\n生産管理の3機能（計画・統制・改善）のどれが弱いかを見極めてから対応策を書く。"
                }
            ]
        }
    ]
}

# ========== 事例Ⅳ（テキスト版） ==========
jirei4 = {
    "chapters": [
        {
            "id": "j4.framework",
            "title": "事例Ⅳの解法フレームワーク",
            "sections": [
                {
                    "id": "j4.framework.structure",
                    "title": "事例Ⅳの出題構造",
                    "content": svg_table("事例Ⅳの定番構造（19年分の実績）", ["大問", "頻出論点", "配点目安", "出題率"],
                        [
                            ["第1問", "経営分析（指標＋記述）", "25点前後", "19/19年"],
                            ["第2問", "CVP・セールスミックス", "20〜30点", "12/19年"],
                            ["第3問", "NPV・投資意思決定", "25〜30点", "17/19年"],
                            ["第4問", "記述（リスク・資金調達等）", "20〜25点", "14/19年"],
                        ])
                    + "\n\n経営分析＋NPVで毎年約60点が配分される。この2つを確実に得点することが合格の最短ルート。"
                },
                {
                    "id": "j4.framework.mgmt",
                    "title": "経営分析の解法手順",
                    "content": svg_flow("経営分析の解法", [
                        ("①与件を読む", "業種・課題把握"),
                        ("②指標を計算", "収益性・効率性・安全性"),
                        ("③3指標を選ぶ", "与件の根拠で絞る"),
                        ("④記述", "特徴を80字で"),
                    ])
                    + "\n\n"
                    + svg_table("頻出指標一覧", ["分野", "指標", "計算式"],
                        [
                            ["収益性", "売上高営業利益率", "営業利益÷売上高×100"],
                            ["収益性", "売上高経常利益率", "経常利益÷売上高×100"],
                            ["効率性", "有形固定資産回転率", "売上高÷有形固定資産"],
                            ["効率性", "棚卸資産回転率", "売上高÷棚卸資産"],
                            ["効率性", "売上債権回転率", "売上高÷売上債権"],
                            ["安全性", "自己資本比率", "純資産÷総資産×100"],
                            ["安全性", "流動比率", "流動資産÷流動負債×100"],
                            ["安全性", "当座比率", "当座資産÷流動負債×100"],
                            ["安全性", "負債比率", "負債÷純資産×100"],
                        ], w=440)
                    + "\n\n指標は計算で出るが、**どの指標を選ぶかは与件文が決める**。「設備投資をした」→有形固定資産回転率、「在庫が増えた」→棚卸資産回転率。"
                },
                {
                    "id": "j4.framework.npv",
                    "title": "NPV計算の手順",
                    "content": svg_flow("NPV計算のステップ", [
                        ("①初期投資", "設備＋運転資本"),
                        ("②年間CF", "利益+償却費"),
                        ("③現在価値", "係数で割引"),
                        ("④NPV判定", "＞0なら投資"),
                    ])
                    + "\n\n"
                    + svg_table("年間CFの計算（2つの公式）", ["公式", "計算式"],
                        [
                            ["公式A（利益ベース）", "税引後利益＋減価償却費"],
                            ["公式B（CF直接法）", "(売上増−現金支出増)×(1−税率)＋減価償却費×税率"],
                        ], w=440)
                    + "\n\n取替投資の注意点：\n- 旧設備の帳簿価額＝取得原価−累計償却額\n- 売却損＝帳簿価額−売却額 → 節税効果＝売却損×税率\n- 運転資本の増減は発生時と回収時の両方でCFに影響\n- 据置年金：年金現価係数×複利現価係数で据え置いた分を割引く"
                }
            ]
        }
    ]
}

# Save all files
for name, data in [('j_common', common), ('j1', jirei1), ('j2', jirei2), ('j3', jirei3), ('j4_text', jirei4)]:
    path = f'/home/claude/shindanshi-trainer/data/{name}.json'
    json.dump(data, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    secs = sum(len(c['sections']) for c in data['chapters'])
    print(f'{name}.json: {len(data["chapters"])} chapters, {secs} sections')

print('\nAll files written.')
