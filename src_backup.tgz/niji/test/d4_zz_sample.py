# 画面の確かめ用の見本（公開しない。niji/src/drill には置かない）。本番形式の問題の書き方の例も兼ねる
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'text'))
from vis import grid, chart

# ---- 見本1：経営分析（数値は Python の変数から作る）
D = dict(sales=2400, cogs=1800, sga=480, nonop_inc=10, interest=40, ca=900, cash=200, ar=400, inv=300, ppe=1000, invest=100, cl=700, fl=800, eq=500)
gp = D['sales'] - D['cogs']; op = gp - D['sga']; ordi = op + D['nonop_inc'] - D['interest']
ta = D['ca'] + D['ppe'] + D['invest']
r2 = lambda x: round(x + 1e-9, 2)
ind = {
    '売上高総利益率': r2(gp / D['sales'] * 100), '売上高営業利益率': r2(op / D['sales'] * 100), '売上高経常利益率': r2(ordi / D['sales'] * 100),
    '有形固定資産回転率': r2(D['sales'] / D['ppe']), '棚卸資産回転率': r2(D['sales'] / D['inv']),
    '自己資本比率': r2(D['eq'] / ta * 100), '流動比率': r2(D['ca'] / D['cl'] * 100), '負債比率': r2((D['cl'] + D['fl']) / D['eq'] * 100),
}
SAMPLE1 = dict(
    id='d4-zz-01', cat='mgmt', lv=2, min=15, src='見本', title='見本：課題と強みを示す指標',
    lead='D社は地方の食品製造業である。D社と同業他社の当期の財務諸表は次のとおりである（期末の値を用いる）。',
    tables=[dict(cap='D社の損益計算書（当期）', unit='百万円', head=['科目', 'D社'],
                 rows=[['売上高', f"{D['sales']:,}"], ['売上原価', f"{D['cogs']:,}"], ['売上総利益', f'{gp:,}'], ['販売費及び一般管理費', f"{D['sga']:,}"],
                       ['営業利益', f'{op:,}'], ['営業外収益', f"{D['nonop_inc']:,}"], ['営業外費用（支払利息）', f"{D['interest']:,}"], ['経常利益', f'{ordi:,}']]),
            dict(cap='同業他社の指標（当期）', head=['指標', '同業他社'],
                 rows=[['売上高総利益率', '28.00%'], ['売上高営業利益率', '7.00%'], ['有形固定資産回転率', '3.20回'], ['自己資本比率', '40.00%']])],
    parts=[dict(h='設問1', q='D社の課題を示す指標を2つ、優れている指標を1つ挙げ、その値を求めよ（小数第3位を四捨五入）。',
                fields=[dict(k='i1', type='ind', label='課題①', dp=2, accept={'売上高営業利益率': dict(v=ind['売上高営業利益率'], u='%'), '売上高経常利益率': dict(v=ind['売上高経常利益率'], u='%')}),
                        dict(k='i2', type='ind', label='課題②', dp=2, accept={'自己資本比率': dict(v=ind['自己資本比率'], u='%'), '負債比率': dict(v=ind['負債比率'], u='%')}),
                        dict(k='i3', type='ind', label='優れている指標', dp=2, accept={'棚卸資産回転率': dict(v=ind['棚卸資産回転率'], u='回')})],
                steps=['売上高営業利益率＝%d÷%s×100＝%.2f%%' % (op, f"{D['sales']:,}", ind['売上高営業利益率']), '自己資本比率＝%d÷%s×100＝%.2f%%' % (D['eq'], f'{ta:,}', ind['自己資本比率'])]),
           dict(h='設問2', q='D社の財務的な特徴と課題を60字以内で述べよ。',
                fields=[dict(k='t2', type='text', label='解答', limit=60, model='在庫の効率は高いが、販管費の負担で収益性が低く、借入への依存で安全性も低い。', points=['在庫の効率が高い', '収益性が低い', '安全性が低い'])])],
    ce={'i1': '売上高総利益率は同業より低いが、課題の中心は販管費を含む営業段階の収益性'},
    e='見本の解説です。\n2行目の段落です。',
    x=grid(['指標', 'D社', '同業他社'], [['売上高営業利益率', '%.2f%%' % ind['売上高営業利益率'], '7.00%'], ['自己資本比率', '%.2f%%' % ind['自己資本比率'], '40.00%']], (130, 80, 90), title='見本の表'),
)

# ---- 見本2：CVP（num・proc・choice）
S, V, F = 1200, 720, 384
bep = F / (1 - V / S)
SAMPLE2 = dict(
    id='d4-zz-02', cat='cvp', lv=1, min=8, src='見本', title='見本：損益分岐点と安全余裕率',
    lead='D社の当期の売上高は1,200百万円、変動費は720百万円、固定費は384百万円である。',
    parts=[dict(h='設問1', q='損益分岐点売上高と安全余裕率を求めよ（損益分岐点売上高は百万円未満、安全余裕率は小数第3位を四捨五入）。',
                fields=[dict(k='bep', type='num', label='損益分岐点売上高', unit='百万円', dp=0, ans=round(bep)),
                        dict(k='ms', type='num', label='安全余裕率', unit='%', dp=2, ans=round((S - bep) / S * 100, 2)),
                        dict(k='p1', type='proc', label='計算過程')],
                steps=['変動費率＝720÷1,200＝0.6', '損益分岐点売上高＝384÷(1−0.6)＝960百万円', '安全余裕率＝(1,200−960)÷1,200×100＝20.00%']),
           dict(h='設問2', q='固定費が減ると、損益分岐点売上高はどうなるか。',
                fields=[dict(k='c2', type='choice', label='損益分岐点売上高', opts=['上がる', '下がる', '変わらない'], ans='下がる')],
                steps=['損益分岐点売上高＝固定費÷限界利益率なので、固定費が減ると下がる'])],
    ce={'bep': '固定費を変動費率で割ると640になる'},
    e='見本の解説です。',
    x=chart([([(0, 0), (1200, 1200)], 'a', False), ([(0, 384), (1200, 1104)], 'b', False)], 0, 1200, 0, 1200, xlab='売上高', ylab='金額', vlines=[(960, '損益分岐点')], title='損益分岐点図（見本）'),
)
P = [SAMPLE1, SAMPLE2]
