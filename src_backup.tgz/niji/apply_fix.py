#!/usr/bin/env python3
"""検証の結果（review/niji/<名前>.json）の直しを当て、ok・fix の id を niji/verified.json に入れる。

使い方：python3 niji/apply_fix.py review/niji/xxx.json [--dry] [--mark]
  --dry ：当てずに、当たるかだけ確かめる（old がファイルの中で1か所だけに一致するか）
  --mark：ok と fix の id を verified.json に入れる（reject は入れない。入っていれば外す）
パスは、このファイルの場所の一つ上（作業フォルダ）から見たもの。
"""
import json, os, sys

S = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
args = [a for a in sys.argv[1:] if not a.startswith('--')]
DRY, MARK = '--dry' in sys.argv, '--mark' in sys.argv
if not args:
    sys.exit(__doc__)
rv = json.load(open(args[0], encoding='utf-8'))
bad = []
texts = {}
for r in rv:
    for fx in r.get('fixes', []) or []:
        p = os.path.join(S, fx['file'])
        if p not in texts:
            texts[p] = open(p, encoding='utf-8').read()
        n = texts[p].count(fx['old'])
        if n != 1:
            bad.append('%s：%s に old が %d か所（1か所でない）：%s' % (r['id'], fx['file'], n, fx['old'][:60]))
            continue
        texts[p] = texts[p].replace(fx['old'], fx['new'])
if bad:
    print('当たらない直し：'); [print('  - ' + b) for b in bad]; sys.exit(1)
if DRY:
    print('すべて当たる（%d ファイル）' % len(texts)); sys.exit(0)
for p, t in texts.items():
    if p.endswith('.json'):
        json.loads(t)   # 壊れた JSON は書かない
    open(p, 'w', encoding='utf-8').write(t)
print('当てた：%d ファイル' % len(texts))
if MARK:
    vp = os.path.join(S, 'niji', 'verified.json')
    V = json.load(open(vp, encoding='utf-8'))
    for r in rv:
        k = r['kind']
        L = V.setdefault(k, [])
        if r['verdict'] in ('ok', 'fix') and r['id'] not in L:
            L.append(r['id'])
        if r['verdict'] == 'reject' and r['id'] in L:
            L.remove(r['id'])
    json.dump(V, open(vp, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('verified.json：' + '、'.join('%s %d' % (k, len(V.get(k, []))) for k in ('text', 'ex', 'drill', 'kako')))
