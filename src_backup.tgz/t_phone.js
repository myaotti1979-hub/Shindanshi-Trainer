// スマホ1画面分の写真。図（aria-label）を画面の上のほうに出して写す。引数: 科目 章ID 図の名前 出力名 [上の余白px] [light|dark]
const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const [s,ch,label,name,off='70',scheme='light']=process.argv.slice(2);
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:390,height:844},deviceScaleFactor:2,serviceWorkers:'block',colorScheme:scheme});
  const p=await ctx.newPage();
  await p.goto('http://127.0.0.1:8765/index.html');await p.waitForTimeout(1500);
  await p.click('[data-act=tab][data-tab=drill]');await p.waitForTimeout(120);
  await p.click('[data-act=open-syl][data-s='+s+']');await p.waitForTimeout(150);
  await p.click(`[data-act=open-text][data-ch="${ch}"]`);await p.waitForTimeout(400);
  const ok=await p.evaluate(([label,off])=>{const sv=[...document.querySelectorAll('#reader figure.tx-fig svg')].find(e=>e.getAttribute('aria-label')===label);if(!sv)return false;
    const sc=document.querySelector('#reader .p-scroll');sc.scrollTop+=sv.getBoundingClientRect().top-sc.getBoundingClientRect().top-(+off);return true;},[label,off]);
  await p.waitForTimeout(250);
  await p.screenshot({path:B+'/shots/phone-'+name+'.png'});
  console.log(name, ok);
  await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
