
(function(){
'use strict';
var APP_VER='v2';   // sw.js の VER と同じ値にする
var STORE='shindan1';

/* ---------- 定数 ---------- */
var SUBJ=[
  {k:'keizai',n:'経済学・経済政策',sh:'経済',code:'A',vol:5},
  {k:'zaimu',n:'財務・会計',sh:'財務',code:'B',vol:5},
  {k:'kigyo',n:'企業経営理論',sh:'企業',code:'C',vol:5},
  {k:'unei',n:'運営管理',sh:'運営',code:'D',vol:10},
  {k:'homu',n:'経営法務',sh:'法務',code:'E',vol:10},
  {k:'joho',n:'経営情報システム',sh:'情報',code:'F',vol:5},
  {k:'chusho',n:'中小企業経営・中小企業政策',sh:'中小',code:'G',vol:10}
];
var SN={};SUBJ.forEach(function(s){SN[s.k]=s;});
var LT=['ア','イ','ウ','エ','オ'];
var DEF={wdMin:60,weMin:180,newPerDay:15,exam1:'2027-08-07',exam2:'2027-10-24',active:['kigyo','unei','zaimu'],start:'2026-11-09'};
var PASS=60, CUT=40, DAY=864e5;
var ICON_O='<svg viewBox="0 0 40 40" width="40" height="40" aria-hidden="true"><circle cx="20" cy="20" r="13" fill="none" stroke="currentColor" stroke-width="4"/></svg>';
var ICON_X='<svg viewBox="0 0 40 40" width="40" height="40" aria-hidden="true"><path d="M10 10L30 30M30 10L10 30" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/></svg>';

/* ---------- 小道具 ---------- */
function $(s){return document.querySelector(s);}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function pad(n){return String(n).padStart(2,'0');}
function ymd(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());}
function todayKey(){return ymd(new Date());}
function parseYmd(s){var p=String(s||'').split('-').map(Number);return new Date(p[0],(p[1]||1)-1,p[2]||1);}
function startOfDay(t){var d=new Date(t);d.setHours(0,0,0,0);return d.getTime();}
function endOfToday(){var d=new Date();d.setHours(23,59,59,999);return d.getTime();}
function daysUntil(s){return Math.round((parseYmd(s).getTime()-startOfDay(Date.now()))/DAY);}
function fmtH(min){return (Math.round((min||0)/6)/10).toFixed(1);}
function md(d){return (d.getMonth()+1)+'/'+d.getDate();}
function cl(x,a,b){return Math.min(b,Math.max(a,x));}
function fmtClock(ms){var s=Math.max(0,Math.floor(ms/1000));var h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;return h?h+':'+pad(m)+':'+pad(x):pad(m)+':'+pad(x);}
function uid(p){return p+Date.now().toString(36)+Math.random().toString(36).slice(2,6);}

/* ---------- FSRS-4.5 ---------- */
var W=[0.4872,1.4003,3.7145,13.8206,5.1618,1.2298,0.8975,0.031,1.6474,0.1367,1.0461,2.1072,0.0793,0.3246,1.587,0.2272,2.8755];
var DECAY=-0.5,FACTOR=19/81,RET=0.9,MAXI=60;
function d0(g){return cl(W[4]-(g-3)*W[5],1,10);}
function fsrs(prev,g,now){
  var s,d;
  if(!prev||!prev.st){s=W[g-1];d=d0(g);}
  else{
    var t=Math.max(0,(now-(prev.last||now))/DAY);
    var r=Math.pow(1+FACTOR*t/prev.st,DECAY);
    if(g===1){s=W[11]*Math.pow(prev.df,-W[12])*(Math.pow(prev.st+1,W[13])-1)*Math.exp((1-r)*W[14]);s=Math.min(s,prev.st);}
    else{s=prev.st*(1+Math.exp(W[8])*(11-prev.df)*Math.pow(prev.st,-W[9])*(Math.exp((1-r)*W[10])-1)*(g===2?W[15]:1));}
    d=cl(W[7]*d0(4)+(1-W[7])*(prev.df-W[6]*(g-3)),1,10);
  }
  s=Math.max(0.1,s);
  var due;
  if(g===1){due=now+10*60000;}
  else{var iv=cl(Math.round(s/FACTOR*(Math.pow(RET,1/DECAY)-1)),1,MAXI);due=startOfDay(now)+iv*DAY+4*3600000;}
  return {st:+s.toFixed(4),df:+d.toFixed(4),last:now,due:due,reps:((prev&&prev.reps)||0)+1,lapses:((prev&&prev.lapses)||0)+(g===1&&prev&&prev.st?1:0)};
}

/* ---------- 保存（この端末のブラウザ） ---------- */
function blankState(){return {v:1,settings:JSON.parse(JSON.stringify(DEF)),srs:{},days:{},past:[],flags:{},timer:null};}
var ST=blankState(), storageOK=true, saveT=0;
function loadState(){
  try{var j=localStorage.getItem(STORE);if(j){var o=JSON.parse(j);if(o&&o.v===1){ST=Object.assign(blankState(),o);ST.settings=Object.assign({},DEF,o.settings||{});}}}
  catch(e){storageOK=false;}
}
function save(){clearTimeout(saveT);saveT=setTimeout(saveNow,250);}
function saveNow(){clearTimeout(saveT);try{localStorage.setItem(STORE,JSON.stringify(ST));storageOK=true;}catch(e){storageOK=false;toast('保存できませんでした。空き容量を確認してください');}}
document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')saveNow();});
window.addEventListener('pagehide',saveNow);

/* ---------- データ ---------- */
var DATA={syl:null,past:null,q:{},qById:{},items:{},groups:{},text:{}};
function loadTexts(){
  return Promise.all(SUBJ.map(function(s){
    return fetch('data/t_'+s.k+'.json').then(function(r){return r.ok?r.json():null;}).catch(function(){return null;}).then(function(j){
      if(j&&j.chapters){var ix={};j.chapters.forEach(function(c){c.sections.forEach(function(x){ix[x.id]=c.id;});});DATA.text[s.k]={chapters:j.chapters,secCh:ix};}
    });
  }));
}
function hasText(s,itemId){var T=DATA.text[s];return !!(T&&T.secCh[itemId]);}
function chapterHas(s,gid){var T=DATA.text[s];return !!(T&&T.chapters.some(function(c){return c.id===gid;}));}
function renderContent(src){
  var out=[],list=null;
  function inline(s){return esc(s).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>');}
  function closeList(){if(list){out.push('<ul>'+list.join('')+'</ul>');list=null;}}
  String(src||'').split('\n').forEach(function(raw){
    var l=raw.trim();
    if(!l){closeList();return;}
    if(/^\*\*[^*]+\*\*$/.test(l)){closeList();out.push('<h4>'+esc(l.slice(2,-2))+'</h4>');return;}
    if(l.charAt(0)==='・'){(list=list||[]).push('<li>'+inline(l.slice(1))+'</li>');return;}
    closeList();
    if(l.indexOf('【事例】')===0){out.push('<div class="tx-case"><b>事例</b><span>'+inline(l.slice(4))+'</span></div>');return;}
    if(l.indexOf('【試験のポイント】')===0){out.push('<div class="tx-point"><b>試験のポイント</b><span>'+inline(l.slice(9))+'</span></div>');return;}
    if(l.indexOf('【ひっかけ注意】')===0){out.push('<div class="tx-trap"><b>ひっかけ注意</b><span>'+inline(l.slice(8))+'</span></div>');return;}
    out.push('<p>'+inline(l)+'</p>');
  });
  closeList();return out.join('');
}
function openText(s,ch,sec,fromSess){
  var T=DATA.text[s];if(!T)return;if(!ch&&sec)ch=T.secCh[sec];if(!ch)return;
  UI.reader={s:s,ch:ch,sec:sec||null,fromSess:!!fromSess};$('#reader').hidden=false;renderReader();
  var sc=$('#reader .p-scroll'),tg=sec?document.getElementById('sec-'+sec.replace(/\./g,'-')):null;
  if(sc)sc.scrollTop=tg?Math.max(0,tg.offsetTop-12):0;
}
function renderReader(){
  var r=UI.reader,el=$('#reader');
  if(!r){el.hidden=true;el.innerHTML='';return;}
  var chs=DATA.text[r.s].chapters,i=-1;chs.forEach(function(c,j){if(c.id===r.ch)i=j;});var c=chs[i];
  var nq=(DATA.q[r.s]||[]).filter(function(q){return groupOf(q.t)===c.id&&!ST.flags[q.id];}).length;
  var h='<div class="p-top gut"><button class="icon" type="button" data-act="rd-close" aria-label="閉じる">×</button><span class="p-title">'+esc(c.title)+'<small>'+esc(SN[r.s].n+(c.part?'・'+c.part:''))+'</small></span></div><div class="p-scroll"><div class="p-body gut">';
  h+=c.sections.map(function(x){return '<section class="tx-sec'+(r.sec===x.id?' tx-hl':'')+'" id="sec-'+x.id.replace(/\./g,'-')+'"><h3>'+esc(x.title)+'</h3>'+renderContent(x.content)+'</section>';}).join('');
  h+='<div class="tx-nav">'+(i>0?'<button class="linkbtn" type="button" data-act="rd-go" data-ch="'+chs[i-1].id+'">← '+esc(chs[i-1].title)+'</button>':'<span></span>')+(i<chs.length-1?'<button class="linkbtn" type="button" data-act="rd-go" data-ch="'+chs[i+1].id+'">'+esc(chs[i+1].title)+' →</button>':'')+'</div>';
  h+='<p class="fine">公式の出題範囲にそって書き下ろしたテキストです。誤りに気づいたら、Claudeに節の名前を伝えてください。</p></div></div>';
  h+='<div class="p-foot gut">'+(r.fromSess?'<button class="btn primary wide" type="button" data-act="rd-close">演習に戻る</button>':(nq?'<button class="btn primary wide" type="button" data-act="rd-drill" data-g="'+c.id+'">この章の演習（'+nq+'問）</button>':'<button class="btn ghost wide" type="button" data-act="rd-close">閉じる</button>'))+'</div>';
  el.innerHTML=h;
}
function loadData(){
  var files=['syllabus','past'].concat(SUBJ.map(function(s){return 'q_'+s.k;}));
  return Promise.all(files.map(function(f){return fetch('data/'+f+'.json').then(function(r){if(!r.ok)throw new Error(f);return r.json();});})).then(function(arr){
    DATA.syl=arr[0];DATA.past=arr[1];
    SUBJ.forEach(function(s,i){DATA.q[s.k]=(arr[i+2].questions||[]).map(function(q){q.s=s.k;return q;});});
    DATA.qById={};SUBJ.forEach(function(s){DATA.q[s.k].forEach(function(q){DATA.qById[q.id]=q;});});
    DATA.items={};DATA.groups={};
    DATA.syl.subjects.forEach(function(sub){sub.parts.forEach(function(p){p.groups.forEach(function(g){DATA.groups[g.id]={g:g,s:sub.k,part:p.n};g.items.forEach(function(it){DATA.items[it.id]={n:it.n,g:g.id,s:sub.k};});});});});
  });
}
function groupOf(t){return t?t.split('.').slice(0,3).join('.'):'';}
function topicName(q){var it=DATA.items[q.t];if(!it)return '';var g=DATA.groups[it.g];return (g?g.g.n+'｜':'')+it.n;}

/* ---------- 画面の状態 ---------- */
var UI={tab:'today',drillSub:null,sess:null,sheet:null,reader:null,toastT:0,armDel:null,armT:0,lastAdd:null,confirmImport:null,setDraft:null,manual:{s:'zaimu',y:'2021',p:''},swWaiting:null};
try{var t0=localStorage.getItem(STORE+'-tab');if(['today','drill','past','judge','log'].indexOf(t0)>=0)UI.tab=t0;}catch(e){}

/* ---------- 集計 ---------- */
function weekStart(t){var x=new Date(t);x.setHours(0,0,0,0);x.setDate(x.getDate()-(x.getDay()+6)%7);return x;}
function weekStats(back){
  var s=weekStart(Date.now());s.setDate(s.getDate()-7*back);var min=0,days=[];
  for(var i=0;i<7;i++){var d=new Date(s);d.setDate(s.getDate()+i);var v=ST.days[ymd(d)]||{};min+=v.min||0;days.push({d:d,min:v.min||0});}
  return {start:s,min:min,days:days};
}
function weeklyTarget(){return ST.settings.wdMin*5+ST.settings.weMin*2;}
function allQ(){var a=[];SUBJ.forEach(function(s){a=a.concat(DATA.q[s.k]||[]);});return a;}
function counts(){
  var eod=endOfToday(),due=0,avail=0;
  allQ().forEach(function(q){if(ST.flags[q.id])return;var r=ST.srs[q.id];if(r){if(r.due<=eod)due++;}else if(ST.settings.active.indexOf(q.s)>=0)avail++;});
  var td=ST.days[todayKey()]||{};var quota=Math.max(0,ST.settings.newPerDay-(td.nw||0));
  return {due:due,avail:avail,newToday:Math.min(quota,avail)};
}
function subjStats(k){
  var tot=0,lr=0,due=0,att=0,cor=0,eod=endOfToday();
  (DATA.q[k]||[]).forEach(function(q){if(ST.flags[q.id])return;tot++;var r=ST.srs[q.id];if(r){lr++;if(r.due<=eod)due++;att+=r.att||0;cor+=r.cor||0;}});
  return {tot:tot,lr:lr,due:due,acc:att?Math.round(cor/att*100):null};
}
function coverage(k){
  var sub=DATA.syl.subjects.filter(function(x){return x.k===k;})[0];var items=0,withQ=0,withT=0,groups=0,gWith=0;
  var has={};(DATA.q[k]||[]).forEach(function(q){has[q.t]=(has[q.t]||0)+1;});
  sub.parts.forEach(function(p){p.groups.forEach(function(g){groups++;var any=false;g.items.forEach(function(it){items++;if(has[it.id]){withQ++;any=true;}if(hasText(k,it.id))withT++;});if(any)gWith++;});});
  return {items:items,withQ:withQ,withT:withT,groups:groups,gWith:gWith,has:has};
}
function weakTopics(n){
  var m={};
  Object.keys(ST.srs).forEach(function(id){var q=DATA.qById[id];if(!q||ST.flags[id])return;var r=ST.srs[id];var g=groupOf(q.t);var o=m[g]||(m[g]={g:g,s:q.s,att:0,cor:0,cw:0});o.att+=r.att||0;o.cor+=r.cor||0;o.cw+=r.cw||0;});
  return Object.keys(m).map(function(k){return m[k];}).filter(function(o){return o.att>=3;}).map(function(o){o.acc=Math.round(o.cor/o.att*100);return o;})
    .filter(function(o){return o.acc<80||o.cw>0;}).sort(function(a,b){return (a.acc-b.acc)||(b.cw-a.cw);}).slice(0,n);
}

/* ---------- 過去問 ---------- */
function pastYear(y){return DATA.past.years.filter(function(e){return e.y===+y;})[0];}
function isReserve(y){return (DATA.past.reserve||[]).indexOf(+y)>=0;}
function attemptsOf(s,y){return ST.past.filter(function(a){return a.s===s&&(y==null||a.y===+y);}).sort(function(a,b){return a.at-b.at;});}
function keyOk(item,mark){if(item.a==='*')return true;if(!mark)return false;return item.a.split('/').indexOf(mark)>=0;}
function scoreSheet(items,marks){var sc=0,ok=0;items.forEach(function(it){if(keyOk(it,marks[it.n])){sc+=it.p;ok++;}});return {score:sc,ok:ok};}
function judgeSubject(s){
  var res={s:s,practice:[],practiceOK:false,reserve:[],reserveOK:false,reserveDone:false,status:'none'};
  var byYear={};ST.past.filter(function(a){return a.s===s&&!isReserve(a.y);}).sort(function(a,b){return b.at-a.at;}).forEach(function(a){if(!byYear[a.y])byYear[a.y]=a;});
  var latest=Object.keys(byYear).map(function(y){return byYear[y];}).sort(function(a,b){return b.at-a.at;}).slice(0,2);
  res.practice=latest;res.practiceOK=latest.length===2&&latest.every(function(a){return a.score>=PASS;});
  var rs=(DATA.past.reserve||[]).map(function(y){var f=attemptsOf(s,y)[0];return {y:y,first:f||null};});
  res.reserve=rs;res.reserveDone=rs.every(function(r){return r.first;});res.reserveOK=res.reserveDone&&rs.every(function(r){return r.first.score>=PASS;});
  var any=ST.past.some(function(a){return a.s===s;});
  res.status=res.practiceOK&&res.reserveOK?'done':(res.reserveDone&&!res.reserveOK?'fail':(res.practiceOK?'ready':(any?'work':'none')));
  return res;
}

/* ---------- 描画 ---------- */
var rq=0;
function schedRender(){if(rq)return;rq=requestAnimationFrame(function(){rq=0;render();});}
function render(){
  renderHeader();renderNote();
  var v=$('#view'),ae=document.activeElement;
  if(ae&&v.contains(ae)&&(ae.tagName==='INPUT'&&ae.type!=='checkbox'&&ae.type!=='file')){UI.dirty=true;}
  else{
    var fid=ae&&v.contains(ae)?ae.id:'';
    v.innerHTML=!DATA.syl?'<p class="fine">読み込んでいます…</p>':UI.tab==='drill'?viewDrill():UI.tab==='past'?viewPast():UI.tab==='judge'?viewJudge():UI.tab==='log'?viewLog():viewToday();
    UI.dirty=false;if(fid){var n=document.getElementById(fid);if(n)n.focus({preventScroll:true});}
  }
  document.querySelectorAll('.tab').forEach(function(b){if(b.dataset.tab===UI.tab)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
}
function renderHeader(){
  var st=ST.settings,d1=daysUntil(st.exam1),d2=daysUntil(st.exam2),w=weekStats(0),tg=weeklyTarget();
  $('#hdr').innerHTML='<div class="cd"><span class="cd-l">1次試験まで</span><b class="cd-n">'+Math.max(0,d1)+'</b><span class="cd-u">日</span><span class="cd-sub">2次筆記まで '+Math.max(0,d2)+'日（日程は仮）</span></div>'
   +'<div class="wk"><div class="wk-t"><span>今週</span><b>'+fmtH(w.min)+'</b><span>/ '+fmtH(tg)+' 時間</span></div><div class="meter" role="meter" aria-label="今週の学習時間" aria-valuemin="0" aria-valuemax="'+tg+'" aria-valuenow="'+w.min+'"><i style="width:'+(tg?Math.min(100,w.min/tg*100):0)+'%"></i></div></div>';
}
function renderNote(){
  var n=$('#note');
  if(UI.swWaiting){n.innerHTML='<span>新しい版があります。</span><button class="btn small" type="button" data-act="sw-update">更新する</button>';n.hidden=false;}
  else if(!storageOK){n.innerHTML='<span>この端末に記録を保存できません。プライベートブラウズを解除してください。</span>';n.hidden=false;}
  else n.hidden=true;
}

function viewToday(){
  var c=counts(),td=ST.days[todayKey()]||{},total=c.due+c.newToday,weak=weakTopics(3);
  var act=ST.settings.active.map(function(k){return SN[k]?SN[k].sh:k;}).join('・')||'なし';
  var h='<section class="sheet"><div class="sec-h"><span>今日の演習</span></div>'
   +'<div class="dueRow"><div class="stat"><span class="k">復習</span><span class="v">'+c.due+'<small>問</small></span></div><div class="stat"><span class="k">新しい問題</span><span class="v">'+c.newToday+'<small>問</small></span></div></div>';
  if(total)h+='<div class="go"><button class="btn primary" type="button" data-act="go" data-n="10">5分<small>10問</small></button><button class="btn" type="button" data-act="go" data-n="30">15分<small>30問</small></button><button class="btn" type="button" data-act="go" data-n="60">30分<small>60問</small></button></div>';
  else h+='<p class="note">今日の分は終わりました。</p>'+(c.avail?'':'<p class="fine">学習中の科目の新しい問題は、いまは残っていません。問題は版を重ねて追加していきます。</p>')+'<button class="btn ghost" type="button" data-act="ahead">先取りで10問</button>';
  h+='<p class="fine">今日 '+(td.ans||0)+'問・正答率 '+(td.ans?Math.round((td.cor||0)/td.ans*100):0)+'%・学習中：'+esc(act)+'</p></section>';
  var todo=nextTodos();
  if(todo.length)h+='<section class="sec"><div class="sec-h"><span>次にやること</span></div><ul class="list">'+todo.map(function(t){return '<li class="todo"><div class="todo-t"><b>'+esc(t.t)+'</b><span>'+esc(t.d)+'</span></div>'+(t.act?'<button class="btn small" type="button" '+t.act+'>'+esc(t.b)+'</button>':'')+'</li>';}).join('')+'</ul></section>';
  if(weak.length)h+='<section class="sec"><div class="sec-h"><span>苦手な論点</span></div><ul class="list">'+weak.map(function(w){var g=DATA.groups[w.g];return '<li class="todo"><div class="todo-t"><b>'+esc(g?g.g.n:w.g)+'</b><span>'+esc(SN[w.s].n)+'・正答率'+w.acc+'%'+(w.cw?'・自信を持って誤答'+w.cw+'回':'')+'</span></div><button class="btn small" type="button" data-act="drill-group" data-g="'+esc(w.g)+'">10問</button></li>';}).join('')+'</ul></section>';
  h+='<section class="sec"><div class="sec-h"><span>学習タイマー</span></div><div class="timer"><span class="tface" id="tface">'+(ST.timer?fmtClock(Date.now()-ST.timer):'00:00')+'</span>'
   +(ST.timer?'<button class="btn primary" type="button" data-act="t-stop">止めて記録</button>':'<button class="btn" type="button" data-act="t-start">計測を始める</button>')+'</div>'
   +'<div class="addrow"><span class="fine">テキストや過去問で学んだ時間を足す</span><button class="btn small ghost" type="button" data-act="add-min" data-m="15">+15分</button><button class="btn small ghost" type="button" data-act="add-min" data-m="30">+30分</button><button class="btn small ghost" type="button" data-act="add-min" data-m="60">+60分</button></div></section>';
  h+='<section class="sec"><div class="sec-h"><span>今週の7日間</span></div>'+weekBubbles()+'</section>';
  return h;
}
function nextTodos(){
  var out=[];
  ST.settings.active.forEach(function(k){
    var j=judgeSubject(k);
    if(j.status==='none'){var y=firstPracticeYear(k);if(y)out.push({t:SN[k].n+'の過去問を1年分',d:pastYear(y).label+'を解いて、実力の起点を測る',b:'開く',act:'data-act="open-sheet" data-s="'+k+'" data-y="'+y+'"'});}
    else if(j.status==='ready')out.push({t:SN[k].n+'は初見判定へ',d:'練習の判定を満たしました。仕上げ用の年度で確かめます',b:'判定を見る',act:'data-act="tab" data-tab="judge"'});
  });
  return out.slice(0,3);
}
function firstPracticeYear(k){
  var ys=DATA.past.years.filter(function(e){return !isReserve(e.y)&&e.subjects[k]&&e.subjects[k].items;}).map(function(e){return e.y;}).sort(function(a,b){return b-a;});
  for(var i=0;i<ys.length;i++){if(!attemptsOf(k,ys[i]).length)return ys[i];}
  return null;
}
function weekBubbles(){
  var w=weekStats(0),names=['月','火','水','木','金','土','日'],tk=todayKey(),st=ST.settings;
  return '<div class="week7">'+w.days.map(function(d,i){var tg=i<5?st.wdMin:st.weMin;var lv=d.min<=0?'':(d.min>=tg?'full':'part');
    return '<div class="d7'+(ymd(d.d)===tk?' today':'')+'"><span class="bub sm '+lv+'" aria-hidden="true"></span><span class="d7-n">'+names[i]+'</span><span class="d7-m">'+(d.min?d.min+'分':'—')+'</span></div>';}).join('')+'</div>';
}

function viewDrill(){
  if(UI.drillSub)return viewSyllabus(UI.drillSub);
  var h='<section class="sec"><div class="sec-h"><span>科目と論点表</span></div><p class="fine">科目名を押すと、公式の出題範囲にそった論点表を開きます。論点表から、テキストと演習に進めます。「学習中」の科目から、新しい問題が1日'+ST.settings.newPerDay+'問まで出ます。復習はすべての科目から出ます。</p><div class="subjs">';
  SUBJ.forEach(function(s){var x=subjStats(s.k),cv=coverage(s.k),on=ST.settings.active.indexOf(s.k)>=0;
    h+='<div class="subj"><button class="subj-n" type="button" data-act="open-syl" data-s="'+s.k+'">'+esc(s.n)+'</button><div class="subj-m">テキスト'+cv.withT+'/'+cv.items+'細目・問題'+x.tot+'問（'+cv.withQ+'細目）・今日の復習'+x.due+'</div><div class="subj-a"><span class="acc" title="正答率">'+(x.acc==null?'—':x.acc+'%')+'</span><button class="toggle'+(on?' on':'')+'" type="button" data-act="toggle-active" data-s="'+s.k+'" aria-pressed="'+on+'">'+(on?'学習中':'休止中')+'</button></div></div>';});
  h+='</div></section>';
  var fl=Object.keys(ST.flags).filter(function(id){return DATA.qById[id];});
  if(fl.length)h+='<section class="sec"><div class="sec-h"><span>報告した問題</span></div><p class="fine">演習から外しています。Claudeに問題番号を伝えると、確認して直した版を出します。</p><ul class="list">'+fl.map(function(id){var q=DATA.qById[id];return '<li class="fl"><b>'+esc(id)+'</b><span>'+esc(q.q)+'</span><div class="row-act"><button class="linkbtn" type="button" data-act="unflag" data-id="'+esc(id)+'">演習に戻す</button></div></li>';}).join('')+'</ul></section>';
  return h;
}
function viewSyllabus(k){
  var sub=DATA.syl.subjects.filter(function(x){return x.k===k;})[0],cv=coverage(k),acc=groupAcc(k);
  var h='<button class="btn small ghost back" type="button" data-act="close-syl">← 科目一覧</button><section class="sec"><h2 class="ttl">'+esc(sub.n)+'</h2>'
   +'<div class="cov" aria-label="テキストの網羅率"><span class="fine" style="min-width:4.5em">テキスト</span><span class="meter"><i style="width:'+Math.round(cv.withT/cv.items*100)+'%"></i></span><b>'+cv.withT+' / '+cv.items+'</b></div>'
   +'<div class="cov" aria-label="問題の網羅率"><span class="fine" style="min-width:4.5em">問題</span><span class="meter"><i style="width:'+Math.round(cv.withQ/cv.items*100)+'%"></i></span><b>'+cv.withQ+' / '+cv.items+'</b></div>'
   +'<p class="fine">公式の出題範囲の細目'+cv.items+'のうち、テキストと問題がある細目の数です。試験時間'+sub.min+'分・100点。</p>'
   +((DATA.q[k]||[]).length?'<button class="btn primary" type="button" data-act="drill-subj" data-s="'+k+'">この科目を10問</button>':'')+'</section>';
  sub.parts.forEach(function(p){
    h+='<section class="sec">'+(p.n?'<div class="sec-h"><span>'+esc(p.n)+'</span></div>':'');
    p.groups.forEach(function(g){var nq=0;g.items.forEach(function(it){nq+=cv.has[it.id]||0;});var a=acc[g.id],ht=chapterHas(k,g.id);
      h+='<div class="grp"><span class="grp-n">'+esc(g.n)+'</span><span class="grp-m">'+(ht?'テキストあり・':'')+'問題'+nq+'問'+(a?'・正答率'+a+'%':'')+'</span><span class="grp-b">'+(ht?'<button class="btn small ghost" type="button" data-act="open-text" data-s="'+k+'" data-ch="'+g.id+'">テキスト</button>':'')+(nq?'<button class="btn small" type="button" data-act="drill-group" data-g="'+g.id+'">演習</button>':'')+'</span>'
       +'<details><summary>細目'+g.items.length+'</summary><ul>'+g.items.map(function(it){var t=hasText(k,it.id);return '<li'+(cv.has[it.id]||t?' class="has"':'')+'>'+esc(it.n)+(t||cv.has[it.id]?'（'+[t?'テキスト':'',cv.has[it.id]?cv.has[it.id]+'問':''].filter(Boolean).join('・')+'）':'')+'</li>';}).join('')+'</ul></details></div>';});
    h+='</section>';
  });
  h+='<p class="fine">出典：'+esc(DATA.syl.source)+'</p>';
  return h;
}
function groupAcc(k){
  var m={};(DATA.q[k]||[]).forEach(function(q){var r=ST.srs[q.id];if(!r||!r.att)return;var g=groupOf(q.t);var o=m[g]||(m[g]={a:0,c:0});o.a+=r.att;o.c+=r.cor||0;});
  var out={};Object.keys(m).forEach(function(g){out[g]=Math.round(m[g].c/m[g].a*100);});return out;
}

function viewPast(){
  var ys=DATA.past.years;
  var h='<section class="sec"><div class="sec-h"><span>過去問（公式）</span></div><p class="fine">公式サイトの問題PDFで解き、ここで答えをマークすると、公式の正解と配点で採点します。<b>仕上げ</b>の年度は初見判定用なので、練習の判定を満たすまで取っておいてください。</p>'
   +'<div class="pgrid"><table><thead><tr><th scope="col"></th>'+SUBJ.map(function(s){return '<th scope="col">'+s.sh+'</th>';}).join('')+'</tr></thead><tbody>';
  ys.forEach(function(e){
    h+='<tr><th scope="row">'+esc(e.label.replace('年度',''))+(isReserve(e.y)?'<small>仕上げ</small>':'')+'</th>';
    SUBJ.forEach(function(s){var se=e.subjects[s.k];var at=attemptsOf(s.k,e.y);var last=at[at.length-1];
      var cls='pc',txt;
      if(last){txt=last.score;cls+=last.score<CUT?' low':last.score>=PASS?' good':'';if(last.mode==='manual')cls+=' manual';}
      else if(se&&se.items){txt='—';cls+=' none';}
      else {txt='入力';cls+=' na';}
      h+='<td><button class="'+cls+'" type="button" data-act="open-sheet" data-s="'+s.k+'" data-y="'+e.y+'" aria-label="'+esc(e.label+' '+s.n+(last?' '+last.score+'点':''))+'">'+txt+'</button></td>';});
    h+='</tr>';
  });
  h+='</tbody></table></div><div class="legend"><span>数字＝直近の得点</span><span>— ＝未着手（マークで採点）</span><span>入力＝正解未収録（点数だけ記録）</span></div></section>';
  var recent=ST.past.slice().sort(function(a,b){return b.at-a.at;}).slice(0,8);
  if(recent.length)h+='<section class="sec"><div class="sec-h"><span>最近の記録</span></div><ul class="list">'+recent.map(function(a){var e=pastYear(a.y);return '<li class="todo"><div class="todo-t"><b>'+esc(SN[a.s].n)+'</b><span>'+esc((e?e.label:a.y)+'・'+md(new Date(a.at))+(a.mode==='manual'?'・点数のみ':'・'+a.ok+'/'+a.total+'問正解')+(a.first&&isReserve(a.y)?'・初見':''))+'</span></div><b>'+a.score+'点</b></li>';}).join('')+'</ul></section>';
  h+='<p class="fine">問題PDF・正解：<a href="'+esc(DATA.past.pastpage)+'" target="_blank" rel="noopener">中小企業診断協会 過去の試験問題</a></p>';
  return h;
}

function viewJudge(){
  var js=SUBJ.map(function(s){return judgeSubject(s.k);}),done=js.filter(function(j){return j.status==='done';}).length;
  var latest=SUBJ.map(function(s){var a=ST.past.filter(function(x){return x.s===s.k;}).sort(function(a,b){return b.at-a.at;})[0];return {s:s,a:a};});
  var meas=latest.filter(function(x){return x.a;}),total=meas.reduce(function(t,x){return t+x.a.score;},0),low=meas.filter(function(x){return x.a.score<CUT;});
  var h='<section class="sheet"><div class="sec-h"><span>完了判定</span></div><div class="simbig"><b>'+done+'</b><span>/ 7科目 完了</span></div>'
   +'<p class="lead">'+(done===7?'全科目が完了しました。本試験の水準に達しています。':'科目ごとに、次の2つを満たすと完了です。')+'</p>'
   +'<ol class="crit"><li><b>練習：</b>公式過去問で、最後に解いた2つの年度（別々の年度）がどちらも'+PASS+'点以上</li><li><b>初見：</b>仕上げ用の'+DATA.past.reserve.map(function(y){return pastYear(y).label;}).join('・')+'を、初めて解いて'+PASS+'点以上</li></ol>'
   +'<p class="fine">本試験の合格基準は「合計420点以上かつ40点未満の科目なし」です。全科目'+PASS+'点以上を条件にしているのは、それより厳しく見て取りこぼしを防ぐためです。</p></section>';
  h+='<section class="sec"><div class="sec-h"><span>科目ごとの状態</span></div><ul class="list">'+js.map(function(j){
    var s=SN[j.s],pill=j.status==='done'?'<span class="pill good">完了</span>':j.status==='ready'?'<span class="pill warn">初見待ち</span>':j.status==='fail'?'<span class="pill bad">初見で未達</span>':j.status==='work'?'<span class="pill mute">練習中</span>':'<span class="pill mute">未着手</span>';
    var pr=j.practice.length?j.practice.map(function(a){return pastYear(a.y).label.replace('年度','')+' '+a.score+'点';}).join('、'):'記録なし';
    var rv=j.reserve.map(function(r){return pastYear(r.y).label.replace('年度','')+' '+(r.first?r.first.score+'点':'未');}).join('、');
    return '<li class="jrow"><span class="jrow-n">'+esc(s.n)+'</span>'+pill+'<div class="jrow-m"><div class="checks"><span class="'+(j.practiceOK?'ok':'')+'">練習（最後の2年度）：'+esc(pr)+'</span><span class="'+(j.reserveOK?'ok':'')+'">初見：'+esc(rv)+'</span></div>'
     +(j.status==='fail'?'<span>初見の年度を使い切りました。次の本試験問題の公開後、その年度で判定します。</span>':'')+'</div></li>';}).join('')+'</ul></section>';
  h+='<section class="sec"><div class="sec-h"><span>直近の得点で見た本試験</span></div>';
  if(!meas.length)h+='<p class="fine">過去問を解くと、直近の得点で本試験の合否を試算します。</p>';
  else{var pess=meas.reduce(function(t,x){return t+Math.max(0,x.a.score-x.s.vol);},0);
    h+='<div class="simbig"><b>'+total+'</b><span>'+(meas.length===7?'/ 700点':'点（'+meas.length+'科目の合計）')+'</span></div>'
     +'<p class="note">'+(low.length?esc(low.map(function(x){return x.s.n;}).join('・'))+'が40点未満で、足切りになります。':meas.length<7?'全7科目がそろうと、合否を試算します。':(total>=420?'合格基準の420点を'+(total-420)+'点上回っています。':'合格基準の420点まであと'+(420-total)+'点です。'))+'</p>'
     +(meas.length===7?'<p class="fine">難化した年を想定（運営管理・経営法務・中小企業経営は−10点、ほかは−5点）すると'+pess+'点です。</p>':'');}
  h+='</section>';
  h+=manualForm();
  return h;
}
function manualForm(){
  var m=UI.manual,ys=DATA.past.years.filter(function(e){return !e.subjects[m.s].items;});
  if(!ys.some(function(e){return String(e.y)===String(m.y);}))m.y=String(ys[0].y);
  return '<section class="sec"><div class="sec-h"><span>点数だけを記録</span></div><p class="fine">アプリに正解を収録していない年度は、公式PDFで自己採点した点数を記録できます。練習の判定に使います。</p>'
   +'<form class="grid2" data-form="manual"><label class="field span" for="mn-s">科目<select id="mn-s" data-bind="manual.s">'+SUBJ.map(function(s){return '<option value="'+s.k+'"'+(m.s===s.k?' selected':'')+'>'+esc(s.n)+'</option>';}).join('')+'</select></label>'
   +'<label class="field" for="mn-y">年度<select id="mn-y" data-bind="manual.y">'+ys.map(function(e){return '<option value="'+e.y+'"'+(String(m.y)===String(e.y)?' selected':'')+'>'+esc(e.label)+'</option>';}).join('')+'</select></label>'
   +'<label class="field" for="mn-p">点数<input id="mn-p" type="number" inputmode="numeric" min="0" max="100" data-bind="manual.p" value="'+esc(m.p)+'" placeholder="0〜100"></label>'
   +'<button class="btn primary span" type="submit">記録する</button></form></section>';
}

function viewLog(){
  var st=ST.settings,tg=weeklyTarget(),weeks=[];for(var i=7;i>=0;i--)weeks.push(weekStats(i));
  var all=0,ans=0,cor=0;Object.keys(ST.days).forEach(function(k){var v=ST.days[k];all+=v.min||0;ans+=v.ans||0;cor+=v.cor||0;});
  var el=Math.max(1/7,(Date.now()-parseYmd(st.start||DEF.start).getTime())/(7*DAY)),plan=Math.round(tg*el);
  var d=UI.setDraft||draftOf(st);
  var h='<section class="sec"><div class="sec-h"><span>週ごとの学習時間</span></div>'+weekChart(weeks,tg)
   +'<div class="kpis"><div class="stat"><span class="k">累計</span><span class="v">'+fmtH(all)+'<small>時間</small></span><span class="fine">計画どおりなら '+fmtH(plan)+'時間</span></div><div class="stat"><span class="k">解いた問題</span><span class="v">'+ans+'<small>問</small></span><span class="fine">正答率 '+(ans?Math.round(cor/ans*100):0)+'%</span></div></div></section>'
   +'<section class="sec"><div class="sec-h"><span>設定</span></div><form class="form" data-form="settings"><div class="grid2">'
   +'<label class="field" for="s-wd">平日の目標（分）<input id="s-wd" type="number" inputmode="numeric" min="0" max="600" data-bind="setDraft.wdMin" value="'+esc(d.wdMin)+'"></label>'
   +'<label class="field" for="s-we">休日の目標（分）<input id="s-we" type="number" inputmode="numeric" min="0" max="900" data-bind="setDraft.weMin" value="'+esc(d.weMin)+'"></label>'
   +'<label class="field" for="s-np">新しい問題（問/日）<input id="s-np" type="number" inputmode="numeric" min="0" max="100" data-bind="setDraft.newPerDay" value="'+esc(d.newPerDay)+'"></label><span></span>'
   +'<label class="field" for="s-e1">1次試験日<input id="s-e1" type="date" data-bind="setDraft.exam1" value="'+esc(d.exam1)+'"></label>'
   +'<label class="field" for="s-e2">2次筆記試験日<input id="s-e2" type="date" data-bind="setDraft.exam2" value="'+esc(d.exam2)+'"></label></div>'
   +'<button class="btn primary" type="submit">保存する</button></form>'
   +'<p class="fine">今の目標は週'+fmtH(tg)+'時間です。試験日は、2027年度の試験案内（例年4月ごろ公表）で直してください。</p></section>';
  h+='<section class="sec"><div class="sec-h"><span>学習記録のバックアップ</span></div><p class="fine">記録はこの端末のブラウザにだけ保存しています。機種変更やアプリの削除の前に、書き出してください。</p>'
   +'<div class="row-act"><button class="btn small" type="button" data-act="export">書き出す</button><button class="btn small ghost" type="button" data-act="import">読み込む</button></div>';
  if(UI.confirmImport)h+='<div class="confirm"><span>'+esc(UI.confirmImport.label)+'の記録で、今の記録を置き換えます。よろしいですか。</span><div class="row-act"><button class="btn small primary" type="button" data-act="import-ok">置き換える</button><button class="btn small ghost" type="button" data-act="import-cancel">やめる</button></div></div>';
  h+='</section><section class="sec"><div class="sec-h"><span>このアプリ</span></div><p class="fine">版 '+APP_VER+'・テキスト '+textCount()+'節・問題 '+allQ().length+'問・論点表'+Object.keys(DATA.items).length+'細目・過去問の正解 '+keyCount()+'科目年度分。出題範囲は令和8年度の試験案内、正解と配点は中小企業診断協会の公表資料によります。</p></section>';
  return h;
}
function textCount(){var n=0;Object.keys(DATA.text).forEach(function(k){DATA.text[k].chapters.forEach(function(c){n+=c.sections.length;});});return n;}
function keyCount(){var n=0;DATA.past.years.forEach(function(e){SUBJ.forEach(function(s){if(e.subjects[s.k].items)n++;});});return n;}
function weekChart(weeks,tg){
  var VW=320,VH=150,L=8,R=8,T=20,B=24,max=Math.max(tg*1.25,60,Math.max.apply(null,weeks.map(function(w){return w.min;})));
  var bw=(VW-L-R)/weeks.length,yv=function(v){return T+(VH-T-B)*(1-v/max);},bars='';
  weeks.forEach(function(w,i){var x=L+i*bw+bw*.2,ww=bw*.6,hh=(VH-T-B)*(w.min/max),cur=i===weeks.length-1;
    bars+='<rect x="'+x.toFixed(1)+'" y="'+(VH-B-hh).toFixed(1)+'" width="'+ww.toFixed(1)+'" height="'+Math.max(0,hh).toFixed(1)+'" rx="2" class="bar'+(cur?' cur':'')+'"><title>'+md(w.start)+'の週：'+fmtH(w.min)+'時間</title></rect>'
     +'<text x="'+(x+ww/2).toFixed(1)+'" y="'+(VH-8)+'" text-anchor="middle" class="ax">'+md(w.start)+'</text>'
     +(w.min?'<text x="'+(x+ww/2).toFixed(1)+'" y="'+(VH-B-hh-4).toFixed(1)+'" text-anchor="middle" class="val">'+fmtH(w.min)+'</text>':'');});
  var ty=yv(tg);
  return '<div class="chartbox"><svg viewBox="0 0 '+VW+' '+VH+'" role="img" aria-label="直近8週の学習時間。目標は週'+fmtH(tg)+'時間">'+bars
   +'<line x1="'+L+'" x2="'+(VW-R)+'" y1="'+ty.toFixed(1)+'" y2="'+ty.toFixed(1)+'" class="tline"/><text x="'+L+'" y="'+(ty-5).toFixed(1)+'" class="ax">目標 '+fmtH(tg)+'時間</text>'
   +'<line x1="'+L+'" x2="'+(VW-R)+'" y1="'+(VH-B)+'" y2="'+(VH-B)+'" class="base"/></svg></div>';
}

/* ---------- 演習 ---------- */
function acc(id){var r=ST.srs[id];return r&&r.att?r.cor/r.att:0;}
function interleave(ids){
  var by={};ids.forEach(function(id){var s=(DATA.qById[id]||{}).s;(by[s]=by[s]||[]).push(id);});
  var keys=Object.keys(by),out=[],last=null;
  while(out.length<ids.length){keys.sort(function(a,b){return by[b].length-by[a].length;});var k=keys.filter(function(x){return by[x].length&&x!==last;})[0]||keys.filter(function(x){return by[x].length;})[0];out.push(by[k].shift());last=k;}
  return out;
}
function buildQueue(n,filter,ahead){
  var eod=endOfToday(),pool=allQ().filter(function(q){return !ST.flags[q.id]&&(!filter||filter(q));});
  var q=pool.filter(function(x){var r=ST.srs[x.id];return r&&r.due<=eod;}).sort(function(a,b){return ST.srs[a.id].due-ST.srs[b.id].due;}).slice(0,n).map(function(x){return x.id;});
  if(q.length<n){
    var td=ST.days[todayKey()]||{},quota=(filter||ahead)?n:Math.max(0,ST.settings.newPerDay-(td.nw||0));
    var fresh=pool.filter(function(x){return !ST.srs[x.id]&&(filter||ST.settings.active.indexOf(x.s)>=0);}).sort(function(a,b){return (a.n||0)-(b.n||0);});
    q=q.concat(fresh.slice(0,Math.min(quota,n-q.length)).map(function(x){return x.id;}));
  }
  if(q.length<n&&(filter||ahead)){
    var rest=pool.filter(function(x){var r=ST.srs[x.id];return r&&r.due>eod;}).sort(function(a,b){return filter?acc(a.id)-acc(b.id):ST.srs[a.id].due-ST.srs[b.id].due;});
    q=q.concat(rest.slice(0,n-q.length).map(function(x){return x.id;}));
  }
  return interleave(q);
}
function startSession(n,filter,ahead){
  var q=buildQueue(n,filter,ahead);
  if(!q.length){toast('いま出せる問題がありません');return;}
  UI.sess={q:q,i:0,phase:'answer',pick:null,res:[],t0:Date.now(),requeued:{},newCount:0,confirmEnd:false};
  $('#sess').hidden=false;renderSession();
}
function isTF(q){return q.type==='tf';}
function correctOf(q,pick){return isTF(q)?pick===q.a:pick===q.a;}
function renderSession(){
  var s=UI.sess,el=$('#sess');
  if(!s){el.hidden=true;el.innerHTML='';return;}
  if(s.phase==='done'){el.innerHTML=sessDone(s);return;}
  var id=s.q[s.i],q=DATA.qById[id];
  if(!q){s.i++;if(s.i>=s.q.length)finishSession();else renderSession();return;}
  var rev=s.phase==='reveal',ok=rev&&correctOf(q,s.pick);
  var prog=s.q.length>24?'<div class="sbar" aria-hidden="true"><i style="width:'+Math.round(s.res.length/s.q.length*100)+'%"></i></div>':'<div class="dots" aria-hidden="true">'+s.q.map(function(_,i){return '<i class="'+(i<s.res.length?(s.res[i].ok?'ok':'ng'):(i===s.i?'cur':''))+'"></i>';}).join('')+'</div>';
  var h='<div class="p-top gut"><button class="icon" type="button" data-act="s-close" aria-label="演習を終える">×</button>'+prog+'<span class="s-count">'+(s.i+1)+'<small>/'+s.q.length+'</small></span></div>';
  if(s.confirmEnd)h+='<div class="endbar gut"><span>ここまでの結果を記録して終わりますか？</span><button class="btn small primary" type="button" data-act="s-end">終わる</button><button class="btn small ghost" type="button" data-act="s-continue">続ける</button></div>';
  h+='<div class="p-scroll"><div class="p-body gut"><div class="s-meta"><span class="chip">'+esc(SN[q.s].n)+'</span><span class="s-topic">'+esc(topicName(q))+'</span>'+(q.st==='draft'?'<span class="chip draft">検証前</span>':'')+'</div>';
  h+='<p class="s-q">'+esc(q.q)+'</p>';
  if(q.fig)h+='<div class="fig">'+q.fig+'</div>';
  if(q.type==='combo'&&q.stm)h+='<div class="stmts">'+q.stm.map(function(t,i){return '<p><b>'+'abcde'[i]+'</b><span>'+esc(t)+'</span></p>';}).join('')+'</div>';
  if(isTF(q)){
    h+='<div class="ox" role="group" aria-label="解答">';
    [true,false].forEach(function(v){var on=s.pick===v,ans=rev&&q.a===v;
      h+='<button class="bub big'+(on?' on':'')+(ans?' ans':'')+'" type="button" data-act="pick" data-v="'+(v?1:0)+'"'+(s.phase!=='answer'?' disabled':'')+' aria-pressed="'+on+'" aria-label="'+(v?'正しい（○）':'誤り（×）')+'">'+(v?ICON_O:ICON_X)+'</button>';});
    h+='</div>';
  } else {
    h+='<div class="choices" role="group" aria-label="選択肢">'+q.ch.map(function(c,i){var on=s.pick===i,ans=rev&&q.a===i;
      return '<button class="choice'+(on?' on':'')+(ans?' ans':'')+'" type="button" data-act="pick" data-v="'+i+'"'+(s.phase!=='answer'?' disabled':'')+' aria-pressed="'+on+'"><span class="lt">'+LT[i]+'</span><span>'+esc(c)+(rev&&q.ce&&q.ce[i]?'<span class="ce">'+esc(q.ce[i])+'</span>':'')+'</span></button>';}).join('')+'</div>';
  }
  if(s.phase==='conf')h+='<div class="confwrap"><p class="conf-q">自信はどのくらい？</p><div class="conf"><button class="btn" type="button" data-act="conf" data-c="sure">確信</button><button class="btn" type="button" data-act="conf" data-c="unsure">迷った</button><button class="btn" type="button" data-act="conf" data-c="guess">勘</button></div></div>';
  if(rev){
    var ansTxt=isTF(q)?(q.a?'○':'×'):LT[q.a];
    h+='<div class="res '+(ok?'ok':'ng')+'" aria-live="polite"><div class="res-h">'+(ok?'正解':'不正解')+'<span class="res-a">正しくは '+ansTxt+'</span></div><p>'+esc(q.e)+'</p>'+(q.ref?'<p class="ref">根拠：'+esc(q.ref)+'</p>':'')
     +'<div class="row-act">'+(hasText(q.s,q.t)?'<button class="linkbtn" type="button" data-act="open-text" data-s="'+q.s+'" data-sec="'+esc(q.t)+'">テキストで確認</button>':'')+(ST.flags[id]?'<span class="fine">報告済み（演習から外しました）</span>':'<button class="linkbtn" type="button" data-act="flag">誤りを報告</button>')+'<span class="fine">問題番号 '+esc(id)+'</span></div></div>';
  }
  h+='</div></div><div class="p-foot gut">'+(rev?'<button class="btn primary wide" type="button" data-act="next">次へ</button>':'<p class="fine center">'+(s.phase==='answer'?(isTF(q)?'正しければ○、誤りなら×':'答えを1つ選ぶ'):'自信を選ぶと答え合わせ')+'</p>')+'</div>';
  el.innerHTML=h;
}
function sessDone(s){
  var seen={},wrong=[],uniq=0,ok1=0,rt=0,rtOk=0;
  s.res.forEach(function(r){if(!seen[r.id]){seen[r.id]=1;uniq++;if(r.ok)ok1++;else{var q=DATA.qById[r.id];if(q)wrong.push(q);}}else{rt++;if(r.ok)rtOk++;}});
  var h='<div class="p-top gut"><span class="p-title">演習の結果</span></div><div class="p-scroll"><div class="p-body gut">';
  if(!uniq)h+='<p class="lead">記録した解答はありません。</p>';
  else{h+='<div class="score"><b>'+ok1+'</b><span>/ '+uniq+'問 正解</span></div><p class="fine">'+(rt?'間違えた'+rt+'問をもう一度出題し'+(rtOk?'、そのうち'+rtOk+'問を正解しました。':'ました。'):'')+(s.mins?s.mins+'分を学習時間に記録しました。':'学習タイマーで計測中のため、演習時間は別に記録していません。')+'</p>';
    h+=wrong.length?'<section class="sec"><div class="sec-h"><span>間違えた問題</span></div><ul class="list">'+wrong.map(function(q){var a=isTF(q)?(q.a?'○':'×'):LT[q.a];return '<li class="wr"><span class="wr-a" aria-hidden="true">'+a+'</span><span class="wr-b">'+esc(q.q)+'<small>正しくは'+a+'。'+esc(q.e)+'</small></span></li>';}).join('')+'</ul></section>':'<p class="lead">全問正解です。</p>';}
  h+='</div></div><div class="p-foot two gut"><button class="btn ghost" type="button" data-act="s-done">閉じる</button><button class="btn primary" type="button" data-act="s-more">続けて10問</button></div>';
  return h;
}
function pick(v){var s=UI.sess;if(!s||s.phase!=='answer')return;s.pick=v;s.phase='conf';renderSession();}
function answerConf(conf){
  var s=UI.sess;if(!s||s.phase!=='conf')return;
  var id=s.q[s.i],q=DATA.qById[id];if(!q)return;
  var ok=correctOf(q,s.pick),g=!ok?1:conf==='sure'?3:conf==='unsure'?2:1,prev=ST.srs[id],now=Date.now();
  var rec=Object.assign(fsrs(prev,g,now),{att:((prev&&prev.att)||0)+1,cor:((prev&&prev.cor)||0)+(ok?1:0),cw:((prev&&prev.cw)||0)+(!ok&&conf==='sure'?1:0),lc:conf});
  if(!prev)s.newCount++;
  ST.srs[id]=rec;save();
  s.res.push({id:id,ok:ok});
  if(!ok&&!s.requeued[id]){s.requeued[id]=1;s.q.push(id);}
  s.phase='reveal';renderSession();
}
function nextCard(){var s=UI.sess;if(!s)return;s.i++;s.pick=null;s.confirmEnd=false;if(s.i>=s.q.length)finishSession();else{s.phase='answer';renderSession();var sc=$('#sess .p-scroll');if(sc)sc.scrollTop=0;}}
function finishSession(){
  var s=UI.sess;if(!s)return;
  var n=s.res.length,cor=s.res.filter(function(r){return r.ok;}).length,mins=(n&&!ST.timer)?Math.max(1,Math.round((Date.now()-s.t0)/60000)):0;
  if(n)bumpDay({min:mins,ans:n,cor:cor,nw:s.newCount});
  s.mins=mins;s.phase='done';renderSession();schedRender();
}
function bumpDay(d){var k=todayKey(),cur=ST.days[k]||{};ST.days[k]={min:Math.max(0,(cur.min||0)+(d.min||0)),ans:(cur.ans||0)+(d.ans||0),cor:(cur.cor||0)+(d.cor||0),nw:(cur.nw||0)+(d.nw||0)};save();}

/* ---------- 過去問のマークシート ---------- */
function openSheet(s,y){
  var e=pastYear(y);if(!e)return;var se=e.subjects[s];
  if(!se.items){UI.tab='judge';UI.manual={s:s,y:String(y),p:''};setTab('judge');setTimeout(function(){var n=document.getElementById('mn-p');if(n)n.focus();},50);return;}
  var first=!attemptsOf(s,y).length;
  UI.sheet={s:s,y:+y,marks:{},phase:(isReserve(y)&&first)?'gate':'mark',t0:null,result:null,first:first};
  $('#msheet').hidden=false;renderSheet();
}
function renderSheet(){
  var m=UI.sheet,el=$('#msheet');
  if(!m){el.hidden=true;el.innerHTML='';return;}
  var e=pastYear(m.y),se=e.subjects[m.s],sub=SN[m.s],lim=DATA.syl.subjects.filter(function(x){return x.k===m.s;})[0].min;
  var h='<div class="p-top gut"><button class="icon" type="button" data-act="ms-close" aria-label="閉じる">×</button><span class="p-title">'+esc(sub.n)+'<small>'+esc(e.label)+(isReserve(m.y)?'・仕上げ用':'')+'・'+lim+'分</small></span>'+(m.t0&&m.phase==='mark'?'<span class="ptimer" id="ptimer">'+fmtClock(Math.max(0,lim*60000-(Date.now()-m.t0)))+'</span>':'')+'</div><div class="p-scroll"><div class="p-body gut">';
  if(m.phase==='gate'){
    h+='<div class="gate"><h2 class="ttl">仕上げ用の年度です</h2><p class="note">初めて解いた結果を「初見判定」に使います。練習の判定（直近2年度で'+PASS+'点以上）を満たしてから解くのがおすすめです。</p>'
     +'<p class="fine">いま解くと、この年度は初見の判定に使えなくなります。</p><div class="row2"><button class="btn ghost" type="button" data-act="ms-close">やめる</button><button class="btn primary" type="button" data-act="ms-gate-ok">初見判定として解く</button></div></div>';
  } else if(m.phase==='mark'){
    h+='<p class="fine"><a href="'+esc(se.pdf)+'" target="_blank" rel="noopener">問題PDFを開く（公式）</a>。解きながら、ここに答えをマークします。'+(m.t0?'':'時間を計るなら「開始」を押してください。')+'</p>'
     +(m.t0?'':'<button class="btn small ghost" type="button" data-act="ms-start">'+lim+'分のタイマーを開始</button>');
    h+='<div>'+se.items.map(function(it){var p=it.n.split('-');return '<div class="ms-row"><span class="ms-n">第'+p[0]+'問'+(p[1]?'<small>設問'+p[1]+'</small>':'')+'</span><span class="ms-b" role="group" aria-label="第'+esc(it.n)+'問の解答">'
      +LT.map(function(l){var on=m.marks[it.n]===l;return '<button class="mb'+(on?' on':'')+'" type="button" data-act="ms-mark" data-n="'+it.n+'" data-l="'+l+'" aria-pressed="'+on+'">'+l+'</button>';}).join('')+'</span></div>';}).join('')+'</div>';
  } else {
    var r=m.result;
    h+='<div class="score"><b>'+r.score+'</b><span>/ 100点（'+r.ok+'/'+se.items.length+'問正解）</span></div>'
     +'<p class="note">'+(r.score>=PASS?'科目合格の基準（60点）を満たしています。':r.score>=CUT?'40点以上ですが、60点に'+(PASS-r.score)+'点届いていません。':'40点未満です。本試験では足切りになります。')+'</p>'
     +(isReserve(m.y)&&m.first?'<p class="fine">初見判定の結果として記録しました。</p>':'');
    var wrongG={};se.items.forEach(function(it){if(!keyOk(it,m.marks[it.n])&&it.t){var g=groupOf(it.t);wrongG[g]=(wrongG[g]||0)+1;}});
    var wg=Object.keys(wrongG).sort(function(a,b){return wrongG[b]-wrongG[a];});
    if(wg.length)h+='<section class="sec"><div class="sec-h"><span>間違えた論点</span></div><ul class="list">'+wg.map(function(g){var G=DATA.groups[g],nq=(DATA.q[m.s]||[]).filter(function(q){return groupOf(q.t)===g;}).length;
      return '<li class="todo"><div class="todo-t"><b>'+esc(G?G.g.n:g)+'</b><span>'+wrongG[g]+'問'+(nq?'・アプリの演習'+nq+'問':'・アプリの演習問題は次の版から')+'</span></div>'+(nq?'<button class="btn small" type="button" data-act="drill-group" data-g="'+g+'">演習</button>':'')+'</li>';}).join('')+'</ul></section>';
    else if(!se.items.some(function(it){return it.t;}))h+='<p class="fine">この年度は、設問と論点の対応づけを次の版で追加します。</p>';
    h+='<div>'+se.items.map(function(it){var p=it.n.split('-'),mk=m.marks[it.n],good=keyOk(it,mk),tn=it.t&&DATA.items[it.t]?DATA.items[it.t].n:'';
      return '<div class="ms-row"><span class="ms-n">第'+p[0]+'問'+(p[1]?'<small>設問'+p[1]+'</small>':'')+'</span><span class="ms-b">'+LT.map(function(l){var on=mk===l,ok=it.a!=='*'&&it.a.split('/').indexOf(l)>=0;return '<button class="mb'+(on?' on':'')+(ok?' ok':'')+'" type="button" disabled aria-label="'+l+(on?'（あなたの解答）':'')+(ok?'（正解）':'')+'">'+l+'</button>';}).join('')+'</span>'
       +'<span class="ms-res"><span class="ms-t">'+esc(tn)+'</span><span>正解 '+(it.a==='*'?'全員正解':esc(it.a))+'・'+it.p+'点</span><b class="'+(good?'ok':'ng')+'">'+(good?'○':'×')+'</b></span></div>';}).join('')+'</div>'
     +'<p class="fine">正解と配点：<a href="'+esc(se.key)+'" target="_blank" rel="noopener">中小企業診断協会の公表資料</a></p>';
  }
  h+='</div></div>';
  if(m.phase==='mark'){var n=Object.keys(m.marks).length;h+='<div class="p-foot gut"><button class="btn primary wide" type="button" data-act="ms-score">採点する（'+n+'/'+se.items.length+'問マーク済み）</button></div>';}
  if(m.phase==='done')h+='<div class="p-foot two gut"><button class="btn ghost" type="button" data-act="ms-close">閉じる</button><button class="btn primary" type="button" data-act="tab-judge">判定を見る</button></div>';
  el.innerHTML=h;
}
function scoreNow(){
  var m=UI.sheet,e=pastYear(m.y),se=e.subjects[m.s],r=scoreSheet(se.items,m.marks);
  var first=!attemptsOf(m.s,m.y).length;
  var at={id:uid('p'),y:m.y,s:m.s,at:Date.now(),mode:'sheet',score:r.score,ok:r.ok,total:se.items.length,marks:Object.assign({},m.marks),first:first,mins:m.t0?Math.round((Date.now()-m.t0)/60000):null};
  ST.past.push(at);
  if(m.t0&&!ST.timer){bumpDay({min:Math.max(1,at.mins)});}
  save();m.result=r;m.phase='done';m.first=first;renderSheet();schedRender();
}

/* ---------- 小さな操作 ---------- */
function toast(msg,undo){var t=$('#toast');t.innerHTML='<span>'+esc(msg)+'</span>'+(undo?'<button class="linkbtn inv" type="button" data-act="undo-add">取り消す</button>':'');t.hidden=false;clearTimeout(UI.toastT);UI.toastT=setTimeout(function(){t.hidden=true;},undo?6000:2800);}
function setTab(t){UI.tab=t;UI.setDraft=null;UI.confirmImport=null;try{localStorage.setItem(STORE+'-tab',t);}catch(e){}$('#main').scrollTop=0;render();}
function draftOf(st){return {wdMin:String(st.wdMin),weMin:String(st.weMin),newPerDay:String(st.newPerDay),exam1:st.exam1,exam2:st.exam2};}
function setBind(path,val){var p=path.split('.');if(p[0]==='setDraft'&&!UI.setDraft)UI.setDraft=draftOf(ST.settings);var o=UI[p[0]];if(o)o[p[1]]=val;}
function saveSettings(){
  var d=UI.setDraft||{},st=ST.settings;
  function num(v,lo,hi,df){var x=Math.round(Number(v));return isFinite(x)&&x>=lo&&x<=hi?x:df;}
  function dt(v,df){return /^\d{4}-\d{2}-\d{2}$/.test(String(v||''))?v:df;}
  ST.settings=Object.assign({},st,{wdMin:num(d.wdMin,0,600,st.wdMin),weMin:num(d.weMin,0,900,st.weMin),newPerDay:num(d.newPerDay,0,100,st.newPerDay),exam1:dt(d.exam1,st.exam1),exam2:dt(d.exam2,st.exam2)});
  UI.setDraft=null;save();if(document.activeElement&&document.activeElement.blur)document.activeElement.blur();toast('設定を保存しました');render();
}
function addManual(){
  var m=UI.manual,raw=String(m.p==null?'':m.p).trim(),p=Number(raw);
  if(raw===''||!isFinite(p)||p<0||p>100){toast('点数は0〜100で入力してください');return;}
  var sc=Math.round(p),first=!attemptsOf(m.s,m.y).length;
  ST.past.push({id:uid('p'),y:+m.y,s:m.s,at:Date.now(),mode:'manual',score:sc,first:first});save();
  m.p='';var el=document.getElementById('mn-p');if(el){el.value='';el.blur();}
  toast(SN[m.s].n+'を'+sc+'点で記録しました');render();
}
function doExport(){
  saveNow();
  var blob=new Blob([JSON.stringify({app:'shindanshi-trainer',ver:APP_VER,exportedAt:new Date().toISOString(),state:ST},null,1)],{type:'application/json'});
  var name='shindanshi-1ji-'+todayKey()+'.json';
  try{var f=new File([blob],name,{type:'application/json'});if(navigator.canShare&&navigator.canShare({files:[f]})){navigator.share({files:[f],title:'学習記録'}).catch(function(){});return;}}catch(e){}
  var a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1000);
}
function onImportFile(file){
  var r=new FileReader();
  r.onload=function(){try{var o=JSON.parse(r.result);if(!o||o.app!=='shindanshi-trainer'||!o.state||o.state.v!==1)throw new Error('format');UI.confirmImport={state:o.state,label:(o.exportedAt?o.exportedAt.slice(0,10):'')+'時点'};setTab('log');}catch(e){toast('このファイルは読み込めません');}};
  r.readAsText(file);
}

/* ---------- 操作 ---------- */
document.addEventListener('click',function(ev){
  var b=ev.target.closest('[data-act]');if(!b||b.disabled)return;
  var a=b.dataset.act,s=UI.sess,m=UI.sheet;
  switch(a){
    case 'tab':setTab(b.dataset.tab);break;
    case 'tab-judge':UI.sheet=null;renderSheet();setTab('judge');break;
    case 'go':startSession(Number(b.dataset.n)||10);break;
    case 'ahead':startSession(10,null,true);break;
    case 'drill-group':{var g=b.dataset.g;if(UI.sheet){UI.sheet=null;renderSheet();}startSession(10,function(q){return groupOf(q.t)===g;});break;}
    case 'open-text':openText(b.dataset.s,b.dataset.ch||null,b.dataset.sec||null,!!(UI.sess&&!$('#sess').hidden));break;
    case 'rd-close':UI.reader=null;renderReader();break;
    case 'rd-go':if(UI.reader){UI.reader.ch=b.dataset.ch;UI.reader.sec=null;renderReader();var rs=$('#reader .p-scroll');if(rs)rs.scrollTop=0;}break;
    case 'rd-drill':{var rg=b.dataset.g;UI.reader=null;renderReader();if(UI.sheet){UI.sheet=null;renderSheet();}startSession(10,function(q){return groupOf(q.t)===rg;});break;}
    case 'drill-subj':{var sk=b.dataset.s;startSession(10,function(q){return q.s===sk;});break;}
    case 'open-syl':UI.drillSub=b.dataset.s;$('#main').scrollTop=0;render();break;
    case 'close-syl':UI.drillSub=null;render();break;
    case 't-start':ST.timer=Date.now();save();render();break;
    case 't-stop':{var mm=Math.round((Date.now()-ST.timer)/60000);ST.timer=null;save();if(mm>=1){bumpDay({min:mm});toast(mm+'分を記録しました');}else toast('1分未満のため記録しませんでした');render();break;}
    case 'add-min':{var mn=Number(b.dataset.m)||0;bumpDay({min:mn});UI.lastAdd={m:mn,at:Date.now()};toast(mn+'分を記録しました',true);render();break;}
    case 'undo-add':if(UI.lastAdd&&Date.now()-UI.lastAdd.at<10000){bumpDay({min:-UI.lastAdd.m});UI.lastAdd=null;toast('取り消しました');render();}break;
    case 'pick':pick(isTF(DATA.qById[s.q[s.i]])?b.dataset.v==='1':Number(b.dataset.v));break;
    case 'conf':answerConf(b.dataset.c);break;
    case 'next':nextCard();break;
    case 's-close':if(!s)break;if(s.phase==='done'||!s.res.length){UI.sess=null;renderSession();render();}else{s.confirmEnd=true;renderSession();}break;
    case 's-end':finishSession();break;
    case 's-continue':if(s){s.confirmEnd=false;renderSession();}break;
    case 's-done':UI.sess=null;renderSession();render();break;
    case 's-more':{UI.sess=null;renderSession();var c=counts();startSession(10,null,c.due+c.newToday===0);render();break;}
    case 'flag':{if(!s)break;var fid=s.q[s.i];ST.flags[fid]={at:Date.now()};save();toast('報告しました。「学習」タブに残ります');renderSession();break;}
    case 'unflag':delete ST.flags[b.dataset.id];save();toast('演習に戻しました');render();break;
    case 'toggle-active':{var k=b.dataset.s,act=ST.settings.active;ST.settings.active=SUBJ.map(function(x){return x.k;}).filter(function(x){return x===k?act.indexOf(k)<0:act.indexOf(x)>=0;});save();render();break;}
    case 'open-sheet':openSheet(b.dataset.s,b.dataset.y);break;
    case 'ms-close':UI.sheet=null;renderSheet();render();break;
    case 'ms-gate-ok':if(m){m.phase='mark';renderSheet();}break;
    case 'ms-start':if(m){m.t0=Date.now();renderSheet();}break;
    case 'ms-mark':if(m&&m.phase==='mark'){var n=b.dataset.n,l=b.dataset.l;if(m.marks[n]===l)delete m.marks[n];else m.marks[n]=l;renderSheet();}break;
    case 'ms-score':if(m&&m.phase==='mark')scoreNow();break;
    case 'export':doExport();break;
    case 'import':$('#importFile').click();break;
    case 'import-ok':if(UI.confirmImport){ST=Object.assign(blankState(),UI.confirmImport.state);ST.settings=Object.assign({},DEF,ST.settings||{});UI.confirmImport=null;saveNow();toast('読み込みました');render();}break;
    case 'import-cancel':UI.confirmImport=null;render();break;
    case 'sw-update':if(UI.swWaiting){UI.swWaiting.postMessage&&UI.swWaiting.postMessage('skip');location.reload();}break;
  }
});
document.addEventListener('change',function(ev){
  var t=ev.target;
  if(t.id==='importFile'){if(t.files&&t.files[0])onImportFile(t.files[0]);t.value='';return;}
  var bd=t.dataset&&t.dataset.bind;if(!bd)return;setBind(bd,t.value);if(t.tagName==='SELECT')render();
});
document.addEventListener('input',function(ev){var t=ev.target,bd=t.dataset&&t.dataset.bind;if(bd&&t.tagName!=='SELECT')setBind(bd,t.value);});
document.addEventListener('focusout',function(){setTimeout(function(){if(UI.dirty)render();},0);});
document.addEventListener('submit',function(ev){
  var f=ev.target,k=f.dataset&&f.dataset.form;if(!k)return;ev.preventDefault();
  if(k==='manual')addManual();else if(k==='settings')saveSettings();
});
document.addEventListener('keydown',function(ev){
  var s=UI.sess;if(!s||$('#sess').hidden||UI.reader)return;if(ev.target.closest&&ev.target.closest('input,select,textarea'))return;
  var k=ev.key.toLowerCase(),q=DATA.qById[s.q[s.i]];if(!q)return;
  if(s.phase==='answer'){if(isTF(q)){if(k==='o')pick(true);else if(k==='x')pick(false);}else{var i='12345'.indexOf(k);if(i>=0&&i<q.ch.length)pick(i);}}
  else if(s.phase==='conf'){if(k==='1')answerConf('sure');else if(k==='2')answerConf('unsure');else if(k==='3')answerConf('guess');}
  else if(s.phase==='reveal'&&k==='enter'){ev.preventDefault();nextCard();}
});
setInterval(function(){
  if(ST.timer){var f=document.getElementById('tface');if(f)f.textContent=fmtClock(Date.now()-ST.timer);}
  var m=UI.sheet;if(m&&m.t0&&m.phase==='mark'){var p=document.getElementById('ptimer');if(p){var lim=DATA.syl.subjects.filter(function(x){return x.k===m.s;})[0].min*60000;p.textContent=fmtClock(Math.max(0,lim-(Date.now()-m.t0)));}}
},1000);
setInterval(renderHeader,60000);

/* ---------- 起動 ---------- */
loadState();
render();
loadData().then(function(){render();return loadTexts();}).then(function(){render();}).catch(function(){
  $('#view').innerHTML='<section class="sheet"><p class="lead">問題データを読み込めませんでした。</p><p class="fine">通信できる場所で一度開くと、その後はオフラインでも使えます。</p><button class="btn primary" type="button" onclick="location.reload()">もう一度読み込む</button></section>';
});
if('serviceWorker' in navigator){
  window.addEventListener('load',function(){
    navigator.serviceWorker.register('sw.js').then(function(reg){
      function watch(w){if(!w)return;w.addEventListener('statechange',function(){if(w.state==='installed'&&navigator.serviceWorker.controller){UI.swWaiting=w;renderNote();}});}
      if(reg.waiting&&navigator.serviceWorker.controller){UI.swWaiting=reg.waiting;renderNote();}
      reg.addEventListener('updatefound',function(){watch(reg.installing);});
    }).catch(function(){});
  });
}
})();
