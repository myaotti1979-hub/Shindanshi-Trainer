import json,re,sys,os
R=sys.argv[1]
ver=lambda p: int(re.search(r"APP_VER='v(\d+)'",open(p,encoding='utf-8').read()).group(1))
if ver('index.html')<ver(R+'/index.html'): sys.exit('作業フォルダの index.html が公開版より古い（先にリポジトリの変更を戻す）')
for s in ['keizai','zaimu','kigyo','unei','homu','joho','chusho']:
    n=lambda p: sum(1 for q in json.load(open(p,encoding='utf-8'))['questions'] if q.get('x'))
    a,b=n('data/q_%s.json'%s),n(R+'/data/q_%s.json'%s)
    if a<b: sys.exit('q_%s.json の解説の図が公開版より少ない（%d < %d）。rebuild_qb_only.sh を確かめる'%(s,a,b))
for f in os.listdir(R+'/data'):
    if re.fullmatch(r'j.*\.json',f) and not os.path.exists('data/'+f): sys.exit('2次のデータ '+f+' が作業フォルダにない')
print('安全装置：OK')
