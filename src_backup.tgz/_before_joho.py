import importlib.util, glob, os
B = os.path.dirname(os.path.abspath(__file__))
T = {}
for f in sorted(glob.glob(os.path.join(B, 'text', 'joho_p*.before_vis.py'))):
    spec = importlib.util.spec_from_file_location(os.path.basename(f)[:-3].replace('.', '_'), f)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    T.update(m.T)
