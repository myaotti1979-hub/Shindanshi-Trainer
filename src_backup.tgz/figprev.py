# 図表の下見用ページを作る。引数: 図のモジュール（text/fig_*.py） [名前の接頭辞]
import sys, re, importlib.util, os
B = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(B, 'text'))
f = sys.argv[1]
pre = sys.argv[2] if len(sys.argv) > 2 else ''
spec = importlib.util.spec_from_file_location('m', f)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
html = open(os.path.join(B, 'pwa/index.html')).read()
css = re.search(r'<style>(.*?)</style>', html, re.S).group(1)
heads = re.findall(r'<link[^>]+fonts[^>]+>', html)
body = []
for k, v in m.FIG.items():
    if ',' in pre:
        if k not in pre.split(',') and k.split('.', 1)[-1] not in pre.split(','):
            continue
    elif not k.startswith(pre):
        continue
    body.append('<section class="pv"><div class="pvn">%s</div><figure class="tx-fig">%s</figure></section>' % (k, v))
out = ('<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">%s<style>%s\n'
       '.pv{padding:8px 12px;border-bottom:1px solid #ccc;background:var(--sheet)}.pvn{font-size:11px;color:#c00}</style></head>'
       '<body><div id="pv">%s</div></body></html>') % (''.join(heads), css, ''.join(body))
open(os.path.join(B, 'pwa/_figprev.html'), 'w').write(out)
print(len(body), 'figures')
