import json, csv, os
B="/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad"
D=B+"/pwa/data"
syl=json.load(open(D+"/syllabus.json",encoding="utf-8"))
items={it["id"]:it["n"] for s in syl["subjects"] for p in s["parts"] for g in p["groups"] for it in g["items"]}
cards=json.load(open(B+"/seed/local.json",encoding="utf-8"))["cards"]
MAP={
"kigyo-01":"kigyo.1.2.3","kigyo-02":"kigyo.1.2.3","kigyo-03":"kigyo.1.2.2","kigyo-04":"kigyo.1.3.1","kigyo-05":"kigyo.1.1.5",
"kigyo-06":"kigyo.1.3.2","kigyo-07":"kigyo.1.2.3","kigyo-08":"kigyo.1.2.2","kigyo-09":"kigyo.1.4.2","kigyo-10":"kigyo.1.4.2",
"kigyo-11":"kigyo.2.2.2","kigyo-12":"kigyo.2.2.1","kigyo-13":"kigyo.2.2.3","kigyo-14":"kigyo.2.4.2","kigyo-15":"kigyo.2.4.2",
"kigyo-16":"kigyo.2.4.2","kigyo-17":"kigyo.2.4.2","kigyo-18":"kigyo.2.5.1","kigyo-19":"kigyo.2.5.1","kigyo-20":"kigyo.2.7.3",
"kigyo-21":"kigyo.2.7.1","kigyo-22":"kigyo.2.8.5","kigyo-23":"kigyo.2.8.5","kigyo-24":"kigyo.2.8.5","kigyo-25":"kigyo.2.8.5",
"kigyo-26":"kigyo.2.8.1","kigyo-27":"kigyo.2.8.5","kigyo-28":"kigyo.2.8.3","kigyo-29":"kigyo.2.8.2",
"kigyo-30":"kigyo.3.2.2","kigyo-31":"kigyo.3.2.2","kigyo-32":"kigyo.3.3.1","kigyo-33":"kigyo.3.3.2","kigyo-34":"kigyo.3.3.2",
"kigyo-35":"kigyo.3.4.1","kigyo-36":"kigyo.3.4.2","kigyo-37":"kigyo.3.4.2","kigyo-38":"kigyo.3.4.3","kigyo-39":"kigyo.3.4.5",
"kigyo-40":"kigyo.3.5.2","kigyo-41":"kigyo.3.5.3","kigyo-42":"kigyo.3.6.1","kigyo-43":"kigyo.3.6.3","kigyo-44":"kigyo.3.7.2",
"kigyo-45":"kigyo.3.7.3","kigyo-46":"kigyo.3.8.1","kigyo-47":"kigyo.3.8.4","kigyo-48":"kigyo.3.8.5","kigyo-49":"kigyo.3.9.3",
"kigyo-50":"kigyo.3.9.4","kigyo-51":"kigyo.3.9.5","kigyo-52":"kigyo.3.10.1","kigyo-53":"kigyo.3.10.3","kigyo-54":"kigyo.3.11.1","kigyo-55":"kigyo.3.11.2",
"unei-01":"unei.1.4.4","unei-02":"unei.1.2.6","unei-03":"unei.1.2.6","unei-04":"unei.1.5.3","unei-05":"unei.1.5.3",
"unei-06":"unei.1.5.3","unei-07":"unei.1.5.5","unei-08":"unei.1.5.5","unei-09":"unei.1.3.2","unei-10":"unei.1.3.1",
"unei-11":"unei.1.3.2","unei-12":"unei.1.3.2","unei-13":"unei.1.2.1","unei-14":"unei.1.2.8","unei-15":"unei.1.4.4",
"unei-16":"unei.2.2.1","unei-17":"unei.2.2.1","unei-18":"unei.2.1.1","unei-19":"unei.2.4.2","unei-20":"unei.2.3.3","unei-21":"unei.1.4.2",
"zaimu-01":"zaimu.1.8.2","zaimu-02":"zaimu.1.8.2","zaimu-03":"zaimu.1.9.2","zaimu-04":"zaimu.1.9.2","zaimu-05":"zaimu.1.7.2",
"zaimu-06":"zaimu.1.7.4","zaimu-07":"zaimu.1.10.1","zaimu-08":"zaimu.1.9.1","zaimu-09":"zaimu.1.5.2","zaimu-10":"zaimu.1.5.2",
"zaimu-11":"zaimu.1.6.4","zaimu-12":"zaimu.1.2.3","zaimu-13":"zaimu.1.10.2","zaimu-14":"zaimu.1.11.3","zaimu-15":"zaimu.1.11.2","zaimu-16":"zaimu.1.7.3",
"keizai-01":"keizai.1.5.2","keizai-02":"keizai.1.6.3","keizai-03":"keizai.1.2.1","keizai-04":"keizai.1.2.3","keizai-05":"keizai.1.2.3",
"keizai-06":"keizai.1.6.6","keizai-07":"keizai.1.6.7","keizai-08":"keizai.1.5.5","keizai-09":"keizai.1.5.5","keizai-10":"keizai.1.3.4",
"keizai-11":"keizai.1.1.1","keizai-12":"keizai.1.7.2",
"homu-01":"homu.1.2.1","homu-02":"homu.1.2.1","homu-03":"homu.1.2.1","homu-04":"homu.1.2.1","homu-05":"homu.1.1.1",
"homu-06":"homu.1.4.2","homu-07":"homu.1.2.2","homu-08":"homu.1.4.8","homu-09":"homu.1.4.1",
"joho-01":"joho.1.1.1","joho-02":"joho.1.3.1","joho-03":"joho.2.3.2","joho-04":"joho.2.3.2","joho-05":"joho.2.2.1","joho-06":"joho.2.5.2",
"chusho-01":"chusho.2.1.1","chusho-02":"chusho.2.1.1","chusho-03":"chusho.2.1.1","chusho-04":"chusho.2.1.1","chusho-05":"chusho.2.1.3","chusho-06":"chusho.2.1.3",
}
assert set(MAP)==set(cards), (set(cards)-set(MAP), set(MAP)-set(cards))
for cid,t in MAP.items():
    assert t in items, (cid,t)
by={}
for cid,c in sorted(cards.items(), key=lambda kv: kv[1]["n"]):
    q={"id":cid,"type":"tf","t":MAP[cid],"q":c["q"],"a":c["a"],"e":c["e"],"st":"draft","n":c["n"]}
    by.setdefault(c["s"],[]).append(q)
# 本試験の形式の問題（単答・組み合わせなど）：qbank/q_<科目>_*.py の Q。検証済み（qbank/verified.json）だけを出す（DRAFT=1 なら下書きも出す）
import glob, importlib.util, hashlib, re
# 正答の位置の偏りをなくす（問題IDから決まる並べ替え。何度作り直しても同じ。記述の真偽と選択肢の中身は変えない）
# ・組み合わせ問題：記述a～dの並びを入れ替え、6つの組のうち5つを解答群にする。注（「× bは誤り」など）は作り直し、
#   解説・図の説明の中の記述の記号（「aとb」「（c）」など）も付け替える
# ・数値の選択肢（keep=True で、どの選択肢にも数字がある）：正答の位置を散らして並べ替える。数字のない keep は並びを保つ
# ・正答の位置は、科目ごとに問題IDの順で5問（数値の問題は4問）ずつ区切り、その中で同じ位置が重ならないように決める
PAIRS=["aとb","aとc","aとd","bとc","bとd","cとd"]
LET="abcd"
_REF=re.compile(r'(?<![A-Za-z0-9_.\-=+*/^])([a-d])(?![A-Za-z0-9_.\-=+*/^])')
def _hx(s): return hashlib.sha1(s.encode()).hexdigest()
def _relabel(s,mp):
    def one(p):
        p=_REF.sub(lambda m:mp[m.group(1)],p)
        # 「cとa」のように付け替わった組は、記号の順に並べ直す
        return re.sub(r'(?<![A-Za-z0-9_.\-])([a-d])と([a-d])(?![A-Za-z0-9_.\-])',lambda m:"と".join(sorted(m.groups())),p)
    parts=re.split(r'(\[\[図:[^\]]+\]\])',s)
    return "".join(p if p.startswith("[[図:") else one(p) for p in parts)
def _combo_ce(ch,true,suf):
    return ["○" if set(p.split("と"))==set(true) else "× "+"と".join(t for t in p.split("と") if t not in true)+suf for p in ch]
def _combo(qid,x,t):
    # t：解答群の中の正答の位置（0～4）
    stm=list(x["stm"]); ch0=list(x["ch"]); ce0=list(x.get("ce") or [])
    assert len(stm)==4 and all(p in PAIRS for p in ch0),("組み合わせの形",qid)
    true0=ch0[x["a"]].split("と")
    suf=None
    for c in ce0:
        m=re.fullmatch(r"× [a-d](?:と[a-d])?(.*)",c)
        if m: suf=m.group(1); break
    assert suf is not None and _combo_ce(ch0,true0,suf)==ce0,("組み合わせの注の形",qid)
    cand=[(an,ex) for an in PAIRS for ex in PAIRS if ex!=an and [p for p in PAIRS if p!=ex].index(an)==t]
    ans,excl=min(cand,key=lambda c:_hx(qid+"#ch#"+c[0]+c[1]))
    ch=[p for p in PAIRS if p!=excl]
    tl=sorted(ans.split("と"),key=lambda L:_hx(qid+"#t#"+L))
    fl=sorted([L for L in LET if L not in ans],key=lambda L:_hx(qid+"#f#"+L))
    olds_t=[LET.index(L) for L in true0]; olds_f=[k for k in range(4) if LET[k] not in true0]
    mp={}
    for k,L in zip(olds_t,tl): mp[LET[k]]=L
    for k,L in zip(olds_f,fl): mp[LET[k]]=L
    new=[None]*4
    for k in range(4): new[LET.index(mp[LET[k]])]=stm[k]
    true=sorted(mp[L] for L in true0)
    assert "と".join(true)==ans
    return new,ch,ch.index(ans),_combo_ce(ch,true,suf),mp
def _isnum(x): return x["type"]=="single" and x.get("keep") and all(re.search(r"[0-9０-９]",c) for c in x["ch"])
RELABELED=[]
QB=[]
for f in sorted(glob.glob(B+"/qbank/q_*.py")):
    sp=importlib.util.spec_from_file_location("qb",f); m=importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    QB+=list(m.Q)
# 科目ごとに、組み合わせ問題・数値の選択肢の問題の正答の位置を、5問（4問）ごとに1つずつ散らす
_RANK={}; _CNT={}
for x in QB:
    k=(x["id"].split("-")[0],"combo" if x["type"]=="combo" else "num" if _isnum(x) else None)
    if k[1] is None: continue
    _RANK[x["id"]]=(k,_CNT.get(k,0)); _CNT[k]=_CNT.get(k,0)+1
def _target(qid,n):
    k,i=_RANK[qid]; b=i//n
    return sorted(range(n),key=lambda j:_hx("%s|%s|%d|%d"%(k[0],k[1],b,j)))[i%n]
VER=json.load(open(B+"/qbank/verified.json",encoding="utf-8")) if os.path.exists(B+"/qbank/verified.json") else {}
DRAFT=os.environ.get("DRAFT")=="1"
seen=set(cards)
nqb={"ok":0,"draft":0}
for i,x in enumerate(QB):
    qid=x["id"]; s=qid.split("-")[0]
    assert qid not in seen,("重複したID",qid); seen.add(qid)
    assert x["t"] in items,(qid,x["t"]); assert x["t"].split(".")[0]==s,(qid,x["t"])
    typ=x["type"]; assert typ in ("single","combo","tf"),(qid,typ)
    if typ=="tf":
        assert isinstance(x["a"],bool),qid
    else:
        assert isinstance(x["a"],int) and 0<=x["a"]<len(x["ch"]) and 2<=len(x["ch"])<=5,qid
        assert len(set(x["ch"]))==len(x["ch"]),("選択肢の重複",qid)
        if x.get("ce"): assert len(x["ce"])==len(x["ch"]),qid
    if typ=="combo": assert 2<=len(x["stm"])<=5,qid
    ok=qid in VER
    if not (ok or DRAFT): continue
    q={"id":qid,"type":typ,"t":x["t"],"q":x["q"],"a":x["a"],"e":x["e"],"st":"ok" if ok else "draft","n":1000+i}
    mp=None
    if typ=="combo":
        stm,ch,a,ce,mp=_combo(qid,x,_target(qid,5))
        q["stm"]=stm; q["ch"]=ch; q["a"]=a; q["ce"]=ce
        e2=_relabel(x["e"],mp)
        if e2!=x["e"]: RELABELED.append((qid,"e",x["e"],e2))
        q["e"]=e2
    elif typ!="tf":
        ch=list(x["ch"]); ce=list(x.get("ce") or []); a=x["a"]
        if _isnum(x):
            # 数値の選択肢：正答を決めた位置に置き、ほかの選択肢は問題IDから決まる順に並べる
            t=_target(qid,len(ch))
            rest=sorted([k for k in range(len(ch)) if k!=a],key=lambda k:_hx(qid+"|"+ch[k]))
            order=rest[:t]+[a]+rest[t:]
            ch=[ch[k] for k in order]; ce=[ce[k] for k in order] if ce else []; a=order.index(a)
        elif typ=="single" and not x.get("keep"):
            # 正答の位置を散らす（問題IDから決まる並べ替え。何度作り直しても同じ）
            order=sorted(range(len(ch)),key=lambda k:hashlib.sha1((qid+"|"+ch[k]).encode()).hexdigest())
            ch=[ch[k] for k in order]; ce=[ce[k] for k in order] if ce else []; a=order.index(a)
        q["ch"]=ch; q["a"]=a
        if ce: q["ce"]=ce
    for k,v in (("x","xsrc"),("f","fsrc"),("ref","ref")):
        if x.get(k):
            val=x[k]
            if mp and k in ("x","f"):
                val=_relabel(val,mp)
                if val!=x[k]: RELABELED.append((qid,k,x[k],val))
            q[v]=val
    by.setdefault(s,[]).append(q); nqb["ok" if ok else "draft"]+=1
print("本試験形式の問題",len(QB),"（出す：検証済み",nqb["ok"],"・下書き",nqb["draft"],"）")
with open(B+"/_relabel.log","w",encoding="utf-8") as lf:
    for r in RELABELED: lf.write("%s %s\n  前：%s\n  後：%s\n"%r)
print("組み合わせ問題で記号を付け替えた解説・図の説明",len(RELABELED),"（_relabel.log）")
for s in ["keizai","zaimu","kigyo","unei","homu","joho","chusho"]:
    json.dump({"s":s,"ver":1,"questions":by.get(s,[])},open(f"{D}/q_{s}.json","w",encoding="utf-8"),ensure_ascii=False,indent=0)
    print(s,len(by.get(s,[])))

# past exam data
SUB={"A":"keizai","B":"zaimu","C":"kigyo","D":"unei","E":"homu","F":"joho","G":"chusho"}
PDF={}
def qurl(y,L):
    # official question PDF URLs (from the official past-exam page)
    m={2026:("1ji2026","{L}1JC2026.pdf"),2025:("1ji2025","{L}1JI2025.pdf"),2024:("1ji2024","{L}1JI2024.pdf"),2023:("1ji2023","{L}1JI2023.pdf"),
       2022:("1ji2022","{L}1ji2022.pdf"),2021:("1ji2021","{L}1ji2021.pdf"),2020:("1ji2020","{L}1ji2020.pdf"),2019:("1ji2019","{L}1ji2019.pdf"),
       2018:("1ji2018","{L}1ji2018.pdf"),2017:("1ji2017","{l}1ji2017.pdf"),2016:("1ji2016","{l}1ji2016.pdf"),2015:("1ji2015","{l}1ji2015.pdf"),
       2014:("1ji2014","{l}1ji2014.pdf"),2013:("1ji2013","{l}1ji2013.pdf"),2012:("1ji2012","{l}1ji2012.pdf"),2011:("1ji2011","{l}1ji2011.pdf"),
       2010:("1ji2010","{l}1ji2010.pdf"),2009:("1ji2009","{l}1ji2009.pdf"),2008:("1ji2008","{l}1ji2008.pdf"),2007:("1ji2007","{l}1ji2007.pdf")}
    d,f=m[y]
    f=f.format(L=L,l=L.lower())
    if y==2008 and L=="A": f="a1j2008.pdf"
    return f"https://www.jf-cmca.jp/attach/test/shikenmondai/{d}/{f}"
KEYURL={
2026:{L:f"https://www.jf-cmca.jp/attach/test/r08/1ji_seikai/2026{L}.pdf" for L in "ABCDEFG"},
2025:{"A":"https://www.jf-cmca.jp/attach/test/r07/1ji_seikai/2025a.pdf","B":"https://www.jf-cmca.jp/attach/test/r07/1ji_seikai/2025b.pdf","C":"https://www.jf-cmca.jp/attach/test/r07/1ji_seikai/2025c.pdf","D":"https://www.jf-cmca.jp/attach/test/r07/1ji_seikai/d_v2_20250902.pdf","E":"https://www.jf-cmca.jp/attach/test/r07/1ji_seikai/2025e.pdf","F":"https://www.jf-cmca.jp/attach/test/r07/1ji_seikai/f_v2_20250902.pdf","G":"https://www.jf-cmca.jp/attach/test/r07/1ji_seikai/2025g.pdf"},
2024:{"A":"https://www.jf-cmca.jp/attach/test/r06/1ji_seikai/2024a.pdf","B":"https://www.jf-cmca.jp/attach/test/r06/1ji_seikai/2024b.pdf","C":"https://www.jf-cmca.jp/attach/test/r06/1ji_seikai/2024c.pdf","D":"https://www.jf-cmca.jp/attach/test/r06/1ji_seikai/Dv2_20240903.pdf","E":"https://www.jf-cmca.jp/attach/test/r06/1ji_seikai/2024e.pdf","F":"https://www.jf-cmca.jp/attach/test/r06/1ji_seikai/Fv2_20240903.pdf","G":"https://www.jf-cmca.jp/attach/test/r06/1ji_seikai/2024g.pdf"},
2023:{"A":"https://www.jf-cmca.jp/attach/test/r05/1ji_seikai/2023a.pdf","B":"https://www.jf-cmca.jp/attach/test/r05/1ji_seikai/2023b.pdf","C":"https://www.jf-cmca.jp/attach/test/r05/1ji_seikai/2023c.pdf","D":"https://www.jf-cmca.jp/attach/test/r05/1ji_seikai/2023dv2.pdf","E":"https://www.jf-cmca.jp/attach/test/r05/1ji_seikai/2023e.pdf","F":"https://www.jf-cmca.jp/attach/test/r05/1ji_seikai/2023f.pdf","G":"https://www.jf-cmca.jp/attach/test/r05/1ji_seikai/2023g.pdf"},
2022:{"A":"https://www.jf-cmca.jp/attach/test/r04/1j_seikai/2022a.pdf","B":"https://www.jf-cmca.jp/attach/test/r04/1j_seikai/2022b.pdf","C":"https://www.jf-cmca.jp/attach/test/r04/1j_seikai/2022c.pdf","D":"https://www.jf-cmca.jp/attach/test/r04/1j_seikai/2022dv2.pdf","E":"https://www.jf-cmca.jp/attach/test/r04/1j_seikai/2022e.pdf","F":"https://www.jf-cmca.jp/attach/test/r04/1j_seikai/2022fv2.pdf","G":"https://www.jf-cmca.jp/attach/test/r04/1j_seikai/2022g.pdf"},
}
WAREKI={2026:"令和8年度",2025:"令和7年度",2024:"令和6年度",2023:"令和5年度",2022:"令和4年度",2021:"令和3年度",2020:"令和2年度",2019:"令和元年度",2018:"平成30年度",2017:"平成29年度",2016:"平成28年度",2015:"平成27年度",2014:"平成26年度",2013:"平成25年度",2012:"平成24年度",2011:"平成23年度",2010:"平成22年度",2009:"平成21年度",2008:"平成20年度",2007:"平成19年度"}
years=[]
for y in range(2026,2006,-1):
    ent={"y":y,"label":WAREKI[y],"subjects":{}}
    for L,s in SUB.items():
        se={"pdf":qurl(y,L)}
        f=f"{B}/keys/{y}{L}.csv"
        if y in KEYURL and os.path.exists(f):
            rows=list(csv.reader(open(f,encoding="utf-8")))
            its=[]
            for r in rows:
                n=r[0] if r[1]=="-" else f"{r[0]}-{r[1]}"
                its.append({"n":n,"a":r[2],"p":int(r[3])})
            assert sum(i["p"] for i in its)==100,(y,L)
            se["key"]=KEYURL[y][L]; se["items"]=its
        ent["subjects"][s]=se
    years.append(ent)
# 採点の対象外の試験（問題PDFのリンクだけ。公式の過去の試験問題のページに載っている）
EXTRA=[{"after":2023,"label":"令和5年度（再試験）","pdfs":{s:f"https://www.jf-cmca.jp/attach/test/shikenmondai/1ji(sai)2023/{L}1JI2023-2.pdf" for L,s in SUB.items()}}]
past={"source":"中小企業診断協会「第1次試験の正解と配点」・過去の試験問題（公式サイト）","pastpage":"https://www.jf-cmca.jp/contents/010_c_/shikenmondai.html","reserve":[2026,2025],"years":years,"extra":EXTRA}
json.dump(past,open(D+"/past.json","w",encoding="utf-8"),ensure_ascii=False,separators=(",",":"))
nk=sum(1 for y in years for s in y["subjects"].values() if "items" in s)
print("past years",len(years),"subject keys",nk)
