#!/usr/bin/env python3
"""Add newly reviewed mock exam question IDs to verified.json."""
import json

B = '/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/'

new_ids = []
for s in ['chusho_5', 'chusho_6', 'chusho_7', 'kigyo_7']:
    fname = B + 'pwa/data/m_' + s + '.json'
    d = json.load(open(fname))
    for item in d['items']:
        if 'id' in item:
            new_ids.append(item['id'])
        for sub in item.get('qs', []):
            if 'id' in sub:
                new_ids.append(sub['id'])

v = json.load(open(B + 'mock/verified.json'))
before = len(v)
v.extend([x for x in new_ids if x not in v])
v.sort()
json.dump(v, open(B + 'mock/verified.json', 'w'), indent=1)
print(f'verified.json: {before} → {len(v)} (+{len(v) - before})')
