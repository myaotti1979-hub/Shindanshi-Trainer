# 模擬試験のセットの全問を mock/verified.json に入れる
# 使い方: python3 mark_set.py <科目>_<回> ...（pwa/data/m_<科目>_<回>.json の id を使う）
import sys, json
B = '/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/'
p = B + 'mock/verified.json'
v = json.load(open(p, encoding='utf-8'))
for a in sys.argv[1:]:
    d = json.load(open(B + 'pwa/data/m_%s.json' % a, encoding='utf-8'))
    ids = []
    for q in d['items']:
        if 'id' in q:
            ids.append(q['id'])
        for x in q.get('qs', []):
            ids.append(x['id'])
    new = [i for i in ids if i not in v]
    v += new
    print(a, len(ids), '問', '追加', len(new))
json.dump(v, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('verified.json', len(v))
