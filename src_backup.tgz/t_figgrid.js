// 図表だけを並べて写す（確認用）。引数: 科目 章ID 図の名前（aria-label）をカンマ区切り 出力名
const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const [s,ch,labels,name,scheme='light']=process.argv.slice(2);
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:390,height:900},deviceScaleFactor:1,serviceWorkers:'block',colorScheme:scheme});
  const p=await ctx.newPage();
  await p.goto('http://127.0.0.1:8765/index.html');await p.waitForTimeout(1200);
  await p.click('[data-act=tab][data-tab=drill]');await p.waitForTimeout(100);
  await p.click('[data-act=open-syl][data-s='+s+']');await p.waitForTimeout(120);
  await p.click(`[data-act=open-text][data-ch="${ch}"]`);await p.waitForTimeout(300);
  const want=labels==='*'?null:labels.split(',');
  const figs=await p.$$('#reader figure.tx-fig');
  let i=0;const shots=[];
  for(const f of figs){const lab=await f.$eval('svg',e=>e.getAttribute('aria-label'));if(want&&!want.includes(lab))continue;
    const path=B+'/shots/fg-'+name+'-'+(i++)+'.png';await f.screenshot({path});shots.push(path);}
  console.log(JSON.stringify(shots));
  await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
