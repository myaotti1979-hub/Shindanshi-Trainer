const http = require('http'), fs = require('fs'), path = require('path');
const srv = http.createServer((q,r)=>{
  let f = path.join('.', q.url==='/'?'index.html':q.url);
  try{const d=fs.readFileSync(f);const t=f.endsWith('.json')?'application/json':f.endsWith('.js')?'text/javascript':'text/html';r.writeHead(200,{'Content-Type':t+'; charset=utf-8'});r.end(d);}
  catch(e){r.writeHead(404);r.end('Not found');}
});
srv.listen(0, async()=>{
  const port = srv.address().port;
  const {chromium} = require('playwright');
  const b = await chromium.launch();
  const p = await b.newPage({viewport:{width:390,height:844},deviceScaleFactor:2});
  const SS = '/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/';

  await p.goto('http://localhost:'+port+'/');
  await p.waitForTimeout(2000);
  await p.click('[data-stage="s2"]');
  await p.waitForTimeout(1000);
  await p.click('[data-tab="jex"]');
  await p.waitForTimeout(1000);
  await p.click('[data-act="ex-open"]');
  await p.waitForTimeout(500);

  // Scroll to bottom to see API key input and buttons
  await p.evaluate(()=>window.scrollTo(0, document.body.scrollHeight));
  await p.waitForTimeout(300);
  await p.screenshot({path: SS+'v38_apikey.png'});

  // Scroll to Q1 and type answers
  await p.evaluate(()=>{document.getElementById('exq1').scrollIntoView();});
  await p.waitForTimeout(300);
  const tas = await p.locator('.ex-ta').all();
  if(tas.length >= 2) {
    await tas[0].fill('熟練職人の手作り製法と地元で長年培ったブランド力が強みである。');
    await tas[1].fill('技術の属人化が進み後継者育成ができていないこと。');
  }
  await p.waitForTimeout(300);
  await p.screenshot({path: SS+'v38_answered.png'});

  // Scroll to bottom
  await p.evaluate(()=>window.scrollTo(0, document.body.scrollHeight));
  await p.waitForTimeout(300);
  await p.screenshot({path: SS+'v38_buttons.png'});

  await b.close();
  srv.close();
  console.log('Done');
});
