#!/bin/sh
# 演習問題の再生成：seed/local.json → q_*.json（build_data.py）→ 過去問の論点タグ（past_topics.py）→ 検証の修正（apply_review.py）→ 解説の図表（build_qfig.py）→ 模擬試験（build_mock.py）→ テキストの場所（build_anchor.py）
# past.json は内容が変わらなければ元のファイルに戻す（キーの並びだけの差分を出さない）
set -e
cd "$(dirname "$0")"
cp pwa/data/past.json _past_keep.json
python3 build_data.py
python3 past_topics.py
python3 apply_review.py
python3 build_qfig.py > _qfig.log 2>&1 || { cat _qfig.log; echo "build_qfig.py が失敗した（解説の図が入らない）"; exit 1; }
tail -1 _qfig.log
rc=0; python3 build_mock.py || rc=$?
if [ $rc -eq 2 ]; then echo "（作成中で作れなかった模擬試験のセットがある。公開するセットは上の行で確かめる）"; elif [ $rc -ne 0 ]; then exit $rc; fi
# 演習・模試の「テキストで確認」で開く場所（テキスト build_text.py を作り直したときも、これを動かす）
python3 build_anchor.py
python3 -c "
import json,shutil
K='_past_keep.json'
if json.load(open(K))==json.load(open('pwa/data/past.json')): shutil.copy(K,'pwa/data/past.json'); print('past.json: 変更なし')
else: print('past.json: 内容が変わった')
"
