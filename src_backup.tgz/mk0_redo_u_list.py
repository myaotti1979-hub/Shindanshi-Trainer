import importlib.util, sys
B="/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad"
def load(path):
    spec=importlib.util.spec_from_file_location("m",path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
want=set(sys.argv[1].split(',')) if len(sys.argv)>1 else None
for r in range(1,8):
    m=load(f"{B}/mock/m_unei_{r}.py")
    for q in m.Q:
        if want and not any(q['t'].startswith(w) for w in want): continue
        print(f"r{r} Q{q['no']:>5} {q['t']:<12} {q.get('model',''):<9} p{q['p']} {q.get('lv','')} | {q['q'][:110]}")
