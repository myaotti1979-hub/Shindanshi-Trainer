# 独立検証の指摘（review/*.json）をテキストのソース（text/*.py の T 辞書）に反映する
# 使い方: python3 apply_text_review.py review/text_kigyo2.json text/kigyo_p2a.py text/kigyo_p2b.py [--dry] [--skip 3,7] [--only 1,2]
#  ・【置換前】…【置換後】… は文字列の完全一致で置換（ちょうど1か所に一致しない場合は手作業に回す）
#  ・【追加】… は該当の節に挿入。位置の指定（「…」の後）が本文で見つかればその段落の後、
#    見つからなければ囲み（【事例】【試験のポイント】【ひっかけ注意】）の前に入れる。
#    追加文が【ひっかけ注意】【試験のポイント】で始まる行だけなら、節の末尾に足す。
import json, sys, re, importlib.util, os

args = [a for a in sys.argv[1:] if not a.startswith('--')]
opts = [a for a in sys.argv[1:] if a.startswith('--')]
dry = '--dry' in opts
skip = set(); only = None
for i, a in enumerate(sys.argv):
    if a == '--skip': skip = set(int(x) for x in sys.argv[i + 1].split(','))
    if a == '--only': only = set(int(x) for x in sys.argv[i + 1].split(','))
args = [a for a in args if not re.fullmatch(r'[\d,]+', a)]
review, files = args[0], args[1:]

def load(f):
    spec = importlib.util.spec_from_file_location(os.path.basename(f)[:-3], f)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    head = open(f, encoding='utf-8').read().split('T = {}')[0]
    return m.T, head

def dump(f, T, head):
    out = [head.rstrip('\n') + '\nT = {}\n']
    for k, (title, content) in T.items():
        assert '"""' not in content and '\\' not in content, k
        out.append('T["%s"] = ("%s", """%s""")\n' % (k, title, content.strip('\n')))
    open(f, 'w', encoding='utf-8').write('\n'.join(out))

srcs = {f: load(f) for f in files}
def find_sec(sec):
    for f, (T, h) in srcs.items():
        if sec in T: return f, T
    return None, None

BOX = ('【事例】', '【試験のポイント】', '【ひっかけ注意】')
def insert_text(content, add, pos):
    add = add.strip('\n')
    lines = content.split('\n')
    if all(l.startswith(('【ひっかけ注意】', '【試験のポイント】')) for l in add.split('\n') if l.strip()):
        # 試験のポイントは既存の行に追記、ひっかけは末尾へ
        for l in add.split('\n'):
            if l.startswith('【試験のポイント】'):
                for i, x in enumerate(lines):
                    if x.startswith('【試験のポイント】'):
                        lines[i] = x + l[len('【試験のポイント】'):]; break
                else:
                    lines.append(l)
            elif l.strip():
                lines.append(l)
        return '\n'.join(lines), 'end'
    # 位置の指定から引用部分を取り出して探す
    for q in reversed(re.findall(r'「([^」]{4,})」', pos or '')):
        q2 = max(q.replace('...', '…').split('…'), key=len).strip('*').strip()
        if q2.endswith('：'): q2 = q2[:-1]
        if len(q2) < (2 if '**' in q else 4): continue
        if '**' in q and len(q2) < 4:
            q2 = '**' + q2 + '**'
        for i, x in enumerate(lines):
            if q2 in x and ('の前' in (pos or '') or '直前' in (pos or '')) and '箇条書きの最後' not in (pos or ''):
                block = add.split('\n')
                k = i
                pre = [''] if (k > 0 and lines[k - 1].strip() and block[0].startswith(('**', '【'))) else []
                post = [''] if (x.startswith(('**', '【')) or block[-1].startswith('【')) else []
                if x.startswith(BOX) and not block[0].startswith('【'):
                    # 囲みの前に本文を足す場合は、囲みのかたまりの先頭（空行の後）に入れる
                    while k > 0 and lines[k - 1].strip() and lines[k - 1].startswith(BOX): k -= 1
                    pre = [''] if (k > 0 and lines[k - 1].strip()) else []
                    post = ['']
                return '\n'.join(lines[:k] + pre + block + post + lines[k:]), 'before:' + q2[:20]
            if q2 in x:
                j = i
                while not lines[i].startswith('・') and j + 1 < len(lines) and lines[j + 1].strip() and not lines[j + 1].startswith(BOX) and not re.fullmatch(r'\*\*[^*]+\*\*', lines[j + 1].strip()):
                    j += 1
                block = add.split('\n')
                sep = [''] if block[0].startswith('**') else []
                return '\n'.join(lines[:j + 1] + sep + block + lines[j + 1:]), 'after:' + q2[:20]
    # 既定：最初の囲みの前
    for i, x in enumerate(lines):
        if x.startswith(BOX):
            k = i
            while k > 0 and not lines[k - 1].strip(): k -= 1
            block = add.split('\n')
            return '\n'.join(lines[:k] + [''] + block + lines[k:]), 'before-box'
    return content.rstrip('\n') + '\n\n' + add, 'end'

R = json.load(open(review, encoding='utf-8'))
manual = []
for i, r in enumerate(R):
    if i in skip or (only is not None and i not in only):
        continue
    fix = r['fix']; sec = r['section']
    if '【置換前】' in fix and '【置換後】' in fix:
        old = fix.split('【置換前】', 1)[1].split('【置換後】', 1)[0].strip('\n')
        new = fix.split('【置換後】', 1)[1].strip('\n')
        hits = [(f, k) for f, (T, h) in srcs.items() for k, (t, c) in T.items() if old in c]
        cnt = sum(T[k][1].count(old) for f, (T, h) in srcs.items() for k in T)
        if cnt != 1:
            manual.append((i, sec, 'replace-miss(%d)' % cnt, old[:50])); continue
        f, k = hits[0]
        T = srcs[f][0]; t, c = T[k]; T[k] = (t, c.replace(old, new))
        print('[%d] %s replace ok' % (i, sec))
    elif '【追加】' in fix:
        body = fix.split('【追加】', 1)[1]
        pos = ''
        b = body.lstrip()
        if b[:1] in '（(':
            depth = 0; inq = 0
            for j, ch in enumerate(b):
                if ch == '「': inq += 1
                elif ch == '」': inq = max(0, inq - 1)
                elif inq: continue
                elif ch in '（(': depth += 1
                elif ch in '）)':
                    depth -= 1
                    if depth == 0:
                        pos = b[1:j]; body = b[j + 1:].lstrip('\n'); break
        f, T = find_sec(sec)
        if not T:
            manual.append((i, sec, 'no-section', body[:50])); continue
        t, c = T[sec]
        c2, where = insert_text(c, body, pos)
        T[sec] = (t, c2)
        print('[%d] %s add %s' % (i, sec, where))
    else:
        manual.append((i, sec, 'unknown-format', fix[:50]))

if manual:
    print('--- 手作業が必要:')
    for x in manual: print(x)
if not dry:
    for f, (T, h) in srcs.items(): dump(f, T, h)
    print('written')
