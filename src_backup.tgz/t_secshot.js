// 節ごとの画面の写真（長い節も全体を写す）。引数: 科目 章ID 節ID [light|dark] [倍率]
const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const [s,ch,sec,scheme='light',dpr='2']=process.argv.slice(2);
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:390,height:9000},deviceScaleFactor:+dpr,serviceWorkers:'block',colorScheme:scheme});
  const p=await ctx.newPage();
  const errs=[];p.on('pageerror',e=>errs.push(e.message));
  await p.goto('http://127.0.0.1:8765/index.html');await p.waitForTimeout(1500);
  await p.click('[data-act=tab][data-tab=drill]');await p.waitForTimeout(120);
  await p.click('[data-act=open-syl][data-s='+s+']');await p.waitForTimeout(150);
  await p.click(`[data-act=open-text][data-ch="${ch}"]`);await p.waitForTimeout(500);
  const el=await p.$('#sec-'+sec.replace(/\./g,'-'));
  const out=B+'/shots/sec-'+sec+'-'+scheme+'.png';
  await el.screenshot({path:out});
  const ov=await p.evaluate(()=>{const d=document.documentElement;return [d.scrollWidth,d.clientWidth];});
  console.log(out, 'ovf',ov,'errs',errs);
  await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
