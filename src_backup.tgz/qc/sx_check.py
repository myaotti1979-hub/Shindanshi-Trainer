# 正誤の組み合わせの記述ごとの理由（sx）を確かめる
# 使い方：python3 -I qc/sx_check.py wip/mk2/sx_out_<番号>.json [wip/mk2/sx_<番号>.md]
#   ・正・誤が、正答の選択肢（ch[a]）の正誤と合うか ・記述の数と合うか ・長さ（理由が90字以内か） ・資料の問題がすべてあるか
import sys, os, re, json, types
S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out = json.load(open(sys.argv[1], encoding='utf-8'))
want = None
if len(sys.argv) > 2:
    want = re.findall(r'^### (m\d-[a-z]+-\S+)', open(sys.argv[2], encoding='utf-8').read(), re.M)
mods = {}
PT = re.compile(r'([a-e])[：:]\s*(正|誤)')
bad, ok = [], 0
for qid, sx in out.items():
    m = re.fullmatch(r'm(\d)-([a-z]+)-(.+)', qid)
    if not m: bad.append('%s：id の形' % qid); continue
    r, s, no = m.group(1), m.group(2), m.group(3)
    key = (s, r)
    if key not in mods:
        mod = types.ModuleType('m'); exec(open(os.path.join(S, 'mock', 'm_%s_%s.py' % key), encoding='utf-8').read(), mod.__dict__); mods[key] = mod
    x = next((q for q in mods[key].Q if str(q['no']) == no), None)
    if not x: bad.append('%s：問題がない' % qid); continue
    stm = x.get('stm') or []
    T = dict(PT.findall(x['ch'][x['a']]))
    if len(sx) != len(stm): bad.append('%s：記述 %d に理由 %d' % (qid, len(stm), len(sx))); continue
    for i, t in enumerate(sx):
        L = 'abcde'[i]
        mm = re.fullmatch(r'(正|誤)：(.+)', t.strip(), re.S)
        if not mm: bad.append('%s %s：「正：」「誤：」で始まっていない' % (qid, L)); continue
        if L in T and mm.group(1) != T[L]: bad.append('%s %s：正答では%s' % (qid, L, T[L]))
        if len(mm.group(2)) > 90: bad.append('%s %s：理由が長い（%d字）' % (qid, L, len(mm.group(2))))
        if re.match(r'^[a-e](は|の)', mm.group(2)): bad.append('%s %s：記号から書かない' % (qid, L))
    ok += 1
if want is not None:
    miss = [q for q in want if q not in out]
    if miss: bad.append('抜け：' + ' '.join(miss))
print('理由のある問題 %d、問題点 %d' % (ok, len(bad)))
for b in bad: print('  ×', b)
