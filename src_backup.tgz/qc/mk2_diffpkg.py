# 直し（模擬試験 review/mk2_*.json、演習 review/qb_abs_*.json）を当てた前後の問題を並べた、検証の担当の資料を作る
# 使い方：python3 -I qc/mk2_diffpkg.py <出力 .md> <直しの JSON> [...]
#   模擬試験：問題の dict(...) の前と後（当てた結果の全文）と、作成の担当のメモ（problem）を並べる
import sys, os, re, json, ast, glob
S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT, files = sys.argv[1], sys.argv[2:]


def items_of(text, key):
    t = ast.parse(text); out = {}
    for n in t.body:
        tg = n.targets[0] if isinstance(n, ast.Assign) else n.target if isinstance(n, ast.AugAssign) else None
        if tg is not None and getattr(tg, 'id', '') == 'Q' and isinstance(n.value, ast.List):
            for e in n.value.elts:
                v = next((ast.literal_eval(k.value) for k in e.keywords if k.arg == key), None)
                out[str(v)] = ast.get_source_segment(text, e)
    return out


out = ['# 検証の担当の資料：直した問題の前と後', '', '検証のしかたは wip/mk2/VERIFY_A.md。', '']
n = 0
for f in files:
    fx = json.load(open(f, encoding='utf-8'))
    m = re.search(r'mk\d+f?_([a-z]+)_(\d)\.json$', f)
    if m:
        s, r = m.group(1), int(m.group(2))
        path = os.path.join(S, 'mock', 'm_%s_%d.py' % (s, r))
        text = open(path, encoding='utf-8').read()
        before = items_of(text, 'no')
        for x in fx:
            no = x['id'].split('-', 2)[2]
            seg = before.get(no)
            if seg is None: continue
            new = seg
            for c in x.get('fixes', []):
                if new.count(c['old']) == 1: new = new.replace(c['old'], c['new'])
            if x.get('lv'): new = re.sub(r"lv='[ABCD]'", "lv='%s'" % x['lv'], new, count=1)
            out += ['## %s（%s）' % (x['id'], os.path.basename(path)), '', '作成の担当のメモ：' + (x.get('problem') or ''), '', '### 前', '```python', seg, '```', '### 後', '```python', new, '```', '']
            for e in x.get('figfix') or []:
                out += ['### 図の直し（%s）' % e.get('file', ''), '- 前：「%s」' % e.get('old', ''), '- 後：「%s」' % e.get('new', ''), '']
            n += 1
    else:
        allseg = {}
        for p in sorted(glob.glob(os.path.join(S, 'qbank', 'q_*.py'))):
            for k, v in items_of(open(p, encoding='utf-8').read(), 'id').items(): allseg[k] = (v, os.path.basename(p))
        for x in fx:
            seg, bn = allseg.get(x['id'], (None, None))
            if seg is None: continue
            new = seg
            for c in x.get('fixes', []):
                if new.count(c['old']) == 1: new = new.replace(c['old'], c['new'])
            out += ['## %s（qbank/%s）' % (x['id'], bn), '', '作成の担当のメモ：' + (x.get('problem') or ''), '', '### 前', '```python', seg, '```', '### 後', '```python', new, '```', '']
            n += 1
open(OUT, 'w', encoding='utf-8').write('\n'.join(out))
print('問題', n, '→', OUT)
