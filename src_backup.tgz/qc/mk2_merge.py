# 作成の担当の直しと、検証の担当の結果を合わせて、当てる直しを作る
# 使い方：python3 -I qc/mk2_merge.py --author review/mk2_kigyo_1.json [...] --verify wip/mk2/vf_out_kigyo_a.json [...] [--prefix mk3f]
#   --prefix：出力の名前の頭（既定 mk2f。D を足す作業 mk3 の分は mk3f にして、前の出力を上書きしない）
#   出力：模擬試験は review/mk2f_<科目>_<回>.json（apply_mkfix.py で当てる）、演習は review/qbf_abs.json（apply_qfix.py で当てる）
#   ・検証で revert の問題は当てない ・検証の結果がない問題は当てない（一覧に出す） ・fix は、作成の直しのあとに検証の直しを続けて当てる
import sys, os, re, json
S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args = sys.argv[1:]
PREFIX = 'mk2f'
if '--prefix' in args:
    PREFIX = args[args.index('--prefix') + 1]; args = args[:args.index('--prefix')] + args[args.index('--prefix') + 2:]
A = args[args.index('--author') + 1:args.index('--verify')] if '--verify' in args else args[args.index('--author') + 1:]
V = args[args.index('--verify') + 1:] if '--verify' in args else []
vm = {}
for f in V:
    for v in json.load(open(f, encoding='utf-8')):
        vm[v['id']] = v
out, miss, rev, nfix, nok = {}, [], [], 0, 0
for f in A:
    for e in json.load(open(f, encoding='utf-8')):
        v = vm.get(e['id'])
        if v is None:
            miss.append(e['id']); continue
        if v.get('verdict') == 'revert':
            rev.append((e['id'], v.get('problem', ''))); continue
        fx = list(e.get('fixes', [])) + (list(v.get('fixes', [])) if v.get('verdict') == 'fix' else [])
        if v.get('verdict') == 'fix': nfix += 1
        else: nok += 1
        m = re.fullmatch(r'm(\d)-([a-z]+)-(.+)', e['id'])
        key = ('%s_%s_%s' % (PREFIX, m.group(2), m.group(1))) if m else 'qbf_abs'
        ent = {'id': e['id'], 'verdict': 'fix', 'problem': (e.get('problem') or '') + ((' ／検証：' + v.get('problem', '')) if v.get('verdict') == 'fix' else ''), 'fixes': fx}
        lv = v.get('lv') or e.get('lv')
        if lv: ent['lv'] = lv
        out.setdefault(key, []).append(ent)
for k, lst in out.items():
    json.dump(lst, open(os.path.join(S, 'review', k + '.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('当てる：%d問（検証 ok %d・検証で直し %d）／取り消し %d／検証なし %d' % (nok + nfix, nok, nfix, len(rev), len(miss)))
for i, p in rev: print('  取り消し', i, p[:80])
if miss: print('  検証なし', ' '.join(miss))
print('出力：', ' '.join('review/%s.json' % k for k in sorted(out)))
