# 2回目の確かめの結果（wip/mk2/vf2_out_<番号>.json）を、当てる道具ごとに分ける
# 使い方：python3 -I qc/vf2_split.py wip/mk2/vf2_out_1.json [...]
#   出力：review/mk2v_<番号>.json（模擬試験。apply_mkfix.py で当てる）、review/qbv_<番号>.json（演習。apply_qfix.py）、
#         wip/mk2/fig_v2_<番号>.json（図。qc/fig_check.py --write で当てる）。hold の項目は一覧に出す（当てない）
import sys, os, re, json
S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for f in sys.argv[1:]:
    n = re.search(r'vf2_out_(\w+)\.json$', f).group(1)
    mk, qb, fg, hold, ok = [], [], [], [], 0
    for x in json.load(open(f, encoding='utf-8')):
        v = x.get('verdict')
        if v == 'hold':
            hold.append((x['id'], x.get('problem', ''))); continue
        if v != 'fix':
            ok += 1; continue
        fx = [c for c in (x.get('fixes') or []) if 'old' in c]
        if fx:
            ent = {'id': x['id'], 'verdict': 'fix', 'problem': x.get('problem', ''), 'fixes': fx}
            if x.get('lv'): ent['lv'] = x['lv']
            (mk if re.fullmatch(r'm\d-[a-z]+-.+', x['id']) else qb).append(ent)
        for e in x.get('figfix') or []:
            fg.append({'id': x['id'], 'file': e['file'], 'old': e['old'], 'new': e['new'], 'why': x.get('problem', '')[:120]})
    if mk: json.dump(mk, open(os.path.join(S, 'review', 'mk2v_%s.json' % n), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    if qb: json.dump(qb, open(os.path.join(S, 'review', 'qbv_%s.json' % n), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    if fg: json.dump(fg, open(os.path.join(S, 'wip', 'mk2', 'fig_v2_%s.json' % n), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('%s：ok %d・模擬試験の直し %d問・演習の直し %d問・図の直し %d件・止める %d問' % (os.path.basename(f), ok, len(mk), len(qb), len(fg), len(hold)))
    for i, p in hold: print('  止める', i, p[:120])
