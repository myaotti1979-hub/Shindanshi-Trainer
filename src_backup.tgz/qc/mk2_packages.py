# 模擬試験（第1〜7回）と演習を「本試験より少しだけ難しめ」に直す作業の、担当ごとの資料（パッケージ）を作る
# 使い方：python3 -I qc/mk2_packages.py <scratchpad のフォルダ>
#   先に qc/mock_worklist.py を実行しておく（wip/mock_work/<科目>_<回>.json を読む）
#   出力：wip/mk2/pkg_<名前>.md（文章の問題の直し）、wip/mk2/sx_<名前>.md（正誤の組み合わせの記述ごとの理由）、wip/mk2/qb_abs.md（演習）
import sys, os, json, re, ast, math, glob, statistics, io, contextlib
S = sys.argv[1]
W = os.path.join(S, 'wip', 'mock_work')
O = os.path.join(S, 'wip', 'mk2')
os.makedirs(O, exist_ok=True)
JP = dict(keizai='経済学・経済政策', zaimu='財務・会計', kigyo='企業経営理論', unei='運営管理', homu='経営法務', joho='経営情報システム', chusho='中小企業経営・中小企業政策')
PKG = [('kigyo_a', 'kigyo', [1, 2]), ('kigyo_b', 'kigyo', [3, 4]), ('kigyo_c', 'kigyo', [5]), ('kigyo_d', 'kigyo', [6, 7]),
       ('chusho_a', 'chusho', [1, 2, 3, 4]), ('chusho_b', 'chusho', [5, 6, 7]),
       ('unei_a', 'unei', [1, 2, 3, 4]), ('unei_b', 'unei', [5, 6, 7]),
       ('joho_a', 'joho', [1, 2, 3, 4]), ('joho_b', 'joho', [5, 6, 7]), ('homu_a', 'homu', [1, 2, 3, 4]), ('homu_b', 'homu', [5, 6, 7]),
       ('zaimu', 'zaimu', [1, 2, 3, 4, 5, 6, 7]), ('keizai', 'keizai', [1, 2, 3, 4, 5, 6, 7])]


def blocks(path):
    """ファイルの Q の各問題（dict(...)）の元の文字列と、LEAD の文字列"""
    src = open(path, encoding='utf-8').read()
    t = ast.parse(src)
    Q, LEAD = {}, {}
    for n in t.body:
        if isinstance(n, ast.Assign) and getattr(n.targets[0], 'id', '') == 'Q':
            for e in n.value.elts:
                seg = ast.get_source_segment(src, e)
                no = next((ast.literal_eval(k.value) for k in e.keywords if k.arg == 'no'), None)
                lead = next((ast.literal_eval(k.value) for k in e.keywords if k.arg == 'lead'), None)
                Q[str(no)] = (seg, lead)
        if isinstance(n, ast.Assign) and getattr(n.targets[0], 'id', '') == 'LEAD':
            LEAD = ast.literal_eval(n.value)
    return Q, LEAD


summary = []
for name, s, rounds in PKG:
    out = ['# 担当の資料：%s 第%s回' % (JP[s], '・'.join(map(str, rounds))), '',
           '作業のしかたは wip/mk2/AGENT_A.md。ここにあるのは、直す候補の問題の元の文字列（mock/m_%s_<回>.py の dict(...)）と、回ごとの目標。' % s, '']
    nitems = 0
    for r in rounds:
        wk = json.load(open(os.path.join(W, '%s_%d.json' % (s, r)), encoding='utf-8'))
        info, work = wk['info'], wk['work']
        Q, LEAD = blocks(os.path.join(S, 'mock', 'm_%s_%d.py' % (s, r)))
        n = info['n']; lvD = info['lv'].get('D', 0); needD = max(0, math.ceil(0.10 * n) - lvD)
        tgt = info['real_avg'] - 2
        nabs = info['abs_false']; qabs = math.ceil(0.45 * nabs)
        out += ['## 第%d回（%d問）' % (r, n), '',
                '- 知識なしの得点（文の肢は「断定のない肢の中でいちばん長いもの」、組み合わせは多数決）：いま %.0f点。目標は %d点以下（本試験の平均 %d点より少し低く）。%s' % (
                    info['score_plan'], tgt, info['real_avg'], '目標を超えているので、下の「狙われる」問題を、超えている分がなくなるまで直す。' if info['score_plan'] > tgt else 'いまは目標以下。「狙われる」問題のうち、正答の肢だけで当たる形（exploit 1.0）は直す。'),
                '- 誤りの肢の「必ず・すべて・のみ・一切・常に・だけ・限る」などの言い切り：候補の問題に %d本。そのうち %d本以上を、別の種類の誤り（要件・数値・主体・時期・用語の対応のずらし）に書き換える。' % (nabs, qabs),
                '- 難しさ D（難）：いま %d問。%s' % (lvD, ('あと%d問以上を D にする（下の「難しくする候補」から選ぶか、ほかの候補の問題を難しくする）。' % needD) if needD else '足りている。'),
                '- lv の配分のめど（1回分）：A 20〜30％・B 30〜40％・C 25〜35％・D 10〜15％。直した問題は lv を付け直す。', '']
        picked = []
        over = info['score_plan'] > tgt
        for w in sorted(work, key=lambda x: -x['exploit']):
            if w['abs_false'] or w['exploit'] >= (0.5 if over else 1.0):   # 目標以下の回は、正答の肢だけで当たる形（1.0）だけ
                picked.append((w['no'], w))
        done = {no for no, _ in picked}
        if needD:
            cand = []
            for no, (seg, lead) in Q.items():
                if no in done: continue
                m = re.search(r"lv='([ABCD])'", seg); p = re.search(r"p=(\d)", seg)
                if m and m.group(1) in 'BC' and 'stm=' not in seg:
                    cand.append((0 if m.group(1) == 'C' else 1, -(int(p.group(1)) if p else 0), no))
            for _, _, no in sorted(cand)[:needD * 2]:
                picked.append((no, {'no': no, 'harder': True}))
        leads = set()
        for no, w in picked:
            seg, lead = Q.get(str(no), (None, None))
            if seg is None: continue
            tags = []
            if w.get('exploit', 0) >= 0.5: tags.append('狙われる（exploit %.1f：%s）' % (w['exploit'], '・'.join(w['why'])))
            if w.get('abs_false'): tags.append('誤りの肢に言い切り %d本' % len(w['abs_false']))
            if w.get('harder'): tags.append('難しくする候補')
            out += ['### m%d-%s-%s　%s' % (r, s, no, ' ／ '.join(tags)), '', '```python', seg, '```', '']
            if lead: leads.add(lead)
            nitems += 1
        for L in sorted(leads):
            out += ['### 第%d回のリード文 %s（読むだけ。直すときは old に lead の文字列を使う）' % (r, L), '', '```', LEAD.get(L, '')[:3000], '```', '']
    open(os.path.join(O, 'pkg_%s.md' % name), 'w', encoding='utf-8').write('\n'.join(out))
    summary.append('%s %d問' % (name, nitems))

# 正誤の組み合わせ（a：正 b：誤 …）の記述ごとの理由（sx）：第1〜7回の全科目
SX = {}
for f in sorted(glob.glob(os.path.join(S, 'mock', 'm_*_[1-7].py'))):
    s, r = re.match(r'm_([a-z]+)_(\d)\.py', os.path.basename(f)).groups()
    Q, LEAD = blocks(f)
    for no, (seg, lead) in Q.items():
        if 'stm=' not in seg: continue
        m = re.search(r"ch=\[(.*?)\],\s*\n\s*a=", seg, re.S)
        if not m or not re.search(r"[a-d][：:]\s*(正|誤)", m.group(1)): continue
        SX.setdefault(s, []).append(('m%s-%s-%s' % (r, s, no), seg))
groups = []
cur, curn = [], 0
for s in ['keizai', 'zaimu', 'kigyo', 'unei', 'homu', 'joho', 'chusho']:
    for qid, seg in SX.get(s, []):
        cur.append((qid, seg)); curn += 1
        if curn >= 62:
            groups.append(cur); cur, curn = [], 0
if cur: groups.append(cur)
for gi, g in enumerate(groups):
    out = ['# 担当の資料：正誤の組み合わせの問題の、記述ごとの理由（sx）その%d' % (gi + 1), '', '作業のしかたは wip/mk2/AGENT_SX.md。', '']
    for qid, seg in g:
        out += ['### ' + qid, '', '```python', seg, '```', '']
    open(os.path.join(O, 'sx_%d.md' % (gi + 1)), 'w', encoding='utf-8').write('\n'.join(out))
summary.append('sx %s' % ' '.join('その%d:%d問' % (i + 1, len(g)) for i, g in enumerate(groups)))
print('\n'.join(summary))
