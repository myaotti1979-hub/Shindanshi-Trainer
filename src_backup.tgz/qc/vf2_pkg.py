# 2回目の確かめの資料：検証の担当が自分で書いた直し（fix）・図の直し・手で入れた直しを、当てた後の本物の状態で並べる
# 使い方：python3 -I qc/vf2_pkg.py <出力 .md> [--vf vf_out_*.json ...] [--fig wip/mk2/fig_all.json] [--ids id,id,...]
#   ・--vf：verdict が fix の問題の、検証の担当のメモ・直し（old→new）・当てた後の dict(...) の全文
#   ・--fig：図の直しごとに、直した図の名前と、当てた後の図の文字（SVG のタグを除く）と、その図を使う問題の id
#   ・--ids：手で直した問題（当てた後の dict(...) の全文）
#   ・--subj keizai,zaimu：その科目の項目だけにする（問題の id、図のファイルの名前で選ぶ）
import sys, os, re, json, ast, glob, importlib.util
S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args = sys.argv[1:]
OUT = args[0]


def part(flag):
    if flag not in args: return []
    i = args.index(flag) + 1; out = []
    while i < len(args) and not args[i].startswith('--'):
        out.append(args[i]); i += 1
    return out


def items_of(text, key):
    t = ast.parse(text); out = {}
    for n in t.body:
        tg = n.targets[0] if isinstance(n, ast.Assign) else n.target if isinstance(n, ast.AugAssign) else None
        if tg is not None and getattr(tg, 'id', '') == 'Q' and isinstance(n.value, ast.List):
            for e in n.value.elts:
                v = next((ast.literal_eval(k.value) for k in e.keywords if k.arg == key), None)
                out[str(v)] = ast.get_source_segment(text, e)
    return out


_qb = None


def seg_of(qid):
    global _qb
    m = re.fullmatch(r'm(\d)-([a-z]+)-(.+)', qid)
    if m:
        p = os.path.join(S, 'mock', 'm_%s_%s.py' % (m.group(2), m.group(1)))
        return items_of(open(p, encoding='utf-8').read(), 'no').get(m.group(3)), os.path.relpath(p, S)
    if _qb is None:
        _qb = {}
        for p in sorted(glob.glob(os.path.join(S, 'qbank', 'q_*.py'))):
            for k, v in items_of(open(p, encoding='utf-8').read(), 'id').items(): _qb[k] = (v, os.path.relpath(p, S))
    return _qb.get(qid, (None, None))


def figtext(v):
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', v)).strip() if isinstance(v, str) else str(v)


_mods = {}


def figmod(rel):
    if rel not in _mods:
        fp = os.path.join(S, rel)
        sys.path.insert(0, os.path.dirname(fp))
        spec = importlib.util.spec_from_file_location('f_' + os.path.basename(fp)[:-3], fp)
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        _mods[rel] = m
    return _mods[rel]


def figname_at(rel, new):
    t = open(os.path.join(S, rel), encoding='utf-8').read()
    i = t.find(new)
    if i < 0: return None
    j = t.rfind("FIG[", 0, i + 4)
    if j < 0: return None
    m = re.match(r"FIG\[\s*(?:'([^']+)'|([A-Za-z_]\w*)\s*\+\s*'([^']+)')\s*\]", t[j:j + 200])
    if not m: return None
    if m.group(1): return m.group(1)
    pm = None
    for pm in re.finditer(r"^%s\s*=\s*'([^']*)'" % m.group(2), t[:j], re.M): pass
    return (pm.group(1) if pm else '') + m.group(3)


users = {}


def users_of(name):
    if not users:
        for p in glob.glob(os.path.join(S, 'mock', 'm_*.py')):
            t = open(p, encoding='utf-8').read()
            m = re.search(r'm_([a-z]+)_(\d)\.py$', p)
            for no, seg in items_of(t, 'no').items():
                for nm in re.findall(r'\[\[図:([^\]]+)\]\]', seg):
                    users.setdefault(nm, []).append('m%s-%s-%s' % (m.group(2), m.group(1), no))
    return users.get(name, [])


SUBJ = [x for a in part('--subj') for x in a.split(',') if x]


def want_id(qid):
    if not SUBJ: return True
    m = re.match(r'(?:m\d-)?([a-z]+)-', qid)
    return bool(m) and m.group(1) in SUBJ


def want_file(rel):
    if not SUBJ: return True
    m = re.search(r'fig_(?:mk_|q_)?([a-z]+)', rel)
    return bool(m) and m.group(1) in SUBJ


out = ['# 2回目の確かめの資料', '', '確かめ方は wip/mk2/VERIFY2.md。', '']
n = 0
for f in part('--vf'):
    for x in json.load(open(f, encoding='utf-8')):
        if x.get('verdict') != 'fix' or not want_id(x['id']): continue
        seg, rel = seg_of(x['id'])
        out += ['## %s（検証の担当の直し・%s）' % (x['id'], os.path.basename(f)), '', '検証の担当のメモ：' + (x.get('problem') or ''), '']
        for fx in x.get('fixes') or []:
            if 'old' in fx: out += ['- 直し：「%s」→「%s」' % (fx['old'], fx['new'])]
        out += ['', '### 当てた後（%s）' % rel, '```python', seg or '（見つからない）', '```', '']
        n += 1
figs = []
for f in part('--fig'):
    figs += json.load(open(f, encoding='utf-8'))
seen = set()
for e in figs:
    if not want_file(e['file']): continue
    nm = figname_at(e['file'], e['new']) if e['new'] else None
    key = (e['file'], nm)
    out += ['## 図の直し：%s（%s）' % (nm or '?', e['file']), '', '関係する問題：%s／理由：%s' % (e.get('id', ''), e.get('why', '')), '', '- 直し：「%s」→「%s」' % (e['old'], e['new'])]
    if nm and key not in seen:
        seen.add(key)
        try:
            v = figmod(e['file']).FIG.get(nm)
            out += ['', '当てた後の図の文字：' + figtext(v)[:1500], '', 'この図を使う問題：' + (' '.join(users_of(nm)) or '（なし）')]
        except Exception as ex:
            out += ['', '図を読み込めない：' + str(ex)[:200]]
    out += ['']
    n += 1
ids = [i for a in part('--ids') for i in a.split(',') if i]
for qid in ids:
    seg, rel = seg_of(qid)
    out += ['## %s（手で直した問題）' % qid, '', '### 当てた後（%s）' % rel, '```python', seg or '（見つからない）', '```', '']
    n += 1
open(OUT, 'w', encoding='utf-8').write('\n'.join(out))
print('項目', n, '→', OUT)
