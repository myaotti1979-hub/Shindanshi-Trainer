# 図の直しを1つの一覧にまとめる（図の点検の担当の fig_out_*.json と、検証の担当の vf_out_*.json の figfix）
# 使い方：python3 -I qc/fig_collect.py <出力 .json> --fig wip/mk2/fig_out_1.json [...] --vf wip/mk2/vf_out_kigyo_a.json [...]
#   順番：図の点検（前に記録された直し）→ 検証の担当（今日の問題の直しに合わせた直し）。同じファイルには、この順に続けて当てる
#   出力の形は qc/fig_check.py と同じ：[{"id","file","old","new","why"}]
import sys, os, json
args = sys.argv[1:]
OUT = args[0]


def part(flag):
    if flag not in args: return []
    i = args.index(flag) + 1; out = []
    while i < len(args) and not args[i].startswith('--'):
        out.append(args[i]); i += 1
    return out


res = []
for f in part('--fig'):
    for e in json.load(open(f, encoding='utf-8')):
        res.append({'id': e.get('id', ''), 'file': e['file'], 'old': e['old'], 'new': e['new'], 'why': (e.get('why') or '') + '（' + os.path.basename(f) + '）'})
for f in part('--vf'):
    for x in json.load(open(f, encoding='utf-8')):
        if x.get('verdict') == 'revert': continue
        fl = list(x.get('figfix') or [])
        for fx in x.get('fixes') or []:
            if isinstance(fx, dict) and fx.get('figfix'): fl += fx['figfix'] if isinstance(fx['figfix'], list) else [fx['figfix']]
        for e in fl:
            res.append({'id': x['id'], 'file': e['file'], 'old': e['old'], 'new': e['new'], 'why': (x.get('problem') or '')[:120] + '（' + os.path.basename(f) + '）'})
json.dump(res, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
from collections import Counter
print('図の直し', len(res), '件 →', OUT)
for k, v in sorted(Counter(e['file'] for e in res).items()): print('  ', k, v)
