import json,glob,re,itertools,collections,sys
S='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/pwa/data/'
PAT=re.compile(r'([a-e])：(正|誤)')
def parse(ch):
    out=[]
    for c in ch:
        m=PAT.findall(c)
        if not m: return None
        out.append({k:(v=='正') for k,v in m})
    return out
def flaws(opts,ans):
    keys=sorted(opts[0].keys())
    F=[]
    # 1) 枝（ある記述の正誤で分けた選択肢）が3つ以上なのに、ほかの記述の正誤が変わらない
    for x in keys:
        for v in (True,False):
            br=[o for o in opts if o[x]==v]
            if len(br)>=3:
                for y in keys:
                    if y==x: continue
                    vals={o[y] for o in br}
                    if len(vals)==1: F.append('%s=%s の%d択で %s が常に%s'%(x,'正' if v else '誤',len(br),y,'正' if list(vals)[0] else '誤'))
    # 2) 正解が各記述の多数派と一致（多数決で当たる）
    C=opts[ans]
    maj=all(sum(1 for o in opts if o[k]==C[k])>=4 for k in keys)
    if maj: F.append('多数決で正解が分かる')
    # 3) どの記述も判断に不要（ある記述を知らなくても、ほかで一つに決まる）
    useless=[]
    for k in keys:
        others=[o for i,o in enumerate(opts) if i!=ans and all(o[q]==C[q] for q in keys if q!=k)]
        if not others: useless.append(k)
    return F,useless
tot=bad=0
rows=[]
files=sorted(glob.glob(S+'m_*_*.json'))+sorted(glob.glob(S+'q_*.json'))
for f in files:
    d=json.load(open(f,encoding='utf-8'))
    items=d.get('items') or d.get('questions') or []
    for it in items:
        if it.get('type')!='combo' and not (it.get('stm') or it.get('st')): continue
        ch=it.get('ch') or []
        P=parse(ch)
        if not P or len(P)<2: continue
        tot+=1
        F,U=flaws(P,it.get('a',0))
        if F:
            bad+=1
            rows.append((f.split('/')[-1], it.get('no') or it.get('id'), F, U))
print('真偽の組み合わせの問題',tot,'うち枝の偏りなどあり',bad)
c=collections.Counter(r[0].split('_')[0]+('_'+r[0].split('_')[1].split('.')[0] if r[0].startswith('m_') else '') for r in rows)
print(c.most_common(30))
for r in rows[:12]: print(r)
