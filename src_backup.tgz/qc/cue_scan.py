# 選択肢の言い回しや組み合わせの作りで、知識なしに正誤が分かってしまうかを、
# 本試験（令和6〜8年度）とアプリ（演習・模試）で同じ物差しで比べる。出すのは数だけ（令和7・8年度の中身は出さない）
# 使い方：python3 -I qc/cue_scan.py <scratchpad のフォルダ>
import sys, os, re, json, unicodedata, glob, itertools, statistics
from collections import Counter, defaultdict

S = sys.argv[1]
D = os.path.join(S, 'pwa', 'data')
TXT = os.path.join(S, 'qc', 'real', 'txt')
SUBJ = ['keizai', 'zaimu', 'kigyo', 'unei', 'homu', 'joho', 'chusho']
JP = dict(keizai='経済', zaimu='財務', kigyo='企業', unei='運営', homu='法務', joho='情報', chusho='中小')
LET = dict(A='keizai', B='zaimu', C='kigyo', D='unei', E='homu', F='joho', G='chusho')
KANA = 'アイウエオ'


def nz(s): return unicodedata.normalize('NFKC', s)
def sq(s): return re.sub(r'\s+', '', nz(s))


# ---- 言い回しの印 ----
EXC = re.compile(r'(なければならない|ねばならない|ざるを得ない|ざるをえない|かもしれない|に違いない|にちがいない|とは限らない|とはかぎらない|に過ぎない|にすぎない|少ない|すくない|に他ならない|にほかならない|かねない|わけではない|しかない|ほかない)$')
NEG = re.compile(r'(ない|ません|なかった|ならない|できない|得ない|えない)$')
ABS = re.compile(r'(必ず(?!しも)|すべて|全て|一切|常に|いかなる|決して|例外なく|全く|まったく|絶対|唯一|のみ(?!ならず)|(?<!できる)だけ(?!で(は)?なく)|に限ら|に限る|に限って|に過ぎ|にすぎ|しかない|ほかない|どのような場合|いずれの場合|あらゆる|完全に)')
HEDGE = re.compile(r'(場合がある|場合もある|ことがある|こともある|ことが多い|ことも多い|場合が多い|多くの場合|可能性がある|傾向がある|傾向にある|とは限らない|とはかぎらない|必ずしも|わけではない|一般に|一般的に|通常|原則として|あり得る|ありうる|なり得る|なりうる|とされる|といわれる|と言われる|と考えられる)')


def feats(t):
    t = sq(t)
    ss = [x for x in t.split('。') if x]
    neg = any(NEG.search(x) and not EXC.search(x) and '必ずしも' not in x for x in ss)
    ab = bool(ABS.search(t))
    return dict(neg=neg, abs=ab, dan=neg or ab, hedge=bool(HEDGE.search(t)), n=len(t))


def pol_single(stem):
    st = sq(stem)
    if re.search(r'最も不適切|誤っているもの|適切でないもの|誤ったもの|妥当でないもの|正しくないもの', st): return False
    if re.search(r'最も適切|正しいもの|最も妥当|妥当なもの', st): return True
    return None


# ---- 組み合わせ問題 ----
PT = re.compile(r'([a-e]):?(正|誤|○|×)')
SEL = re.compile(r'[a-e](?:(?:と|・|,|、|および|及び)[a-e])*(?:のみ)?')


def combo_parse(chs, stem, keys_hint):
    cs = [sq(c) for c in chs]
    pats = [{k: v in ('正', '○') for k, v in PT.findall(c)} for c in cs]
    if all(len(p) >= 2 for p in pats):
        keys = set(pats[0])
        if all(set(p) == keys for p in pats) and len({tuple(sorted(p.items())) for p in pats}) == len(pats):
            return 'pat', pats
        return None, None
    if all(SEL.fullmatch(c) for c in cs):
        st = sq(stem)
        if re.search(r'(誤っている|誤った|不適切な|適切でない|妥当でない|正しくない)もの(の|を)(すべて)?(選んだ)?組み?合わせ|最も不適切な組み?合わせ', st): pol = False
        elif re.search(r'(正しい|適切な|妥当な)もの(の|を)(すべて)?(選んだ)?組み?合わせ|最も適切な組み?合わせ', st): pol = True
        else: pol = None   # 「〜に該当するもの」など：作りの点検には使い、言い回しの点検からは外す
        keys = sorted(set(keys_hint) | set(re.findall(r'[a-e]', ''.join(cs))))
        pats = [{k: (k in set(re.findall(r'[a-e]', c))) == (pol is not False) for k in keys} for c in cs]
        if len({tuple(sorted(p.items())) for p in pats}) != len(pats): return None, None
        return ('sel' if pol is not None else 'sel?'), pats
    return None, None


def combo_metrics(pats, ans):
    keys = sorted(pats[0]); C = pats[ans]; k = len(pats)
    maj = {}
    for s in keys:
        t = sum(1 for p in pats if p[s]); f = k - t
        maj[s] = True if t > f else (False if f > t else None)
    agree = [sum(1 for s in keys if maj[s] is not None and p[s] == maj[s]) for p in pats]
    top = [i for i, a in enumerate(agree) if a == max(agree)]
    low = [i for i, a in enumerate(agree) if a == min(agree)]
    br = any(len(b) >= 3 and any(len({p[y] for p in b}) == 1 for y in keys if y != x)
             for x in keys for v in (True, False) for b in [[p for p in pats if p[x] == v]])
    strict = all(sum(1 for p in pats if p[s] == C[s]) >= k - 1 for s in keys)
    one = statistics.mean(1 / sum(1 for p in pats if p[s] == C[s]) for s in keys)
    need = next(r for r in range(len(keys) + 1) if any(
        sum(1 for p in pats if all(p[s] == C[s] for s in T)) == 1 for T in itertools.combinations(keys, r)))
    return dict(maj=(1 / len(top) if ans in top else 0.0), anti=(1 / len(low) if ans in low else 0.0), br=br, strict=strict, one=one, need=need)


# ---- 本試験の切り出し ----
FOOT = re.compile(r'(?m)^[ \t\f]*(?:[-―−‐ー]+[ \t]*)?\d{1,3}(?:[ \t]*[-―−‐ー]+)?[ \t]*$')
CONT = re.compile(r'(?m)^[ \t\f]*\(?(次(ページ|頁)(へ|に)続く|以下余白)\)?[ \t]*$')
OPT = re.compile(r'(?m)(?:^[ \t\f]*|[ \t]{2,})([アイウエオ])[ \t]+(?=\S)')
STM = re.compile(r'(?m)^[ \t\f]*([a-e])[ \t]+(?=\S)')


def split_by(pat, t):
    parts = re.split(pat, t); out = {}
    for i in range(1, len(parts), 2): out.setdefault(int(parts[i]), []).append(parts[i + 1])
    return out


def seq_markers(ms, order):
    best = []
    for i, m in enumerate(ms):
        if m.group(1) != order[0]: continue
        seq = [m]; j = i + 1
        while j < len(ms) and len(seq) < len(order) and ms[j].group(1) == order[len(seq)]:
            seq.append(ms[j]); j += 1
        if len(seq) > len(best): best = seq
    return best


def best_opts(body):
    best = seq_markers(list(OPT.finditer(body)), KANA)
    texts = []
    for k, m in enumerate(best):
        if k + 1 < len(best): seg = body[m.end():best[k + 1].start()]
        else:
            seg = body[m.end():]
        texts.append(sq(seg))
    return texts, (body[:best[0].start()] if best else body)


def stmts_real(stem):
    st = stem.split('解答群')[0]
    best = seq_markers(list(STM.finditer(st)), 'abcde')
    out = {}
    for k, m in enumerate(best):
        end = best[k + 1].start() if k + 1 < len(best) else len(st)
        out[m.group(1)] = sq(st[m.end():end]).rstrip('〔[(【')
    return out


items = []
past = json.load(open(os.path.join(D, 'past.json'), encoding='utf-8'))
ANS = {(e['y'], s): v.get('items', []) for e in past['years'] for s, v in e['subjects'].items()}
for f in sorted(glob.glob(os.path.join(TXT, '*.txt'))):
    name = os.path.basename(f)[:-4]; sub, y = LET[name[0]], int(name[-4:])
    t = nz(open(f, encoding='utf-8', errors='replace').read())
    t = re.sub(r'(?m)^.*(\.indd|\d{4}/\d{2}/\d{2}[ \t]+\d{1,2}:\d{2}:\d{2}).*$', '', t)  # 印刷用の書き込み（ファイル名と日時）
    t = CONT.sub('', FOOT.sub('', t))
    qs = split_by(r'(?m)^[ \t\f]*第[ \t]*(\d+)[ \t]*問', t)
    for it in ANS[(y, sub)]:
        m = re.match(r'\s*(\d+)\D*(\d+)?', it['n']); qn, sn = int(m.group(1)), (int(m.group(2)) if m.group(2) else 0)
        got = None
        for body in qs.get(qn, []):
            for b in (split_by(r'(?m)^[ \t\f]*\(?設問[ \t]*(\d+)\)?', body).get(sn, []) if sn else [body]):
                tx, stem = best_opts(b)
                if got is None or len(tx) > len(got[0]): got = (tx, stem)
        ok = bool(got and len(got[0]) >= 4)
        stem = got[1] if got else ''
        items.append(dict(src='本試験', sub=sub, set=y, p=it.get('p', 0), ans={KANA.index(c) for c in it['a'] if c in KANA},
                          allok=not any(c in KANA for c in it['a']), ch=got[0] if ok else None, stem=stem,
                          combo_hint=bool(re.search(r'組み?合わせ', sq(stem))), stm_d=stmts_real(stem) if ok else {}))

for f in sorted(glob.glob(os.path.join(D, 'm_*_*.json'))):
    b = os.path.basename(f)[:-5].split('_')
    for it in json.load(open(f, encoding='utf-8'))['items']:
        st = it.get('stm') or []
        items.append(dict(src='模試', sub=b[1], set=int(b[2]), p=it.get('p', 0), ans={int(it['a'])}, allok=False, ch=it.get('ch'),
                          stem=it.get('q', ''), type=it.get('type'), combo_hint=it.get('type') == 'combo',
                          stm_d={'abcde'[i]: s for i, s in enumerate(st)}))
for f in sorted(glob.glob(os.path.join(D, 'q_*.json'))):
    sub = os.path.basename(f)[2:-5]
    for it in json.load(open(f, encoding='utf-8'))['questions']:
        st = it.get('stm') or []
        if it.get('type') == 'tf':
            items.append(dict(src='演習', sub=sub, set=0, p=0, type='tf', stem=it.get('q', ''), truth=str(it.get('a')) == 'True', ans=set(), allok=False, ch=None))
            continue
        items.append(dict(src='演習', sub=sub, set=0, p=0, ans={int(it['a'])}, allok=False, ch=it.get('ch'), stem=it.get('q', ''),
                          type=it.get('type'), combo_hint=it.get('type') == 'combo', stm_d={'abcde'[i]: s for i, s in enumerate(st)}))


def classify(it):
    if it.get('type') == 'tf': return 'tf'
    if it['allok']: return 'all'
    ch, stem = it['ch'], it['stem']
    if not ch or not it['ans']: return 'other'
    if it['combo_hint'] or all(SEL.fullmatch(sq(c)) for c in ch):
        style, pats = combo_parse(ch, stem, list(it['stm_d']))
        if style:
            it['style'], it['pats'], it['polunk'] = style.rstrip('?'), pats, style.endswith('?'); return 'combo'
        if it.get('type') == 'combo': return 'other'
    if re.search(r'空欄', sq(stem)) or any(re.search(r'[A-E]:', sq(c)) for c in ch): return 'other'
    if statistics.mean(len(sq(c)) for c in ch) < 20: return 'other'
    it['pol'] = pol_single(stem)
    return 'text' if it['pol'] is not None else 'other'


def probs(it):
    if it['kind'] == 'all': return dict(rnd=1, s1=1, s2=1, s3=1, s4=1, plan=1, planB=1)
    k = len(it['ch']) if it.get('ch') else 4.5
    rnd = len(it['ans']) / k
    r = dict(rnd=rnd, s1=rnd, s2=rnd, s3=rnd, s4=rnd, plan=rnd, planB=rnd)
    if it['kind'] == 'combo':
        it['cm'] = combo_metrics(it['pats'], min(it['ans'])); r['plan'] = it['cm']['maj']; r['planB'] = it['cm']['anti']
    elif it['kind'] == 'text':
        F = [feats(c) for c in it['ch']]; pol = it['pol']; idx = list(range(len(F)))
        def P(c): c = c or idx; return sum(1 for i in c if i in it['ans']) / len(c)
        c1 = [i for i in idx if F[i]['dan'] != pol]           # 適切を選ぶ問題は断定のないもの、不適切を選ぶ問題は断定のあるもの
        L = [F[i]['n'] for i in idx]
        pick = (lambda xs: max(xs)) if pol else (lambda xs: min(xs))
        c2 = [i for i in idx if L[i] == pick(L)]                 # 適切→いちばん長い、不適切→いちばん短い
        base = c1 or idx; c3 = [i for i in base if L[i] == pick([L[j] for j in base])]
        c4 = [i for i in idx if F[i]['hedge'] == pol]           # 適切→ぼかしのあるもの
        r.update(s1=P(c1), s2=P(c2), s3=P(c3), s4=P(c4), plan=P(c3), planB=P(c3))
    return r


def statements(it):
    if it['kind'] == 'tf': return [(it['truth'], it['stem'])]
    if it['kind'] == 'text': return [((i in it['ans']) == it['pol'], c) for i, c in enumerate(it['ch'])]
    if it['kind'] == 'combo':
        if it.get('polunk'): return []
        C = it['pats'][min(it['ans'])]
        return [(C[k], tx) for k, tx in it['stm_d'].items() if k in C and len(tx) >= 8]
    return []


for it in items:
    it['kind'] = classify(it); it['P'] = probs(it)

SRC = ['本試験', '模試', '演習']
print('■ 分類（問題の数）')
for s in SRC:
    c = Counter(it['kind'] for it in items if it['src'] == s)
    print(f"  {s}: " + ' '.join(f"{k}{v}" for k, v in sorted(c.items())))
rt = [it for it in items if it['src'] == '本試験' and it['kind'] == 'text']
print('  本試験の最後の選択肢の長さの点検：最後', round(statistics.mean(len(it['ch'][-1]) for it in rt)), '／それ以外', round(statistics.mean(len(c) for it in rt for c in it['ch'][:-1])))

print('\n■1 言い回し（正しい文→誤りの文に出る割合）')
for s in SRC + ['演習○×']:
    st = [x for it in items if (it['src'] == s and it['kind'] != 'tf') or (s == '演習○×' and it['src'] == '演習' and it['kind'] == 'tf') for x in statements(it)]
    if s == '演習': st = [x for it in items if it['src'] == '演習' and it['kind'] in ('text', 'combo') for x in statements(it)]
    T = [feats(t) for v, t in st if v]; Fz = [feats(t) for v, t in st if not v]
    row = [f"{s} 正{len(T)}/誤{len(Fz)}"]
    for key, lab in (('neg', '否定で言い切る'), ('abs', '範囲の言い切り'), ('dan', '断定どちらか'), ('hedge', 'ぼかし')):
        a = sum(f[key] for f in T) / len(T); b = sum(f[key] for f in Fz) / len(Fz)
        row.append(f"{lab} {a:.0%}→{b:.0%}({(b / a if a else float('inf')):.1f}倍)")
    row.append(f"長さ 正{statistics.mean(f['n'] for f in T):.0f}字/誤{statistics.mean(f['n'] for f in Fz):.0f}字")
    print('  ' + ' | '.join(row))
for s in SRC:
    X = [it for it in items if it['src'] == s and it['kind'] == 'text' and it['pol']]
    lg = statistics.mean(1.0 if max(len(c) for c in it['ch']) == len(it['ch'][min(it['ans'])]) else 0.0 for it in X)
    print(f"  {s}：「最も適切」を選ぶ問題{len(X)}問で、正解がいちばん長い {lg:.0%}（でたらめなら {statistics.mean(1 / len(it['ch']) for it in X):.0%}）")

print('\n■2 知識なしの得点')
for s in SRC:
    X = [it for it in items if it['src'] == s and it['kind'] == 'text']
    print(f"  {s} 文の選択肢{len(X)}問の正答率：でたらめ{statistics.mean(it['P']['rnd'] for it in X):.0%} 断定を避ける{statistics.mean(it['P']['s1'] for it in X):.0%} 長さ{statistics.mean(it['P']['s2'] for it in X):.0%} 両方{statistics.mean(it['P']['s3'] for it in X):.0%} ぼかしを選ぶ{statistics.mean(it['P']['s4'] for it in X):.0%}")
    X = [it for it in items if it['src'] == s and it['kind'] == 'combo']
    print(f"  {s} 組み合わせ{len(X)}問の正答率：でたらめ{statistics.mean(it['P']['rnd'] for it in X):.0%} 多数決{statistics.mean(it['P']['plan'] for it in X):.0%} 少数派{statistics.mean(it['P']['planB'] for it in X):.0%}")
    X = [it for it in items if it['src'] == s and it.get('ch') and it['ans'] and len(it['ch']) in (4, 5)]
    pos = Counter(min(it['ans']) for it in X); n = len(X)
    print(f"  {s} 正解の位置（4・5択{n}問）：" + ' '.join(f"{KANA[i]}{pos[i] / n:.0%}" for i in range(5)))
print('  科目別の100点換算（でたらめ → 作戦：文は「断定を避ける＋長さ」、組み合わせは多数決、その他はでたらめ）')
res = defaultdict(list)
for s in ('本試験', '模試'):
    for sub in SUBJ:
        for k in sorted({it['set'] for it in items if it['src'] == s and it['sub'] == sub}):
            X = [it for it in items if it['src'] == s and it['sub'] == sub and it['set'] == k]
            tot = sum(it['p'] for it in X) or 1
            res[(s, sub)].append((100 * sum(it['p'] * it['P']['rnd'] for it in X) / tot, 100 * sum(it['p'] * it['P']['plan'] for it in X) / tot, 100 * sum(it['p'] * it['P']['planB'] for it in X) / tot))
line = []
for sub in SUBJ:
    a = res[('本試験', sub)]; b = res[('模試', sub)]
    line.append(f"{JP[sub]} 本試験 {statistics.mean(v[0] for v in a):.0f}→多数決{statistics.mean(v[1] for v in a):.0f}/少数派{statistics.mean(v[2] for v in a):.0f}（最高{max(max(v[1], v[2]) for v in a):.0f}） 模試 {statistics.mean(v[0] for v in b):.0f}→多数決{statistics.mean(v[1] for v in b):.0f}/少数派{statistics.mean(v[2] for v in b):.0f}（最高{max(max(v[1], v[2]) for v in b):.0f}）")
print('  ' + '\n  '.join(line))
A = [v for sub in SUBJ for v in res[('本試験', sub)]]; B = [v for sub in SUBJ for v in res[('模試', sub)]]
print(f"  全体 本試験 {statistics.mean(v[0] for v in A):.1f}→多数決{statistics.mean(v[1] for v in A):.1f}/少数派{statistics.mean(v[2] for v in A):.1f} 模試 {statistics.mean(v[0] for v in B):.1f}→多数決{statistics.mean(v[1] for v in B):.1f}/少数派{statistics.mean(v[2] for v in B):.1f}")

print('\n■3 組み合わせ問題の作り')
for s in SRC:
    X = [it for it in items if it['src'] == s and it['kind'] == 'combo']
    if not X: continue
    st = Counter(it['style'] for it in X)
    n = len(X); cm = [it['cm'] for it in X]
    pat = [it['cm'] for it in X if it['style'] == 'pat' and len(it['pats']) == 5]
    print(f"  {s} {n}問（正誤型{st['pat']}・選ぶ型{st['sel']}）：多数決で当たる{statistics.mean(c['maj'] for c in cm):.0%}"
          f" 枝の偏り{sum(c['br'] for c in cm) / n:.0%} 4択以上が正解と同じ{sum(c['strict'] for c in cm) / n:.0%}"
          f" 前の点検と同じ判定（正誤型5択）{sum(c['br'] or c['strict'] for c in pat)}/{len(pat)}"
          f" 1つ分かれば当たる{statistics.mean(c['one'] for c in cm):.0%} 当てるのに要る記述 平均{statistics.mean(c['need'] for c in cm):.2f}"
          f" {dict(sorted(Counter(c['need'] for c in cm).items()))} 少数派で当たる{statistics.mean(c['anti'] for c in cm):.0%}")
    sel = [it for it in X if it['style'] == 'sel']
    if sel:
        sets = Counter(tuple(sq(c) for c in it['ch']) for it in sel)
        top = sets.most_common(1)[0]
        ansd = Counter(sq(it['ch'][min(it['ans'])]) for it in sel if tuple(sq(c) for c in it['ch']) == top[0])
        print(f"    選ぶ型：選択肢の並び{len(sets)}通り、最多の並び{'/'.join(top[0])}が{top[1]}問、その正解 {dict(ansd)}")

json.dump([{k: v for k, v in it.items() if k in ('src', 'sub', 'set', 'kind', 'P', 'cm', 'style')} for it in items],
          open(os.path.join(S, 'qc', 'real', 'cue_result.json'), 'w', encoding='utf-8'), ensure_ascii=False)
