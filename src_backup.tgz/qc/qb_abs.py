# 演習（qbank）の「必ず・すべて・のみ」などの言い切りの偏りを直すための資料づくりと、直しの確かめ
# 使い方：
#   python3 -I qc/qb_abs.py pkg            → wip/mk2/qb_abs.md（直す候補の問題の元の文字列）を作る
#   python3 -I qc/qb_abs.py check review/qb_abs_1.json [...]   → 直しを写しに当て、言い切りの数と形を確かめる（qbank は書き換えない）
import sys, os, re, json, ast, glob, io, contextlib, statistics, types
S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = open(os.path.join(S, 'qc', 'cue_scan.py'), encoding='utf-8').read().split('items = []')[0]
G = {'__name__': 'cue'}
argv0 = sys.argv; sys.argv = ['cue', S]
with contextlib.redirect_stdout(io.StringIO()):
    exec(src, G)
sys.argv = argv0
feats, pol_single, sq = G['feats'], G['pol_single'], G['sq']


def segs(path):
    text = open(path, encoding='utf-8').read(); t = ast.parse(text); out = {}
    for n in t.body:
        tg = n.targets[0] if isinstance(n, ast.Assign) else n.target if isinstance(n, ast.AugAssign) else None
        if tg is not None and getattr(tg, 'id', '') == 'Q' and isinstance(n.value, ast.List):
            for e in n.value.elts:
                qid = next((ast.literal_eval(k.value) for k in e.keywords if k.arg == 'id'), None)
                out[qid] = ast.get_source_segment(text, e)
    return text, out


def statements(x):
    """(正しいか, 文) の組。文の選択肢の問題と、組み合わせの問題の記述"""
    out = []
    if x['type'] == 'single':
        ch = x['ch']
        if re.search(r'空欄', sq(x['q'])) or any(re.search(r'[A-E]:', sq(c)) for c in ch) or statistics.mean(len(sq(c)) for c in ch) < 20: return out
        pol = pol_single(x['q'])
        if pol is None: return out
        for i, c in enumerate(ch): out.append(((i == x['a']) == pol, c, 'ch'))
    elif x['type'] == 'combo':
        st = sq(x['q'])
        pol = False if re.search(r'(誤っている|不適切な)もの', st) else True if re.search(r'(正しい|適切な)もの', st) else None
        if pol is None or not all(re.fullmatch(r'[a-d]と[a-d]', c) for c in x['ch']): return out
        sel = set(x['ch'][x['a']].split('と'))
        for i, t in enumerate(x['stm']): out.append((('abcd'[i] in sel) == pol, t, 'stm'))
    return out


def load_all(texts=None):
    Q = []
    for f in sorted(glob.glob(os.path.join(S, 'qbank', 'q_*.py'))):
        if texts and f in texts:
            mod = types.ModuleType('q'); exec(texts[f], mod.__dict__)
        else:
            mod = types.ModuleType('q'); exec(open(f, encoding='utf-8').read(), mod.__dict__)
        for x in mod.Q: Q.append((f, x))
    return Q


def counts(Q):
    nT = nF = aT = aF = 0
    for f, x in Q:
        for t, s, _ in statements(x):
            a = feats(s)['abs']
            if t: nT += 1; aT += a
            else: nF += 1; aF += a
    return nT, nF, aT, aF


if sys.argv[1] == 'pkg':
    Q = load_all()
    nT, nF, aT, aF = counts(Q)
    out = ['# 担当の資料：演習の問題の、誤りの肢・記述の言い切り', '', '作業のしかたは wip/mk2/AGENT_QB.md。', '',
           'いま：正しい文 %d のうち言い切り %d（%.1f%%）、誤りの文 %d のうち言い切り %d（%.1f%%）。誤りの文の言い切りを、正しい文と同じ割合（%.1f%% ＝ およそ %d本）まで減らす（%d本以上を書き換える）。' % (
               nT, aT, 100 * aT / nT, nF, aF, 100 * aF / nF, 100 * aT / nT, round(nF * aT / nT), aF - round(nF * aT / nT)), '']
    cache = {}
    n = 0
    for f, x in Q:
        hits = [s for t, s, k in statements(x) if not t and feats(s)['abs']]
        if not hits: continue
        if f not in cache: cache[f] = segs(f)[1]
        seg = cache[f].get(x['id'])
        out += ['### %s（%s）　誤りの文の言い切り %d' % (x['id'], os.path.basename(f), len(hits)), '']
        for h in hits: out.append('- 候補：' + h[:80])
        out += ['', '```python', seg or '（元の文字列が見つからない）', '```', '']
        n += 1
    head, body = out[:5], out[5:]
    parts = {1: [], 2: []}; cur = None
    for ln in body:
        m = re.match(r'### ([a-z]+)-', ln)
        if m: cur = 1 if m.group(1) in ('keizai', 'zaimu', 'kigyo') else 2
        if cur: parts[cur].append(ln)
    for k, v in parts.items():
        open(os.path.join(S, 'wip', 'mk2', 'qb_abs_%d.md' % k), 'w', encoding='utf-8').write('\n'.join(head + ['担当の範囲：' + ('経済学・経済政策、財務・会計、企業経営理論' if k == 1 else '運営管理、経営法務、経営情報システム、中小企業経営・中小企業政策'), ''] + v))
    print('候補の問題', n, '／正しい文', nT, aT, '／誤りの文', nF, aF)
elif sys.argv[1] == 'check':
    texts, errs, applied = {}, [], 0
    files = sorted(glob.glob(os.path.join(S, 'qbank', 'q_*.py')))
    for rf in sys.argv[2:]:
        for fx in json.load(open(rf, encoding='utf-8')):
            qid = fx.get('id')
            for f in files:
                t = texts.get(f) or open(f, encoding='utf-8').read()
                _, sg = (None, None)
                tree = ast.parse(t)
                seg = None
                for nd in tree.body:
                    if isinstance(nd, ast.Assign) and getattr(nd.targets[0], 'id', '') == 'Q':
                        for e in nd.value.elts:
                            if next((ast.literal_eval(k.value) for k in e.keywords if k.arg == 'id'), None) == qid:
                                seg = ast.get_source_segment(t, e)
                if seg is None: continue
                new = seg
                for c in fx.get('fixes', []):
                    if new.count(c['old']) != 1: errs.append('%s：old が %d か所に一致（%s…）' % (qid, new.count(c['old']), c['old'][:30])); continue
                    new = new.replace(c['old'], c['new']); applied += 1
                texts[f] = t.replace(seg, new)
                break
            else:
                errs.append('%s：問題が見つからない' % qid)
    Q0 = load_all(); Q1 = load_all(texts)
    b, a = counts(Q0), counts(Q1)
    print('直し %d件を当てた%s' % (applied, ('、当てられない %d件' % len(errs)) if errs else ''))
    for e in errs: print('  ×', e)
    print('前：正しい文の言い切り %d/%d（%.1f%%）・誤りの文の言い切り %d/%d（%.1f%%）' % (b[2], b[0], 100 * b[2] / b[0], b[3], b[1], 100 * b[3] / b[1]))
    print('後：正しい文の言い切り %d/%d（%.1f%%）・誤りの文の言い切り %d/%d（%.1f%%）・倍率 %.2f' % (a[2], a[0], 100 * a[2] / a[0], a[3], a[1], 100 * a[3] / a[1], (a[3] / a[1]) / (a[2] / a[0])))
    bad = []
    for f, x in Q1:
        if x['type'] == 'single':
            ce = x.get('ce') or []
            if ce and not (ce[x['a']].startswith('○') and all(c.startswith('×') for i, c in enumerate(ce) if i != x['a'])): bad.append(x['id'] + '：注の○×')
            if len(set(x['ch'])) != len(x['ch']): bad.append(x['id'] + '：選択肢の重複')
    if bad: print('  形の誤り：' + '；'.join(bad[:20]))
