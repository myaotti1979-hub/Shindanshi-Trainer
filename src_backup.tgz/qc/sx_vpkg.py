# sx（記述ごとの理由）と、作り直した解答群の検証の資料を作る
# 使い方：python3 -I qc/sx_vpkg.py <sx.json> <作り直した後の data フォルダ> <出力の頭（wip/mk2/vsx）> [分ける数]
import sys, os, re, json, glob, types
S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SXF, DATA, HEAD = sys.argv[1], sys.argv[2], sys.argv[3]
NP = int(sys.argv[4]) if len(sys.argv) > 4 else 2
sx = json.load(open(SXF, encoding='utf-8'))
built = {}
for f in glob.glob(os.path.join(DATA, 'm_*_*.json')):
    for it in json.load(open(f, encoding='utf-8'))['items']:
        built[it['id']] = it
mods = {}
blocks = []
for qid in sorted(sx, key=lambda q: (q.split('-')[1], int(q[1]), q)):
    r, s, no = re.fullmatch(r'm(\d)-([a-z]+)-(.+)', qid).groups()
    if (s, r) not in mods:
        m = types.ModuleType('m'); exec(open(os.path.join(S, 'mock', 'm_%s_%s.py' % (s, r)), encoding='utf-8').read(), m.__dict__); mods[(s, r)] = m
    x = next(q for q in mods[(s, r)].Q if str(q['no']) == no)
    b = built.get(qid)
    L = ['## ' + qid, '', '記述：']
    for i, t in enumerate(x['stm']): L.append('- %s：%s' % ('abcde'[i], t))
    L += ['', '元の解答群（正答は%s）：' % 'アイウエオ'[x['a']]]
    for i, c in enumerate(x['ch']): L.append('- %s %s　／注：%s' % ('アイウエオ'[i], c, x['ce'][i]))
    L += ['', '解説：' + x['e'], '', 'sx：']
    for i, t in enumerate(sx[qid]): L.append('- %s：%s' % ('abcde'[i], t))
    if b:
        L += ['', '作り直した解答群（正答は%s）：' % 'アイウエオ'[b['a']]]
        for i, c in enumerate(b['ch']): L.append('- %s %s　／注：%s' % ('アイウエオ'[i], c, b['ce'][i]))
    else:
        L += ['', '（作り直した解答群が見つからない）']
    blocks.append('\n'.join(L) + '\n')
per = (len(blocks) + NP - 1) // NP
for k in range(NP):
    part = blocks[k * per:(k + 1) * per]
    open('%s_%d.md' % (HEAD, k + 1), 'w', encoding='utf-8').write('# 検証の担当の資料：記述ごとの理由（sx）と作り直した解答群 その%d\n\n検証のしかたは wip/mk2/VERIFY_SX.md。\n\n' % (k + 1) + '\n'.join(part))
    print('その%d：%d問' % (k + 1, len(part)))
