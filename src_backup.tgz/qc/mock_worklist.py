# 模擬試験（第1〜7回）を「本試験より少しだけ難しめ」に直すための作業表を作る（qc/cue_scan.py と同じ物差し）
# 使い方：python3 -I qc/mock_worklist.py <scratchpad のフォルダ> [出力フォルダ]
#   出力：<出力フォルダ>/<科目>_<回>.json（直す候補）と、画面への集計
import sys, os, json, re, statistics, io, contextlib
from collections import Counter
S = sys.argv[1]
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(S, 'wip', 'mock_work')
os.makedirs(OUT, exist_ok=True)
src = open(os.path.join(S, 'qc', 'cue_scan.py'), encoding='utf-8').read().split('items = []')[0]
G = {'__name__': 'cue', 'sys': sys}
sys_argv = sys.argv
sys.argv = ['cue', S]
with contextlib.redirect_stdout(io.StringIO()):
    exec(src, G)
sys.argv = sys_argv
feats, pol_single, combo_parse, combo_metrics, sq = G['feats'], G['pol_single'], G['combo_parse'], G['combo_metrics'], G['sq']
REAL_AVG = dict(keizai=27, zaimu=34, kigyo=24, unei=30, homu=31, joho=30, chusho=23)
SUBJ = ['keizai', 'zaimu', 'kigyo', 'unei', 'homu', 'joho', 'chusho']


def classify(it):
    ch, stem = it.get('ch'), it.get('q', '')
    if it.get('type') == 'combo' or all(G['SEL'].fullmatch(sq(c)) for c in ch):
        style, pats = combo_parse(ch, stem, ['abcde'[i] for i in range(len(it.get('stm') or []))])
        if style:
            return 'combo', style, pats
        return 'other', None, None
    if re.search(r'空欄', sq(stem)) or any(re.search(r'[A-E]:', sq(c)) for c in ch): return 'other', None, None
    if statistics.mean(len(sq(c)) for c in ch) < 20: return 'other', None, None
    return ('text', pol_single(stem), None) if pol_single(stem) is not None else ('other', None, None)


tot = Counter()
rows = []
DATA = os.environ.get('DATA') or os.path.join(S, 'pwa', 'data')   # 砂場で作ったデータを見るときは DATA=<data のフォルダ>
for s in SUBJ:
    for r in [x for k in range(1, 8) for x in (str(k), '%db' % k)]:
        f = os.path.join(DATA, 'm_%s_%s.json' % (s, r))
        if not os.path.exists(f): continue
        st = json.load(open(f, encoding='utf-8'))
        work, pts_rnd, pts_plan, ptot = [], 0.0, 0.0, 0
        lv = Counter(it['lv'] for it in st['items'])
        absT = absF = nT = nF = 0
        combos = []
        for it in st['items']:
            kind, pol, pats = classify(it)
            k = len(it['ch']); a = it['a']; ptot += it['p']
            rnd = 1 / k; plan = rnd
            entry = None
            if kind == 'text':
                F = [feats(c) for c in it['ch']]; idx = range(k)
                c1 = [i for i in idx if F[i]['dan'] != pol] or list(idx)
                L = [F[i]['n'] for i in idx]; pick = max if pol else min
                c3 = [i for i in c1 if L[i] == pick(L[j] for j in c1)]
                p3 = (1 / len(c3)) if a in c3 else 0.0
                plan = p3
                truth = [(i == a) == pol for i in idx]
                for i in idx:
                    if truth[i]: nT += 1; absT += F[i]['abs']
                    else: nF += 1; absF += F[i]['abs']
                why = []
                if p3 >= 0.5:
                    if [i for i in idx if F[i]['dan'] != pol] == [a]: why.append('正答の肢だけが' + ('断定なし' if pol else '断定あり'))
                    if L[a] == pick(L): why.append('正答の肢がいちばん' + ('長い' if pol else '短い'))
                    if not why: why.append('断定のない肢の中で正答がいちばん長い' if pol else '断定のある肢の中で正答がいちばん短い')
                abs_false = [it['ch'][i] for i in idx if not truth[i] and F[i]['abs']]
                if p3 >= 0.5 or abs_false:
                    entry = dict(id=it['id'], no=it['no'], lv=it['lv'], pol='適切を選ぶ' if pol else '不適切を選ぶ', exploit=round(p3, 2), why=why,
                                 answer=it['ch'][a], abs_false=abs_false, lens=[len(sq(c)) for c in it['ch']])
            elif kind == 'combo':
                cm = combo_metrics(pats, a)
                plan = cm['maj']
                combos.append(dict(id=it['id'], no=it['no'], style=pats and ('pat' if G['PT'].findall(sq(it['ch'][0])) else 'sel'), maj=cm['maj'], anti=cm['anti'], br=cm['br'], need=cm['need']))
                C = pats[a]
                for i_, t_ in enumerate(it.get('stm') or []):
                    L_ = 'abcde'[i_]
                    if L_ in C:
                        fx = feats(t_)
                        if C[L_]: nT += 1; absT += fx['abs']
                        else: nF += 1; absF += fx['abs']
            pts_rnd += it['p'] * rnd; pts_plan += it['p'] * plan
            if entry: work.append(entry)
        sc_rnd, sc_plan = 100 * pts_rnd / ptot, 100 * pts_plan / ptot
        info = dict(s=s, r=r, n=len(st['items']), lv=dict(lv), score_rnd=round(sc_rnd, 1), score_plan=round(sc_plan, 1), real_avg=REAL_AVG[s],
                    over=sc_plan > REAL_AVG[s], exploit=sum(1 for w in work if w['exploit'] >= 0.5), abs_false=sum(len(w['abs_false']) for w in work),
                    absT=absT, absF=absF, nT=nT, nF=nF, combos=combos)
        json.dump(dict(info=info, work=work), open(os.path.join(OUT, '%s_%s.json' % (s, r)), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        rows.append(info)
        for k_ in ('n', 'exploit', 'abs_false', 'absT', 'absF', 'nT', 'nF'): tot[k_] += info[k_]
        tot['combos'] += len(combos); tot['over'] += info['over']
        for L_ in 'ABCD': tot['lv' + L_] += lv.get(L_, 0)
for x in rows:
    lvs = ' '.join('%s%d%%' % (L, round(100 * x['lv'].get(L, 0) / x['n'])) for L in 'ABCD')
    print('%s_%s 問%d 知識なし%.0f（本試験平均%d）%s 狙われる肢%d 誤りの肢の言い切り%d 組み合わせ%d %s' % (x['s'], x['r'], x['n'], x['score_plan'], x['real_avg'], '超' if x['over'] else '', x['exploit'], x['abs_false'], len(x['combos']), lvs))
print('合計', dict(tot), '言い切り 正%.1f%% 誤%.1f%%' % (100 * tot['absT'] / tot['nT'], 100 * tot['absF'] / tot['nF']))
