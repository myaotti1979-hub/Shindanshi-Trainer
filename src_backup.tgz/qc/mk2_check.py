# 模擬試験の直し（review/mk2_<科目>_<回>.json）を、元の問題（mock/m_<科目>_<回>.py）の写しに当てて、目標に届いたかを確かめる
# 使い方：python3 -I qc/mk2_check.py review/mk2_kigyo_1.json [review/mk2_kigyo_2.json ...] [--write <出力フォルダ>]
#   ・元のファイルは書き換えない。--write を付けると、直した後のファイルを <出力フォルダ>/m_<科目>_<回>.py に書く
#   ・出すもの：当てられなかった直し、形の誤り（○×の注、選択肢の数、重複など）、知識なしの得点（組み合わせとその他は、でたらめの確率で数える）、
#     誤りの肢の言い切りの数、lv の配分、まだ「狙われる」問題
import sys, os, re, json, statistics, io, contextlib, types
S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args = sys.argv[1:]
outdir = None
if '--write' in args:
    outdir = args[args.index('--write') + 1]; args = [a for a in args if a not in ('--write', outdir)]
src = open(os.path.join(S, 'qc', 'cue_scan.py'), encoding='utf-8').read().split('items = []')[0]
G = {'__name__': 'cue'}
argv0 = sys.argv; sys.argv = ['cue', S]
with contextlib.redirect_stdout(io.StringIO()):
    exec(src, G)
sys.argv = argv0
feats, pol_single, sq = G['feats'], G['pol_single'], G['sq']
REAL_AVG = dict(keizai=27, zaimu=34, kigyo=24, unei=30, homu=31, joho=30, chusho=23)


def segments(text):
    """各問題の dict(...) の範囲（no ごと）"""
    import ast
    t = ast.parse(text); out = {}
    lines = text.split('\n'); off = [0]
    for ln in lines: off.append(off[-1] + len(ln) + 1)
    for n in t.body:
        tg = n.targets[0] if isinstance(n, ast.Assign) else n.target if isinstance(n, ast.AugAssign) else None
        if tg is not None and getattr(tg, 'id', '') == 'Q' and isinstance(n.value, ast.List):   # Q = [...] と Q += [...]
            for e in n.value.elts:
                no = next((ast.literal_eval(k.value) for k in e.keywords if k.arg == 'no'), None)
                # ast の列は UTF-8 のバイトで数えるので、文字の位置に直す（2026-11-24。日本語のある行で範囲の終わりがずれていた）
                ch = lambda ln, col: len(lines[ln - 1].encode('utf-8')[:col].decode('utf-8', errors='ignore'))
                a = off[e.lineno - 1] + ch(e.lineno, e.col_offset); b = off[e.end_lineno - 1] + ch(e.end_lineno, e.end_col_offset)
                out[str(no)] = (a, b)
    return out


def apply(text, s, r, fixes):
    errs, applied = [], 0
    for fx in fixes:
        qid = fx.get('id', '')
        m = re.fullmatch(r'm(\d)-([a-z]+)-(.+)', qid)
        if not m or int(m.group(1)) != r or m.group(2) != s:
            errs.append('%s：この回の問題の id ではない' % qid); continue
        no = m.group(3)
        for f in fx.get('fixes', []):
            seg = segments(text)
            if no not in seg:
                errs.append('%s：問題が見つからない' % qid); break
            a, b = seg[no]; body = text[a:b]; old, new = f.get('old', ''), f.get('new', '')
            c = body.count(old)
            if c == 1:
                text = text[:a] + body.replace(old, new) + text[b:]; applied += 1
            elif c == 0 and text.count(old) == 1:
                text = text.replace(old, new); applied += 1   # リード文など
            else:
                errs.append('%s：old が %d か所に一致（%s…）' % (qid, c if c else text.count(old), old[:30]))
        lv = fx.get('lv')
        if lv:
            seg = segments(text); a, b = seg[no]; body = text[a:b]
            body2 = re.sub(r"lv='[ABCD]'", "lv='%s'" % lv, body, count=1)
            text = text[:a] + body2 + text[b:]
    return text, applied, errs


def check(text, s, r, label):
    mod = types.ModuleType('m'); exec(compile(text, 'm_%s_%d.py' % (s, r), 'exec'), mod.__dict__)
    probs, pts, ptot, absF, absT, nF, nT, exp = [], 0.0, 0, 0, 0, 0, 0, []
    lv = {'A': 0, 'B': 0, 'C': 0, 'D': 0}
    for x in mod.Q:
        no = str(x['no']); ch, ce, a = x['ch'], x['ce'], x['a']; k = len(ch); ptot += x['p']; lv[x['lv']] += 1
        if not (4 <= k <= 5 and len(ce) == k and 0 <= a < k): probs.append('%s：選択肢・注の数' % no)
        if not (ce[a].startswith('○') and all(c.startswith('×') for i, c in enumerate(ce) if i != a)): probs.append('%s：注の○×' % no)
        if len(set(ch)) != k: probs.append('%s：選択肢の重複' % no)
        if 'どれか' not in x['q']: probs.append('%s：問い方' % no)
        if x['lv'] not in 'ABCD' or x['p'] not in (2, 3, 4): probs.append('%s：lv か配点' % no)
        p = 1 / k
        stem = x['q']
        textq = not x.get('stm') and not re.search(r'空欄', sq(stem)) and not any(re.search(r'[A-E]:', sq(c)) for c in ch) and statistics.mean(len(sq(c)) for c in ch) >= 20
        pol = pol_single(stem) if textq else None
        if pol is not None:
            F = [feats(c) for c in ch]; idx = range(k)
            c1 = [i for i in idx if F[i]['dan'] != pol] or list(idx)
            L = [F[i]['n'] for i in idx]; pick = max if pol else min
            c3 = [i for i in c1 if L[i] == pick(L[j] for j in c1)]
            p = (1 / len(c3)) if a in c3 else 0.0
            if p >= 0.5: exp.append('%s(%.1f)' % (no, p))
            for i in idx:
                t = (i == a) == pol
                if t: nT += 1; absT += F[i]['abs']
                else: nF += 1; absF += F[i]['abs']
        pts += x['p'] * p
    sc = 100 * pts / ptot
    n = len(mod.Q)
    print('%s %s 第%d回：知識なし %.1f点（目標 %d点以下）・誤りの肢の言い切り %d本（正しい肢 %d本）・lv %s・狙われる %d問 %s' % (
        label, s, r, sc, REAL_AVG[s] - 2, absF, absT, ' '.join('%s%d(%d%%)' % (L, lv[L], round(100 * lv[L] / n)) for L in 'ABCD'), len(exp), ' '.join(exp)))
    if probs: print('  形の誤り：' + '；'.join(probs))
    return sc


for f in args:
    m = re.search(r'mk\d+f?_([a-z]+)_(\d)\.json$', f)
    if not m: print('ファイル名は mk2_<科目>_<回>.json：', f); continue
    s, r = m.group(1), int(m.group(2))
    path = os.path.join(S, 'mock', 'm_%s_%d.py' % (s, r))
    text0 = open(path, encoding='utf-8').read()
    try:
        fixes = json.load(open(f, encoding='utf-8'))
    except Exception as ex:
        print('JSON が読めない：', f, ex); continue
    text1, applied, errs = apply(text0, s, r, fixes)
    print('== %s：直し %d件を当てた%s' % (os.path.basename(f), applied, ('、当てられない %d件' % len(errs)) if errs else ''))
    for e in errs: print('  ×', e)
    check(text0, s, r, '前')
    try:
        check(text1, s, r, '後')
    except Exception as ex:
        print('  直した後のファイルが読めない：', str(ex)[:300])
    if outdir:
        os.makedirs(outdir, exist_ok=True); open(os.path.join(outdir, 'm_%s_%d.py' % (s, r)), 'w', encoding='utf-8').write(text1)
