# 演習問題（pwa/data/q_*.json）で、選択肢の並びだけで正答が当たる組み合わせの問題を探す（combo_scan.scan_item を使う）
# 使い方: python3 qc/qbank_combo_scan.py [科目...]  → 該当の一覧と qc/qbank_combo_hits.json
import json, glob, os, sys, collections
B = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, B)
import combo_scan
subs = sys.argv[1:]
hits = []; n = 0
for f in sorted(glob.glob(os.path.join(B, 'pwa/data/q_*.json'))):
    s = os.path.basename(f)[2:-5]
    if subs and s not in subs:
        continue
    for it in json.load(open(f, encoding='utf-8'))['questions']:
        if 'ch' not in it:
            continue
        x = dict(it)
        try:
            x['a'] = int(x['a'])
        except Exception:
            continue
        n += 1
        r = combo_scan.scan_item(x)
        if r and r[0]:
            hits.append(dict(id=it['id'], kind=r[1], why=r[0], type=it['type']))
json.dump(hits, open(os.path.join(B, 'qc/qbank_combo_hits.json'), 'w'), ensure_ascii=False, indent=1)
print('選択肢のある問題', n, '該当', len(hits), dict(collections.Counter(h['id'].split('-')[0] for h in hits)))
