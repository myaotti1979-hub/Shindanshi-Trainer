# 記号の組（aとb など）の問題で、build が記述の記号を付け替えた（stm の並びが変わった）のに、
# 解説・問題の図（SVG）の中に記述の記号（a〜e）が書かれている問題を探す。図の中の文字は付け替わらないので食い違うおそれがある。
# 使い方: python3 qc/relabel_fig_scan.py [科目_回 ...]
import json, glob, os, re, sys, importlib.util
B = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sets = sys.argv[1:] or [os.path.basename(f)[2:-5] for f in sorted(glob.glob(os.path.join(B, 'pwa/data/m_*_*.json')))]
TXT = re.compile(r'<text[^>]*>([^<]*)</text>')
LET = re.compile(r'(?:^|[^A-Za-z0-9])([a-e])(?:[^A-Za-z0-9]|$)')
n = 0
for k in sets:
    s, r = k.split('_')
    src = os.path.join(B, 'mock', 'm_%s_%s.py' % (s, r))
    js = os.path.join(B, 'pwa', 'data', 'm_%s_%s.json' % (s, r))
    if not (os.path.exists(src) and os.path.exists(js)):
        continue
    spec = importlib.util.spec_from_file_location('m', src); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    srcq = {q['no']: q for q in m.Q}
    for it in json.load(open(js, encoding='utf-8'))['items']:
        q = srcq.get(it['no'])
        if not q or not q.get('stm') or not it.get('stm'):
            continue
        if list(q['stm']) == list(it['stm']):
            continue
        texts = []
        for fld in ('x', 'f'):
            for t in TXT.findall(it.get(fld) or ''):
                if LET.search(t):
                    texts.append(t)
        if texts:
            n += 1
            print('%s 第%s問：記号を付け替え。図の中の記号つきの文字 %d：%s' % (k, it['no'], len(texts), ' ｜ '.join(texts[:4])[:200]))
print('該当', n)
