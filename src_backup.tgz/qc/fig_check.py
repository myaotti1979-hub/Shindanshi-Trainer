# 図のファイル（text/fig_*.py）の直しを、写しに当てて読み込めるかを確かめる（本物は書き換えない）
# 使い方：python3 -I qc/fig_check.py wip/mk2/fig_out_1.json [--write <出力フォルダ>]
#   直しの形：[{"id":"m2-chusho-6","file":"text/fig_mk_chusho_2.py","old":"ファイルの中で1か所だけに一致する文字列","new":"置き換え","why":"理由"}]
#   出すもの：当てられない直し、読み込めない図のファイル、直した図の文字（SVG のタグを除いたもの）
import sys, os, re, json, shutil, importlib.util, tempfile
S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args = sys.argv[1:]
outdir = None
if '--write' in args:
    outdir = args[args.index('--write') + 1]; args = [a for a in args if a not in ('--write', outdir)]
edits = []
for f in args:
    edits += json.load(open(f, encoding='utf-8'))
tmp = tempfile.mkdtemp(prefix='figsb_')
shutil.copytree(os.path.join(S, 'text'), os.path.join(tmp, 'text'))
texts, errs, n = {}, [], 0
for e in edits:
    fp = os.path.join(tmp, e['file'])
    if not os.path.exists(fp):
        errs.append('%s：ファイルがない %s' % (e.get('id'), e['file'])); continue
    t = texts.get(fp) or open(fp, encoding='utf-8').read()
    c = t.count(e['old'])
    if c != 1:
        errs.append('%s：old が %d か所に一致（%s…）' % (e.get('id'), c, e['old'][:40])); continue
    texts[fp] = t.replace(e['old'], e['new']); n += 1
for fp, t in texts.items():
    open(fp, 'w', encoding='utf-8').write(t)
print('直し %d件を当てた%s' % (n, ('、当てられない %d件' % len(errs)) if errs else ''))
for e in errs: print('  ×', e)
sys.path.insert(0, os.path.join(tmp, 'text'))
names = set()
for e in edits:
    names.update(re.findall(r'(?:mk\.)?[a-z]+\.[0-9a-z_\-\.]+', e.get('new', '')))
for fp in sorted(texts):
    try:
        spec = importlib.util.spec_from_file_location(os.path.basename(fp)[:-3], fp)
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        print('読み込めた：%s（図 %d）' % (os.path.relpath(fp, tmp), len(getattr(m, 'FIG', {}))))
        for e in edits:
            if os.path.join(tmp, e['file']) != fp: continue
            for k, v in m.FIG.items():
                if e['new'] and isinstance(v, str) and re.sub(r'\s+', '', re.sub(r'<[^>]+>', ' ', e['new']))[:12] in re.sub(r'\s+', '', re.sub(r'<[^>]+>', ' ', v)):
                    txt = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', v)).strip()
                    print('  %s：%s' % (k, txt[:300]))
                    break
    except Exception as ex:
        print('× 読み込めない：%s：%s' % (os.path.relpath(fp, tmp), str(ex)[:300]))
if outdir:
    os.makedirs(outdir, exist_ok=True)
    for fp, t in texts.items():
        open(os.path.join(outdir, os.path.basename(fp)), 'w', encoding='utf-8').write(t)
shutil.rmtree(tmp, ignore_errors=True)
