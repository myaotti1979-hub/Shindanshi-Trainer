# テキストの直し（[{"file","old","new"}]）を当てる。old はそのファイルの中でちょうど1か所に一致すること。
# 使い方: python3 qc/apply_textfix.py qc/xxx.json [--dry]
import sys, json, os
B = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
dry = '--dry' in sys.argv
fx = []
for f in [a for a in sys.argv[1:] if a.endswith('.json')]:
    fx += json.load(open(f, encoding='utf-8'))
src = {}
for x in fx:
    p = os.path.join(B, x['file'])
    if p not in src:
        src[p] = open(p, encoding='utf-8').read()
    n = src[p].count(x['old'])
    if n != 1:
        sys.exit('%s: 置換前の文字列が %d か所に一致: %s' % (x['file'], n, x['old'][:60]))
    src[p] = src[p].replace(x['old'], x['new'])
for p, s in src.items():
    if not dry:
        import shutil
        bk = os.path.join(os.path.dirname(p), '_bak_' + os.path.basename(p) + '.pre_textfix')
        if not os.path.exists(bk):
            shutil.copy(p, bk)
        open(p, 'w', encoding='utf-8').write(s)
    print('書いた' if not dry else '当てられる', os.path.relpath(p, B))
