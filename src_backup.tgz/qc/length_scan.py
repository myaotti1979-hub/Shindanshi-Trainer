# 選択肢の長さの偏り：文の選択肢の問題で、正答の肢だけが最も長いと、「いちばん長い肢を選ぶ」だけで当たる。
# 使い方: python3 qc/length_scan.py [ファイル（pwa/data/m_*_*.json や q_*.json）...] [-v]
#   1回分（ファイル）ごとに、正答だけが最も長い問題の数と、偶然の期待値（Σ1/選択肢の数）を出す。
#   目安：正答だけが最も長い問題の割合を「偶然の割合＋10ポイント」以下にする。2割以上長い問題（★）はできるだけなくす。
#   逆の偏り：正答が最も長くなる問題が偶然より極端に少ない（偶然でこれ以下になる確率が1％未満）と、「いちばん長い肢は外す」が手がかりになる。直しすぎに注意
#   -v：正答だけが最も長い問題の一覧（番号・長さの比）
import sys, json, glob, os
B = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args = [a for a in sys.argv[1:] if not a.startswith('-')]
verbose = '-v' in sys.argv
files = args or sorted(glob.glob(os.path.join(B, 'pwa', 'data', 'm_*_*.json')))
bad = rev = 0


def cdf_le(ps, k):
    # 各問題が偶然に「正答だけが最長」になる確率 ps のとき、その数が k 以下になる確率
    P = [1.0]
    for p in ps:
        Q = [0.0] * (len(P) + 1)
        for i, x in enumerate(P):
            Q[i] += x * (1 - p); Q[i + 1] += x * p
        P = Q
    return sum(P[:k + 1])


for f in files:
    d = json.load(open(f, encoding='utf-8'))
    items = d.get('items') or d.get('questions')
    n = lo = 0; exp = 0.0; hits = []; ps = []
    for it in items:
        ch = it.get('ch')
        if not ch or len(ch) < 3:
            continue
        try:
            a = int(it['a'])
        except Exception:
            continue
        if max(len(c) for c in ch) < 15:      # 数値・記号の組など、短い選択肢の問題は除く
            continue
        n += 1; exp += 1 / len(ch); ps.append(1 / len(ch))
        L = [len(c) for c in ch]
        md = max(L[k] for k in range(len(L)) if k != a)
        if L[a] > md:
            lo += 1
            hits.append((it.get('no') or it.get('id'), round(L[a] / md, 2)))
    if not n:
        continue
    lim = exp / n + 0.10
    over = lo / n > lim
    bad += over
    under = cdf_le(ps, lo) < 0.01
    rev += under
    star = sum(1 for _, r in hits if r >= 1.2)
    print('%-16s 文の選択肢の問題 %3d　正答だけが最長 %3d（%2.0f％、偶然 %2.0f％）　うち2割以上長い★ %2d%s' % (
        os.path.basename(f), n, lo, 100 * lo / n, 100 * exp / n, star, '　← 偏りあり' if over else ('　← 逆の偏り' if under else '')))
    if verbose:
        print('   ', ' '.join('%s%s(%.2f)' % (no, '★' if r >= 1.2 else '', r) for no, r in hits))
print('偏りのあるファイル', bad, '　逆の偏りのあるファイル', rev)
