# 本試験（1次）のPDFから取り出した文で、選択肢を問題ごとに切り出せるかを確かめる。中身は出さず、数だけ出す
# 使い方：python3 -I qc/real_scan.py <scratchpad のフォルダ>
import sys, os, re, json, unicodedata, glob
S = sys.argv[1]
TXT = os.path.join(S, 'qc', 'real', 'txt')
past = json.load(open(os.path.join(S, 'pwa', 'data', 'past.json'), encoding='utf-8'))
SUB = dict(A='keizai', B='zaimu', C='kigyo', D='unei', E='homu', F='joho', G='chusho')
ANS = {(e['y'], s): v.get('items', []) for e in past['years'] for s, v in e['subjects'].items()}
KANA = 'アイウエオ'
OPT = re.compile(r'(?m)(?:^[ \t\f]*|[ \t]{2,})([アイウエオ])[ \t]+(?=\S)')


def split_by(pat, t):
    parts = re.split(pat, t)
    out = {}
    for i in range(1, len(parts), 2):
        out.setdefault(int(parts[i]), []).append(parts[i + 1])
    return parts[0], out


def best_opts(body):
    """ア から順に並ぶ選択肢の印を探し、いちばん長い並びの選択肢の文を返す"""
    ms = list(OPT.finditer(body))
    best = []
    for i, m in enumerate(ms):
        if m.group(1) != 'ア':
            continue
        seq = [m]; j = i + 1
        while j < len(ms) and len(seq) < 5 and ms[j].group(1) == KANA[len(seq)]:
            seq.append(ms[j]); j += 1
        if len(seq) > len(best):
            best = seq
    texts = []
    for k, m in enumerate(best):
        end = best[k + 1].start() if k + 1 < len(best) else min(len(body), m.end() + 400)
        texts.append(re.sub(r'\s+', '', body[m.end():end]))
    stem = body[:best[0].start()] if best else body
    return texts, stem


rows = []
tot = dict(items=0, ok=0, pos=0, neg=0, other=0, longi=0, combo=0, combo_ok=0)
for f in sorted(glob.glob(os.path.join(TXT, '*.txt'))):
    name = os.path.basename(f)[:-4]
    sub, y = SUB[name[0]], int(name[-4:])
    raw = open(f, encoding='utf-8', errors='replace').read()
    kx = sum(1 for ch in raw if 0x2E80 <= ord(ch) <= 0x2FDF)
    bad = raw.count('�') + sum(1 for ch in raw if 0xE000 <= ord(ch) <= 0xF8FF)
    t = unicodedata.normalize('NFKC', raw)
    _, qs = split_by(r'(?m)^[ \t\f]*第[ \t]*(\d+)[ \t]*問', t)
    items = ANS.get((y, sub), [])
    ok = pos = neg = oth = longi = combo = combo_ok = 0
    for it in items:
        m = re.match(r'\s*(\d+)\D*(\d+)?', it['n'])
        qn, sn = int(m.group(1)), (int(m.group(2)) if m.group(2) else 0)
        cands = qs.get(qn, [])
        got = None
        for body in cands:
            if sn:
                _, ss = split_by(r'(?m)^[ \t\f]*\(?設問[ \t]*(\d+)\)?', body)
                bodies = ss.get(sn, [])
            else:
                bodies = [body]
            for b in bodies:
                texts, stem = best_opts(b)
                if got is None or len(texts) > len(got[0]):
                    got = (texts, stem)
        if not got:
            continue
        texts, stem = got
        need = KANA.index(it['a'][0]) + 1 if it['a'][:1] in KANA else 4
        if len(texts) >= max(4, need):
            ok += 1
            if re.search(r'最も不適切|誤っているもの|適切でないもの', stem): neg += 1
            elif re.search(r'最も適切|正しいもの', stem): pos += 1
            else: oth += 1
            if sum(len(x) for x in texts) / len(texts) >= 20: longi += 1
            if re.search(r'組み?合わせ', stem) and re.search(r'正|誤|○|×', ''.join(texts)):
                combo += 1
                if all(re.search(r'[a-d][:：]?\s*(正|誤|○|×)', x) for x in texts): combo_ok += 1
    rows.append(f"{name} 字化け{bad} 部首字{kx} 問題{len(qs)} 解答{len(items)} 切出{ok} 適切{pos}/不適切{neg}/他{oth} 長文{longi} 正誤組{combo_ok}/{combo}")
    for k, v in zip(('items', 'ok', 'pos', 'neg', 'other', 'longi', 'combo', 'combo_ok'), (len(items), ok, pos, neg, oth, longi, combo, combo_ok)):
        tot[k] += v
print('\n'.join(rows))
print('合計', tot)
