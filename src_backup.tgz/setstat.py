import json, os, glob, re, subprocess
V = set(json.load(open('mock/verified.json')))
S = ['keizai','zaimu','kigyo','unei','homu','joho','chusho']
mj = json.load(open('pwa/data/mock.json', encoding='utf-8'))
pub = set()
def walk(o):
    if isinstance(o, dict):
        for k, v in o.items():
            if k in ('file','f','src') and isinstance(v, str) and v.startswith('m_'):
                pub.add(v)
            walk(v)
    elif isinstance(o, list):
        for v in o: walk(v)
walk(mj)
import combo_scan
for s in S:
    row = []
    for r in range(1, 8):
        py = 'mock/m_%s_%d.py' % (s, r)
        js = 'pwa/data/m_%s_%d.json' % (s, r)
        if not os.path.exists(py):
            row.append('%d:—' % r); continue
        st = ''
        if os.path.exists(js):
            d = json.load(open(js, encoding='utf-8'))
            items = d.get('items') or d.get('q') or d
            ids = [it['id'] for it in items]
            nv = sum(1 for i in ids if i in V)
            hits = sum(1 for it in items if (combo_scan.scan_item(it) or [[]])[0])
            rv = os.path.exists('review/mk_%s_%d.json' % (s, r))
            st = '%d/%d%s%s' % (nv, len(ids), ' R' if rv else '', (' C%d' % hits) if hits else '')
        else:
            st = 'nojson'
        row.append('%d:%s' % (r, st))
    print(s.ljust(7), '  '.join(row))
print('pub', sorted(pub)[:3], len(pub))
