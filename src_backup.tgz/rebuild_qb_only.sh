#!/bin/sh
# 演習問題だけを作り直す（rebuild_q.sh から模擬試験の build_mock を除いたもの）
set -e
cd "$(dirname "$0")"
cp pwa/data/past.json _past_keep.json
python3 build_data.py
python3 past_topics.py
python3 apply_review.py
python3 build_qfig.py > _qfig.log 2>&1 || { cat _qfig.log; echo "build_qfig.py が失敗した（解説の図が入らない）"; exit 1; }
tail -1 _qfig.log
python3 -c "
import json,shutil
K='_past_keep.json'
if json.load(open(K))==json.load(open('pwa/data/past.json')): shutil.copy(K,'pwa/data/past.json'); print('past.json: 変更なし')
else: print('past.json: 内容が変わった')
"
