# 作り直しの前後で、事実（数字・用語・文）が落ちていないかを調べる。
# 使い方: python3 fcheck.py <置き換え前のテキスト.py> <NEW を定義した .py> [しきい値]
import sys, os, re, glob, html, importlib.util
B = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(B, 'text'))


def load(p):
    spec = importlib.util.spec_from_file_location(os.path.basename(p)[:-3].replace('.', '_'), p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


FIG = {}
for f in sorted(glob.glob(os.path.join(B, 'text', 'fig_*.py'))):
    FIG.update(load(f).FIG)


def figtext(name):
    return html.unescape(re.sub(r'<[^>]+>', ' ', FIG.get(name, '')))


def toks(s):
    s = re.sub(r'\[\[図:[^\]]+\]\]', '', s)
    t = set(re.findall(r'[0-9][0-9,\.]*[％%万円個日年月件人桁㎡kmmlx時間分秒倍]*', s))
    t |= set(re.findall(r'(?<![ァ-ヶー])[ァ-ヶー]{3,}', s))
    t |= set(re.findall(r'[一-龥々]{3,}', s))
    t |= set(re.findall(r'[A-Za-z][A-Za-z0-9\-]{1,}', s))
    return t


def bigr(s):
    s = re.sub(r'[\s・、。（）「」：]', '', s)
    return set(s[i:i + 2] for i in range(len(s) - 1))


old = load(sys.argv[1]).T
new = load(sys.argv[2]).NEW
th = float(sys.argv[3]) if len(sys.argv) > 3 else 0.75
for k, v in new.items():
    body = old[k][1]
    nb = v[1]
    full = nb + ' ' + ' '.join(figtext(x) for x in re.findall(r'\[\[図:([^\]]+)\]\]', nb))
    miss = sorted(t for t in toks(body) if t not in full)
    if miss:
        print('TOK', k, miss)
    Bg = bigr(full)
    for sent in re.split(r'[\n。]', body):
        sent = sent.strip()
        if len(sent) < 12 or sent.startswith('**') or sent.startswith('[[図'):
            continue
        bs = bigr(sent)
        cov = len(bs & Bg) / len(bs) if bs else 1
        if cov < th:
            print('SEN %.2f' % cov, k, sent[:100])
