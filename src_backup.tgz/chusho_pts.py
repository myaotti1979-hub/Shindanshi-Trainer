# 中小企業経営・政策の調査から、細目ごとに短く出す。引数: 細目ID（カンマ区切り） [past|haku|sei|all] [最大文字数]
import json, sys
want = sys.argv[1].split(',')
mode = sys.argv[2] if len(sys.argv) > 2 else 'all'
mx = int(sys.argv[3]) if len(sys.argv) > 3 else 160
def L(f):
    try:
        d = json.load(open(f))
        return d if isinstance(d, list) else d.get('items', [])
    except Exception as e:
        print('skip', f, e); return []
if mode in ('past', 'all'):
    for x in sorted(L('review/past_chusho_a.json') + L('review/past_chusho_b.json'), key=lambda x: (x['year'], str(x['q']))):
        if x.get('item') in want:
            print('#', x['year'], 'Q' + str(x['q']) + (('-' + str(x['sub'])) if x.get('sub') else ''), x['topic'][:50], '|', ' / '.join(p[:mx] for p in x.get('points', [])[:2]))
if mode in ('haku', 'all'):
    for x in L('review/src_chusho_hakusho2026.json'):
        if x.get('item') in want:
            v = x.get('values'); v = v if isinstance(v, str) else json.dumps(v, ensure_ascii=False)
            print('H', x.get('topic', '')[:40], '|', v[:mx], '|', (x.get('finding') or '')[:90])
if mode in ('sei', 'all'):
    for x in L('review/src_chusho_seisaku2026.json'):
        if x.get('item') in want:
            print('S', x.get('topic', '')[:40], '|', ' '.join(str(x.get(k, '')) for k in ('target', 'requirements', 'support', 'period', 'changes'))[:mx * 2])
