# 組み合わせの問題（正誤の組・語句の組）で、誤りの選択肢の注 ce が、正答と違う記述・空欄のどれかに触れているかを調べる
import sys, json, re
sys.path.insert(0, '.')
import combo_scan
for f in sys.argv[1:]:
    j = json.load(open(f, encoding='utf-8'))
    for it in j['items']:
        t = combo_scan.tuples(it['ch'])
        if not t:
            continue
        keys, V = t
        ans = V[it['a']]
        for k, (v, ce) in enumerate(zip(V, it['ce'])):
            if k == it['a']:
                continue
            diff = [keys[i] for i in range(len(keys)) if v[i] != ans[i]]
            if not any(re.search(r'(?<![A-Za-z])' + re.escape(d) + r'(?![A-Za-z])', ce) for d in diff):
                print(f.split('/')[-1], it['no'], 'アイウエオ'[k], '違い', diff, '注:', ce[:80])
print('済み')
