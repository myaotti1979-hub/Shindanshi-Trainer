# 模擬試験の検証結果（review/mk_<科目>_<回>.json）を mock/m_<科目>_<回>.py に当てる
# 使い方: python3 apply_mkfix.py review/mk_keizai_1.json [--dry] [--mark]
#   fix の old は、その問題の dict(...) の中で1か所だけに一致すること（問題の中になく、ファイル全体で1か所ならリード文などとして当てる）。leadfix も同じく当てる
#   検証の担当の lv が書いたものと違えば、lv を担当の値に直す
#   --mark: ok と、直しを当てた fix の問題を mock/verified.json に入れる（figfix・easy・hard・reject は入れない。直した後に見直してもらう）
import sys, os, json, re
B = os.path.dirname(os.path.abspath(__file__))
args = sys.argv[1:]
dry, mark = '--dry' in args, '--mark' in args
R = []
for f in [a for a in args if a.endswith('.json')]:
    R += json.load(open(f, encoding='utf-8'))
src = {}


def fileof(qid):
    m = re.fullmatch(r'm(\d)-([a-z]+)-(.+)', qid)
    if not m:
        sys.exit('IDの形が違う: ' + qid)
    f = os.path.join(B, 'mock', 'm_%s_%s.py' % (m.group(2), m.group(1)))
    if f not in src:
        src[f] = open(f, encoding='utf-8').read()
    return f, m.group(3)


def block(qid):
    f, no = fileof(qid)
    s = src[f]
    i = s.find("dict(no='%s'" % no)
    if i < 0:
        sys.exit('問題が見つからない: ' + qid)
    j = s.find("\ndict(no='", i + 1)
    if j < 0:
        j = s.rfind(']')
    return f, i, j


ok, fixed, held, rej, fig, lvch = [], [], [], [], [], []
for r in R:
    qid, v = r['id'], r['verdict']
    f, i, j = block(qid)
    if r.get('lv') in ('A', 'B', 'C', 'D'):
        part = src[f][i:j]
        m = re.search(r"lv='([ABCD])'", part)
        if m and m.group(1) != r['lv']:
            part = part[:m.start()] + "lv='%s'" % r['lv'] + part[m.end():]
            src[f] = src[f][:i] + part + src[f][j:]
            lvch.append((qid, m.group(1), r['lv']))
    if v == 'ok':
        ok.append(qid)
        continue
    if v == 'reject':
        rej.append((qid, r.get('problem', '')))
        continue
    if r.get('figfix'):
        fig.append((qid, r['figfix']))
    # leadfix（リード文の直し：lead・old・new）も、ファイル全体で1か所だけに一致する直しとして当てる
    for fx in r.get('fixes', []) + [{'old': lf['old'], 'new': lf['new']} for lf in r.get('leadfix', [])]:
        if 'old' not in fx:
            if fx.get('figfix'):
                fig.append((qid, fx['figfix']))
            continue
        f, i, j = block(qid)
        s = src[f]
        part = s[i:j]
        n = part.count(fx['old'])
        if n == 1:
            src[f] = s[:i] + part.replace(fx['old'], fx['new']) + s[j:]
        elif n == 0 and s.count(fx['old']) == 1:
            src[f] = s.replace(fx['old'], fx['new'])
            print('問題の外（リード文など）に当てた', qid, fx['old'][:40])
        else:
            sys.exit('%s: 置換前の文字列が %d か所に一致: %s' % (qid, n, fx['old'][:60]))
    if v == 'fix' and not any(q == qid for q, _ in fig):
        fixed.append(qid)
    else:
        held.append((qid, v))
print('ok', len(ok), 'fix', len(fixed), '見直し待ち', len(held), 'reject', len(rej), '図の直し', len(fig), '難しさの変更', len(lvch))
for q, v in held:
    print('見直し待ち', q, v)
for q, p in rej:
    print('reject', q, p[:200])
for q, p in fig:
    print('図', q, p[:300])
for q, a, b in lvch:
    print('lv', q, a, '→', b)
if not dry:
    for f, s in src.items():
        if s != open(f, encoding='utf-8').read():
            open(f, 'w', encoding='utf-8').write(s)
            print('書いた', os.path.basename(f))
    if mark:
        p = os.path.join(B, 'mock', 'verified.json')
        V = set(json.load(open(p))) if os.path.exists(p) else set()
        V |= set(ok + fixed)
        json.dump(sorted(V), open(p, 'w'), ensure_ascii=False, indent=0)
        print('verified.json', len(V))
