const http = require('http'), fs = require('fs'), path = require('path');
const srv = http.createServer((q,r)=>{
  let f = path.join('.', q.url==='/'?'index.html':q.url);
  try{const d=fs.readFileSync(f);const t=f.endsWith('.json')?'application/json':f.endsWith('.js')?'text/javascript':'text/html';r.writeHead(200,{'Content-Type':t+'; charset=utf-8'});r.end(d);}
  catch(e){r.writeHead(404);r.end('Not found');}
});
srv.listen(0, async()=>{
  const port = srv.address().port;
  const {chromium} = require('playwright');
  const b = await chromium.launch();
  const p = await b.newPage({viewport:{width:390,height:844},deviceScaleFactor:2});
  await p.goto('http://localhost:'+port+'/');
  await p.waitForTimeout(2000);
  // Go to 2次
  await p.click('[data-stage="s2"]');
  await p.waitForTimeout(1500);
  await p.screenshot({path:'/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/v33_j4_home.png'});
  // Click 経営分析
  await p.click('[data-cat="mgmt"]');
  await p.waitForTimeout(500);
  await p.screenshot({path:'/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/v33_j4_cat.png'});
  // Pick first problem
  const rows = await p.locator('[data-act="j4-pick"]').all();
  if(rows.length) await rows[0].click();
  await p.waitForTimeout(500);
  await p.screenshot({path:'/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/v33_j4_q1.png'});
  // Select answer イ (index 1)
  await p.click('[data-act="j4-ch"][data-v="1"]');
  await p.waitForTimeout(300);
  // Submit
  await p.click('[data-act="j4-answer"]');
  await p.waitForTimeout(500);
  await p.screenshot({path:'/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/v33_j4_ans.png'});
  // Scroll down to see result
  await p.evaluate(()=>window.scrollBy(0,600));
  await p.waitForTimeout(300);
  await p.screenshot({path:'/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/v33_j4_ans2.png'});
  await b.close();
  srv.close();
  console.log('Done');
});
