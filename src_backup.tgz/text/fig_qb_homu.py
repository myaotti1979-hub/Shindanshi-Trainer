# 経営法務の本試験形式の演習（qbank/q_homu_*.py）に付ける図表
# homu.qd.* … 問題文の資料、homu.qx.* … 解説の図（テキストの図で足りないもの）
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import timeline, ARROW, R, T, L, _svg
from ekit import eq, hbars
from kit import _box

FIG = {}

# ------------------------------------------------ 1.1 事業開始・会社設立
FIG['homu.qx.kanni'] = eq([[('簡易合併の上限', 'a'), '＝', '純資産額12億円', '×', '5分の1', '＝', ('2億4,000万円', 'a')]],
                          '簡易合併：対価の額の上限', size=10.5, opw=14)

# ------------------------------------------------ 1.2 知的財産権
FIG['homu.qx.hogo'] = timeline([(0, '2005年\n3月20日', '著作者の死亡', 'a'), (0.4, '2006年\n1月1日', '翌年の1月1日\nから数える', 'c'),
                                (1, '2075年\n12月31日', '保護期間の満了', 'b')],
                               '保護期間の数え方（暦年主義）', spans=[(0.4, 1, '70年', 'b')])

# ------------------------------------------------ 1.3 取引関係
FIG['homu.qx.chien'] = eq([[('遅延損害金', 'a'), '＝', '300万円', '×', '年3％', '×', '1年', '＝', ('9万円', 'a')]],
                          '金銭債務の遅延損害金（法定利率）', size=10.5, opw=14)

# ------------------------------------------------ 1.4.2 会社法
FIG['homu.qx.tokubetsu'] = eq([[('定足数', 'b'), '＝', '議決権1,000個の過半数\n（501個以上）', '→', ('出席600個で\n満たす', 'b')],
                               [('必要な賛成', 'a'), '＝', '出席600個', '×', '3分の2', '＝', ('400個以上', 'a')]],
                              '特別決議の要件', size=10.5, opw=14)

FIG['homu.qx.teian'] = eq([[('1％の基準', 'a'), '＝', '総株主の議決権\n20,000個', '×', '1％', '＝', ('200個', 'a')],
                           [('要件', 'b'), '＝', '200個以上\nまたは300個以上', '＋', ('6か月前から\n引き続き保有', 'b')]],
                          '株主提案権の要件（公開会社・取締役会設置会社）', size=10.5, opw=14)

# ------------------------------------------------ 1.4.4 独占禁止法
FIG['homu.qx.hhi'] = eq([[('HHIの増分', 'a'), '＝', '2', '×', '25', '×', '8', '＝', ('400', 'a')],
                         [('基準', 'b'), '＝', '合併後のHHI 2,300\n（1,500超2,500以下）', '→', ('増分250以下なら\nセーフハーバー', 'b')],
                         [('判定', 'c'), '＝', '増分400', '＞', '250', '→', ('該当しない', 'c')]],
                        'HHIの増分とセーフハーバー', size=10.5, opw=14)

FIG['homu.qx.kachokin'] = eq([[('基本の課徴金', 'a'), '＝', '5億円', '×', '10％', '＝', ('5,000万円', 'a')],
                              [('減免の後', 'b'), '＝', '5,000万円', '×', '（1－20％）', '＝', ('4,000万円', 'b')]],
                             'カルテルの課徴金と減免（調査開始日の前・2位）', size=10.5, opw=14)

# ------------------------------------------------ 1.4.7 消費者保護法
FIG['homu.qx.kensho'] = eq([[('最高額', 'a'), '＝', '取引価額3,000円', '×', '20倍', '＝', ('6万円', 'a')],
                            [('総額', 'b'), '＝', '売上予定総額\n5,000万円', '×', '2％', '＝', ('100万円', 'b')]],
                           '一般懸賞の景品類の上限（取引価額5,000円未満）', size=10.5, opw=14)


# ------------------------------------------------ 1.4.9 事業承継（相続）
def _family():
    o = []
    # 被相続人と配偶者
    _box(o, 60, 6, 100, 40, 'A\n被相続人', col='sub', size=10.5)
    _box(o, 200, 6, 100, 40, 'B\n配偶者', col='b', size=10.5)
    o.append(L(160, 23, 200, 23, col='main', sw=1.3))
    o.append(L(160, 29, 200, 29, col='main', sw=1.3))
    o.append(L(180, 29, 180, 70, col='main', sw=1.3))
    o.append(L(95, 70, 275, 70, col='main', sw=1.3))
    # 子
    o.append(L(95, 70, 95, 82, col='main', sw=1.3))
    o.append(L(275, 70, 275, 82, col='main', sw=1.3))
    _box(o, 40, 82, 110, 42, 'C（子）\nAより先に死亡', col=None, size=10.5, dash=True)
    _box(o, 220, 82, 110, 42, 'F（子）', col='c', size=10.5)
    # 孫
    o.append(L(95, 124, 95, 140, col='main', sw=1.3))
    o.append(L(50, 140, 140, 140, col='main', sw=1.3))
    o.append(L(50, 140, 50, 152, col='main', sw=1.3))
    o.append(L(140, 140, 140, 152, col='main', sw=1.3))
    _box(o, 10, 152, 80, 38, 'D（孫）', col='a', size=10.5)
    _box(o, 100, 152, 80, 38, 'E（孫）', col=None, size=10.5)
    o.append(T(196, 176, '相続財産 1億2,000万円', size=10.5, bold=True))
    return _svg(360, 196, o, 'Aの家族')


FIG['homu.qd.souzoku'] = _family()
FIG['homu.qx.souzoku'] = eq([[('配偶者B', 'b'), '＝', '1億2,000万円', '×', '2分の1', '＝', ('6,000万円', 'b')],
                             [('子F', 'c'), '＝', '1億2,000万円', '×', '4分の1', '＝', ('3,000万円', 'c')],
                             [('孫D・E\n（Cを代襲）', 'a'), '＝', 'Cの分3,000万円', '÷', '2人', '＝', ('各1,500万円', 'a')]],
                            '法定相続分（配偶者と子が相続人）', size=10.5, opw=14)

FIG['homu.qx.ryuubun'] = eq([[('総体的遺留分', 'sub'), '＝', '1億6,000万円', '×', '2分の1', '＝', ('8,000万円', 'sub')],
                             [('Cの遺留分', 'a'), '＝', '8,000万円', '×', '法定相続分\n4分の1', '＝', ('2,000万円', 'a')]],
                            '遺留分（配偶者と子2人が相続人）', size=10.5, opw=14)

FIG['homu.qx.kotei'] = eq([[('算定の基礎', 'b'), '＝', 'ほかの財産\n8,000万円', '＋', '株式1億円\n（合意の時の価額）', '＝', ('1億8,000万円', 'b')],
                           [('Cの遺留分', 'a'), '＝', '1億8,000万円', '×', '2分の1×3分の1\n＝6分の1', '＝', ('3,000万円', 'a')]],
                          '固定合意をした場合の遺留分', size=10.5, opw=14)


def _man(v):
    r = round(v)
    s = format(r, ',') + '万円'
    return s if abs(v - r) < 1e-6 else '約' + s


FIG['homu.qx.kotei2'] = hbars([('除外合意\n（株式を除く）', 8000 / 6, 'sub'), ('固定合意\n（1億円で計算）', 18000 / 6, 'a'),
                               ('合意なし\n（死亡時の3億円）', 38000 / 6, 'sub')],
                              'Cの遺留分の額の比較', fmt=_man, lo=0, hi=6400, vw=84, lw=124)


# ------------------------------------------------ 1.6.1 英文契約
def _clause(lines, title):
    o = []
    h = 14 + 17 * len(lines) + 8
    o.append(R(2, 2, 356, h, fill='sheet', stroke='main', sw=1.2, rx=6))
    for j, (s, b) in enumerate(lines):
        o.append(T(12, 22 + 17 * j, s, size=11, bold=b))
    return _svg(360, h + 4, o, title)


FIG['homu.qd.eibun1'] = _clause([('Article 15', True),
                                 ('This Agreement shall be governed by and construed', False),
                                 ('in accordance with the laws of Japan. Any dispute', False),
                                 ('arising out of or in connection with this Agreement', False),
                                 ('shall be submitted to the exclusive jurisdiction of', False),
                                 ('the Tokyo District Court in the first instance.', False)],
                                '英文契約の条項（第15条）')

FIG['homu.qd.eibun2'] = _clause([('Article 20', True),
                                 ('If any provision of this Agreement is held to be', False),
                                 ('invalid or unenforceable, the remaining provisions', False),
                                 ('of this Agreement shall remain in full force and', False),
                                 ('effect.', False)],
                                '英文契約の条項（第20条）')
