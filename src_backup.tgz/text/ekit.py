# 経済学のグラフの部品。座標はデータの値で指定する（x: xmin〜xmax、y: ymin〜ymax）。fig_keizai_*.py から使う
import math
from vis import ARROW, R, T, L, _svg, _c, _esc, wrap, tw

# 線や面の上に置く文字が読めるように、文字のまわりを背景の色でふちどる
HALO = ';stroke:var(--paper);stroke-width:3px;paint-order:stroke;stroke-linejoin:round'


def r1(v):
    return round(v, 1)


def txt(x, y, s, anchor='start', col='main', bold=False, size=11.5, halo=True, vc=False, lh=None, op=None):
    """複数行（\\n）の文字（画素の座標）。vc=True なら y を文字のかたまりの縦の中心にする"""
    ls = str(s).split('\n')
    lh = lh or round(size * 1.25, 1)
    y0 = (y - (len(ls) - 1) * lh / 2 + size * 0.36) if vc else y
    a = ' text-anchor="%s"' % anchor if anchor != 'start' else ''
    b = ' font-weight="bold"' if bold else ''
    o = ' opacity="%s"' % op if op else ''
    st = 'fill:%s%s' % (_c(col), HALO if halo else '')
    return ''.join('<text x="%s" y="%s"%s%s font-size="%s"%s style="%s">%s</text>' % (r1(x), r1(y0 + i * lh), a, b, size, o, st, _esc(ln))
                   for i, ln in enumerate(ls))


def _dash(d):
    if d is True:
        return ' stroke-dasharray="6 4"'
    return ' stroke-dasharray="%s"' % d if d else ''


class G:
    """1枚のグラフ。メソッドは自分を返すので続けて書ける。svg(題) で SVG、render() で部品の一覧を返す"""

    def __init__(self, xmax=10, ymax=10, w=360, h=250, xlab='', ylab='', ox=0, oy=0, pl=34, pr=16, pt=16, pb=26,
                 xmin=0, ymin=0, cap='', ccol='main', size=11.5, origin='0', xaxis=None, xlpos='below', axes=True):
        self.xmin, self.xmax, self.ymin, self.ymax = xmin, xmax, ymin, ymax
        self.w, self.h, self.ox, self.oy = w, h, ox, oy
        self.cap, self.ccol = cap, ccol
        ct = 18 if cap else 0
        self.pl, self.pr, self.pt, self.pb = pl, pr, pt + ct, pb
        self.pw, self.ph = w - pl - pr, h - self.pt - pb
        self.xlab, self.ylab, self.size, self.origin = xlab, ylab, size, origin
        self.xlpos, self.axes = xlpos, axes
        self.bg, self.mid, self.fg = [], [], []
        self.xaxis = ymin if xaxis is None else xaxis

    def X(self, x):
        return self.ox + self.pl + (x - self.xmin) / (self.xmax - self.xmin) * self.pw

    def Y(self, y):
        return self.oy + self.pt + self.ph - (y - self.ymin) / (self.ymax - self.ymin) * self.ph

    # ---- 面
    def area(self, pts, col='b', op=0.22, label=None, at=None, lcol=None, size=10.5, bold=True):
        d = ' '.join('%s,%s' % (r1(self.X(a)), r1(self.Y(b))) for a, b in pts)
        self.bg.append('<polygon points="%s" style="fill:%s;fill-opacity:%s;stroke:none"/>' % (d, _c(col), op))
        if label:
            if at is None:
                at = (sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts))
            lc = lcol or (col if col in ('a', 'b', 'c') else 'main')
            self.fg.append(txt(self.X(at[0]), self.Y(at[1]), label, 'middle', lc, bold, size, vc=True))
        return self

    def rect(self, x1, y1, x2, y2, col='b', op=0.22, **kw):
        return self.area([(x1, y1), (x2, y1), (x2, y2), (x1, y2)], col, op, **kw)

    # ---- 線
    def line(self, pts, col='a', dash=False, sw=2.2, label=None, at=None, anchor='start', lsize=None, lbold=True, dx=0, dy=0, lcol=None):
        d = 'M' + ' L'.join('%s %s' % (r1(self.X(a)), r1(self.Y(b))) for a, b in pts)
        self.mid.append('<path d="%s" fill="none" style="stroke:%s" stroke-width="%s"%s stroke-linecap="round" stroke-linejoin="round"/>'
                        % (d, _c(col), sw, _dash(dash)))
        if label:
            if at is None:
                x, y = pts[-1]
                px, py = self.X(x) + 4 + dx, self.Y(y) + 4 + dy
            else:
                px, py = self.X(at[0]) + dx, self.Y(at[1]) + 4 + dy
            self.fg.append(txt(px, py, label, anchor, lcol or col, lbold, lsize or self.size))
        return self

    def fn(self, f, x0, x1, col='a', n=80, **kw):
        """関数のグラフ。描く範囲（ymin〜ymax）の外に出る部分は、境目で切る"""
        raw = [(x0 + (x1 - x0) * i / n, f(x0 + (x1 - x0) * i / n)) for i in range(n + 1)]
        lo, hi = self.ymin, self.ymax
        inside = lambda y: lo - 1e-9 <= y <= hi + 1e-9
        pts = []
        for i, (x, y) in enumerate(raw):
            if inside(y):
                if i and not inside(raw[i - 1][1]):
                    px, py = raw[i - 1]
                    b = hi if py > hi else lo
                    t = (b - py) / (y - py)
                    pts.append((px + (x - px) * t, b))
                pts.append((x, y))
            elif i and inside(raw[i - 1][1]):
                px, py = raw[i - 1]
                b = hi if y > hi else lo
                t = (b - py) / (y - py)
                pts.append((px + (x - px) * t, b))
        return self.line(pts, col, **kw)

    def seg(self, x1, y1, x2, y2, col='main', dash='3 3', sw=1, op=0.75):
        o = ' opacity="%s"' % op if op else ''
        self.mid.append('<path d="M%s %sL%s %s" fill="none" style="stroke:%s" stroke-width="%s"%s%s/>'
                        % (r1(self.X(x1)), r1(self.Y(y1)), r1(self.X(x2)), r1(self.Y(y2)), _c(col), sw, _dash(dash), o))
        return self

    def hl(self, y, col='b', x0=None, x1=None, **kw):
        """水平な直線（グラフの端から端まで）"""
        return self.line([(self.xmin if x0 is None else x0, y), (self.xmax if x1 is None else x1, y)], col, **kw)

    def vl(self, x, col='b', y0=None, y1=None, **kw):
        """垂直な直線"""
        return self.line([(x, self.xaxis if y0 is None else y0), (x, self.ymax if y1 is None else y1)], col, **kw)

    def guide(self, x, y, xt=None, yt=None, col='main', tcol=None, h=True, v=True, bold=False):
        """点から両方の軸へ点線を引き、軸に目盛りの文字（xt, yt）を付ける"""
        if v:
            self.seg(x, y, x, self.xaxis, col)
        if h:
            self.seg(x, y, self.xmin, y, col)
        if xt:
            self.xt(x, xt, tcol or col, bold)
        if yt:
            self.yt(y, yt, tcol or col, bold)
        return self

    def xt(self, x, s, col='main', bold=False, size=10.5):
        self.fg.append(txt(self.X(x), self.Y(self.xaxis) + 14, s, 'middle', col, bold, size))
        return self

    def yt(self, y, s, col='main', bold=False, size=10.5):
        self.fg.append(txt(self.X(self.xmin) - 4, self.Y(y) + 4, s, 'end', col, bold, size))
        return self

    # ---- 点・矢印・文字
    def dot(self, x, y, col='main', r=3.4, label=None, pos='ne', lcol=None, size=None, bold=True, d=5):
        px, py = self.X(x), self.Y(y)
        self.fg.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s"/>' % (r1(px), r1(py), r, _c(col)))
        if label:
            dx, dy, an = {'ne': (d, -d, 'start'), 'nw': (-d, -d, 'end'), 'se': (d, d + 9, 'start'), 'sw': (-d, d + 9, 'end'),
                          'n': (0, -d - 2, 'middle'), 's': (0, d + 11, 'middle'), 'e': (d + 2, 4, 'start'), 'w': (-d - 2, 4, 'end')}[pos]
            self.fg.append(txt(px + dx, py + dy, label, an, lcol or ('main' if col == 'main' else col), bold, size or self.size))
        return self

    def arrow(self, x1, y1, x2, y2, col='main', sw=1.6, head=6, dash=None, gap=0):
        p1, p2 = (self.X(x1), self.Y(y1)), (self.X(x2), self.Y(y2))
        if gap:
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]
            n = math.hypot(dx, dy) or 1
            p1 = (p1[0] + dx / n * gap, p1[1] + dy / n * gap)
            p2 = (p2[0] - dx / n * gap, p2[1] - dy / n * gap)
        self.fg.append(ARROW([p1, p2], col=col, sw=sw, head=head, dash=dash))
        return self

    def text(self, x, y, s, anchor='start', col='main', bold=False, size=None, dx=0, dy=0, vc=True, halo=True):
        self.fg.append(txt(self.X(x) + dx, self.Y(y) + dy, s, anchor, col, bold, size or self.size, halo=halo, vc=vc))
        return self

    def raw(self, s, layer='fg'):
        getattr(self, layer).append(s)
        return self

    def vspan(self, x, y1, y2, label='', col='a', anchor='start', dx=6, size=10.5):
        """縦の長さを両矢印で示す（ギャップ、税の大きさなど）"""
        p, q = self.Y(y1), self.Y(y2)
        px = self.X(x)
        self.fg.append(ARROW([(px, (p + q) / 2), (px, p)], col=col, sw=1.4, head=5))
        self.fg.append(ARROW([(px, (p + q) / 2), (px, q)], col=col, sw=1.4, head=5))
        if label:
            self.fg.append(txt(px + (dx if anchor == 'start' else -dx), (p + q) / 2, label, anchor, col, True, size, vc=True))
        return self

    def hspan(self, y, x1, x2, label='', col='a', dy=-6, size=10.5):
        """横の長さを両矢印で示す"""
        p, q = self.X(x1), self.X(x2)
        py = self.Y(y)
        self.fg.append(ARROW([((p + q) / 2, py), (p, py)], col=col, sw=1.4, head=5))
        self.fg.append(ARROW([((p + q) / 2, py), (q, py)], col=col, sw=1.4, head=5))
        if label:
            self.fg.append(txt((p + q) / 2, py + dy, label, 'middle', col, True, size, vc=True))
        return self

    # ---- 仕上げ
    def render(self):
        o = list(self.bg)
        if self.axes:
            X0, Y0 = self.X(self.xmin), self.Y(self.xaxis)
            top = self.oy + self.pt - 8
            o.append(ARROW([(X0, self.Y(self.ymin)), (X0, top)], col='main', sw=1.3, head=6))
            o.append(ARROW([(X0, Y0), (self.X(self.xmax) + 8, Y0)], col='main', sw=1.3, head=6))
            if self.ylab:
                o.append(txt(X0 + 7, top + 8, self.ylab, size=11))
            if self.xlab:
                if self.xlpos == 'above':
                    o.append(txt(self.X(self.xmax) + 8, Y0 - 6, self.xlab, 'end', size=11))
                else:
                    o.append(txt(self.X(self.xmax) + 8, Y0 + (28 if self.xlpos == 'low' else 18), self.xlab, 'end', size=11))
            if self.origin:
                o.append(txt(X0 - 4, Y0 + 13, self.origin, 'end', size=10.5))
        if self.cap:
            o.append(txt(self.ox + self.w / 2, self.oy + 13, self.cap, 'middle', self.ccol, True, 11.5))
        return o + self.mid + self.fg

    def svg(self, title):
        return _svg(self.w, self.h, self.render(), title)


def panels(gs, title, w=360, h=None, extra=()):
    """複数のグラフ（ox, oy をずらして作った G）を1枚にまとめる"""
    h = h or max(g.oy + g.h for g in gs)
    o = []
    for g in gs:
        o += g.render()
    o += list(extra)
    return _svg(w, h, o, title)


def payoff(rows, cols, cells, title, ra='A', ca='B', w=360, lw=86, hh=30, rh=42, note='', nash=None, marks=True):
    """利得表。cells[i][j] = (Aの利得, Bの利得)。最適反応の利得を丸で囲み（A は a 色、B は b 色）、
    両方が丸のマス（ナッシュ均衡）を太枠にする。nash=[] で太枠を付けない"""
    nr, nc = len(rows), len(cols)
    cw = (w - lw - 2) / nc
    o = []
    # 最適反応
    bra = set()
    for j in range(nc):
        m = max(cells[i][j][0] for i in range(nr))
        bra |= {(i, j) for i in range(nr) if cells[i][j][0] == m}
    brb = set()
    for i in range(nr):
        m = max(cells[i][j][1] for j in range(nc))
        brb |= {(i, j) for j in range(nc) if cells[i][j][1] == m}
    ne = bra & brb if nash is None else set(nash)
    # 見出し
    o.append(R(1, 1, lw - 2, hh, fill='paper', stroke='line'))
    o.append(T(lw / 2, hh / 2 + 6, '%s ＼ %s' % (ra, ca), 'middle', bold=True, size=12))
    for j, s in enumerate(cols):
        x = lw + j * cw
        o.append(R(x, 1, cw - 2, hh, fill='paper', stroke='line'))
        o.append(T(x + cw / 2 - 1, hh / 2 + 6, '%s：%s' % (ca, s), 'middle', col='b', bold=True, size=12))
    for i, s in enumerate(rows):
        y = hh + 3 + i * rh
        o.append(R(1, y, lw - 2, rh - 2, fill='paper', stroke='line'))
        o.append(T(lw / 2, y + rh / 2 + 4, '%s：%s' % (ra, s), 'middle', col='a', bold=True, size=12))
        for j in range(nc):
            x = lw + j * cw
            isne = (i, j) in ne
            o.append(R(x, y, cw - 2, rh - 2, fill='sheet', stroke='main' if isne else 'line', sw=2.4 if isne else 1))
            if isne:
                o.append(R(x, y, cw - 2, rh - 2, fill='c', stroke=None, op=0.14))
            cx, cy = x + cw / 2 - 1, y + rh / 2 + 4
            a, b = cells[i][j]
            o.append(T(cx - 36, cy, '（', 'middle', size=13))
            o.append(T(cx - 17, cy, a, 'middle', col='a', bold=True, size=14))
            o.append(T(cx, cy, '，', 'middle', size=13))
            o.append(T(cx + 17, cy, b, 'middle', col='b', bold=True, size=14))
            o.append(T(cx + 36, cy, '）', 'middle', size=13))
            if marks and (i, j) in bra:
                o.append('<circle cx="%s" cy="%s" r="11" style="fill:none;stroke:%s" stroke-width="1.6"/>' % (r1(cx - 17), r1(cy - 5), _c('a')))
            if marks and (i, j) in brb:
                o.append('<circle cx="%s" cy="%s" r="11" style="fill:none;stroke:%s" stroke-width="1.6"/>' % (r1(cx + 17), r1(cy - 5), _c('b')))
    h = hh + 3 + nr * rh
    if note:
        for k, ln in enumerate(wrap(note, w - 8, 10.5)):
            o.append(T(4, h + 14 + k * 14, ln, size=10.5))
        h += 8 + 14 * len(wrap(note, w - 8, 10.5))
    return _svg(w, h + 2, o, title)


def hbars(items, title, w=360, lw=118, rh=24, bh=14, size=11, fmt=None, lo=None, hi=None, note='', vw=46):
    """横棒グラフ（負の値も描ける）。items: [(名前, 値, 色)]。色が 'main' の棒は合計として太字で描く"""
    fmt = fmt or (lambda v: '%g' % v)
    vals = [it[1] for it in items]
    lo = min(0, min(vals)) if lo is None else lo
    hi = max(0, max(vals)) if hi is None else hi
    x0, x1 = lw, w - vw
    X = lambda v: x0 + (v - lo) / (hi - lo) * (x1 - x0)
    o = []
    y = 2
    lh = size + 3
    for nm, v, col in items:
        ls = wrap(nm, lw - 12, size)
        h = max(rh, len(ls) * lh + 8)
        by = y + (h - bh) / 2
        xa, xb = X(min(0, v)), X(max(0, v))
        tot = (col == 'main')
        o.append(R(xa, by, max(1.5, xb - xa), bh, fill='sub' if tot else col, stroke='main' if tot else col, op=0.3, sw=1.2 if tot else 1))
        for j, ln in enumerate(ls):
            o.append(T(lw - 8, y + h / 2 + size * 0.36 + (j - (len(ls) - 1) / 2) * lh, ln, 'end', size=size, bold=tot))
        vc = col if col in ('a', 'b', 'c') else 'main'
        o.append(T((xb if v >= 0 else X(0)) + 5, by + bh / 2 + 4, fmt(v), 'start', col=vc, bold=True, size=size))
        y += h
    o.append(L(X(0), 0, X(0), y + 2, col='main', sw=1.1))
    if note:
        ls = wrap(note, w - 8, 10.5)
        for k, ln in enumerate(ls):
            o.append(T(4, y + 16 + k * 14, ln, size=10.5))
        y += 8 + 14 * len(ls)
    return _svg(w, y + 4, o, title)


def stackbar(rows, title, w=360, lw=50, bh=40, gap=12, size=10.5, note=''):
    """100％の積み上げ横棒。rows: [(名前, [(文字, 値, 色)])]。文字は \\n で改行できる"""
    o = []
    y = 2
    for nm, segs in rows:
        tot = float(sum(s[1] for s in segs))
        x = lw
        for j, ln in enumerate(nm.split('\n')):
            o.append(T(lw - 8, y + bh / 2 + 4 + (j - (len(nm.split('\n')) - 1) / 2) * 14, ln, 'end', size=size + 0.5, bold=True))
        for s, v, col in segs:
            ww = (w - lw - 2) * v / tot
            o.append(R(x, y, ww, bh, fill=col, stroke=col if col != 'sub' else 'main', op=0.3 if col != 'sub' else 0.16, sw=1))
            ls = s.split('\n')
            for k, ln in enumerate(ls):
                o.append(T(x + ww / 2, y + bh / 2 + size * 0.36 + (k - (len(ls) - 1) / 2) * (size + 2), ln, 'middle', size=size, bold=(k == 0)))
            x += ww
        y += bh + gap
    y -= gap
    if note:
        ls = wrap(note, w - 8, 10.5)
        for k, ln in enumerate(ls):
            o.append(T(4, y + 16 + k * 14, ln, size=10.5))
        y += 8 + 14 * len(ls)
    return _svg(w, y + 4, o, title)


OPS = '＝＋－×÷≒→＜＞'


def eq(rows, title, w=360, size=11, opw=18, bh=None, gapy=10):
    """式を箱で示す。rows: 行のリスト。各行は部品のリスト。箱は (文字, 色) か 文字、
    演算子は '＝＋－×÷≒→＜＞' のどれか1文字。文字は \\n で改行でき、1段落目を太字にする"""
    from kit import _box, _lines
    o = []
    y = 2
    lh = round(size * 1.34, 1)
    for row in rows:
        isop = [isinstance(p, str) and len(p) == 1 and p in OPS for p in row]
        boxes = [p for p, k in zip(row, isop) if not k]
        nops = sum(isop)
        avail = w - 4 - nops * opw
        nat = []
        for p in boxes:
            s = p[0] if isinstance(p, tuple) else p
            nat.append(max(44, max(tw(l, size) for l in s.split('\n')) + 16))
        k = avail / sum(nat)
        ws = [n * k for n in nat]
        nl = max(len(_lines(p[0] if isinstance(p, tuple) else p, ww - 10, size)) for p, ww in zip(boxes, ws))
        hh = bh or max(34, nl * lh + 12)
        x = 2
        bi = 0
        for p, k2 in zip(row, isop):
            if k2:
                o.append(T(x + opw / 2, y + hh / 2 + 5, p, 'middle', bold=True, size=size + 3))
                x += opw
            else:
                s = p[0] if isinstance(p, tuple) else p
                col = p[1] if isinstance(p, tuple) else None
                _box(o, x, y, ws[bi], hh, s, col=col, size=size, c0=col)
                x += ws[bi]
                bi += 1
        y += hh + gapy
    return _svg(w, y - gapy + 2, o, title)
