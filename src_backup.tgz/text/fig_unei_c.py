# 運営管理の図表（2 店舗・販売管理：2.1 店舗・商業集積、2.2 商品仕入・販売、2.3 物流、2.4 流通情報システム、2.5 その他）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, boxes, flow, chart, htree, quad, timeline, barchart, gantt, cycle, pyramid, waterfall, matrix2, decomp,
                 ARROW, R, T, L, _svg, _c, wrap, tw)

FIG = {}

# ------------------------------------------------ 2.1.1 店舗施設に関する法律
FIG['unei.machi3'] = grid(['まちづくり三法', '役割'],
                          [['都市計画法', '用途地域などのゾーニングで、商業施設の立地を計画的に誘導する'],
                           ['大規模小売店舗立地法', '大型店の出店が周辺の生活環境に与える影響を、出店の前に確認する'],
                           ['中心市街地活性化法', '中心市街地の衰退を止めるための振興策を進める']],
                          [120, 240], align=['l', 'l'], title='まちづくり三法', size=10.5)
FIG['unei.senbiki'] = htree(('都市計画区域\n（原則、都道府県が指定）', 'sheet', [
    ('線引き', 'b', [('市街化区域：すでに市街地を形成している区域と、おおむね10年以内に優先的・計画的に市街化を図るべき区域。用途地域を必ず定める', 'sheet', []),
                                    ('市街化調整区域：市街化を抑制する区域。原則として開発を制限し、用途地域を定めない', 'sheet', [])]),
    ('非線引き', 'c', [('用途地域が定められていない区域は、白地地域と呼ばれる', 'sheet', [])])]),
    title='都市計画区域の区分（線引き＝区域区分を定めること）', colw=(96, 64, 176))
FIG['unei.youto13'] = grid(['住居系（8種類）', '商業系（2種類）', '工業系（3種類）'],
                           [['第一種・第二種低層住居専用地域', '近隣商業地域', '準工業地域'], ['第一種・第二種中高層住居専用地域', '商業地域', '工業地域'],
                            ['第一種・第二種住居地域', '', '工業専用地域'], ['準住居地域', '', ''], ['田園住居地域', '', '']],
                           [152, 104, 104], align=['l', 'l', 'l'], title='13種類の用途地域', size=10.5)


def _youto_shop():
    rows = [('第一種低層住居専用', 0, '原則として建てられない', 'a'),
            ('第二種低層住居専用', 1, '150㎡以下（2階以下）', 'c'),
            ('田園住居', 1, '150㎡以下（2階以下）※', 'c'),
            ('第一種中高層住居専用', 2, '500㎡以下（2階以下）', 'c'),
            ('第二種中高層住居専用', 3, '1,500㎡以下（2階以下）', 'c'),
            ('第一種住居', 4, '3,000㎡以下', 'c'),
            ('第二種住居・準住居・工業', 5, '10,000㎡以下', 'c'),
            ('近隣商業・商業・準工業', 6, '上限なし', 'b'),
            ('工業専用', 0, '建てられない', 'a')]
    w, lw, rh, top = 360, 122, 26, 4
    bx0 = lw + 4
    unit = (w - 6 - bx0) / 6.0
    o = []
    for i, (nm, lv, txt, col) in enumerate(rows):
        y = top + i * rh
        ls = wrap(nm, lw - 8, 10)
        for j, ln in enumerate(ls):
            o.append(T(lw - 2, y + rh / 2 + 4 + (j - (len(ls) - 1) / 2) * 12, ln, 'end', size=10, bold=True))
        if lv > 0:
            o.append(R(bx0, y + 3, unit * lv, rh - 6, fill=col, stroke=None, op=0.3, rx=3))
        o.append(T(bx0 + 5, y + rh / 2 + 4, txt, size=10.5, bold=lv in (0, 6), col='a' if lv == 0 else ('b' if lv == 6 else 'main')))
        o.append(L(2, y + rh, w - 2, y + rh, col='line', sw=0.5, dash='2 2'))
    y = top + len(rows) * rh + 16
    o.append(T(4, y, '第二種低層・田園住居の150㎡は、日用品の販売店などに限る', size=9.5))
    o.append(T(4, y + 15, '※農産物直売所や農家レストランなどは500㎡以下（2階以下）', size=9.5))
    o.append(T(4, y + 31, '床面積1万㎡超の大規模集客施設は、近隣商業・商業・準工業だけ', size=10, bold=True, col='b'))
    return _svg(w, y + 37, o, '用途地域ごとの店舗・飲食店の床面積の上限')


FIG['unei.youto_shop'] = _youto_shop()


def _kenpei():
    w, h = 360, 196
    o = []
    o.append(T(88, 14, '建ぺい率＝建築面積÷敷地面積', 'middle', size=10.5, bold=True, col='b'))
    o.append(R(14, 26, 150, 104, fill='sheet', stroke='main', sw=1.2))
    o.append(T(20, 42, '敷地', size=10))
    o.append(R(48, 52, 82, 56, fill='b', stroke='b', op=0.25, sw=1.2))
    o.append(T(89, 84, '建築面積', 'middle', size=10.5, bold=True))
    o.append(R(4, 136, 172, 22, fill='sub', stroke='sub', op=0.18))
    o.append(T(90, 151, '道路（幅員4m以上）', 'middle', size=10))
    o.append(L(40, 130, 140, 130, col='a', sw=3))
    o.append(T(90, 174, '敷地は道路に2m以上接する', 'middle', size=10, bold=True, col='a'))
    o.append(T(272, 14, '容積率＝延べ床面積÷敷地面積', 'middle', size=10.5, bold=True, col='c'))
    o.append(L(196, 130, 352, 130, col='main', sw=1.2))
    for k, s in enumerate(['3階', '2階', '1階']):
        y = 52 + k * 26
        o.append(R(232, y, 82, 26, fill='c', stroke='c', op=0.22, sw=1.1))
        o.append(T(273, y + 17, s, 'middle', size=10.5, bold=True))
    o.append(T(272, 150, '延べ床面積＝各階の床面積の合計', 'middle', size=10))
    o.append(T(4, 192, '建築確認：高さ4m超の広告塔・広告板、用途変更で200㎡超の店舗など', size=9.5))
    return _svg(w, h, o, '建ぺい率・容積率と接道義務')


FIG['unei.kenpei'] = _kenpei()
FIG['unei.daiten_tbl'] = grid(['項目', '内容'],
                              [['対象', '店舗面積が1,000㎡を超える大規模小売店舗。店舗面積に飲食店の部分は含まない。敷地面積ではない'],
                               ['目的', '周辺の地域の生活環境の保持（交通の渋滞、駐車・駐輪、騒音、廃棄物など）。需給調整はしない'],
                               ['届出先', '都道府県（政令指定都市）'],
                               ['配慮すべき事項', '交通、騒音、廃棄物など。開店日や休業日数は含まない']],
                              [80, 280], align=['l', 'l'], title='大規模小売店舗立地法の要点', size=10.5)
FIG['unei.daiten_flow'] = timeline([(0, '0か月', '届出', 'a'), (0.25, '2か月以内', '説明会', 'c'), (1, '8か月', '開店できる', 'b')],
                                   title='大規模小売店舗立地法の手続き',
                                   spans=[(0, 1, '都道府県が意見を述べる（届出から8か月以内）', 'b')])
FIG['unei.chukatsu'] = flow(['国が基本方針を定める\n（本部長は内閣総理大臣）', '市町村が基本計画を作る\n（協議会が意見を述べる）', '内閣総理大臣が認定する',
                             '認定された計画の事業は\n国の支援を受けられる'], per_row=2, title='中心市街地活性化法の流れ', bh=46)


def _ricchi():
    w, h = 360, 214
    o = [R(4, 22, 352, 158, fill='none', stroke='sub', sw=1.2, rx=10)]
    o.append(T(10, 16, '立地適正化計画の区域（都市計画区域の全体が基本）', size=10.5, bold=True))
    for (cx, cy, rx, ry, irx, iry) in [(104, 108, 92, 60, 46, 26), (276, 108, 70, 50, 36, 22)]:
        o.append('<ellipse cx="%s" cy="%s" rx="%s" ry="%s" style="fill:%s;fill-opacity:0.16;stroke:%s" stroke-width="1.3"/>' % (cx, cy, rx, ry, _c('b'), _c('b')))
        o.append('<ellipse cx="%s" cy="%s" rx="%s" ry="%s" style="fill:%s;fill-opacity:0.35;stroke:%s" stroke-width="1.3"/>' % (cx, cy + 6, irx, iry, _c('c'), _c('c')))
        o.append(T(cx, cy - ry + 18, '居住誘導区域', 'middle', size=10, bold=True, col='b'))
        o.append(T(cx, cy + 4, '都市機能', 'middle', size=9.5, bold=True))
        o.append(T(cx, cy + 16, '誘導区域', 'middle', size=9.5, bold=True))
    o.append(L(150, 114, 240, 114, col='a', sw=3))
    o.append(T(196, 108, '公共交通', 'middle', size=10, bold=True, col='a'))
    o.append(T(4, 196, '都市機能誘導区域は、居住誘導区域の中に定める', size=10))
    o.append(T(4, 211, '居住誘導区域は、市街化調整区域には定めない', size=10))
    return _svg(w, h, o, '立地適正化計画（コンパクト・プラス・ネットワーク）')


FIG['unei.ricchi'] = _ricchi()
FIG['unei.keikan'] = grid(['景観計画で', '事項'],
                          [['定めなければならない', '景観計画区域、良好な景観の形成の方針、行為の制限、景観重要建造物・景観重要樹木の指定の方針（対象がある場合）'],
                           ['必要に応じて定める', '屋外広告物の表示などの制限、景観重要公共施設（道路・河川・海岸など）の整備']],
                          [110, 250], align=['l', 'l'], title='景観計画の内容', size=10.5)
FIG['unei.shobo'] = grid(['', '特定防火対象物（店舗など）', 'それ以外（事務所、工場など）'],
                         [['防火管理者の選任', '収容人員30人以上', '収容人員50人以上'], ['点検の結果の報告', '1年に1回', '3年に1回'],
                          ['消防用設備の点検', '機器点検6か月に1回、総合点検1年に1回', '機器点検6か月に1回、総合点検1年に1回']],
                         [96, 132, 132], align=['l', 'l', 'l'], title='消防法の防火管理と点検', size=10.5)

# ------------------------------------------------ 2.1.2 店舗立地と出店


def _reilly():
    w, h = 360, 160
    xa, xb, y = 44, 316, 64
    xp = xb - (xb - xa) * 4 / 12
    o = [L(xa + 26, y, xb - 13, y, col='main', sw=1.6)]
    o.append('<circle cx="%s" cy="%s" r="26" style="fill:%s;fill-opacity:0.25;stroke:%s" stroke-width="1.4"/>' % (xa, y, _c('a'), _c('a')))
    o.append('<circle cx="%s" cy="%s" r="13" style="fill:%s;fill-opacity:0.25;stroke:%s" stroke-width="1.4"/>' % (xb, y, _c('b'), _c('b')))
    o.append(T(xa, y + 4, 'A市', 'middle', size=11, bold=True))
    o.append(T(xb, y + 30, 'B市', 'middle', size=11, bold=True))
    o.append(T(xa, y + 44, '人口36万人', 'middle', size=10))
    o.append(T(xb, y + 44, '人口9万人', 'middle', size=10))
    o.append(L(xp, y - 26, xp, y + 26, col='c', sw=1.6, dash='4 3'))
    o.append(T(xp, y - 32, '商圏分岐点', 'middle', size=10.5, bold=True, col='c'))
    o.append(T((xa + xp) / 2 + 12, y - 6, 'A市から8km', 'middle', size=10))
    o.append(T((xp + xb) / 2 - 6, y - 6, 'B市から4km', 'middle', size=10))
    o.append(T(180, 18, '両市の距離12km', 'middle', size=10.5, bold=True))
    o.append(T(4, 136, 'B市から分岐点まで＝12÷（1＋√（36÷9））＝12÷3＝4km', size=10.5, bold=True))
    o.append(T(4, 154, '分岐点は、人口の少ない都市の側に寄る', size=10))
    return _svg(w, h, o, 'コンバースの商圏分岐点')


FIG['unei.reilly'] = _reilly()
FIG['unei.huff'] = grid(['店舗', '売場面積', '距離', '面積÷距離²', '選ばれる確率'],
                        [['A', '1,000㎡', '1km', '1,000÷1²＝1,000', '1,000÷2,000＝50％'], ['B', '4,000㎡', '2km', '4,000÷2²＝1,000', '1,000÷2,000＝50％']],
                        [44, 64, 44, 104, 104], align=['c', 'r', 'r', 'l', 'l'], title='ハフ・モデルの計算（λ＝2）', size=10)

# ------------------------------------------------ 2.1.3 商業集積と業種・業態
FIG['unei.gyoshu'] = grid(['', '業種', '業態'],
                          [['分類の基準', '何を売るか（取り扱う商品の種類）', 'どのように売るか（販売の方法、価格、品揃え、営業の形態）'],
                           ['例', '青果店、書店、衣料品店', '百貨店、スーパー、コンビニエンスストア']],
                          [72, 128, 160], align=['l', 'l', 'l'], title='業種と業態', size=10.5)
FIG['unei.gyotai'] = grid(['業態', '特徴'],
                          [['百貨店', '衣食住の幅広い商品を、部門別に管理し、対面販売を中心に扱う'], ['総合スーパー（GMS）', '衣食住の幅広い商品を、セルフサービスで扱う'],
                           ['食品スーパー', '食料品を中心に、セルフサービスで扱う'], ['コンビニエンスストア', '小さな売場で日常の必需品を長い営業時間で扱う。フランチャイズ・チェーンが多い'],
                           ['ドラッグストア', '医薬品、化粧品、日用品など'], ['ホームセンター', '住まいの関連の商品、DIYの用品'],
                           ['ディスカウントストア', '低価格を武器に、幅広い商品を扱う'], ['カテゴリーキラー', '特定の分野の商品を、豊富な品揃えと低価格で扱う大型の専門店'],
                           ['SPA（製造小売業）', '商品の企画から製造、販売までを一貫して行う']],
                          [120, 240], align=['l', 'l'], title='主な業態', size=10)
FIG['unei.sc'] = grid(['SCの基準（日本ショッピングセンター協会。2025年1月改定）'],
                      [['①小売業の店舗面積が1,000㎡以上'], ['②テナントが10店舗以上含まれている'],
                       ['③最大店舗の面積が、SCの面積の80％程度を超えない（最大店舗を除く小売業の店舗面積が1,000㎡以上なら、この限りでない）'],
                       ['④広告宣伝、共同催事などの共同活動を行っている']],
                      [360], align=['l'], title='ショッピングセンターの基準', size=10.5)
FIG['unei.mogori'] = grid(['分類', '買い方', '例'],
                          [['最寄品', '頻繁に、手近な店で、手間をかけずに買う', '日用品、食料品'], ['買回品', '複数の店で品質や価格を比べて買う', '衣料品、家具'],
                           ['専門品', '時間や手間をかけ、遠くの店まででも買いに行く', '高級ブランド品']],
                          [64, 200, 96], align=['l', 'l', 'l'], title='消費者の購買慣習による商品の分類', size=10.5)
FIG['unei.shotengai'] = grid(['類型', '主な商品', '客が来る範囲'],
                             [['近隣型', '最寄品が中心', '近隣の住民（日常の買物）'], ['地域型', '最寄品と買回品が混在', '近隣型より広い範囲'],
                              ['広域型', '買回品が多い（百貨店や大型店がある）', '広い範囲'], ['超広域型', '有名な専門店などが集まる', '遠くからも来る']],
                             [70, 160, 130], align=['l', 'l', 'l'], title='商店街の類型', size=10.5)
FIG['unei.gyotai_sales'] = barchart([16.1, 12.9, 8.9, 6.3, 4.7, 3.4], ['スーパー', 'コンビニ', 'ドラッグ\nストア', '百貨店', '家電大型\n専門店', 'ホーム\nセンター'],
                                    title='業態別の年間販売額（2024年、兆円）', colors=['b', 'b', 'c', 'a', 'sub', 'sub'], ylab='兆円',
                                    vfmt=lambda v: '%.1f' % v, ymax=18, h=200)

# ------------------------------------------------ 2.1.4 店舗施設


def _doosen():
    w, h = 360, 240
    o = [R(14, 14, 332, 180, fill='none', stroke='main', sw=1.6)]
    o.append(R(26, 188, 52, 12, fill='sheet', stroke=None))
    o.append(T(52, 214, '入口', 'middle', size=10.5, bold=True))
    for k in range(3):
        o.append(R(262 + k * 26, 160, 20, 20, fill='sub', stroke='main', op=0.25, sw=0.8))
    o.append(T(296, 214, 'レジ', 'middle', size=10.5, bold=True))
    for gx in (100, 150, 200, 250):
        o.append(R(gx, 62, 30, 82, fill='sub', stroke='sub', op=0.18, sw=0.8))
    o.append(ARROW([(52, 184), (52, 40), (318, 40), (318, 150)], col='c', sw=3, head=8))
    o.append(T(60, 100, '主通路', size=10.5, bold=True, col='c'))
    o.append(T(60, 114, '（広く）', size=9.5, col='c'))
    o.append(T(166, 158, '副通路（主通路より狭く）', 'middle', size=9.5))
    for (cx, cy) in [(34, 30), (330, 30)]:
        o.append('<circle cx="%s" cy="%s" r="9" style="fill:%s;fill-opacity:0.5;stroke:%s"/>' % (cx, cy, _c('a'), _c('a')))
    o.append(T(180, 30, 'マグネット商品を奥や角に置いて、客を奥まで誘導', 'middle', size=9.5, bold=True, col='a'))
    for (x, y, s) in [(70, 156, '牛乳'), (318, 104, '卵'), (180, 76, 'パン')]:
        o.append('<path d="M%s %sl8 8l-8 8l-8 -8z" style="fill:%s;fill-opacity:0.5;stroke:%s"/>' % (x, y - 8, _c('b'), _c('b')))
        o.append(T(x + 11, y + 4, s, size=9.5, bold=True, col='b'))
    o.append(T(4, 232, '◆パワーカテゴリーは店内に分散して置き、回遊を促す', size=10, col='b', bold=True))
    return _svg(w, h, o, '店内のレイアウトと顧客動線（模式図）')


FIG['unei.doosen'] = _doosen()
FIG['unei.light'] = grid(['用語', '意味', '単位など'],
                         [['照度', '照らされている面の明るさ', 'ルクス（lx）'], ['光度', '光源からある方向に出る光の強さ', 'カンデラ（cd）'],
                          ['演色性', '物の色を、どれだけ自然光に近く見せるか', '平均演色評価数Ra。100に近いほど自然'],
                          ['色温度', '光の色合い（光色）', 'ケルビン（K）。低いと赤み、高いと青白い']],
                         [60, 160, 140], align=['l', 'l', 'l'], title='照明の用語', size=10.5)
FIG['unei.lux'] = barchart([750, 500, 200], ['重要陳列部', '大形店の全般', '洗面所'], title='JISの照明の基準（推奨照度、lx）',
                           colors=['a', 'c', 'sub'], ylab='lx', ymax=800, h=180, vfmt=lambda v: '%d' % v)


def _colortemp():
    w, h = 360, 92
    o = ['<defs><linearGradient id="unei-ctg" x1="0" x2="1" y1="0" y2="0"><stop offset="0" stop-color="#f08a3c"/>'
         '<stop offset="0.5" stop-color="#fbf3e6"/><stop offset="1" stop-color="#9cc3f2"/></linearGradient></defs>']
    o.append('<rect x="10" y="26" width="340" height="24" rx="5" fill="url(#unei-ctg)" stroke="#888" stroke-width="0.6"/>')
    o.append(ARROW([(10, 62), (350, 62)], col='main', sw=1.3, head=6))
    o.append(T(180, 18, '色温度（K：ケルビン）', 'middle', size=10.5, bold=True))
    o.append(T(10, 80, '低い：赤みのある暖かい光', size=10.5, bold=True, col='c'))
    o.append(T(350, 80, '高い：青白い光', 'end', size=10.5, bold=True, col='b'))
    return _svg(w, h, o, '色温度と光の色')


FIG['unei.colortemp'] = _colortemp()


def _colorwheel():
    w, h = 360, 176
    cx, cy, r = 84, 88, 62
    o = []
    for k in range(12):
        a0 = math.radians(k * 30 - 105)
        a1 = math.radians(k * 30 - 75)
        hue = (k * 30) % 360
        p0 = (cx + r * math.cos(a0), cy + r * math.sin(a0))
        p1 = (cx + r * math.cos(a1), cy + r * math.sin(a1))
        q0 = (cx + 30 * math.cos(a0), cy + 30 * math.sin(a0))
        q1 = (cx + 30 * math.cos(a1), cy + 30 * math.sin(a1))
        d = 'M%.1f %.1fA%s %s 0 0 1 %.1f %.1fL%.1f %.1fA30 30 0 0 0 %.1f %.1fZ' % (p0[0], p0[1], r, r, p1[0], p1[1], q1[0], q1[1], q0[0], q0[1])
        o.append('<path d="%s" fill="hsl(%d,72%%,55%%)" stroke="#fff" stroke-width="1"/>' % (d, hue))
    o.append(L(cx, cy - r - 6, cx, cy + r + 6, col='main', sw=1.4, dash='4 3'))
    o.append(T(cx + 6, cy - r - 2, '赤', size=10, bold=True))
    o.append(T(cx + 6, cy + r + 12, '青緑', size=10, bold=True))
    tx = 168
    for i, (s, col, b) in enumerate([('向かい合う色＝補色', 'main', True), ('並べると互いを引き立てる', 'main', False),
                                      ('暖色（赤・橙など）：進出して見える', 'c', True), ('寒色（青など）：後退して見える', 'b', True),
                                      ('明度が高い：膨張して見える', 'main', False), ('明度が低い：収縮して見える', 'main', False)]):
        o.append(T(tx, 30 + i * 22, s, size=10.5, bold=b, col=col))
    return _svg(w, h, o, '色相環と色の見え方')


FIG['unei.colorwheel'] = _colorwheel()
FIG['unei.color3'] = grid(['色の三属性', '内容'],
                          [['色相', '赤、青などの色み'], ['明度', '明るさ'], ['彩度', '鮮やかさ'], ['（無彩色）', '白、灰色、黒。色相と彩度を持たず、明度だけを持つ']],
                          [90, 270], align=['l', 'l'], title='色の三属性', size=10.5)
FIG['unei.color_eff'] = grid(['性質', '意味'],
                             [['誘目性', '注意していない人の目も引きつける度合い。注意や危険の表示では高める'], ['視認性', '遠くからでも見つけやすく、周囲から際立って見える度合い'],
                              ['明視性', '形や細部を認めやすく、情報を細かく判別できる度合い'], ['可読性', '文字や数字の読みやすさ。文字と背景の明度の差を大きくすると高い'],
                              ['識別性', '複数のものを区別しやすい度合い']],
                             [70, 290], align=['l', 'l'], title='色の性質', size=10.5)

# ------------------------------------------------ 2.2.1 商品販売計画


def _uriage():
    w, h = 360, 150
    o = []

    def box(cx, cy, s, col, bw=96):
        o.append(R(cx - bw / 2, cy - 15, bw, 30, fill=col, stroke=col if col != 'sheet' else 'main', op=0.22 if col != 'sheet' else None, rx=6, sw=1.2))
        o.append(T(cx, cy + 4.5, s, 'middle', size=11, bold=True))
    box(180, 20, '売上高', 'sheet')
    box(90, 74, '客数', 'b')
    box(270, 74, '客単価', 'c')
    o.append(T(180, 78, '×', 'middle', size=14, bold=True))
    o.append(L(180, 35, 90, 59, col='main', sw=1))
    o.append(L(180, 35, 270, 59, col='main', sw=1))
    box(46, 128, '来店客数', 'sheet', 70)
    box(134, 128, '購入率', 'sheet', 70)
    o.append(T(90, 132, '×', 'middle', size=12, bold=True))
    box(226, 128, '1品単価', 'sheet', 70)
    box(314, 128, '買上点数', 'sheet', 70)
    o.append(T(270, 132, '×', 'middle', size=12, bold=True))
    for (x1, x2) in [(90, 46), (90, 134), (270, 226), (270, 314)]:
        o.append(L(x1, 89, x2, 113, col='main', sw=1))
    return _svg(w, h, o, '売上高の分解')


FIG['unei.uriage'] = _uriage()
FIG['unei.bep_store'] = chart([([(0, 0), (600, 600)], 'b', False), ([(0, 120), (600, 540)], 'a', False), ([(0, 120), (600, 120)], 'sub', True)],
                              0, 620, 0, 620, xlab='売上高（万円）', ylab='金額（万円）',
                              labels=[(560, 598, '売上高', 'end', 'b'), (20, 540, '総費用＝120＋0.7×売上高', 'start', 'a'), (590, 95, '固定費120', 'end', 'sub'),
                                      (390, 440, '損益分岐点', 'end', 'main')],
                              vlines=[(400, '400万円')], dots=[(400, 400, 'main')], xticks=[(0, '0'), (200, '200'), (400, '400'), (600, '600')],
                              yticks=[(120, '120'), (400, '400')], w=360, h=230, title='損益分岐点（変動費率70％、固定費120万円）', zero=False)


def _neire():
    w, h = 360, 128
    x0, x1 = 20, 340
    X = lambda v: x0 + v / 1000 * (x1 - x0)
    o = [R(X(0), 34, X(700) - X(0), 30, fill='sub', stroke='main', op=0.2, sw=1)]
    o.append(R(X(700), 34, X(1000) - X(700), 30, fill='b', stroke='b', op=0.3, sw=1))
    o.append(T((X(0) + X(700)) / 2, 54, '原価 700円', 'middle', size=11, bold=True))
    o.append(T((X(700) + X(1000)) / 2, 54, '値入額 300円', 'middle', size=11, bold=True, col='b'))
    o.append(ARROW([(X(0), 24), (X(1000), 24)], col='main', sw=1.1, head=5))
    o.append(ARROW([(X(1000), 24), (X(0), 24)], col='main', sw=1.1, head=5))
    o.append(T(180, 16, '売価 1,000円', 'middle', size=11, bold=True))
    o.append(T(4, 86, '値入額＝売価－原価', size=10.5, bold=True))
    o.append(T(4, 103, '値入率（売価値入率）＝値入額÷売価＝300÷1,000＝30％', size=10.5, bold=True, col='b'))
    o.append(T(4, 120, '実際の粗利益は、値下げや、破損・盗難などのロスで、値入額より小さくなる', size=10))
    return _svg(w, h, o, '値入額と値入率')


FIG['unei.neire'] = _neire()
FIG['unei.sojoseki'] = grid(['カテゴリー', '売上構成比', '粗利益率', '相乗積'],
                            [['X', '40％', '25％', '40％×25％＝10％'], ['Y', '60％', '30％', '60％×30％＝18％'], ['店全体', '100％', '28％', '10％＋18％＝28％']],
                            [80, 80, 80, 120], align=['l', 'r', 'r', 'l'], title='相乗積（＝売上構成比×粗利益率）', size=10.5, total_rows=(2,))


def _haba():
    w, h = 360, 168
    o = []

    def panel(ox, ncat, nitem, title, col):
        o.append(T(ox + 85, 14, title, 'middle', size=11, bold=True, col=col))
        bw = min(22, 150 / ncat - 4)
        for c in range(ncat):
            for i in range(nitem):
                o.append(R(ox + 10 + c * (bw + 4), 128 - (i + 1) * 15, bw, 12, fill=col, stroke=col, op=0.3, sw=0.8))
        o.append(ARROW([(ox + 10, 140), (ox + 10 + ncat * (bw + 4) - 4, 140)], col='main', sw=1.2, head=5))
        o.append(T(ox + 10 + (ncat * (bw + 4) - 4) / 2, 156, '幅（カテゴリーの数）', 'middle', size=10))
        return ox + 10 + ncat * (bw + 4)
    xr = panel(0, 6, 2, '総合化：幅を広げる', 'c')
    xr2 = panel(186, 2, 6, '専門化：奥行きを深くする', 'b')
    o.append(ARROW([(xr2 + 4, 128), (xr2 + 4, 128 - 6 * 15)], col='main', sw=1.2, head=5))
    o.append(T(xr2 + 10, 76, '奥行き', size=10))
    o.append(T(xr2 + 10, 90, '（品目の数）', size=9.5))
    return _svg(w, h, o, '品揃えの幅と奥行き')


FIG['unei.haba'] = _haba()
FIG['unei.eiyo'] = grid(['食品', '栄養成分の表示'],
                        [['容器包装に入れた一般用の加工食品', '義務（熱量、たんぱく質、脂質、炭水化物、食塩相当量）'], ['業務用の加工食品', '義務ではない'],
                         ['生鮮食品', '義務ではない（任意で表示できる）']],
                        [150, 210], align=['l', 'l'], title='栄養成分の表示（食品表示法）', size=10.5, tcol={'義務ではない': 'sub'})
FIG['unei.hokenkino'] = grid(['保健機能食品', '表示のしくみ'],
                             [['特定保健用食品（トクホ）', '国が商品ごとに審査し、許可する'], ['機能性表示食品', '事業者の責任で、根拠を国に届け出る'],
                              ['栄養機能食品', '国の定めた基準に合えば、届出なしで表示できる']],
                             [140, 220], align=['l', 'l'], title='保健機能食品の3つ（どれも機能性を表示できる）', size=10.5)
FIG['unei.tokusho'] = grid(['通信販売のルール', '内容'],
                           [['クーリング・オフ', 'ない'], ['返品の特約を広告に表示していない', '商品を受け取ってから8日以内なら返品できる（送料は購入者の負担）'],
                            ['最終確認画面（2022年6月施行）', '分量、販売価格（支払総額）、支払の時期と方法、引渡しの時期、申込みの期間、申込みの撤回・解除に関する事項を表示']],
                           [130, 230], align=['l', 'l'], title='特定商取引法の通信販売', size=10.5)
FIG['unei.iyaku'] = grid(['区分', '販売できる人', 'インターネット販売'],
                         [['要指導医薬品', '薬剤師', '2026年5月から、オンライン服薬指導をすれば可（緊急避妊薬などを除く）'],
                          ['第1類医薬品', '薬剤師', '一定の条件を満たせば可'], ['第2類・第3類医薬品', '薬剤師または登録販売者', '一定の条件を満たせば可']],
                         [96, 104, 160], align=['l', 'l', 'l'], title='医薬品の区分と販売', size=10.5)

# ------------------------------------------------ 2.2.2 商品調達・取引条件
FIG['unei.torihiki'] = grid(['', '買取仕入', '委託仕入', '消化仕入'],
                            [['所有権', '仕入れた時点で小売業者', '委託者（仕入先）のまま', '売れた時点まで仕入先'],
                             ['売れ残りのリスク', '小売業者（原則として返品できない）', '委託者（返品できる）', '仕入先'],
                             ['特徴', '粗利益の率を高くしやすい', '価格は委託者が決める。小売業者は販売手数料を受け取る', '売れた時点で仕入を計上。百貨店で多い']],
                            [72, 96, 96, 96], align=['l', 'l', 'l', 'l'], title='取引の形態', size=10)

# ------------------------------------------------ 2.2.3 売場構成・陳列
FIG['unei.vmd'] = pyramid([('VP', 'a'), ('PP', 'c'), ('IP', 'b')], title='VMDの3つの要素', lh=38,
                          notes=['店や季節のテーマを表現', 'コーディネートを提案', '分類・整理して陳列'])
FIG['unei.vmd_tbl'] = grid(['要素', '主な場所', '役割'],
                           [['VP（ビジュアル・プレゼンテーション）', 'ショーウィンドウ、店の入口', '店や季節のテーマを表現する'],
                            ['PP（ポイント・オブ・セールス・プレゼンテーション）', '売場ごとの見せ場', '売りたい商品とコーディネートを提案する'],
                            ['IP（アイテム・プレゼンテーション）', '棚やハンガー', '個々の商品を分類・整理して、見やすく選びやすく陳列する']],
                           [130, 90, 140], align=['l', 'l', 'l'], title='VP・PP・IP', size=10)


def _golden():
    w, h = 360, 214
    o = []
    sx, sw_, top, tier = 150, 110, 14, 30
    o.append(R(sx - 12, 52, sw_ + 24, 70, fill='c', stroke=None, op=0.22))
    for k in range(7):
        y = top + k * tier
        o.append(L(sx, y, sx + sw_, y, col='main', sw=1.4))
    o.append(L(sx, top, sx, top + 6 * tier, col='main', sw=1.4))
    o.append(L(sx + sw_, top, sx + sw_, top + 6 * tier, col='main', sw=1.4))
    for k in range(6):
        for j in range(5):
            o.append(R(sx + 6 + j * 21, top + k * tier + 8, 16, tier - 8, fill='sub', stroke=None, op=0.3))
    px = 70
    o.append('<circle cx="%s" cy="38" r="12" style="fill:none;stroke:%s" stroke-width="1.6"/>' % (px, _c('main')))
    o.append('<path d="M%s 50L%s 128M%s 128L%s 194M%s 128L%s 194M%s 66L%s 102M%s 66L%s 100" style="stroke:%s" stroke-width="1.6" fill="none"/>' % (
        px, px, px, px - 14, px, px + 14, px, px - 18, px, px + 18, _c('main')))
    o.append(L(px + 14, 52, sx - 14, 52, col='a', sw=1, dash='3 3'))
    o.append(L(px + 14, 122, sx - 14, 122, col='a', sw=1, dash='3 3'))
    o.append(T(px - 8, 46, '目線', 'end', size=10, bold=True, col='a'))
    o.append(T(px - 8, 126, '腰', 'end', size=10, bold=True, col='a'))
    o.append(T(sx + sw_ + 16, 80, 'ゴールデン', size=11, bold=True, col='c'))
    o.append(T(sx + sw_ + 16, 95, 'ゾーン', size=11, bold=True, col='c'))
    o.append(T(sx + sw_ + 16, 112, '見やすく', size=9.5))
    o.append(T(sx + sw_ + 16, 125, '手に取りやすい', size=9.5))
    o.append(T(4, 210, '通路が広いと、ゴールデンゾーンは広がる', size=10, bold=True))
    return _svg(w, h, o, 'ゴールデンゾーン（模式図）')


FIG['unei.golden'] = _golden()


def _tatewari():
    w, h = 360, 168
    o = []
    cols = ['b', 'c', 'a']

    def shelf(ox, vertical, title, note):
        o.append(T(ox + 80, 14, title, 'middle', size=11, bold=True))
        for k in range(4):
            for j in range(6):
                col = cols[j // 2] if vertical else cols[min(k, 3) % 3] if k < 3 else 'sub'
                if not vertical:
                    col = ['b', 'c', 'a', 'sub'][k]
                o.append(R(ox + 8 + j * 25, 24 + k * 26, 22, 22, fill=col, stroke=col, op=0.3, sw=0.8))
        o.append(T(ox + 80, 140, note[0], 'middle', size=10))
        o.append(T(ox + 80, 156, note[1], 'middle', size=10))
    shelf(0, True, '縦割り陳列', ('同じ分類を上から下へ並べる', '顧客が商品を比べやすい'))
    shelf(184, False, '横割り陳列', ('同じ商品グループを', '同じ棚の段に横に並べる'))
    return _svg(w, h, o, '縦割り陳列と横割り陳列')


FIG['unei.tatewari'] = _tatewari()
FIG['unei.chinretsu'] = grid(['陳列の方法', '特徴'],
                             [['前進立体陳列', '商品を棚の前面にそろえ、立体的に積み上げて、豊富に見せる'], ['エンド陳列', '通路の端（ゴンドラのエンド）で、特売品や季節の商品を目立たせる'],
                              ['島陳列', '通路の中ほどに平台などを置いて陳列する'], ['ジャンブル陳列', 'かごなどに無造作に入れ、安さや気軽さを演出する（投げ込み陳列）'],
                              ['フック陳列', 'フックに掛ける。見やすく取りやすく、在庫の量も分かりやすい'], ['レジ前陳列', '会計を待つ客の非計画購買を誘う。低価格の小さな商品に向く'],
                              ['フェイスアウト', '衣料品をハンガーに掛け、正面を見せる（IPの手法）'], ['スリーブアウト', '袖（側面）を見せて、多くの量を掛ける']],
                             [100, 260], align=['l', 'l'], title='主な陳列の方法', size=10)
FIG['unei.face'] = chart([([(f / 4, 40 * (1 - math.exp(-0.45 * f / 4))) for f in range(4, 29)], 'b', False)],
                         0.5, 7.4, 0, 42, xlab='フェイス数', ylab='販売数量',
                         labels=[(2.2, 12, '1フェイス増やしたときの増加は、', 'start', 'main'), (2.2, 7, 'だんだん小さくなる', 'start', 'main')],
                         dots=[(f, 40 * (1 - math.exp(-0.45 * f)), 'b') for f in range(1, 8)], xticks=[(f, str(f)) for f in range(1, 8)], w=360, h=200,
                         title='フェイス効果（模式図）', zero=False)

# ------------------------------------------------ 2.2.4 価格設定


def _price_line():
    w, h = 360, 216
    x0, x1, yb = 30, 340, 150
    prices = [(980, 4), (1980, 9), (2980, 6), (3980, 3), (4980, 2)]
    X = lambda p: x0 + (p - 500) / 5000 * (x1 - x0)
    o = [L(x0, yb, x1, yb, col='main', sw=1.2)]
    for p, n in prices:
        col = 'a' if p == 1980 else 'b'
        o.append(R(X(p) - 16, yb - n * 10, 32, n * 10, fill=col, stroke=col, op=0.3, sw=1))
        o.append(T(X(p), yb + 14, '{:,}円'.format(p), 'middle', size=10))
    o.append(T(X(1980), yb - 112, 'プライスポイント', 'middle', size=10.5, bold=True, col='a'))
    o.append(T(X(1980), yb - 98, '（品目が最も多い中心の価格）', 'middle', size=9.5, col='a'))
    o.append(T(X(3980) - 12, yb - 70, 'プライスライン', size=10.5, bold=True, col='b'))
    o.append(T(X(3980) - 12, yb - 56, '（具体的な価格の段階）', size=9.5, col='b'))
    yb2 = yb + 28
    o.append(ARROW([(X(980), yb2), (X(4980), yb2)], col='c', sw=1.3, head=5))
    o.append(ARROW([(X(4980), yb2), (X(980), yb2)], col='c', sw=1.3, head=5))
    o.append(T((X(980) + X(4980)) / 2, yb2 + 18, 'プライスゾーン（最低価格から最高価格までの幅）', 'middle', size=10.5, bold=True, col='c'))
    o.append(T(x0, 14, '品目の数', size=10))
    return _svg(w, h, o, 'プライスライン・プライスゾーン・プライスポイント')


FIG['unei.price_line'] = _price_line()
FIG['unei.edlp'] = chart([([(0, 100), (2.6, 100), (2.6, 80), (3.4, 80), (3.4, 100), (6.6, 100), (6.6, 80), (7.4, 80), (7.4, 100), (10.6, 100), (10.6, 80), (11.4, 80),
                            (11.4, 100), (12, 100)], 'a', False), ([(0, 92), (12, 92)], 'b', False)],
                         0, 12.5, 70, 118, xlab='時間', ylab='価格',
                         labels=[(1.2, 114, '━ ハイ・ロー：通常の価格と特売の価格', 'start', 'a'), (1.2, 107.5, '━ EDLP：毎日安い価格を続ける', 'start', 'b')],
                         w=360, h=180, title='EDLPとハイ・ロー・プライシング（模式図）', zero=False)
FIG['unei.markup'] = grid(['商品', '売価×数量', '原価×数量', '値入額'],
                          [['A（売価1,000円・原価700円）', '1,000×10＝10,000', '700×10＝7,000', '3,000'], ['B（売価500円・原価300円）', '500×40＝20,000', '300×40＝12,000', '8,000'],
                           ['合計', '30,000', '19,000', '11,000']],
                          [120, 88, 88, 64], align=['l', 'r', 'r', 'r'], title='全体の値入率＝値入額の合計÷売価の合計', size=10, total_rows=(2,))
FIG['unei.nesage'] = waterfall([('原価', 700, 'start'), ('値入額（値入率30％）', 300, 'delta'), ('当初の売価', None, 'total'), ('値下げ（10％）', -100, 'delta'),
                                ('実際の売価', None, 'total')], title='値下げと粗利益（円）', lw=140)

# ------------------------------------------------ 2.2.5 販売促進
FIG['unei.hikeikaku'] = htree(('購買', 'sheet', [
    ('計画購買', 'b', [('来店の前に、買う商品を決めている', 'sheet', [])]),
    ('非計画購買\n（店内で\n決める）', 'c', [('想起購買：店頭で見て、必要だったことを思い出す', 'sheet', []), ('関連購買：一緒に使う商品を買う（酒とおつまみ）', 'sheet', []),
                              ('条件購買：値引きなどの条件にひかれる', 'sheet', []), ('衝動購買：新しさや珍しさに心を動かされる', 'sheet', [])])]),
    title='計画購買と非計画購買', colw=(44, 76, 216))
FIG['unei.ism'] = htree(('インストア・\nマーチャン\nダイジング', 'sheet', [
    ('スペース・\nマネジメント', 'b', [('売場の配置や棚割りで、商品を効果的に見せる', 'sheet', [])]),
    ('インストア・\nプロモーション', 'c', [('価格主導型：特売、値引き、クーポン、まとめ売り（バンドル）', 'sheet', []),
                                    ('非価格主導型：POP広告、試食・実演、関連陳列（クロス・マーチャンダイジング）、店内の演出', 'sheet', [])])]),
    title='インストア・マーチャンダイジング（ISM）', colw=(76, 90, 170))
FIG['unei.hansoku'] = grid(['手段', '主な目的・効果'],
                           [['チラシ', '特売などを伝えて来店を促す。計画購買につながる'], ['試食・デモンストレーション販売', '新しい商品の購買（トライアル）を促す'],
                            ['サンプリング', '試供品を配り、商品の魅力や機能を伝えて、試用を促す'], ['クーポン', '通常の価格は変えないので、内的参照価格を下げにくい'],
                            ['バンドル販売（まとめ売り）', '複数個を割安にして、買上点数を増やす'], ['大量陳列', '露出を高め、想起購買や衝動購買を促す'],
                            ['POP広告', '価値や使い方を伝え、買上率を高める']],
                           [130, 230], align=['l', 'l'], title='主な販売促進の手段', size=10)

# ------------------------------------------------ 2.3.1 商品在庫管理
FIG['unei.kosa'] = grid(['指標', '式', '例'],
                        [['商品回転率', '売上高÷平均在庫高（売価）', '1,000÷250＝4回'],
                         ['交差比率', '粗利益率×商品回転率（＝粗利益÷平均在庫高（売価））', '30％×4＝120％'],
                         ['GMROI', '粗利益÷平均在庫高（原価）', '300÷175≒171％']],
                        [80, 176, 104], align=['l', 'l', 'l'], title='在庫の効率の指標', size=10.5)
FIG['unei.teiki_ex'] = waterfall([('（発注間隔＋調達期間）の\n予測販売量 20×（7＋3）', 200, 'start'), ('安全在庫', 30, 'delta'), ('手持在庫', -80, 'delta'),
                                  ('発注残', -40, 'delta'), ('発注量', None, 'total')], title='定期発注の発注量（個）', lw=158)
FIG['unei.hatchu4'] = grid(['方式', '発注量', '発注の間隔'],
                           [['定量発注方式', '一定', '販売量によって変わる'], ['定期発注方式', '毎回変わる', '一定'],
                            ['発注点補充点方式', '補充点－有効在庫（変わる）', '販売量によって変わる'], ['ダブルビン方式', '1容器分（一定）', '販売量によって変わる']],
                           [110, 140, 110], align=['l', 'l', 'l'], title='発注方式と、発注量・間隔', size=10.5)
FIG['unei.yosoku'] = grid(['手法', '内容', '性質・注意点'],
                          [['移動平均法', '直近の一定期間の実績の平均を、予測値とする', '期間を短くするほど、直近の変化を強く反映する。新商品には使えない'],
                           ['指数平滑法', '次期の予測値＝当期の予測値＋平滑化係数×（当期の実績値－当期の予測値）', '係数を大きくするほど、直近の変化に速く反応する'],
                           ['重回帰分析', '販売量と、複数の要因（気温、価格など）の関係を式にする', '説明変数どうしの相関が強いと（多重共線性）、回帰係数を正しく推定できない']],
                          [76, 150, 134], align=['l', 'l', 'l'], title='需要の予測の手法', size=10)


def _hendo():
    w, h = 360, 170
    o = []
    panels = [('傾向変動', '長期の増減', lambda t: 0.2 + 0.6 * t),
              ('循環変動', '景気などによる数年単位の波', lambda t: 0.5 + 0.3 * math.sin(2 * math.pi * t * 1.2)),
              ('季節変動', '1年を周期とする波', lambda t: 0.5 + 0.3 * math.sin(2 * math.pi * t * 4)),
              ('不規則変動', '突発的な変動', None)]
    noise = [0.5, 0.48, 0.52, 0.5, 0.9, 0.5, 0.47, 0.53, 0.5, 0.12, 0.5, 0.52, 0.49, 0.5, 0.51, 0.5]
    for k, (nm, ds, f) in enumerate(panels):
        ox, oy = (k % 2) * 182, (k // 2) * 84
        o.append(R(ox + 2, oy + 2, 176, 78, fill='sheet', stroke='line', rx=6))
        o.append(T(ox + 10, oy + 18, nm, size=11, bold=True))
        o.append(T(ox + 10, oy + 33, ds, size=9.5))
        x0, x1, y0, y1 = ox + 12, ox + 168, oy + 74, oy + 40
        if f:
            pts = [(x0 + (x1 - x0) * i / 60, y0 - (y0 - y1) * f(i / 60)) for i in range(61)]
        else:
            pts = [(x0 + (x1 - x0) * i / (len(noise) - 1), y0 - (y0 - y1) * v) for i, v in enumerate(noise)]
        o.append('<path d="M%s" fill="none" style="stroke:%s" stroke-width="1.8"/>' % (' L'.join('%.1f %.1f' % p for p in pts), _c('b')))
    return _svg(w, h, o, '時系列の4つの変動')


FIG['unei.hendo'] = _hendo()

# ------------------------------------------------ 2.3.2 輸配送管理


def _pallet():
    w, h = 360, 196
    o = []
    x0, y0, s = 14, 14, 156
    o.append(R(x0, y0, s, s, fill='c', stroke='main', op=0.15, sw=1.6))
    cw, chh = s / 2, s / 3
    for i in range(2):
        for j in range(3):
            o.append(R(x0 + i * cw + 3, y0 + j * chh + 3, cw - 6, chh - 6, fill='b', stroke='b', op=0.25, sw=1))
            o.append(T(x0 + i * cw + cw / 2, y0 + j * chh + chh / 2 + 4, '550×366', 'middle', size=10, bold=True))
    o.append(T(x0 + s / 2, y0 + s + 18, '1,100mm', 'middle', size=10))
    tx = 186
    for i, (st, col, b) in enumerate([('T11型パレット', 'main', True), ('（1,100mm×1,100mm）', 'main', False), ('日本の標準のパレット', 'main', False),
                                      ('', 'main', False), ('包装モジュール', 'b', True), ('550mm×366mmなら', 'b', False), ('1段に6個（2列×3行）', 'b', True)]):
        if st:
            o.append(T(tx, 30 + i * 19, st, size=10.5, bold=b, col=col))
    return _svg(w, h, o, 'T11型パレットと包装モジュール')


FIG['unei.pallet'] = _pallet()
FIG['unei.yuso'] = grid(['輸送の手段', '特徴'],
                        [['トラック', '戸口から戸口へ運べ、柔軟'], ['鉄道', '大量の中長距離輸送に向く。トンキロ当たりのCO2の排出量は、営業用トラックの約10分の1'],
                         ['船舶', '大量、安価だが遅い'], ['航空', '速いが高価']],
                        [80, 280], align=['l', 'l'], title='輸送の手段', size=10.5)
FIG['unei.unso_kpi'] = grid(['指標', '式・意味', '上げる方法'],
                            [['積載率', '実際の積載量÷最大積載量', '複数の荷主の貨物の積合せ、貨物の集約'],
                             ['実車率', '実車で走った距離÷総走行距離', '帰り荷の確保、中継輸送'],
                             ['実働率', '稼働できる日数（時間）のうち、実際に稼働した割合', '宿泊を伴う長距離の運行を、中継輸送で日帰りにする']],
                            [60, 150, 150], align=['l', 'l', 'l'], title='輸送の効率を表す指標', size=10.5)


def _saving():
    w, h = 360, 190
    o = []

    def panel(ox, together):
        P, A, B = (ox + 86, 140), (ox + 36, 46), (ox + 140, 56)
        o.append(T(ox + 86, 14, '1回で回る：P→A→B→P' if together else '別々に往復', 'middle', size=11, bold=True, col='b' if together else 'a'))
        if together:
            o.append(ARROW([P, (A[0] + 4, A[1] + 9)], col='b', sw=1.6, head=6))
            o.append(ARROW([A, (B[0] - 9, B[1] - 1)], col='b', sw=1.6, head=6))
            o.append(ARROW([B, (P[0] + 6, P[1] - 9)], col='b', sw=1.6, head=6))
            o.append(T((A[0] + B[0]) / 2, (A[1] + B[1]) / 2 - 6, '4km', 'middle', size=10, bold=True))
        else:
            for Q in (A, B):
                o.append(L(P[0] - 3, P[1], Q[0] - 3, Q[1], col='a', sw=1.4))
                o.append(L(P[0] + 3, P[1], Q[0] + 3, Q[1], col='a', sw=1.4))
        o.append(T((P[0] + A[0]) / 2 - 12, (P[1] + A[1]) / 2, '10km', 'end', size=10, bold=True))
        o.append(T((P[0] + B[0]) / 2 + 12, (P[1] + B[1]) / 2 + 4, '8km', 'start', size=10, bold=True))
        for (x, y, s, col) in [(P[0], P[1], 'P', 'main'), (A[0], A[1], 'A', 'c'), (B[0], B[1], 'B', 'c')]:
            o.append('<circle cx="%s" cy="%s" r="10" style="fill:%s;stroke:%s" stroke-width="1.4"/>' % (x, y, _c('sheet'), _c(col)))
            o.append(T(x, y + 4, s, 'middle', size=11, bold=True))
        o.append(T(ox + 86, 170, '10＋4＋8＝22km' if together else '（10＋8）×2＝36km', 'middle', size=10.5, bold=True, col='b' if together else 'a'))
    panel(0, False)
    panel(180, True)
    o.append(T(180, 188, '節約量＝PA＋PB－AB＝10＋8－4＝14km', 'middle', size=11, bold=True))
    return _svg(w, h + 6, o, 'セービング法の節約量')


FIG['unei.saving'] = _saving()


def _hub():
    w, h = 360, 170
    o = []
    for (ox, hub, title) in [(0, False, 'ポイント・トゥ・ポイント'), (180, True, 'ハブ・アンド・スポーク')]:
        cx, cy, r = ox + 90, 92, 56
        pts = [(cx + r * math.cos(math.radians(-90 + 72 * k)), cy + r * math.sin(math.radians(-90 + 72 * k))) for k in range(5)]
        o.append(T(cx, 16, title, 'middle', size=11, bold=True))
        if hub:
            for p in pts:
                o.append(L(cx, cy, p[0], p[1], col='b', sw=1.6))
            o.append('<circle cx="%s" cy="%s" r="16" style="fill:%s"/>' % (cx, cy, _c('sheet')))
            o.append('<circle cx="%s" cy="%s" r="16" style="fill:%s;fill-opacity:0.35;stroke:%s" stroke-width="1.5"/>' % (cx, cy, _c('b'), _c('b')))
            o.append(T(cx, cy + 4, 'ハブ', 'middle', size=10, bold=True))
        else:
            for i in range(5):
                for j in range(i + 1, 5):
                    o.append(L(pts[i][0], pts[i][1], pts[j][0], pts[j][1], col='a', sw=1.1))
        for p in pts:
            o.append('<circle cx="%.1f" cy="%.1f" r="7" style="fill:%s;stroke:%s" stroke-width="1.3"/>' % (p[0], p[1], _c('sheet'), _c('main')))
        o.append(T(cx, 166, '中心の拠点に集めて仕分ける' if hub else '発地から着地へ直行する', 'middle', size=10))
    return _svg(w, h, o, 'ポイント・トゥ・ポイントとハブ・アンド・スポーク')


FIG['unei.hub'] = _hub()
FIG['unei.butsuryu_law'] = grid(['時期', '対象', '内容'],
                                [['2024年4月', 'トラック運転者', '時間外労働の上限（年960時間）が適用。輸送能力の不足が課題に（物流の2024年問題）'],
                                 ['2025年4月', 'すべての荷主と物流事業者', '積載効率の向上、荷待ち時間・荷役などの時間の短縮の努力義務（物流効率化法）'],
                                 ['2026年1月', '発荷主と運送事業者', '取適法の対象に特定運送委託が加わる。荷待ちや荷役を無償でさせることなどを禁止'],
                                 ['2026年4月', '特定事業者（取扱貨物が年9万トン以上の荷主、保管量が年70万トン以上の倉庫業者、保有車両が150台以上の運送事業者など）', '中長期計画の作成と定期報告を義務づけ。物流統括管理者（CLO）の選任の義務は、特定荷主と特定連鎖化事業者（フランチャイズチェーンの本部）だけ']],
                                [64, 110, 186], align=['l', 'l', 'l'], title='物流の人手不足への対応', size=10)

# ------------------------------------------------ 2.3.3 物流センター管理
FIG['unei.dctcpc'] = grid(['センター', '在庫', '主な機能'],
                          [['DC（在庫型）', '持つ', '店舗の注文に応じてピッキングして出荷する'], ['TC（通過型）', '持たない', '入荷した商品を、すぐに店舗別に仕分けて出荷する'],
                           ['PC（流通加工型）', '―', '生鮮食品のカットやパックなどの流通加工を行う']],
                          [104, 64, 192], align=['l', 'c', 'l'], title='物流センターの種類', size=10.5)
FIG['unei.tc2'] = grid(['通過型（TC）の方式', '店舗別の仕分け', 'センターの中の作業'],
                       [['事前仕分け型', '仕入先が店舗別に仕分けて納品', '少ない'], ['総量納品型', '総量で納品し、センターで仕分ける', '多い']],
                       [110, 170, 80], align=['l', 'l', 'c'], title='通過型センターの2つの方式', size=10.5)
FIG['unei.zaiko_tsuka'] = grid(['比べる点', '結果'],
                               [['店舗の発注から納品までのリードタイム', '在庫型の方が短くしやすい（在庫からすぐ出荷できる）'],
                                ['仕入先からセンターへの納品の頻度', '在庫型の方が少なくしやすい（まとめて仕入れて在庫できる）'],
                                ['一括物流（多くの仕入先の商品をまとめて店舗へ）', 'どちらでもできる'], ['低温の商品', 'どちらでも、温度の管理をすれば扱える']],
                               [150, 210], align=['l', 'l'], title='在庫型と通過型の比べ方', size=10.5)
FIG['unei.center_flow'] = flow(['入荷', '検品', '格納・保管', 'ピッキング', '流通加工', '仕分け', '検品', '出荷'], per_row=4, title='センターの中の作業の流れ', bh=36)


def _picking():
    w, h = 360, 220
    o = []
    o.append(T(88, 14, '摘み取り方式', 'middle', size=11, bold=True, col='b'))
    o.append(T(88, 28, '（シングル・ピッキング）', 'middle', size=9.5))
    for k in range(6):
        x, y = 10 + (k % 3) * 56, 40 + (k // 3) * 66
        o.append(R(x, y, 46, 28, fill='sub', stroke='main', op=0.2, sw=0.8))
        o.append(T(x + 23, y + 18, '商品%d' % (k + 1), 'middle', size=9.5))
    o.append(ARROW([(20, 90), (150, 90), (150, 76)], col='b', sw=2, head=6))
    o.append(T(88, 104, '店舗Aの注文の商品を集める', 'middle', size=9.5, bold=True, col='b'))
    o.append(T(88, 160, '注文（店舗）ごとに', 'middle', size=10))
    o.append(T(88, 175, '保管場所を回る（DPS）', 'middle', size=10))
    o.append(T(88, 200, '品目数＞オーダー数に向く', 'middle', size=10, bold=True, col='b'))
    o.append(L(180, 20, 180, 210, col='line', sw=0.8))
    o.append(T(272, 14, '種まき方式', 'middle', size=11, bold=True, col='c'))
    o.append(T(272, 28, '（トータル・ピッキング）', 'middle', size=9.5))
    o.append(R(246, 40, 52, 28, fill='sub', stroke='main', op=0.2, sw=0.8))
    o.append(T(272, 58, '商品X', 'middle', size=9.5))
    o.append(ARROW([(272, 70), (272, 92)], col='c', sw=2, head=6))
    o.append(T(282, 86, 'まとめて取り出す', size=9.5, col='c', bold=True))
    for k, s in enumerate(['店舗A', '店舗B', '店舗C']):
        x = 200 + k * 54
        o.append(ARROW([(272, 98), (x + 22, 118)], col='c', sw=1.3, head=5))
        o.append(R(x, 120, 44, 26, fill='c', stroke='c', op=0.25, sw=1))
        o.append(T(x + 22, 137, s, 'middle', size=9.5, bold=True))
    o.append(T(272, 160, '品目ごとにまとめて取り出し、', 'middle', size=10))
    o.append(T(272, 175, '後で店舗ごとに仕分ける（DAS）', 'middle', size=10))
    o.append(T(272, 200, '品目数＜オーダー数に向く', 'middle', size=10, bold=True, col='c'))
    return _svg(w, h, o, '摘み取り方式と種まき方式')


FIG['unei.picking'] = _picking()

# ------------------------------------------------ 2.4.1 店舗システム
FIG['unei.pos'] = grid(['ハード・メリット（機器による効果）', 'ソフト・メリット（データの活用による効果）'],
                       [['レジでの精算の迅速化', '単品ごとの売上の把握'], ['入力の誤りの防止', '売れ筋・死に筋の把握'], ['レジ業務の省力化', '発注や品揃え、棚割りへの活用'],
                        ['従業員の教育の簡素化', '販促の効果の検証']],
                       [170, 190], align=['l', 'l'], title='POSシステムのメリット', size=10.5)
FIG['unei.rfm'] = grid(['指標', '意味'],
                       [['R（Recency）', '最終購買日（最近買ったか）'], ['F（Frequency）', '購買頻度'], ['M（Monetary）', '購買金額']],
                       [120, 240], align=['l', 'l'], title='RFM分析', size=10.5)


def _venn():
    w, h = 360, 150
    o = [R(4, 4, 352, 126, fill='none', stroke='sub', rx=8)]
    o.append(T(12, 20, '取引1,000件', size=10.5, bold=True))
    o.append('<circle cx="140" cy="72" r="54" style="fill:%s;fill-opacity:0.22;stroke:%s" stroke-width="1.4"/>' % (_c('b'), _c('b')))
    o.append('<circle cx="202" cy="72" r="48" style="fill:%s;fill-opacity:0.22;stroke:%s" stroke-width="1.4"/>' % (_c('c'), _c('c')))
    o.append(T(118, 66, 'Aだけ', 'middle', size=10, bold=True, col='b'))
    o.append(T(118, 82, '300件', 'middle', size=10.5, bold=True))
    o.append(T(174, 66, '両方', 'middle', size=10, bold=True, col='a'))
    o.append(T(174, 82, '100件', 'middle', size=10.5, bold=True, col='a'))
    o.append(T(226, 66, 'Bだけ', 'middle', size=10, bold=True, col='c'))
    o.append(T(226, 82, '200件', 'middle', size=10.5, bold=True))
    o.append(T(300, 110, 'どちらもなし', 'middle', size=9.5))
    o.append(T(300, 124, '400件', 'middle', size=10, bold=True))
    o.append(T(4, 146, 'Aを含む取引400件、Bを含む取引300件、両方を含む取引100件', size=10))
    return _svg(w, h, o, 'バスケット分析の例')


FIG['unei.venn'] = _venn()
FIG['unei.basket'] = grid(['指標', '式', '例'],
                          [['支持度', 'AとBを両方含む取引÷全体の取引', '100÷1,000＝0.1'], ['信頼度', 'AとBを両方含む取引÷Aを含む取引', '100÷400＝0.25'],
                           ['リフト値', '信頼度÷（Bを含む取引÷全体の取引）', '0.25÷0.3≒0.83'],
                           ['ジャッカード係数', 'AとBを両方含む取引÷AとBの少なくとも一方を含む取引', '100÷（400＋300－100）≒0.17']],
                          [80, 170, 110], align=['l', 'l', 'l'], title='バスケット分析の指標', size=10)
FIG['unei.confusion'] = grid(['', '実際に反応した', '実際に反応しない', '計'],
                             [['「反応する」と予測', '20', '20', '40'], ['「反応しない」と予測', '10', '50', '60'], ['計', '30', '70', '100']],
                             [120, 84, 96, 60], align=['l', 'c', 'c', 'c'], title='予測と実際の結果（100人）', size=10.5, total_rows=(2,))
FIG['unei.shakudo'] = grid(['尺度', '例', '性質'],
                           [['名義尺度', '顧客ID、性別、会員の区分', '区別のための番号'], ['順序尺度', '順位、満足度の段階', '順序に意味がある'],
                            ['間隔尺度', '西暦の年、温度', '差に意味がある。0に絶対的な意味はない'], ['比例尺度', '年齢、購買金額、購買点数', '0に意味があり、比率を計算できる']],
                           [70, 140, 150], align=['l', 'l', 'l'], title='尺度水準', size=10.5)
FIG['unei.kakou'] = grid(['', '匿名加工情報', '仮名加工情報（2022年4月施行）'],
                         [['加工', '特定の個人を識別できず、元の個人情報に戻せないように加工', '他の情報と照合しない限り、特定の個人を識別できないように加工'],
                          ['第三者への提供', '一定のルールのもとで、本人の同意なしに提供できる', '原則としてできない（社内での分析に使う）']],
                         [76, 142, 142], align=['l', 'l', 'l'], title='匿名加工情報と仮名加工情報', size=10)
FIG['unei.qr'] = grid(['QRコード決済', 'しくみ', '店舗の読取りの機器'],
                      [['利用者提示型', '利用者のスマートフォンに表示したコードを、店舗が読み取る', '要る'],
                       ['店舗提示型', '店舗に掲示したコードを、利用者のアプリで読み取る', 'なくても導入できる']],
                      [86, 190, 84], align=['l', 'l', 'l'], title='QRコード決済の2つの方式', size=10.5)
FIG['unei.prepaid'] = grid(['前払式支払手段', '使える店', '手続き'],
                           [['自家型', '発行者の店舗だけ', '未使用の残高が一定額を超えると届出'], ['第三者型', '他の店舗でも使える', '登録']],
                           [100, 120, 140], align=['l', 'l', 'l'], title='前払式支払手段（資金決済法）', size=10.5)

# ------------------------------------------------ 2.4.2 取引情報システム


def _jan():
    w, h = 360, 132
    o = []
    bw = 24
    x0 = (w - 13 * bw) / 2
    digits = ['4', '9'] + [''] * 10 + ['']
    for k in range(13):
        col = 'b' if k < 9 else ('c' if k < 12 else 'a')
        o.append(R(x0 + k * bw, 44, bw - 2, 28, fill=col, stroke=col, op=0.25, sw=1))
        if digits[k]:
            o.append(T(x0 + k * bw + bw / 2 - 1, 63, digits[k], 'middle', size=12, bold=True))
    o.append(T(x0 + 12 * bw + bw / 2 - 1, 63, 'C', 'middle', size=11, bold=True, col='a'))

    def brace(i0, i1, s, col, up):
        xa, xb = x0 + i0 * bw, x0 + (i1 + 1) * bw - 2
        y = 38 if up else 78
        o.append('<path d="M%s %sv%sH%sv%s" fill="none" style="stroke:%s" stroke-width="1.2"/>' % (xa, y + (4 if up else -4), -4 if up else 4, xb, 4 if up else -4, _c(col)))
        o.append(T((xa + xb) / 2, y - 6 if up else y + 16, s, 'middle', size=10, bold=True, col=col))
    brace(0, 8, 'GS1事業者コード（先頭は45か49）', 'b', True)
    brace(9, 11, '商品アイテムコード', 'c', False)
    xa, xb = x0 + 12 * bw, x0 + 13 * bw - 2
    o.append('<path d="M%s 42v-4H%sv4" fill="none" style="stroke:%s" stroke-width="1.2"/>' % (xa, xb, _c('a')))
    o.append(T(xb, 32, 'チェックデジット', 'end', size=10, bold=True, col='a'))
    o.append(T(4, 116, '例：GS1事業者コードが9桁なら、商品アイテムコードは3桁', size=10))
    o.append(T(4, 130, '短縮タイプ（GTIN-8）は8桁で、小さな商品に使う', size=10))
    return _svg(w, h, o, 'JANコード（標準タイプ13桁）の構成')


FIG['unei.jan'] = _jan()
FIG['unei.gtin'] = grid(['GTIN', '主な使い方'],
                        [['GTIN-13', 'JANコードの標準タイプ（13桁）'], ['GTIN-8', 'JANコードの短縮タイプ（8桁）。小さな商品'], ['GTIN-12', 'UPCコード（米国とカナダ）'],
                         ['GTIN-14', '集合包装用商品コード（ケースやボール）。ITFシンボルで表す']],
                        [90, 270], align=['l', 'l'], title='GTINの4種類', size=10.5)


def _gtin14():
    w, h = 360, 150
    o = []
    bw = 19
    x14 = 80
    x13 = x14 + bw
    o.append(T(4, 41, 'GTIN-13', size=10.5, bold=True))
    for k in range(13):
        col = 'a' if k == 12 else 'sub'
        o.append(R(x13 + k * bw, 24, bw - 2, 22, fill=col, stroke=col if col != 'sub' else 'main', op=0.25, sw=0.8))
    o.append(T(x13 + 12 * bw + bw / 2 - 1, 39, 'C', 'middle', size=10, bold=True, col='a'))
    o.append(T(4, 111, 'GTIN-14', size=10.5, bold=True))
    for k in range(14):
        col = 'b' if k == 0 else ('a' if k == 13 else 'sub')
        o.append(R(x14 + k * bw, 94, bw - 2, 22, fill=col, stroke=col if col != 'sub' else 'main', op=0.25, sw=0.8))
    o.append(T(x14 + bw / 2 - 1, 109, 'I', 'middle', size=10, bold=True, col='b'))
    o.append(T(x14 + 13 * bw + bw / 2 - 1, 109, 'C', 'middle', size=10, bold=True, col='a'))
    o.append(ARROW([(x13 + 6 * bw + 8, 50), (x13 + 6 * bw + 8, 90)], col='main', sw=1.2, head=5))
    o.append(T(x13 + 6 * bw + 16, 74, '12桁をそのまま使う', size=9.5))
    o.append(T(4, 134, 'I：インジケータ（1〜8）。入数などの荷姿の違いを表す', size=9.5, col='b', bold=True))
    o.append(T(4, 148, 'C：チェックデジットは計算し直す（最後の1桁も変わる）', size=9.5, col='a', bold=True))
    return _svg(w, h, o, 'GTIN-14（集合包装用商品コード）の作り方')


FIG['unei.gtin14'] = _gtin14()
FIG['unei.gtin_new'] = grid(['新しいGTINが要る10の基準'],
                            [['①新しい商品を発売した'], ['②成分や機能を変え、商品の表示を変えた（アレルゲンの追加など）'], ['③正味内容量を変え、表示を変えた'],
                             ['④包装の外寸または総重量が、20％を超えて変わった'], ['⑤認証マーク（有機の認証など）を追加、または削除した'], ['⑥ブランドを変えた'],
                             ['⑦販促のために期間限定で包装を変えた、または景品・試供品を付けた（単品のGTINは変えず、集合包装のGTINだけ新しくする）'], ['⑧集合包装の入数を変えた（集合包装用商品コードだけ変える）'],
                             ['⑨組合せ商品の中身を変えた'], ['⑩商品に直接表示した価格を変えた']],
                            [360], align=['l'], title='GTIN設定ガイドライン', size=10)
FIG['unei.ai'] = grid(['AI', 'データの種類'],
                      [['（01）', 'GTIN（14桁。GTIN-13は先頭に0を足す）'], ['（10）', 'ロット番号（長さが決まっていない）'], ['（11）', '製造日'], ['（15）', '賞味期限'],
                       ['（17）', '有効期限']],
                      [70, 290], align=['c', 'l'], title='GS1-128のアプリケーション識別子（AI）の例', size=10.5)
FIG['unei.marking'] = grid(['', 'ソースマーキング', 'インストアマーキング'],
                           [['付ける人', '製造業者など（製造や出荷の段階で印刷）', '小売業者（店内でラベルを付ける）'],
                            ['コード', 'GS1事業者コードを使うJANコード', 'インストアコード（先頭2桁が20〜29など）。店内だけで使う'],
                            ['主な対象', '一般の商品', '生鮮食品など']],
                           [70, 140, 150], align=['l', 'l', 'l'], title='ソースマーキングとインストアマーキング', size=10.5)
FIG['unei.plu'] = grid(['方式', 'バーコードに入れる情報', '価格'],
                       [['PLU', '商品のコードだけ', 'POSのシステムの商品マスタから読み出す'], ['NonPLU', '価格の情報も入れる', 'バーコードから読む（生鮮食品のインストアマーキングなど）']],
                       [70, 120, 170], align=['l', 'l', 'l'], title='PLUとNonPLU', size=10.5)
FIG['unei.edi'] = grid(['方式', 'しくみ', '問題'],
                       [['個別EDI', '発注者と受注者が1対1でつなぐ', '受注者は取引先ごとに専用の端末が要る（多端末）'],
                        ['Web-EDI', '発注者のウェブサイトに、受注者がブラウザで接続する', '発注者ごとに画面や操作、データの形式が違う（多画面）'],
                        ['標準のEDI', '流通BMS、中小企業共通EDIなどの標準の形式でデータを交換', 'これらの問題を減らせる']],
                       [70, 150, 140], align=['l', 'l', 'l'], title='受発注のEDIの方式', size=10)

# ------------------------------------------------ 2.4.3 物流情報システム
FIG['unei.code3'] = grid(['', 'バーコード', '2次元コード', 'RFID（電子タグ）'],
                         [['情報量', '少ない', '多い', '多い。書き換えられるものもある'], ['読み取り', '1つずつ', '1つずつ。一部が欠けても読める（誤り訂正）', '電波で、離れた場所から、箱の中も、複数を一括で'],
                          ['費用', '安い', '安い（印刷する）', '高い'], ['注意点', '―', '―', '金属や水分の多い環境では読みにくいことがある']],
                         [60, 76, 112, 112], align=['l', 'l', 'l', 'l'], title='バーコード・2次元コード・RFID', size=10)


def _trace():
    w, h = 360, 150
    o = []
    names = ['生産', '加工', '卸', '小売', '消費者']
    bw, gap = 58, 12
    x0 = (w - 5 * bw - 4 * gap) / 2
    for k, s in enumerate(names):
        x = x0 + k * (bw + gap)
        o.append(R(x, 56, bw, 30, fill='sheet', stroke='main', rx=6, sw=1.2))
        o.append(T(x + bw / 2, 76, s, 'middle', size=11, bold=True))
    o.append(ARROW([(x0, 42), (w - x0, 42)], col='b', sw=2, head=7))
    o.append(T(x0, 16, 'トレースフォワード（追跡）：製品がどこへ流れたか', size=10.5, bold=True, col='b'))
    o.append(T(x0, 31, '→ 問題が起きたときの回収に使う', size=9.5, col='b'))
    o.append(ARROW([(w - x0, 100), (x0, 100)], col='c', sw=2, head=7))
    o.append(T(x0, 120, 'トレースバック（遡及）：原材料や生産の段階へさかのぼる', size=10.5, bold=True, col='c'))
    o.append(T(x0, 136, '→ 原因の究明に使う', size=9.5, col='c'))
    return _svg(w, h, o, 'トレースフォワードとトレースバック')


FIG['unei.trace'] = _trace()

# ------------------------------------------------ 2.5.1 その他
FIG['unei.haccp12'] = grid(['手順', '内容'],
                           [['手順1', 'HACCPチームの編成'], ['手順2', '製品説明書の作成'], ['手順3', '意図する用途と対象者の確認'], ['手順4', '製造工程一覧図の作成'],
                            ['手順5', '製造工程一覧図の現場での確認'], ['手順6（原則①）', '危害要因の分析'], ['手順7（原則②）', '重要管理点（CCP）の決定'],
                            ['手順8（原則③）', '管理基準（CL）の設定'], ['手順9（原則④）', 'モニタリング方法の設定'], ['手順10（原則⑤）', '改善措置の設定'],
                            ['手順11（原則⑥）', '検証方法の設定'], ['手順12（原則⑦）', '記録と保存方法の設定']],
                           [120, 240], align=['l', 'l'], title='HACCPの12手順と7原則', size=10.5, hl_rows=(5, 6, 7, 8, 9, 10, 11))
FIG['unei.food_rec'] = flow(['①発生の抑制', '②再生利用\n（飼料化を最も優先）', '③熱回収\n（再生利用ができない場合）', '④減量'], per_row=2,
                            title='食品リサイクル法の取組みの優先順位', bh=46)
FIG['unei.food_rate'] = barchart([95, 75, 65, 50], ['食品製造業', '食品卸売業', '食品小売業', '外食産業'], title='再生利用等実施率の目標（2029年度まで）',
                                 colors=['b', 'b', 'c', 'a'], ylab='％', ymax=100, h=180, vfmt=lambda v: '%d％' % v)
FIG['unei.taxfree'] = flow(['①購入\n消費税を含めた価格で買う', '②出国\n購入から90日以内。税関で持ち出しを確認', '③返金\n店舗が消費税に相当する額を返す'], per_row=3,
                           title='免税店のリファンド方式（2026年11月1日から）', bh=62)
FIG['unei.taxfree_tbl'] = grid(['', 'それまでの方式', 'リファンド方式'],
                               [['消費税', '販売の時点で免除', 'いったん払い、持ち出しの確認の後に返金'],
                                ['一般物品と消耗品の区分', 'あり（消耗品は特殊な包装をして、30日以内に持ち出す）', 'なし'],
                                ['消耗品の購入の上限（50万円）', 'あり', '廃止'], ['購入額の下限（税抜5,000円以上）', 'あり', '残る']],
                               [120, 130, 110], align=['l', 'l', 'l'], title='免税制度の変更点', size=10)


def _funnel():
    w, h = 360, 176
    o = []
    stages = [('表示回数', 300, 'sub'), ('クリック数', 210, 'c'), ('成果（購入など）', 120, 'b')]
    for k, (s, bw, col) in enumerate(stages):
        y = 8 + k * 50
        x = 110 - bw / 2 + 60
        o.append(R(x, y, bw, 34, fill=col, stroke=col if col != 'sub' else 'main', op=0.25, rx=6, sw=1))
        o.append(T(170, y + 22, s, 'middle', size=11, bold=True))
    o.append(T(278, 52, 'CTR＝クリック数', 'start', size=10, bold=True, col='c'))
    o.append(T(300, 66, '÷表示回数', 'start', size=10, bold=True, col='c'))
    o.append(T(244, 102, 'CVR＝成果の数', 'start', size=10, bold=True, col='b'))
    o.append(T(266, 116, '÷クリック数', 'start', size=10, bold=True, col='b'))
    o.append(T(4, 172, 'ROAS（広告費用対効果）＝広告経由の売上÷広告費', size=10.5, bold=True))
    return _svg(w, h, o, 'ネット広告の指標')


FIG['unei.funnel'] = _funnel()


def _opendata():
    w, h = 360, 150
    o = []
    steps = [('PDF・画像（JPG）', 30, 'sub'), ('表計算・文書\n（xls、doc）', 60, 'c'), ('CSV・XML', 90, 'b')]
    for k, (s, hh, col) in enumerate(steps):
        x = 14 + k * 112
        o.append(R(x, 116 - hh, 100, hh, fill=col, stroke=col if col != 'sub' else 'main', op=0.28, sw=1))
        ls = s.split('\n')
        for j, ln in enumerate(ls):
            o.append(T(x + 50, 116 - hh - 6 - (len(ls) - 1 - j) * 13, ln, 'middle', size=10, bold=True))
    o.append(ARROW([(14, 132), (346, 132)], col='b', sw=1.4, head=6))
    o.append(T(346, 148, '機械で読み取りやすい＝開放性が高い', 'end', size=10.5, bold=True, col='b'))
    return _svg(w, h + 4, o, 'オープンデータの形式と開放性')


FIG['unei.opendata'] = _opendata()
