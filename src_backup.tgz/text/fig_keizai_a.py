# 経済学・経済政策の図表（1.1 国民経済計算と主要経済指標、1.4 主要な経済学派）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, flow, chart, htree, quad, timeline, pyramid, barchart, waterfall, decomp, dtree, ARROW, R, T, L, _svg, _c, wrap, tw)
from kit import (_lines, _dashrect, _box, _lists, _flow, _rowflow, _bands, _hub, _nest, _ladder)
from ekit import G, panels, payoff, txt, hbars, stackbar, eq

FIG = {}


def _br(o, x1, x2, y, label, col='main', up=True, size=10.5):
    """横向きの括弧と見出し（up=True なら上向き）"""
    d = 6 if up else -6
    o.append('<path d="M%s %sV%sH%sV%s" fill="none" style="stroke:%s" stroke-width="1.3"/>' % (round(x1, 1), y + d, y, round(x2, 1), y + d, _c(col)))
    o.append(T((x1 + x2) / 2, y - 5 if up else y + 15, label, 'middle', col=col, bold=True, size=size))


# ------------------------------------------------ 1.1.1 国民経済計算の概念


def _gdp_va():
    w, h = 360, 248
    base, k, bw = 196, 150 / 250.0, 60
    xs = [8, 92, 176, 290]
    st = [('小麦農家', '小麦', 0, 100, 'b'), ('製粉業者', '小麦粉', 100, 50, 'c'), ('パン屋', 'パン', 150, 100, 'a')]
    o = [L(0, base, w, base, col='main', sw=1.2)]
    for (nm, prod, mid, va, col), x in zip(st, xs):
        tot = mid + va
        if mid:
            o.append(R(x, base - mid * k, bw, mid * k, fill='sub', stroke='line', op=0.2))
            o.append(T(x + bw / 2, base - mid * k / 2 - 2, '中間投入', 'middle', size=10))
            o.append(T(x + bw / 2, base - mid * k / 2 + 12, str(mid), 'middle', size=10.5, bold=True))
        yv = base - tot * k
        o.append(R(x, yv, bw, va * k, fill=col, stroke=col, op=0.3))
        o.append(T(x + bw / 2, yv + va * k / 2 - 1, '付加価値', 'middle', size=10, col=col, bold=True))
        o.append(T(x + bw / 2, yv + va * k / 2 + 12, str(va), 'middle', size=10.5, bold=True, col=col))
        o.append(T(x + bw / 2, yv - 6, '%s %d' % (prod, tot), 'middle', size=10.5, bold=True))
        o.append(T(x + bw / 2, base + 16, nm, 'middle', size=10.5, bold=True))
    for i in range(2):
        y = base - (st[i][2] + st[i][3]) * k
        o.append(L(xs[i] + bw, y, xs[i + 1], y, dash='3 3', col='main', sw=0.9))
    x, yy = xs[3], base
    for (nm, prod, mid, va, col) in st:
        o.append(R(x, yy - va * k, bw, va * k, fill=col, stroke=col, op=0.3))
        o.append(T(x + bw / 2, yy - va * k / 2 + 4, '%d' % va, 'middle', size=10.5, bold=True, col=col))
        yy -= va * k
    o.append(T(x + bw / 2, yy - 6, 'GDP 250', 'middle', size=11, bold=True))
    o.append(T(x + bw / 2, base + 16, '付加価値の合計', 'middle', size=10, bold=True))
    o.append(L(xs[2] + bw, yy, x, yy, dash='3 3', col='main', sw=0.9))
    o.append(T((xs[2] + bw + x) / 2, yy - 4, '＝', 'middle', size=15, bold=True))
    o.append(T(4, base + 38, '点線：前の段階の生産物が、次の段階の中間投入になる', size=10.5))
    return _svg(w, h, o, '付加価値の合計とGDP')


FIG['keizai.gdp_va'] = _gdp_va()

FIG['keizai.gdp_in'] = _lists([('GDPに含まれる', 'b', ['持ち家の住宅サービス（帰属家賃）', '農家の自家消費', '政府の公共サービス（費用で評価）', '中古品・株式の売買の仲介手数料',
                                                 '新築の住宅の購入（民間住宅＝投資）', '企業が払う利子・配当（付加価値の分配）']),
                               ('GDPに含まれない', 'a', ['家事労働、ボランティア', '中古品そのものの売買', '株式や土地の売買（所有権の移転）', '年金などの移転支出',
                                                    'キャピタル・ゲイン（値上がり益）'])],
                              'GDPに含まれるもの・含まれないもの')


def _three():
    w, h = 360, 262
    top, H, cw, gap = 34, 176, 98, 33
    xs = [4, 4 + cw + gap, 4 + 2 * (cw + gap)]
    cols = [('生産面', [('各産業の\n付加価値\n（生産額－\n中間投入）', 100, 'c')], '付加価値の合計'),
            ('分配面', [('雇用者報酬', 48, 'b'), ('営業余剰・\n混合所得', 18, 'b'), ('固定資本減耗', 21, 'sub'), ('生産・輸入品に\n課される税－補助金', 13, 'sub')], '所得として分配'),
            ('支出面', [('民間最終\n消費支出', 53, 'a'), ('投資\n（総資本形成）', 27, 'a'), ('政府最終\n消費支出', 20, 'a')], '最終生産物への支出')]
    o = []
    for (hd, segs, ft), x in zip(cols, xs):
        o.append(T(x + cw / 2, top - 10, hd, 'middle', bold=True, size=12))
        y = top + H
        for s, v, col in segs:
            hh = H * v / 100.0
            o.append(R(x, y - hh, cw, hh, fill=col, stroke=col if col != 'sub' else 'main', op=0.28 if col != 'sub' else 0.14, sw=1))
            ls = s.split('\n')
            sz = 9.5 if hh < 30 else 10.5
            for j, ln in enumerate(ls):
                o.append(T(x + cw / 2, y - hh / 2 + sz * 0.36 + (j - (len(ls) - 1) / 2) * (sz + 2.5), ln, 'middle', size=sz, bold=(j == 0)))
            y -= hh
        o.append(T(x + cw / 2, top + H + 16, ft, 'middle', size=10.5, bold=True))
    for i in range(2):
        o.append(T(xs[i] + cw + gap / 2, top + H / 2 + 6, '＝', 'middle', size=18, bold=True))
    o.append(T(4, top + H + 38, '支出面の投資は在庫変動を含む。純輸出（輸出－輸入）は小さいので省いた', size=10))
    return _svg(w, h, o, '三面等価の原則（大きさはイメージ）')


FIG['keizai.gdp_3face'] = _three()

FIG['keizai.gdp_gni'] = waterfall([('国内総生産（GDP）', 100, 'start'), ('＋海外からの所得', 8, 'delta'), ('－海外への所得', -3, 'delta'),
                                   ('国民総所得（GNI）', None, 'total'), ('－固定資本減耗', -21, 'delta'), ('国民純所得（NNI）\n市場価格表示の国民所得', None, 'total'),
                                   ('－（生産・輸入品に課される税－補助金）', -9, 'delta'), ('国民所得（要素費用表示）', None, 'total')],
                                  'GDPから国民所得まで（棒の長さはイメージ）', lw=160, vw=20, fmt=lambda v: '')

FIG['keizai.gdp_nomreal'] = grid(['', '名目成長率', '≒ 実質成長率', '＋ デフレーターの変化率'],
                                 [['物価が上がる', '＋3％', '＋1％', '約＋2％（上昇）'], ['名実逆転', '＋0.5％', '＋1.5％', '約－1％（下落）']],
                                 [84, 76, 84, 116], align=['l', 'c', 'c', 'c'], title='名目と実質の成長率', size=11.5, tcol={'約＋2％（上昇）': 'b', '約－1％（下落）': 'a'})

# ------------------------------------------------ 1.1.2 国民所得統計
FIG['keizai.gdp_share'] = hbars([('民間最終消費支出', 53, 'a'), ('政府最終消費支出', 20, 'c'), ('民間企業設備', 19, 'b'), ('公的固定資本形成', 5, 'c'),
                                 ('民間住宅', 4, 'b')], '名目GDPの構成比（2024年度）', lw=124, fmt=lambda v: '%d％' % v,
                                note='輸出と輸入は、それぞれGDPの2割強（純輸出はほぼゼロ）')

FIG['keizai.gdp_tree'] = htree(('GDP\n（支出側）', 'main', [
    ('国内需要\n（内需）', 'a', [('民間需要', 'a', [('民間最終消費支出', None, []), ('民間住宅 ★', 'c', []), ('民間企業設備 ★', 'c', []), ('民間在庫変動', None, [])]),
                         ('公的需要', 'a', [('政府最終消費支出', None, []), ('公的固定資本形成 ★', 'c', []), ('公的在庫変動', None, [])])]),
    ('外需\n（純輸出）', 'b', [('輸出', 'b', []), ('輸入（差し引く）', 'b', [])])]),
    '支出面のGDPの分類（★＝総固定資本形成）', colw=(64, 66, 76, 116), gapx=10)

FIG['keizai.gdp_dist'] = grid(['分配面の項目', '中身'],
                              [['雇用者報酬', '雇われて働く人の賃金・俸給（アルバイトを含む）と、社会保険料の雇主の負担'],
                               ['営業余剰・混合所得', '生産から生まれた利益。混合所得は自営業の所得（労働の対価と利益が分けられない）。持ち家の帰属家賃は営業余剰'],
                               ['固定資本減耗', '設備や建物の価値の減少（減価償却にあたる）'],
                               ['生産・輸入品に課される税－補助金', '消費税などの税から、補助金を差し引いたもの']],
                              [112, 248], align=['l', 'l'], title='分配面のGDP', size=11)


def _laborshare():
    g = G(xmax=10, ymax=10, h=200, xlab='時間', ylab='大きさ', origin='', pl=16)
    wave = lambda x, a, s: 5 + a * math.sin(2 * math.pi * (x - s) / 8)
    g.rect(0.0, 0, 4.0, 10, col='b', op=0.08).rect(4.0, 0, 8.0, 10, col='a', op=0.07)
    g.text(2.0, 9.3, '好況', 'middle', 'b', True).text(6.0, 9.3, '不況', 'middle', 'a', True)
    g.fn(lambda x: wave(x, 3.2, 0), 0, 10, 'b', label='企業の利益', at=(9.0, wave(9.0, 3.2, 0) + 1.3), anchor='middle')
    g.fn(lambda x: wave(x, -1.4, 0) - 0.6, 0, 10, 'a', label='労働分配率', at=(9.1, wave(9.1, -1.4, 0) - 2.1), anchor='middle')
    g.text(5.0, 0.8, '賃金は利益より変動が小さいので、労働分配率は利益と逆に動く', 'middle', size=10.5)
    return g.svg('労働分配率と景気（イメージ）')


FIG['keizai.laborshare'] = _laborshare()

FIG['keizai.contrib'] = hbars([('民間最終消費支出（＋5兆円）', 1.0, 'b'), ('民間企業設備（＋3兆円）', 0.6, 'b'), ('純輸出（－1兆円）', -0.2, 'a'),
                               ('GDP（＋7兆円）の成長率', 1.4, 'main')], '寄与度（前期のGDPが500兆円の例）', lw=170, lo=-0.4, hi=1.6,
                              fmt=lambda v: '＋1.4％' if v == 1.4 else (('＋%.1f' % v if v > 0 else '－%.1f' % -v) + 'ポイント'), vw=90,
                              note='寄与度＝項目の増減÷前期の全体×100。寄与度の合計（1.0＋0.6－0.2）が成長率1.4％になる')

FIG['keizai.qe'] = _rowflow([('QE', 'c', ['1次速報', '2次速報\n法人企業統計などを反映', '年次推計で改定'])],
                            '四半期別GDP速報（内閣府）の改定', lw=40, size=10.5)


def _io():
    w = 360
    cw = [76, 56, 56, 84, 86]
    xs = [2]
    for c in cw:
        xs.append(xs[-1] + c)
    rh, hh = 30, 44
    hd = ['', '農業', '工業', '最終需要\n（消費・投資・輸出）', '国内\n生産額']
    rows = [['農業', '10', '40', '50', '100'], ['工業', '20', '60', '120', '200'], ['付加価値', '70', '100', '', ''], ['国内生産額', '100', '200', '', '']]
    o = []
    top = 20
    o.append(T((xs[1] + xs[3]) / 2, top - 6, '中間需要（買い手）', 'middle', size=10.5, bold=True))
    # 農業の行（横）と列（縦）を色で示す
    o.append(R(xs[0], top + hh, xs[5] - xs[0], rh, fill='b', stroke=None, op=0.16))
    o.append(R(xs[1], top, cw[1], hh + rh * 4, fill='c', stroke=None, op=0.18))
    for j, s in enumerate(hd):
        ls = s.split('\n')
        for k, ln in enumerate(ls):
            o.append(T((xs[j] + xs[j + 1]) / 2, top + hh / 2 + 4 + (k - (len(ls) - 1) / 2) * 13, ln, 'middle', size=10.5 if k else 11, bold=(k == 0)))
    for i, r in enumerate(rows):
        y = top + hh + i * rh
        for j, s in enumerate(r):
            if s:
                o.append(T((xs[j] + xs[j + 1]) / 2 if j else xs[0] + 6, y + rh / 2 + 4, s, 'middle' if j else 'start', size=11.5, bold=(j == 0 or i == 3 or j == 4)))
        o.append(L(xs[0], y, xs[5], y, sw=0.6 if i else 1.2, col='line' if i else 'main'))
    yb = top + hh + 4 * rh
    o.append(L(xs[0], yb, xs[5], yb, col='main', sw=1.2))
    o.append(L(xs[0], top + hh + 2 * rh, xs[5], top + hh + 2 * rh, col='main', sw=1.2))
    for x in xs[1:-1]:
        o.append(L(x, top, x, yb, sw=0.6))
    o.append(R(xs[0], top, xs[5] - xs[0], yb - top, fill='none', stroke='main', sw=1.2))
    o.append(T(xs[0] + 4, top + hh / 2 + 4, '売り手＼買い手', size=9.5, bold=True))
    y = yb + 18
    o.append(T(4, y, '横（行）：農業の生産物の行き先 10＋40＋50＝100', size=11, bold=True, col='b'))
    o.append(T(4, y + 18, '縦（列）：農業の生産額の内訳 10＋20＋70＝100', size=11, bold=True, col='c'))
    o.append(T(4, y + 36, '付加価値の合計170＝最終需要の合計170（輸入は0とした）', size=11))
    return _svg(w, y + 44, o, '産業連関表のしくみ（数値例）')


FIG['keizai.io'] = _io()

# ------------------------------------------------ 1.1.3 雇用統計


def _laborbox():
    w = 360
    x0, x1, y, bh = 4, 356, 40, 66
    segs = [('就業者', '従業者＋休業者', 0.46, 'b'), ('完全\n失業者', '', 0.15, 'a'), ('非労働力人口', '通学のみの学生\n専業主婦（夫）\n高齢者など', 0.39, 'sub')]
    o = []
    x = x0
    pos = []
    for nm, sub, r, col in segs:
        ww = (x1 - x0) * r
        o.append(R(x, y, ww, bh, fill=col, stroke=col if col != 'sub' else 'main', op=0.28 if col != 'sub' else 0.12))
        ls = nm.split('\n') + (sub.split('\n') if sub else [])
        nn = len(nm.split('\n'))
        for j, ln in enumerate(ls):
            o.append(T(x + ww / 2, y + bh / 2 + 4 + (j - (len(ls) - 1) / 2) * 13, ln, 'middle', size=11 if j < nn else 9.5, bold=(j < nn),
                       col=col if (j < nn and col != 'sub') else 'main'))
        pos.append((x, x + ww))
        x += ww
    _br(o, pos[0][0] + 1, pos[1][1] - 1, y - 8, '労働力人口', col='main')
    _br(o, x0 + 1, x1 - 1, y + bh + 8, '15歳以上人口', col='main', up=False)
    yy = y + bh + 46
    o.append(T(4, yy, '完全失業率＝完全失業者÷労働力人口×100', size=11.5, bold=True, col='a'))
    o.append(T(4, yy + 20, '労働力率＝労働力人口÷15歳以上人口×100', size=11.5, bold=True))
    o.append(T(4, yy + 40, '就業者：月末の1週間に収入を伴う仕事を1時間以上した人と休業者', size=10.5))
    return _svg(w, yy + 48, o, '15歳以上人口の区分（幅はイメージ）')


FIG['keizai.laborbox'] = _laborbox()


def _discourage():
    w = 360
    o = []
    bw, bh, y = 104, 58, 36
    xs = [4, 128, 252]
    data = [('就業者', '570', '570', 'b'), ('完全失業者', '30', '20', 'a'), ('非労働力人口', '400', '410', 'sub')]
    for (nm, a, b, col), x in zip(data, xs):
        o.append(R(x, y, bw, bh, fill=col, stroke=col if col != 'sub' else 'main', op=0.24 if col != 'sub' else 0.12, rx=6))
        o.append(T(x + bw / 2, y + 20, nm, 'middle', bold=True, size=11, col=col if col != 'sub' else 'main'))
        o.append(T(x + bw / 2, y + 42, a if a == b else '%s → %s' % (a, b), 'middle', bold=True, size=13))
    o.append(ARROW([(xs[1] + bw / 2, y - 2), (xs[1] + bw / 2, 14), (xs[2] + bw / 2, 14), (xs[2] + bw / 2, y - 2)], col='a', sw=1.6, head=6))
    o.append(T((xs[1] + xs[2] + bw) / 2, 10, '求職をあきらめた10人', 'middle', col='a', bold=True, size=11))
    g = [('前', '30÷（570＋30）＝5.0％'), ('後', '20÷（570＋20）≒3.4％')]
    yy = y + bh + 26
    o.append(T(4, yy, '完全失業率', size=11.5, bold=True))
    for i, (s, v) in enumerate(g):
        o.append(T(84, yy + i * 20, '%s：%s' % (s, v), size=11.5, bold=(i == 1), col='a' if i == 1 else 'main'))
    o.append(T(4, yy + 46, '雇用は増えていないのに、失業率は下がる', size=11, bold=True))
    return _svg(w, yy + 54, o, '求職をあきらめた人と完全失業率（数値例）')


FIG['keizai.discourage'] = _discourage()

FIG['keizai.jobsratio'] = hbars([('有効求人数', 122, 'b'), ('有効求職者数', 100, 'a')], '有効求人倍率1.22倍（2025年平均）の意味', lw=96, lo=0, hi=130,
                                fmt=lambda v: '%d' % v, note='求職者100人に対して、求人が122件ある。1を超えると、求人が求職者より多い')

FIG['keizai.laborstat'] = grid(['統計（作成）', '主な指標', '景気動向指数での位置'],
                               [['労働力調査（総務省）', '完全失業率、就業者、労働力人口', '完全失業率＝遅行（逆サイクル）'],
                                ['職業安定業務統計（厚生労働省）', '有効求人倍率、新規求人倍率', '有効求人倍率＝一致、新規求人数＝先行'],
                                ['毎月勤労統計調査（厚生労働省）', '賃金、労働時間、雇用', 'きまって支給する給与、常用雇用指数＝遅行']],
                               [112, 118, 130], align=['l', 'l', 'l'], title='雇用の統計', size=10.5)

# ------------------------------------------------ 1.1.4 物価指数
FIG['keizai.pidx'] = grid(['', '消費者物価指数\n（CPI）', '企業物価指数', 'GDP\nデフレーター'],
                          [['作成', '総務省', '日本銀行', '内閣府'],
                           ['対象', '家計が買う財・サービス', '企業間で取引される財', '国内で生産された財・サービス'],
                           ['算式', 'ラスパイレス型', 'ラスパイレス型', 'パーシェ型'],
                           ['輸入品', '含む', '輸入物価指数で別に示す', '含まない（控除）']],
                          [56, 100, 100, 104], align=['l', 'c', 'c', 'c'], title='主な物価指数', size=10.5,
                          tcol={'ラスパイレス型': 'c', 'パーシェ型': 'b', '含まない（控除）': 'a'})

FIG['keizai.laspa'] = grid(['', '使うかご（数量）', '比較時の価格で', '基準時の価格で', '指数'],
                           [['ラスパイレス', '基準時\nA10個・B20個', '120×10＋50×20\n＝2,200', '100×10＋50×20\n＝2,000', '110'],
                            ['パーシェ', '比較時\nA8個・B24個', '120×8＋50×24\n＝2,160', '100×8＋50×24\n＝2,000', '108']],
                           [84, 70, 82, 82, 42], align=['l', 'c', 'c', 'c', 'c'], title='ラスパイレス型とパーシェ型（計算例）', size=10.5,
                           tcol={'110': 'a', '108': 'b'})

FIG['keizai.importp'] = _rowflow([('CPI', 'a', ['原油の輸入\n価格が上がる', 'ガソリン代・\n電気代が上がる', ('CPIは上昇', 'a')]),
                                  ('GDP\nデフレーター', 'b', ['原油の輸入\n価格が上がる', '輸入はGDPから\n差し引くので、\n国内の付加価値\nが減る方向', ('デフレーターは\n下がる方向', 'b')])],
                                 '輸入物価が上がったとき', lw=78, size=10, gapx=12)


def _inflation():
    g1 = G(xmax=10, ymax=10, w=176, h=208, ox=0, pl=24, pr=12, xlab='Y', ylab='P', cap='ディマンド・プル', ccol='a')
    g2 = G(xmax=10, ymax=10, w=176, h=208, ox=184, pl=24, pr=12, xlab='Y', ylab='P', cap='コスト・プッシュ', ccol='c')
    for g in (g1, g2):
        g.line([(0.5, 8.6), (9.5, 1.4)], 'a', label='AD', at=(9.6, 1.4))
        g.line([(0.5, 1.4), (9.5, 8.6)], 'b', label='AS', at=(9.6, 8.6))
        g.dot(5, 5, 'main', label='E0', pos='w').guide(5, 5)
    g1.line([(2.0, 9.0), (9.6, 2.9)], 'a', dash=True, label='AD′', at=(8.4, 4.6))
    g1.arrow(6.6, 3.7, 7.6, 3.7, 'a', gap=0)
    g1.dot(6, 5.8, 'a', label='E1', pos='nw').guide(6, 5.8)
    g2.line([(0.5, 3.0), (8.4, 9.3)], 'c', dash=True, label='AS′', at=(6.2, 8.6), anchor='end')
    g2.arrow(6.2, 6.0, 5.2, 6.0, 'c')
    g2.dot(4, 5.8, 'c', label='E1', pos='w').guide(4, 5.8)
    ex = [txt(4, 222, 'P↑ Y↑（需要の増加）', size=10.5, bold=True, col='a'), txt(188, 222, 'P↑ Y↓（スタグフレーション）', size=10.5, bold=True, col='c')]
    return panels([g1, g2], 'インフレの2つの型', h=228, extra=ex)


FIG['keizai.inflation'] = _inflation()

# ------------------------------------------------ 1.1.5 景気動向指数


def _ciwave():
    g = G(xmax=10, ymax=10, h=212, xlab='時間', ylab='', origin='', pl=12, pt=24)
    wv = lambda s: (lambda x: 5 + 3 * math.sin(2 * math.pi * (x - s) / 8))
    g.seg(2, 9.6, 2, 0, 'main', op=0.5).seg(6, 9.6, 6, 0, 'main', op=0.5)
    g.text(2, 9.9, '景気の山', 'middle', bold=True, size=11).text(6, 9.9, '景気の谷', 'middle', bold=True, size=11)
    g.fn(wv(-1), 0, 10, 'c', label='先行', at=(5.0, 1.0), anchor='middle')
    g.fn(wv(0), 0, 10, 'a', label='一致', at=(6.0, 1.0), anchor='middle')
    g.fn(wv(1), 0, 10, 'b', label='遅行', at=(7.0, 1.0), anchor='middle')
    g.dot(1, 8, 'c').dot(2, 8, 'a').dot(3, 8, 'b').dot(5, 2, 'c').dot(6, 2, 'a').dot(7, 2, 'b')
    return g.svg('先行・一致・遅行の系列（イメージ）')


FIG['keizai.ciwave'] = _ciwave()

FIG['keizai.cilist'] = _lists([('先行系列', 'c', ['新規求人数', '実質機械受注', '新設住宅着工床面積', '消費者態度指数', '東証株価指数', 'マネーストック（M2）★', '中小企業売上げ見通しDI★']),
                               ('一致系列', 'a', ['鉱工業生産指数', '有効求人倍率', '商業販売額', '営業利益（全産業）★', '耐久消費財出荷指数★', '輸出数量指数★']),
                               ('遅行系列', 'b', ['完全失業率（逆サイクル）', '家計消費支出', '法人税収入', '実質法人企業設備投資★', '消費者物価指数（生鮮食品を除く総合）★',
                                              'きまって支給する給与★', '常用雇用指数★'])],
                              '景気動向指数の主な系列（★＝間違えやすい）', size=10)


def _cidi():
    g1 = G(xmax=10, ymax=10, h=128, oy=0, pl=40, pt=6, pb=10, ylab='', origin='', cap='CI一致指数（変化の大きさ）', ccol='a')
    g2 = G(xmax=10, ymax=100, h=150, oy=128, pl=40, pt=6, pb=24, xlab='時間', origin='', cap='DI一致指数（改善した指標の割合）', ccol='b')
    g1.fn(lambda x: 5 + 3.4 * math.sin(2 * math.pi * x / 8), 0, 10, 'a')
    g1.dot(2, 8.4, 'a', label='山', pos='n').dot(6, 1.6, 'a', label='谷', pos='s')
    g2.hl(50, 'main', dash='5 4', sw=1.2)
    g2.yt(50, '50％', bold=True).yt(100, '100％').yt(0, '0％')
    g2.fn(lambda x: 50 + 38 * math.cos(2 * math.pi * x / 8), 0, 10, 'b')
    g2.dot(2, 50, 'b', label='上から下へ＝山', pos='ne').dot(6, 50, 'b', label='下から上へ＝谷', pos='se')
    for x in (2, 6):
        g1.seg(x, 10, x, 0, 'main', op=0.45)
        g2.seg(x, 100, x, 0, 'main', op=0.45)
    return panels([g1, g2], 'CIとDI（イメージ）', h=280)


FIG['keizai.cidi'] = _cidi()

FIG['keizai.tankan'] = stackbar([('回答', [('良い\n30％', 30, 'b'), ('さほど良くない\n50％', 50, 'sub'), ('悪い\n20％', 20, 'a')])],
                                '日銀短観の業況判断DI（数値例）', lw=40, bh=44, note='業況判断DI＝「良い」30％－「悪い」20％＝＋10（％ポイント）')

# ------------------------------------------------ 1.1.6 マネーストック統計
FIG['keizai.moneynest'] = _nest([('広義流動性\nM3＋投資信託、金融債、国債、外債など', 'sub'), ('M3\nM1＋準通貨（定期預金など）＋CD（譲渡性預金）', 'c'),
                                 ('M1\n現金通貨＋預金通貨（普通預金・当座預金など）', 'a')], 'マネーストックの範囲', size=10.5)

FIG['keizai.moneytbl'] = grid(['', 'M1', 'M2', 'M3', '広義\n流動性'],
                              [['現金通貨', '○', '○', '○', '○'], ['預金通貨（要求払預金）', '○', '○', '○', '○'], ['準通貨（定期預金など）・CD', '－', '○', '○', '○'],
                               ['投資信託・国債・外債など', '－', '－', '－', '○'], ['預金の預け先', 'すべて', '国内銀行\nなど', 'すべて', 'すべて']],
                              [140, 52, 60, 52, 56], align=['l', 'c', 'c', 'c', 'c'], title='マネーストックの指標と範囲', size=11, tcol={'国内銀行\nなど': 'a'})


def _mult():
    w, h = 360, 248
    base, k, bw = 176, 1.2, 64
    o = [L(0, base, w, base, col='main', sw=1.2)]
    x1, x2 = 60, 236
    for x, segs, nm in ((x1, [('現金 20', 20, 'c'), ('準備 10', 10, 'sub')], 'マネタリーベース 30'), (x2, [('現金 20', 20, 'c'), ('預金 100', 100, 'b')], 'マネーストック 120')):
        y = base
        for s, v, col in segs:
            o.append(R(x, y - v * k, bw, v * k, fill=col, stroke=col if col != 'sub' else 'main', op=0.3 if col != 'sub' else 0.16))
            o.append(T(x + bw / 2, y - v * k / 2 + 4, s, 'middle', size=10.5, bold=True))
            y -= v * k
        o.append(T(x + bw / 2, base + 16, nm, 'middle', size=11, bold=True))
    o.append(ARROW([(x1 + bw + 6, base - 30), (x2 - 6, base - 70)], col='a', sw=1.8, head=7))
    o.append(T((x1 + bw + x2) / 2, base - 74, '×4', 'middle', size=14, bold=True, col='a'))
    o.append(T((x1 + bw + x2) / 2, base - 58, '信用乗数', 'middle', size=10.5, bold=True, col='a'))
    o.append(T(4, base + 40, '信用乗数＝（c＋1）÷（c＋r）＝1.2÷0.3＝4', size=11.5, bold=True))
    o.append(T(4, base + 60, 'c：現金預金比率 0.2　r：預金準備率 0.1', size=10.5))
    return _svg(w, h, o, 'マネタリーベースとマネーストック（数値例）')


FIG['keizai.mult'] = _mult()

FIG['keizai.multchg'] = hbars([('c＝0.2、r＝0.1', 4, 'b'), ('現金預金比率cが0.3に上昇', 3.25, 'a'), ('預金準備率rが0.2に上昇', 3, 'a')],
                              '信用乗数の変化', lw=150, lo=0, hi=4.6, fmt=lambda v: '%g' % v)

FIG['keizai.mbops'] = grid(['日本銀行などの操作', 'マネタリーベース'],
                           [['買いオペ（国債などを買い、代金を払う）', '増える'], ['売りオペ（国債などを売り、代金を受け取る）', '減る'],
                            ['円売り・ドル買いの介入（資金を吸収する操作で打ち消さない場合）', '増える']],
                           [262, 98], align=['l', 'c'], title='マネタリーベースを動かす操作', size=11, tcol={'増える': 'b', '減る': 'a'})

# ------------------------------------------------ 1.1.7 国際収支
FIG['keizai.boptree'] = htree(('国際\n収支', 'main', [
    ('経常収支', 'a', [('貿易・サービス\n収支', 'a', [('貿易収支\n財の輸出－輸入', None, []), ('サービス収支\n輸送・旅行・知的財産権\n等使用料など', None, [])]),
                       ('第一次所得収支', 'a', [('利子・配当（投資収益）、\n雇用者報酬', None, [])]),
                       ('第二次所得収支', 'a', [('対価を伴わない移転\n（無償の資金協力など）', None, [])])]),
    ('資本移転等\n収支', 'c', [('債務免除など', 'c', [])]),
    ('金融収支', 'b', [('直接投資・証券投資・\n金融派生商品・\nその他投資・外貨準備', 'b', [])])]),
    '国際収支統計の構成', colw=(40, 66, 92, 132), gapx=8, size=10)

FIG['keizai.bop2025'] = waterfall([('第一次所得収支', 41.6, 'delta'), ('貿易収支', -0.8, 'delta'), ('サービス収支', -3.4, 'delta'), ('第二次所得収支', -5.5, 'delta'),
                                   ('経常収支', None, 'total')], '日本の経常収支（2025年）', lw=104, vw=64, fmt=lambda v: '%.1f兆円' % v)

FIG['keizai.bopid'] = eq([[('経常収支', 'a'), '＋', ('資本移転等\n収支', 'c'), '－', ('金融収支', 'b'), '＋', '誤差脱漏', '＝', '0'],
                          [('経常収支の黒字\n（外貨を稼ぐ）', 'a'), '≒', ('金融収支の黒字\n（対外資産が増える）', 'b')]], '国際収支の恒等式', size=10.5, opw=15)

FIG['keizai.bopitem'] = grid(['取引の例', '計上する項目'],
                             [['自動車を輸出する', '貿易収支'], ['訪日外国人が日本で宿泊・飲食する', 'サービス収支（旅行）'], ['海外のクラウドサービスの利用料を払う', 'サービス収支'],
                              ['海外の子会社から配当を受け取る', '第一次所得収支'], ['外国の債券の利子を受け取る', '第一次所得収支'],
                              ['無償の資金協力、海外で働く人の本国への送金', '第二次所得収支'], ['債務を免除する', '資本移転等収支'],
                              ['海外に工場を持つ子会社をつくる', '金融収支（直接投資）'], ['外国の株式や債券を買う', '金融収支（証券投資）']],
                             [212, 148], align=['l', 'l'], title='取引と国際収支の項目', size=11,
                             tcol={'第一次所得収支': 'a', '第二次所得収支': 'a'})

FIG['keizai.bopcmp'] = grid(['国', '国際収支の特徴'],
                            [['日本', '貿易ではなく、第一次所得収支（海外への投資の収益）で黒字を稼ぐ'], ['米国', '経常収支の大きな赤字国'],
                             ['ドイツ', '財の貿易黒字が中心の黒字国'], ['英国', '財の貿易赤字が大きく、サービス収支は黒字']],
                            [60, 300], align=['l', 'l'], title='主要国の国際収支の特徴', size=11)

# ------------------------------------------------ 1.1.8 為替レート
FIG['keizai.fxeff'] = grid(['', '1ドル＝150円', '1ドル＝130円（円高）', '影響'],
                           [['1万ドルの輸出の受取', '150万円', '130万円', '輸出に不利'], ['1万ドルの輸入の支払', '150万円', '130万円', '輸入に有利'],
                            ['150万円の商品のドルでの価格', '1万ドル', '約1.15万ドル', '輸出品が割高']],
                           [112, 72, 92, 84], align=['l', 'c', 'c', 'c'], title='円高の影響（円安はこの逆）', size=10.5,
                           tcol={'輸出に不利': 'a', '輸入に有利': 'b', '輸出品が割高': 'a'})

FIG['keizai.ppp'] = grid(['', '米国の価格', '日本の価格', '購買力平価'],
                         [['いま', '5ドル', '750円', '750÷5＝150円'], ['米国の物価だけ10％上昇', '5.5ドル', '750円', '750÷5.5≒136円\n（円高・ドル安）']],
                         [110, 66, 66, 118], align=['l', 'c', 'c', 'c'], title='購買力平価（同じハンバーガーの例）', size=10.5, tcol={'750÷5.5≒136円\n（円高・ドル安）': 'b'})

FIG['keizai.fxdir'] = _lists([('円高の方向', 'b', ['日本の金利が上がる（外国の金利が下がる）', '輸出が増え、経常収支の黒字が拡大する', '将来の円高が予想される',
                                               '日本の物価が外国より下がる']),
                              ('円安の方向', 'a', ['外国の金利が上がる（米国の利上げの予想など）', '原油などの輸入価格が上がる（ドルの需要が増える）',
                                               '日本から海外への投資が増える（円を売る）', '日本の物価が外国より大きく上がる'])],
                             '為替レートを動かす要因')

FIG['keizai.fxkind'] = _ladder([('名目為替レート\n市場で取引される2通貨の交換比率', None), ('実効為替レート\n複数の相手国の通貨との為替レートを、貿易額などで加重平均', 'c'),
                                ('実質実効為替レート\nさらに物価の違いを調整。通貨の総合的な購買力（低いほど円安）', 'a')],
                               '為替レートの指標', bw=250)

FIG['keizai.fxip'] = _rowflow([('日本で\n運用', 'c', ['150万円', '金利0％', ('1年後\n150万円', 'c')]),
                               ('米国で\n運用', 'b', ['150万円を\n1万ドルに替える', '金利5％\n→1.05万ドル', ('先物レートで\n円に戻す', 'b')]),
                               ('結果', 'a', ['1.05万ドル×先物レート＝150万円', ('先物レート≒142.9円\n（ドルは先物で安い）', 'a')])],
                              '金利平価：どちらで運用しても同じ収益になる', lw=56, size=10.5)

# ------------------------------------------------ 1.1.9 経済事情
FIG['keizai.fisrev'] = stackbar([('歳入', [('税収\n83.7兆円（66.8％）', 66.8, 'b'), ('公債金\n32.7兆円\n（26.1％）', 26.1, 'a'), ('', 7.2, 'sub')])],
                                '一般会計の歳入（令和8年度補正後、総額125.4兆円）', lw=40, bh=56,
                                note='右端の灰色はその他収入9.0兆円（7.2％）。公債金のうち、特例公債26.0兆円、建設公債6.7兆円。公債依存度26.1％')

FIG['keizai.fisexp'] = hbars([('社会保障関係費', 39.1, 'a'), ('国債費', 31.3, 'c'), ('地方交付税交付金等', 20.9, 'b'), ('防衛関係費', 9.0, 'sub'),
                              ('公共事業', 6.1, 'sub'), ('文教及び科学振興', 6.0, 'sub'), ('その他', 13.1, 'sub')],
                             '一般会計の歳出（令和8年度補正後、総額125.4兆円）', lw=120, fmt=lambda v: '%.1f兆円' % v, vw=60,
                             note='社会保障関係費が約3割（31.1％）、国債費が約4分の1（24.9％）。出典：財務省「日本の財政関係資料」')

FIG['keizai.taxr7'] = hbars([('消費税', 26.0, 'b'), ('所得税', 25.3, 'c'), ('法人税', 21.7, 'a'), ('その他', 11.2, 'sub'), ('税収の合計', 84.2, 'main')],
                            '税目別の税収（令和7年度決算）', lw=86, fmt=lambda v: '%.1f兆円' % v, vw=64, note='2020年度から消費税が最も大きい。合計は過去最高')

FIG['keizai.debt'] = hbars([('日本', 204, 'a'), ('イタリア', 138, 'c'), ('米国', 126, 'c'), ('ドイツ', 65, 'b')], '一般政府の債務残高の対GDP比（2026年の推計）',
                           lw=70, fmt=lambda v: '%d％' % v, note='出典：IMF（2026年4月）')

FIG['keizai.fisbal'] = hbars([('日本', 1.9, 'b'), ('英国', 5.1, 'a'), ('米国', 8.0, 'a')], '一般政府の財政収支の対GDP比（2026年の見通し）', lw=70,
                             fmt=lambda v: '－%.1f％' % v, note='棒の長さは赤字の大きさ。出典：OECD（2026年6月）')

FIG['keizai.hhasset'] = grid(['家計の金融資産', '現金・預金', '株式等＋投資信託'],
                             [['日本', '約半分（47％）', '約4分の1'], ['米国', '約1割', '5割超']],
                             [110, 120, 130], align=['l', 'c', 'c'], title='家計の金融資産の構成（日本は2026年3月末）', size=11.5,
                             tcol={'約半分（47％）': 'a', '5割超': 'b'})

FIG['keizai.pw2025'] = hbars([('消費者物価（総合）', 3.2, 'a'), ('消費者物価（生鮮食品を除く総合）', 3.1, 'a'), ('名目賃金', 2.3, 'b'), ('実質賃金', -1.3, 'c')],
                             '物価と賃金（2025年、前年比）', lw=170, lo=-2, hi=4, fmt=lambda v: ('＋%.1f％' % v) if v > 0 else ('－%.1f％' % -v),
                             note='名目賃金の伸びが物価の上昇に追いつかず、実質賃金は4年連続のマイナス')


def _lvl():
    lv = [100, 105, 109, 112, 114]
    gr = [None, 5.0, 3.8, 2.8, 1.8]
    g1 = G(xmax=4.6, ymax=120, ymin=90, w=176, h=196, ox=0, pl=34, pr=8, cap='水準（指数）', origin='', xmin=-0.4)
    g2 = G(xmax=4.6, ymax=6, ymin=0, w=176, h=196, ox=184, pl=30, pr=8, cap='伸び率（前年比、％）', origin='', xmin=-0.4)
    g1.line([(i, v) for i, v in enumerate(lv)], 'b')
    for i, v in enumerate(lv):
        g1.dot(i, v, 'b', label=str(v), pos='n', size=10)
        g1.xt(i, '%d年' % (i + 1))
    for i in range(1, 5):
        g2.rect(i - 0.3, 0, i + 0.3, gr[i], col='a', op=0.3, label='%.1f' % gr[i], at=(i, gr[i] + 0.45), lcol='main', size=10)
        g2.xt(i, '%d年' % (i + 1))
    ex = [txt(180, 214, '伸び率は下がっても、水準は上がり続ける', 'middle', size=11, bold=True, col='a')]
    return panels([g1, g2], '水準と伸び率（数値例）', h=222, extra=ex)


FIG['keizai.lvlgr'] = _lvl()

# ------------------------------------------------ 1.4.1 ケインズ理論
FIG['keizai.schools'] = grid(['年', '学派・理論', '人物'],
                            [['1776年', '古典派（『国富論』）', 'スミス'], ['1803年', 'セイの法則', 'セイ'], ['1936年', 'ケインズ経済学（『一般理論』）', 'ケインズ'],
                             ['1956年', '新古典派の成長理論', 'ソロー'], ['1968年', 'マネタリズム（自然失業率仮説）', 'フリードマン'], ['1970年代', '合理的期待形成学派', 'ルーカス'],
                             ['1980年代', '実物的景気循環理論、内生的成長理論', '']],
                            [66, 214, 80], align=['l', 'l', 'l'], title='主な経済学派の流れ', size=11, tcol={'ケインズ経済学（『一般理論』）': 'a', 'マネタリズム（自然失業率仮説）': 'c'})

FIG['keizai.effdemand'] = _rowflow([('', None, [('有効需要\n消費＋投資＋\n政府支出など', 'a'), '生産量\n（国民所得）', '雇用量']),
                                    ('', None, [('需要が不足', 'a'), '生産と雇用が\n減る', ('非自発的失業', 'a')])], '有効需要の原理', lw=0, size=10.5)

FIG['keizai.kvc'] = grid(['', '古典派', 'ケインズ'],
                         [['生産量を決めるもの', '供給（セイの法則）', '需要（有効需要の原理）'], ['価格・賃金', '伸縮的に動く', '名目賃金は下がりにくい（下方硬直性）'],
                          ['失業', '自発的失業と摩擦的失業だけ', '非自発的失業が生じる'], ['利子率を決めるもの', '貯蓄と投資（資金の需給）', '貨幣の需給（流動性選好説）'],
                          ['貨幣', '物価だけを動かす（二分法）', '利子率を通じて生産に影響'], ['政策', '市場に任せる', '不況時は財政政策で需要を増やす']],
                         [98, 120, 142], align=['l', 'l', 'l'], title='古典派とケインズの比較', size=10.5)


def _consf():
    g = G(xmax=220, ymax=220, h=258, xlab='所得 Y', ylab='消費 C', pr=20)
    g.line([(0, 0), (215, 215)], 'sub', dash='4 3', sw=1.4, label='45度線（C＝Y）', at=(178, 214), anchor='end', lcol='main', lsize=10.5)
    g.line([(0, 40), (215, 169)], 'a', label='C＝40＋0.6Y', at=(214, 146), anchor='end')
    g.seg(0, 0, 100, 100, 'b', dash='5 3', sw=1.3, op=1).seg(0, 0, 200, 160, 'b', dash='5 3', sw=1.3, op=1)
    g.dot(100, 100, 'b', label='A：平均消費性向1.0', pos='nw').dot(200, 160, 'b', label='B：0.8', pos='n')
    g.dot(0, 40, 'a').yt(40, 'C0', col='a', bold=True)
    g.text(62, 36, '傾き＝限界消費性向c', 'start', 'a', True, 10.5)
    g.guide(100, 100, xt='100').guide(200, 160, xt='200')
    g.text(6, 166, '原点からの直線の傾き\n＝平均消費性向\n所得が増えると下がる', 'start', 'b', True, 10.5)
    return g.svg('ケインズ型の消費関数')


FIG['keizai.consf'] = _consf()

FIG['keizai.cons4'] = grid(['仮説', '提唱者', '消費を決めるもの', '押さえどころ'],
                           [['絶対所得仮説', 'ケインズ', 'その期の所得', '所得が増えると平均消費性向が下がる'],
                            ['相対所得仮説', 'デューゼンベリー', '過去の最高の所得、周囲の人の消費', 'ラチェット効果、デモンストレーション効果'],
                            ['恒常所得仮説', 'フリードマン', '長期的に見込める平均の所得', '一時的な減税は消費をあまり増やさない'],
                            ['ライフサイクル仮説', 'モディリアーニ', '一生の所得と資産', '高齢者の割合が高まると貯蓄率が下がる']],
                           [84, 78, 92, 106], align=['l', 'l', 'l', 'l'], title='消費関数の4つの仮説', size=10.5)


def _life():
    g = G(xmax=90, xmin=20, ymax=12, h=236, xlab='年齢', ylab='金額（年間）', pr=22, origin='')
    c = 10 * 45 / 65.0
    g.area([(20, c), (65, c), (65, 10), (20, 10)], 'b', label='貯蓄', size=11)
    g.area([(65, 0), (85, 0), (85, c), (65, c)], 'a', label='貯蓄の取り崩し', size=10.5)
    g.line([(20, 10), (65, 10), (65, 0)], 'b', label='所得', at=(42, 10.6), anchor='middle')
    g.line([(20, c), (85, c)], 'a', label='消費（一定）', at=(52, c - 1.0), anchor='middle')
    g.guide(65, 0, xt='引退65', v=False, h=False).guide(85, 0, xt='85', v=False, h=False)
    g.xt(20, '20')
    g.text(42, 3.2, '働く時期の貯蓄で、\n引退後の消費をまかなう', 'middle', bold=True, size=10.5)
    return g.svg('ライフサイクル仮説（イメージ）')


FIG['keizai.life'] = _life()


def _ratchet():
    g = G(xmax=10, ymax=10, h=200, xlab='時間', ylab='金額', origin='')
    inc = [(0, 4), (3, 6.5), (4.5, 7.5), (5.5, 5.2), (7, 6.2), (10, 9)]
    con = [(0, 3), (3, 4.9), (4.5, 5.6), (5.5, 5.0), (7, 5.2), (10, 6.8)]
    g.line(inc, 'b', label='所得', at=(9.0, 9.0), anchor='end')
    g.line(con, 'a', label='消費', at=(9.0, 6.0), anchor='middle')
    g.rect(4.5, 0, 6.2, 10, col='sub', op=0.1)
    g.text(5.35, 1.6, '不況で\n所得が減る', 'middle', bold=True, size=10.5)
    g.text(3.2, 8.6, '消費は過去の最高の所得に\n引きずられ、あまり減らない', 'middle', 'a', True, 10.5)
    return g.svg('ラチェット効果（相対所得仮説、イメージ）')


FIG['keizai.ratchet'] = _ratchet()

# ------------------------------------------------ 1.4.2 古典派と新古典派の理論
FIG['keizai.qtm'] = grid(['', 'M\n貨幣量', 'V\n流通速度', 'P\n物価', 'Y\n実質の生産量', 'MV＝PY'],
                         [['いま', '100', '5', '5', '100', '500'], ['Mを10％増やす', '110', '5', '5.5', '100', '550']],
                         [76, 54, 56, 50, 70, 54], align=['l', 'c', 'c', 'c', 'c', 'c'], title='貨幣数量説と貨幣の中立性（数値例）', size=10.5,
                         tcol={'110': 'a', '5.5': 'a'})


def _solow():
    g = G(xmax=12, ymax=14, h=270, xlab='1人当たり資本 k', ylab='1人当たり', pr=44, pb=38, xlpos='low')
    g.fn(lambda k: 4 * math.sqrt(k), 0, 12, 'main', label='f（k）', at=(8.0, 12.9), anchor='end', lcol='main')
    g.fn(lambda k: 1.2 * math.sqrt(k), 0, 12, 'b', label='sf（k）', at=(12.0, 1.2 * math.sqrt(12)), dx=4)
    g.line([(0, 0), (11.6, 4.64)], 'a', label='nk', at=(11.0, 5.5), anchor='middle')
    g.dot(9, 3.6, 'main').guide(9, 3.6, xt='k*', bold=True)
    g.seg(9, 3.6, 9, 12, 'main')
    g.dot(9, 12, 'main')
    g.vspan(8.6, 3.6, 12, '消費', 'main', anchor='end', size=10.5)
    g.text(5.0, 5.6, 'sf（k）＞nk\nなら k が増える', 'middle', 'b', True, 10.5)
    g.text(11.0, 8.2, 'sf（k）＜nk\nなら k が減る', 'middle', 'a', True, 10.5)
    g.arrow(5.6, 0.45, 8.3, 0.45, 'b', sw=2).arrow(11.8, 0.45, 9.7, 0.45, 'a', sw=2)
    g.text(10.7, 2.3, '定常状態', 'middle', bold=True, size=11)
    return g.svg('ソロー・モデルの定常状態')


FIG['keizai.solow'] = _solow()


def _solow2():
    g1 = G(xmax=12, ymax=7, w=176, h=200, ox=0, pl=24, pr=12, xlab='k', cap='貯蓄率が上がる', ccol='b')
    g2 = G(xmax=12, ymax=7, w=176, h=200, ox=184, pl=24, pr=12, xlab='k', cap='人口成長率が上がる', ccol='a')
    g1.fn(lambda k: 1.2 * math.sqrt(k), 0, 12, 'b', label='sf', at=(12.0, 1.2 * math.sqrt(12)), dx=-14, dy=10)
    g1.fn(lambda k: 1.6 * math.sqrt(k), 0, 12, 'b', dash=True, label='s′f', at=(6.6, 5.2), anchor='end')
    g1.line([(0, 0), (12, 6.0)], 'a', label='nk', at=(11.6, 6.6), anchor='end')
    g1.dot(5.76, 2.88, 'main').guide(5.76, 2.88, xt='k*')
    g1.dot(10.24, 5.12, 'b').guide(10.24, 5.12, xt='k*′', tcol='b', bold=True)
    g1.arrow(6.6, 1.2, 9.4, 1.2, 'b', sw=1.8)
    g2.fn(lambda k: 1.2 * math.sqrt(k), 0, 12, 'b', label='sf', at=(12.0, 1.2 * math.sqrt(12)), dx=-14, dy=10)
    g2.line([(0, 0), (12, 4.8)], 'a', label='nk', at=(12.0, 4.8), dx=-2, dy=-12, anchor='end')
    g2.line([(0, 0), (9.6, 5.76)], 'a', dash=True, label='n′k', at=(8.0, 5.7), anchor='end')
    g2.dot(9, 3.6, 'main').guide(9, 3.6, xt='k*')
    g2.dot(4, 2.4, 'a').guide(4, 2.4, xt='k*′', tcol='a', bold=True)
    g2.arrow(8.2, 1.0, 5.0, 1.0, 'a', sw=1.8)
    return panels([g1, g2], '定常状態の変化', h=200)


FIG['keizai.solow2'] = _solow2()

FIG['keizai.growthacc'] = hbars([('資本の寄与（0.3×2％）', 0.6, 'b'), ('労働の寄与（0.7×（－0.5％））', -0.35, 'a'), ('TFPの伸び', 1.0, 'c'), ('経済成長率', 1.25, 'main')],
                                '成長会計（数値例）', lw=176, lo=-0.5, hi=1.4, fmt=lambda v: ('＋%g％' % v) if v > 0 else ('－%g％' % -v),
                                note='経済成長率＝資本分配率×資本の伸び＋労働分配率×労働の伸び＋TFPの伸び')


def _mei():
    g = G(xmax=70, ymax=17, h=240, xlab='投資額', ylab='投資の限界効率・利子率（％）', pr=20)
    mei = [12, 10, 8, 6, 4, 2]
    for i, m in enumerate(mei):
        col = 'b' if m > 5 else ('c' if m > 3 else 'sub')
        g.rect(i * 10 + 0.6, 0, i * 10 + 9.4, m, col=col, op=0.3, label='%s\n%d％' % ('ABCDEF'[i], m), at=(i * 10 + 5, m + 1.4), lcol='main', size=10)
    g.hl(5, 'a', label='利子率5％', at=(70, 5.4), anchor='end', dy=-6)
    g.hl(3, 'c', dash=True, label='利子率3％', at=(70, 3.0), anchor='end', dy=-6)
    g.guide(40, 0, xt='40', h=False, v=False).guide(50, 0, xt='50', h=False, v=False)
    g.text(69, 15.0, '利子率5％：A～Dを実行（投資40）\n利子率3％：Eも実行（投資50）', 'end', 'main', True, 10.5)
    return g.svg('投資の限界効率と利子率（数値例）')


FIG['keizai.mei'] = _mei()


def _stockadj():
    g = G(xmax=4.8, ymax=112, xmin=-0.4, h=220, ylab='', origin='')
    ks = [60, 80, 90, 95]
    for i, k in enumerate(ks):
        g.rect(i - 0.34, 0, i + 0.34, k, col='sub', op=0.18, label=str(k), at=(i, k / 2), lcol='main', size=11)
        if i < 3:
            inv = (100 - k) * 0.5
            g.rect(i + 1 - 0.34, k, i + 1 + 0.34, k + inv, col='b', op=0.35)
            if inv >= 10:
                g.text(i + 1, k + inv / 2, '投資%g' % inv, 'middle', 'b', True, 10)
            else:
                g.text(i + 1.38, k + inv / 2, '投資%g' % inv, 'start', 'b', True, 10)
        g.xt(i, '%d期' % i if i else '今期')
    g.hl(100, 'a', dash=True, label='望ましい資本ストック K*＝100', at=(-0.35, 100), dy=-9)
    return g.svg('資本ストック調整原理（調整速度0.5の数値例）')


FIG['keizai.stockadj'] = _stockadj()

FIG['keizai.tobinq'] = grid(['', '企業の市場価値', '資本の再取得費用', 'q', '投資'],
                            [['ケース1', '120', '100', '1.2', '増やす'], ['ケース2', '80', '100', '0.8', '減らす']],
                            [60, 92, 100, 40, 68], align=['l', 'c', 'c', 'c', 'c'], title='トービンのq（q＝市場価値÷再取得費用）', size=11,
                            tcol={'増やす': 'b', '減らす': 'a'})

# ------------------------------------------------ 1.4.3 マネタリズム


def _phillips():
    g = G(xmax=10, ymax=8, h=290, xlab='失業率（％）', ylab='インフレ率（％）', pr=18, pb=62)
    g.vl(5, 'b', sw=2.4, label='長期フィリップス曲線', at=(5.15, 7.7))
    g.fn(lambda u: 7 - u, 1, 7, 'a')
    g.fn(lambda u: 9 - u, 2, 9, 'c')
    g.text(6.0, 1.9, '短期（予想2％）', 'start', 'a', True, 10.5)
    g.text(7.4, 2.9, '短期（予想4％）', 'start', 'c', True, 10.5)
    g.dot(5, 2, 'a', label='A', pos='e').dot(3, 4, 'a', label='B', pos='w').dot(5, 4, 'c', label='C', pos='e')
    g.arrow(4.55, 1.85, 3.15, 3.25, 'a', sw=2)
    g.arrow(3.2, 4.0, 4.8, 4.0, 'c', sw=2, gap=6)
    g.xt(5, '自然失業率', 'b', True)
    g.yt(2, '2').yt(4, '4')
    g.raw(txt(6, 258, 'A→B：拡張的な政策で、失業率が自然失業率より下がる', size=10.5, bold=True, col='a'))
    g.raw(txt(6, 276, 'B→C：予想インフレ率が追いつき、失業率は元に戻る', size=10.5, bold=True, col='c'))
    return g.svg('短期と長期のフィリップス曲線')


FIG['keizai.phillips'] = _phillips()

FIG['keizai.phtbl'] = grid(['失業率', 'インフレ率'],
                           [['自然失業率に等しい', '予想インフレ率に等しい'], ['自然失業率より高い', '予想より低い'], ['自然失業率より低い', '予想より高い']],
                           [180, 180], align=['c', 'c'], title='インフレ率＝予想インフレ率－α×（失業率－自然失業率）', size=11.5)

FIG['keizai.expect'] = grid(['', 'マネタリズム\n（適応的期待）', '合理的期待形成学派'],
                            [['予想の作り方', '過去の物価の動きから', '入手できる情報をすべて使う'], ['短期のフィリップス曲線', '右下がり', '垂直（予想された政策）'],
                             ['長期のフィリップス曲線', '垂直（自然失業率）', '垂直'], ['予想された拡張政策', '短期だけ失業率を下げる', '短期でも効果がない']],
                            [104, 124, 132], align=['l', 'c', 'c'], title='期待（予想）の考え方の違い', size=10.5)


def _lag():
    g = G(xmax=10, ymax=11, h=214, xlab='時間', ylab='', origin='', pl=14)
    g.hl(5, 'sub', dash='4 3', sw=1.2, label='平常', at=(9.2, 5.5), lsize=10, lcol='main')
    g.fn(lambda x: 5 + 3 * math.sin(2 * math.pi * x / 8), 0, 10, 'b', label='景気', at=(2.0, 8.7), anchor='middle')
    g.fn(lambda x: 5 + 1.6 * math.sin(2 * math.pi * (x - 6.4) / 8), 0, 10, 'a', dash=True, label='政策の効果', at=(4.4, 2.6), anchor='middle')
    g.dot(6, 2, 'b', label='不況で対策を決める', pos='s')
    g.dot(8.4, 6.6, 'a', label='効果が出るのは回復後', pos='nw')
    g.text(5.0, 10.5, '効果の遅れ（ラグ）があると、景気の振れを大きくしかねない', 'middle', 'main', True, 10.5)
    return g.svg('裁量的な政策とラグ（イメージ）')


FIG['keizai.lag'] = _lag()
