# 経営情報システムの図表（1.2 システム構成・処理形態・ヒューマンインタフェース・外部資源、1.3 データベース）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, htree, gantt, ARROW, R, T, L, _svg, _c, wrap, tw)
from kit import (_lines, _dashrect, _box, _lists, _flow, _rowflow, _nest, _hub)
from ekit import G, txt, eq, panels
from vis import quad
from jkit import stack, tiles, dtab, lab, pc, srv, cyl, cloud, person, rtr, brace, code, seq, r1, MONO

FIG = {}


def poly(o, pts, col='main', fill=None, op=0.16, sw=1.3, dash=None):
    d = 'M' + ' L'.join('%s %s' % (r1(a), r1(b)) for a, b in pts) + ' Z'
    ds = ' stroke-dasharray="%s"' % dash if dash else ''
    o.append('<path d="%s" style="fill:var(--sheet);stroke:none"/>' % d)
    o.append('<path d="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="%s"%s/>' % (d, _c(fill or 'sheet'), op if fill else 1, _c(col), sw, ds))


def circ(o, x, y, r, col='main', fill=None, op=0.16, sw=1.3):
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:var(--sheet);stroke:none"/>' % (r1(x), r1(y), r))
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="%s"/>' % (
        r1(x), r1(y), r, _c(fill or 'sheet'), op if fill else 1, _c(col), sw))


# ------------------------------------------------ 1.2.1 システム構成
def _cs3():
    o = []
    rows = [('プレゼンテーション層', 'c', '入出力の画面\n（クライアントの側）', 'pc'), ('ファンクション層', 'b', '業務の処理\n（アプリケーション層ともいう）', 'srv'),
            ('データベースアクセス層', 'a', 'データの管理', 'db')]
    for i, (a, col, b, ic) in enumerate(rows):
        y = 4 + i * 52
        _box(o, 40, y, 150, 36, a, col=col, size=10.5, c0=col, op=0.22)
        bl = b.split('\n')
        for k, ln in enumerate(bl):
            o.append(T(198, y + 22 + (k - (len(bl) - 1) / 2) * 14, ln, size=10))
        if ic == 'pc':
            pc(o, 18, y + 18)
        elif ic == 'srv':
            srv(o, 18, y + 18)
        else:
            cyl(o, 18, y + 18, w=26, h=30)
        if i:
            o.append(ARROW([(108, y - 15), (108, y - 2)], sw=1.3, head=5))
            o.append(ARROW([(122, y - 2), (122, y - 15)], sw=1.3, head=5))
    o.append(T(4, 168, '層ごとに変更できるため、保守や拡張がしやすい', size=10.5, bold=True, col='b'))
    return _svg(360, 174, o, '3層クライアントサーバシステム')


FIG['joho.cs3'] = _cs3()


def _csp2p():
    o = []
    for k, t in enumerate(['クライアントサーバ', 'P2P', 'シンクライアント']):
        o.append(T(60 + k * 120, 14, t, 'middle', bold=True, size=11))
    srv(o, 60, 46, col='b')
    for x in (22, 60, 98):
        o.append(L(60, 64, x, 98, col='line', sw=1.2))
        pc(o, x, 110)
    o.append(T(60, 146, '要求に応じてサーバが処理', 'middle', size=9.5))
    pts = [(150, 52), (210, 52), (150, 110), (210, 110)]
    for i in range(4):
        for j in range(i + 1, 4):
            o.append(L(pts[i][0], pts[i][1], pts[j][0], pts[j][1], col='c', sw=1.2))
    for (x, y) in pts:
        pc(o, x, y, col='c')
    o.append(T(180, 146, '対等な機器どうしが直接', 'middle', size=9.5))
    pc(o, 262, 84)
    srv(o, 330, 80, col='b')
    o.append(ARROW([(280, 76), (314, 76)], sw=1.2, head=5))
    o.append(ARROW([(314, 90), (280, 90)], sw=1.2, head=5))
    o.append(T(262, 116, '画面・入力', 'middle', size=9.5))
    o.append(T(330, 116, '処理・データ', 'middle', size=9.5))
    o.append(T(300, 146, '端末にデータが残らない', 'middle', size=9.5, col='b', bold=True))
    return _svg(360, 152, o, 'クライアントサーバ、P2P、シンクライアント')


FIG['joho.csp2p'] = _csp2p()


def _dual():
    o = []
    o.append(T(4, 14, 'デュアルシステム：2組で同じ処理を同時に行い、結果を照合', bold=True, size=10.5, col='b'))
    _box(o, 2, 36, 48, 30, '入力', size=10)
    _box(o, 92, 22, 80, 26, '系1：処理', col='b', size=10, c0='b')
    _box(o, 92, 56, 80, 26, '系2：処理', col='b', size=10, c0='b')
    _box(o, 212, 36, 56, 30, '照合', col='c', size=10, c0='c')
    _box(o, 306, 36, 50, 30, '出力', size=10)
    for y in (35, 69):
        o.append(ARROW([(50, 51), (70, 51), (70, y), (90, y)], sw=1.2, head=5))
        o.append(ARROW([(172, y), (192, y), (192, 51), (210, 51)], sw=1.2, head=5))
    o.append(ARROW([(268, 51), (304, 51)], sw=1.2, head=5))
    o.append(T(4, 108, 'デュプレックスシステム：本番系が故障したら待機系に切り替える', bold=True, size=10.5, col='c'))
    _box(o, 2, 120, 48, 30, '入力', size=10)
    _box(o, 92, 120, 96, 30, '本番系：処理', col='b', size=10, c0='b')
    _box(o, 306, 120, 50, 30, '出力', size=10)
    o.append(ARROW([(50, 135), (90, 135)], sw=1.2, head=5))
    o.append(ARROW([(188, 135), (304, 135)], sw=1.2, head=5))
    o.append(_dashrect(92, 172, 96, 30, col='c'))
    o.append(T(140, 191, '待機系', 'middle', size=10, bold=True, col='c'))
    o.append(ARROW([(140, 152), (140, 170)], col='a', sw=1.4, head=5, dash='3 2'))
    o.append(T(146, 165, '故障したら切替え', size=9.5, col='a'))
    o.append(T(4, 222, 'ホットスタンバイ：待機系を、いつでも切り替えられる状態で動かしておく', size=9.5))
    o.append(T(4, 238, 'コールドスタンバイ：故障してから待機系を起動する', size=9.5))
    return _svg(360, 244, o, 'デュアルシステムとデュプレックスシステム')


FIG['joho.dual'] = _dual()


def _virt():
    o = []
    defs = [('ハイパーバイザ型', [[('アプリ', 'sub'), ('アプリ', 'sub')], [('ゲストOS', 'c'), ('ゲストOS', 'c')], [('ハイパーバイザ', 'a')], [('ハードウェア', None)]],
             'ホストOSがいらず、無駄が少ない'),
            ('ホストOS型', [[('アプリ', 'sub'), ('アプリ', 'sub')], [('ゲストOS', 'c'), ('ゲストOS', 'c')], [('仮想化ソフト', 'a')], [('ホストOS', 'b')],
                        [('ハードウェア', None)]], '導入は手軽だが、無駄が大きい'),
            ('コンテナ型', [[('コンテナ', 'sub'), ('コンテナ', 'sub')], [('コンテナを動かすソフト', 'a')], [('ホストOS', 'b')],
                        [('ハードウェア', None)]], 'カーネルを共有し、ゲストOSがいらない。軽く速いが、異なる種類のOSは動かせない')]
    lh, base = 26, 160
    for k, (ttl, layers, note) in enumerate(defs):
        x0 = 2 + k * 120
        o.append(T(x0 + 56, 14, ttl, 'middle', bold=True, size=11))
        for i, row in enumerate(reversed(layers)):
            y = base - (i + 1) * lh
            n = len(row)
            ww = (112 - (n - 1) * 4) / n
            for j, (s, col) in enumerate(row):
                xx = x0 + j * (ww + 4)
                o.append(R(xx, y, ww, lh - 3, fill='sheet', stroke=None, rx=3))
                o.append(R(xx, y, ww, lh - 3, fill=col or 'sheet', stroke=col or 'main', op=0.22 if col else None, rx=3, sw=1.1))
                fs = 9.5 if tw(s, 10) > ww - 6 else 10
                o.append(T(xx + ww / 2, y + 16, s, 'middle', size=fs, bold=True))
        for j, ln in enumerate(wrap(note, 110, 9.5)):
            o.append(T(x0 + 56, base + 16 + j * 13, ln, 'middle', size=9.5, col='b' if k != 1 else 'a'))
    return _svg(360, 238, o, 'サーバの仮想化の方式')


FIG['joho.virt'] = _virt()


def _scale():
    o = []
    o.append(T(86, 14, 'スケールアップ', 'middle', bold=True, size=11, col='b'))
    srv(o, 40, 64)
    o.append(ARROW([(60, 64), (96, 64)], col='b', sw=1.8, head=6))
    o.append(R(108, 30, 42, 68, fill='b', stroke='b', op=0.2, sw=1.4, rx=3))
    for k in range(5):
        o.append(L(116, 42 + k * 9, 142, 42 + k * 9, col='b', sw=1.2))
    o.append(T(86, 120, '部品を高性能にして', 'middle', size=10))
    o.append(T(86, 134, '1台の能力を高める', 'middle', size=10, bold=True))
    o.append(T(270, 14, 'スケールアウト', 'middle', bold=True, size=11, col='c'))
    srv(o, 200, 64)
    o.append(ARROW([(220, 64), (246, 64)], col='c', sw=1.8, head=6))
    for i, x in enumerate((268, 304, 340)):
        srv(o, x, 64, col='c')
    o.append(T(270, 120, 'サーバの台数を増やして', 'middle', size=10))
    o.append(T(270, 134, '処理を分散する', 'middle', size=10, bold=True))
    return _svg(360, 140, o, 'スケールアップとスケールアウト')


FIG['joho.scale'] = _scale()


def _lb():
    o = []
    pc(o, 30, 94, label='クライアント')
    o.append(R(104, 78, 70, 32, fill='c', stroke='c', op=0.22, rx=4, sw=1.3))
    o.append(T(139, 92, 'ロード', 'middle', size=10, bold=True))
    o.append(T(139, 105, 'バランサ', 'middle', size=10, bold=True))
    ys = [40, 98, 156]
    for i, y in enumerate(ys):
        srv(o, 270, y, col='b')
        o.append(T(270, y - 22, 'サーバ%d' % (i + 1), 'middle', size=9.5))
        o.append(ARROW([(176, 94), (254, y)], sw=1.3, head=5))
    o.append(ARROW([(48, 94), (102, 94)], sw=1.3, head=5))
    o.append(T(75, 88, '要求', 'middle', size=9.5))
    o.append(ARROW([(284, 98), (330, 98), (330, 196), (30, 196), (30, 118)], col='a', sw=1.4, head=6, dash='5 3'))
    o.append(T(180, 214, 'DSR：応答はロードバランサを通さず、直接返す', 'middle', size=10, col='a', bold=True))
    return _svg(360, 220, o, 'ロードバランサとDSR')


FIG['joho.lb'] = _lb()


def _cloud():
    o = []
    cols = ['オンプレミス', 'IaaS', 'PaaS', 'SaaS']
    rows = ['データ・利用者ID', 'アプリケーション', 'ミドルウェア', 'OS', 'サーバ・ストレージ・ネットワーク']
    who = [['利', '利', '利', '利'], ['利', '利', '利', '事'], ['利', '利', '事', '事'], ['利', '利', '事', '事'], ['利', '事', '事', '事']]
    lw, cw, rh, top = 108, 62, 30, 26
    for j, c in enumerate(cols):
        o.append(T(lw + j * cw + cw / 2, 17, c, 'middle', bold=True, size=10.5))
    for i, rname in enumerate(rows):
        y = top + i * rh
        ls = wrap(rname, lw - 8, 10)
        for k, ln in enumerate(ls):
            o.append(T(lw - 6, y + rh / 2 + 3.6 + (k - (len(ls) - 1) / 2) * 12.5, ln, 'end', size=10, bold=True))
        for j in range(4):
            u = who[i][j] == '利'
            x = lw + j * cw
            o.append(R(x + 2, y + 2, cw - 4, rh - 4, fill='c' if u else 'b', stroke='c' if u else 'b', op=0.28 if u else 0.18, rx=3, sw=1))
            o.append(T(x + cw / 2, y + rh / 2 + 4, '利用者' if u else '事業者', 'middle', size=10, bold=u))
    y = top + 5 * rh + 18
    o.append(T(4, y, 'データの扱い、利用者IDとアクセス権の管理は、どの形態でも利用者の責任', size=10, col='c', bold=True))
    o.append(T(4, y + 16, 'IaaSでは、OSから上を利用者が管理する', size=10))
    return _svg(360, y + 22, o, 'クラウドの責任分担')


FIG['joho.cloud'] = _cloud()

FIG['joho.deploy'] = grid(['実装の形態', '使い方'],
                          [['パブリッククラウド', '不特定多数の利用者が、事業者の設備を共用する'],
                           ['プライベートクラウド', '特定の組織が専用で使う（自社の設備に構築するオンプレミス型、事業者の設備を専用に使うホステッド型）'],
                           ['コミュニティクラウド', '共通の目的を持つ複数の組織が、共同で使う'],
                           ['ハイブリッドクラウド', 'パブリッククラウドと、プライベートクラウドやオンプレミスを組み合わせる']],
                          [118, 242], align=['l', 'l'], title='クラウドの実装の形態', size=10.5)

FIG['joho.hosting'] = grid(['形態', '建物・電源・回線', 'サーバ'],
                           [['オンプレミス', '自社', '自社が保有'], ['ハウジング（コロケーション）', '事業者（場所などを借りる）', '自社が保有'],
                            ['ホスティング', '事業者', '事業者のサーバを借りる'], ['クラウド', '事業者', '事業者（必要な分だけ使う）']],
                           [124, 120, 116], align=['l', 'c', 'c'], title='設備を持つのは誰か', size=10.5,
                           tcol={'自社': 'c', '自社が保有': 'c'})


def _edge():
    o = []
    for i, y in enumerate((30, 80, 130)):
        circ(o, 24, y, 12, col='c', fill='c', op=0.2)
        o.append(T(24, y + 4, 'S', 'middle', size=10, bold=True, col='c'))
        o.append(ARROW([(38, y), (112, 80 + (y - 80) * 0.25)], col='c', sw=2.6, head=7))
    o.append(T(4, 160, 'センサーなど', size=9.5))
    o.append(T(4, 172, '（デバイス）', size=9.5))
    o.append(T(72, 24, '大量のデータ', 'middle', size=9.5, col='c'))
    _box(o, 116, 52, 92, 56, 'エッジ（近くの\nサーバやゲートウェイ）', col='c', size=9.5, c0='c')
    o.append(T(162, 128, 'すぐに処理・判断', 'middle', size=10, bold=True, col='c'))
    o.append(T(162, 142, '（リアルタイム性）', 'middle', size=9.5))
    o.append(ARROW([(210, 80), (262, 80)], col='b', sw=1.2, head=6))
    o.append(T(236, 72, '必要な分', 'middle', size=9.5, col='b'))
    cloud(o, 310, 80, 92, 62, 'クラウド', col='b', size=11)
    o.append(T(310, 128, '蓄積・分析', 'middle', size=10, bold=True, col='b'))
    o.append(T(4, 196, '送るデータを減らし、回線の負荷と通信の遅れを抑える', size=10))
    o.append(T(4, 212, 'デバイスとの通信には、LPWAなどの省電力の無線を使うことが多い', size=10))
    return _svg(360, 218, o, 'エッジコンピューティングとIoT')


FIG['joho.edge'] = _edge()

FIG['joho.lift'] = _flow(['既存のシステム\n（オンプレミス）', ('リフト\nまずそのまま\nクラウドに移す', 'c'), ('シフト\nクラウドに合わせて\n最適化する', 'b')], 'リフト＆シフト', per_row=3, size=10.5)

# ------------------------------------------------ 1.2.2 情報処理の形態


def _batch():
    o = []
    xs = [112 + k * 22 for k in range(8)]
    o.append(T(4, 30, 'バッチ処理', bold=True, size=11, col='c'))
    o.append(ARROW([(100, 40), (356, 40)], col='line', sw=1, head=5))
    for x in xs:
        circ(o, x, 40, 5, col='c', fill='c', op=0.4)
    brace(o, 106, 272, 22, '一定の期間ためる', col='c', up=True, size=10)
    _box(o, 282, 14, 74, 22, 'まとめて処理', col='c', size=10, c0='c')
    o.append(T(96, 64, '給与計算、月次の集計など', size=10))
    o.append(T(4, 104, 'リアルタイム処理', bold=True, size=11, col='b'))
    o.append(ARROW([(100, 114), (356, 114)], col='line', sw=1, head=5))
    for x in xs:
        circ(o, x, 114, 5, col='b', fill='b', op=0.4)
        o.append(ARROW([(x, 106), (x + 6, 92)], col='b', sw=1, head=4))
        o.append(R(x + 3, 84, 9, 8, fill='b', stroke='b', op=0.5))
    o.append(T(96, 138, '発生したらすぐ処理：座席の予約、ATM、機械の制御など', size=10))
    o.append(T(4, 160, '● ＝データの発生', size=10))
    return _svg(360, 166, o, 'バッチ処理とリアルタイム処理')


FIG['joho.batch'] = _batch()

FIG['joho.stream'] = _rowflow([('ためてから処理', None, ['データをデータベースに蓄積する', 'あとで処理する']),
                               ('ストリームデータ処理', 'b', ['絶え間なく流れるデータを、蓄積する前に、流れてくるまま処理', ('すぐに結果を出す', 'b')]),
                               ('CEP（複合イベント処理）', 'c', ['複数のイベントの組み合わせ（例：温度の上昇と振動の増加）から、意味のあるパターンを見つける',
                                                         ('即座に対応する', 'c')])],
                              'ストリームデータ処理とCEP', lw=84, size=10, bold0=False)

FIG['joho.tss'] = gantt([('利用者A', [('', 0, 1, 'b'), ('', 3, 4, 'b'), ('', 6, 7, 'b')]),
                         ('利用者B', [('', 1, 2, 'c'), ('', 4, 5, 'c'), ('', 7, 8, 'c')]),
                         ('利用者C', [('', 2, 3, 'a'), ('', 5, 6, 'a'), ('', 8, 9, 'a')])], 9, 'タイムシェアリング', lw=64, rh=26,
                        tlabel='CPUの処理時間を細かく区切り、順番に割り当てる')

FIG['joho.oltpolap'] = _flow([('日々の取引の処理\nOLTP（販売、在庫、会計）', 'c'), 'データウェアハウス\nデータを集めて蓄積', ('分析の処理\nOLAP、BI', 'b')],
                             '取引の処理と分析の処理', per_row=3, size=10)

# ------------------------------------------------ 1.2.3 ヒューマンインタフェース


def _ux():
    o = []
    o.append(R(2, 4, 356, 128, fill='b', stroke='b', op=0.08, rx=8, sw=1.2))
    o.append(T(10, 22, 'UX：製品やサービスで利用者が得る体験の全体', bold=True, size=11, col='b'))
    for i, s in enumerate(['使う前', '使っている間', '使った後']):
        x = 12 + i * 116
        _box(o, x, 32, 104, 30, s, col='b', size=10.5, c0='b', op=0.2)
        if i < 2:
            o.append(ARROW([(x + 106, 47), (x + 114, 47)], sw=1.2, head=4))
    o.append(L(180, 62, 180, 78, col='c', sw=1.4))
    _box(o, 74, 78, 212, 46, 'UI：利用者とシステムの接点\n画面、ボタン、操作の方法（UXを形づくる要素の1つ）', col='c', size=10, c0='c', op=0.22)
    o.append(T(4, 152, 'ユーザビリティ（ISO 9241-11）：特定の利用者が特定の状況で目標を', size=10.5))
    o.append(T(4, 168, '達成するときの、有効さ・効率・満足度の度合い', size=10.5))
    return _svg(360, 174, o, 'UX、UI、ユーザビリティ')


FIG['joho.ux'] = _ux()


def _uiparts():
    o = []
    # テキストボックス
    o.append(T(6, 14, 'テキストボックス', bold=True, size=10.5))
    o.append(R(6, 22, 160, 26, fill='sheet', stroke='main', sw=1.2, rx=3))
    o.append(T(14, 40, '山田 太郎', size=11))
    o.append(L(66, 28, 66, 42, col='main', sw=1.2))
    o.append(T(6, 64, '文字を自由に入力する', size=10, col='sub'))
    # プルダウン
    o.append(T(190, 14, 'プルダウンメニュー', bold=True, size=10.5))
    o.append(R(190, 22, 160, 26, fill='sheet', stroke='main', sw=1.2, rx=3))
    o.append(T(198, 40, '東京都', size=11))
    o.append('<path d="M334 31 L344 31 L339 38 Z" style="fill:currentColor"/>')
    o.append(R(190, 48, 160, 54, fill='sheet', stroke='line', sw=1))
    for k, s in enumerate(['北海道', '東京都', '大阪府']):
        if k == 1:
            o.append(R(191, 50 + k * 17, 158, 17, fill='c', stroke=None, op=0.25))
        o.append(T(198, 63 + k * 17, s, size=10.5))
    o.append(T(190, 118, '一覧から選ぶ', size=10, col='b', bold=True))
    o.append(T(190, 132, '（入力の誤りや表記のゆれを防ぐ）', size=10, col='sub'))
    # ラジオボタン
    o.append(T(6, 92, 'ラジオボタン', bold=True, size=10.5))
    for k, s in enumerate(['小', '中', '大']):
        x = 14 + k * 52
        circ(o, x, 110, 6.5, col='main')
        if k == 1:
            o.append('<circle cx="%s" cy="110" r="3.4" style="fill:currentColor"/>' % x)
        o.append(T(x + 11, 114, s, size=11))
    o.append(T(6, 136, '1つだけを選ぶ', size=10, col='b', bold=True))
    # チェックボックス
    o.append(T(6, 164, 'チェックボックス', bold=True, size=10.5))
    for k, s in enumerate(['メール', '電話', '郵送']):
        x = 8 + k * 64
        o.append(R(x, 175, 13, 13, fill='sheet', stroke='main', sw=1.2, rx=2))
        if k != 1:
            o.append('<path d="M%s 181 L%s 186 L%s 177" style="fill:none;stroke:currentColor" stroke-width="1.8"/>' % (x + 2.5, x + 6, x + 11))
        o.append(T(x + 18, 186, s, size=11))
    o.append(T(6, 208, '複数を選べる', size=10, col='b', bold=True))
    return _svg(360, 214, o, '入力のための部品')


FIG['joho.uiparts'] = _uiparts()


def _kana():
    o = []
    o.append(T(80, 14, 'トグル入力', 'middle', bold=True, size=11))
    o.append(R(10, 26, 40, 40, fill='c', stroke='c', op=0.2, rx=6, sw=1.3))
    o.append(T(30, 52, 'あ', 'middle', size=16, bold=True))
    o.append(T(30, 84, '何度も押す', 'middle', size=9.5))
    seq_ = ['あ', 'い', 'う', 'え', 'お']
    for k, s in enumerate(seq_):
        x = 66 + k * 22
        o.append(T(x, 52, s, 'middle', size=12, bold=True))
        if k < 4:
            o.append(ARROW([(x + 6, 47), (x + 16, 47)], sw=1, head=3.5))
    o.append(T(260, 14, 'フリック入力', 'middle', bold=True, size=11))
    cx, cy = 260, 66
    for dx, dy, s in [(0, 0, 'あ'), (-34, 0, 'い'), (0, -32, 'う'), (34, 0, 'え'), (0, 32, 'お')]:
        main = (dx == 0 and dy == 0)
        o.append(R(cx + dx - 15, cy + dy - 14, 30, 28, fill='b' if main else 'sheet', stroke='b' if main else 'line', op=0.25 if main else None, rx=5, sw=1.2))
        o.append(T(cx + dx, cy + dy + 5, s, 'middle', size=13, bold=True))
    o.append(T(260, 128, 'キーから上下左右に指をずらす', 'middle', size=9.5))
    return _svg(360, 134, o, 'スマートフォンの文字入力')


FIG['joho.kana'] = _kana()


def _color():
    o = []
    o.append(T(86, 14, '色だけで区別する', 'middle', bold=True, size=10.5, col='a'))
    o.append(T(270, 14, '形や文字も併せて使う', 'middle', bold=True, size=10.5, col='b'))
    for k, colr in enumerate(['#d32f2f', '#388e3c']):
        circ(o, 60 + k * 52, 42, 10, col=colr, fill=colr, op=0.85)
    o.append('<path d="M232 52 L242 34 L252 52 Z" style="fill:#d32f2f;fill-opacity:0.85"/>')
    o.append(T(258, 47, '不合格', size=10.5, bold=True))
    circ(o, 312, 42, 10, col='#388e3c', fill='#388e3c', op=0.85)
    o.append(T(326, 47, '合格', size=10.5, bold=True))
    o.append(T(86, 72, '色の区別がつきにくい人がいる', 'middle', size=9.5))
    o.append(R(10, 88, 160, 34, fill='#ffffff', stroke='line', rx=4))
    o.append(T(90, 110, '明度の差が小さい', 'middle', size=11.5, bold=True, col='#c9c9c9'))
    o.append(R(190, 88, 160, 34, fill='#ffffff', stroke='line', rx=4))
    o.append(T(270, 110, '明度の差が大きい', 'middle', size=11.5, bold=True, col='#202020'))
    o.append(T(90, 140, '読みにくい', 'middle', size=10, col='a', bold=True))
    o.append(T(270, 140, '読みやすい', 'middle', size=10, col='b', bold=True))
    return _svg(360, 146, o, '色の使い方')


FIG['joho.color'] = _color()


def _scr(o, x, y, w, h, cols, col='main'):
    o.append(R(x, y, w, h, fill='sheet', stroke=col, sw=1.3, rx=3))
    o.append(R(x + 3, y + 3, w - 6, 6, fill=col, stroke=None, op=0.35))
    gw = (w - 6 - (cols - 1) * 3) / cols
    for c in range(cols):
        o.append(R(x + 3 + c * (gw + 3), y + 12, gw, h - 15, fill=col, stroke=None, op=0.15))


def _resp():
    o = []
    o.append(T(4, 14, 'レスポンシブデザイン', bold=True, size=11, col='b'))
    _box(o, 4, 24, 92, 40, '1つのHTML\n＋CSSのメディアクエリ', col='b', size=9.5, c0='b')
    o.append(ARROW([(98, 44), (120, 44)], sw=1.3, head=5, col='b'))
    _scr(o, 126, 22, 92, 50, 3, 'b')
    _scr(o, 230, 26, 62, 44, 2, 'b')
    _scr(o, 304, 22, 30, 50, 1, 'b')
    o.append(T(232, 90, '画面の幅に応じて、レイアウトが自動で変わる', 'middle', size=9.5))
    o.append(T(4, 116, 'アダプティブデザイン', bold=True, size=11, col='c'))
    _box(o, 4, 128, 92, 40, '端末の種類を\n判別する', col='c', size=9.5, c0='c')
    o.append(ARROW([(98, 140), (148, 136)], sw=1.3, head=5, col='c'))
    o.append(ARROW([(98, 156), (240, 160)], sw=1.3, head=5, col='c'))
    _scr(o, 152, 118, 80, 40, 3, 'c')
    o.append(T(192, 172, 'PC用', 'middle', size=9.5))
    _scr(o, 246, 132, 26, 44, 1, 'c')
    o.append(T(259, 190, 'スマートフォン用', 'middle', size=9.5))
    o.append(T(316, 150, '端末ごとに', 'middle', size=9.5))
    o.append(T(316, 163, '別に用意', 'middle', size=9.5))
    return _svg(360, 196, o, 'レスポンシブデザインとアダプティブデザイン')


FIG['joho.resp'] = _resp()


def _wire():
    o = []
    x, y, w, h = 60, 6, 240, 150
    o.append(R(x, y, w, h, fill='sheet', stroke='main', sw=1.2))
    o.append(R(x + 8, y + 8, 50, 18, fill='none', stroke='main', sw=1))
    o.append(T(x + 33, y + 21, 'ロゴ', 'middle', size=9.5))
    for k in range(3):
        o.append(R(x + 120 + k * 38, y + 12, 32, 10, fill='none', stroke='main', sw=1))
    o.append(T(x + 176, y + 36, 'メニュー', 'middle', size=9))
    o.append(R(x + 8, y + 42, w - 16, 46, fill='none', stroke='main', sw=1))
    o.append(L(x + 8, y + 42, x + w - 8, y + 88, col='line', sw=0.8))
    o.append(L(x + w - 8, y + 42, x + 8, y + 88, col='line', sw=0.8))
    o.append(T(x + w / 2, y + 69, '画像', 'middle', size=10, bold=True))
    for k in range(3):
        o.append(L(x + 8, y + 100 + k * 10, x + (w - 8 if k < 2 else 160), y + 100 + k * 10, col='line', sw=2))
    o.append(R(x + 8, y + 130, w - 16, 12, fill='none', stroke='main', sw=1))
    o.append(T(x + w / 2, y + 140, 'フッター', 'middle', size=8.5))
    o.append(T(180, 172, '線と枠で、どこに何を置くかを示す', 'middle', size=10))
    return _svg(360, 178, o, 'ワイヤーフレーム')


FIG['joho.wire'] = _wire()

FIG['joho.uieval'] = _lists([('ヒューリスティック評価', 'c', ['専門家が、経験則に照らして問題を見つける']), ('ユーザテスト', 'b', ['利用者に実際に使ってもらう'])],
                            'ユーザビリティの評価', size=10.5)

# ------------------------------------------------ 1.2.4 外部情報資源の活用


def _outsrc():
    o = []
    rows = [('自社', '外部の専門の事業者', 'アウトソーシング', '業務や情報システムの開発・運用を委託', 'r', 'c'),
            ('自社', '外部の事業者', 'BPO', '経理、人事、コールセンターなどの業務の処理そのものを委託', 'r', 'c'),
            ('自社', '外部の事業者', 'インソーシング', '外部に委託していた業務を社内に戻す', 'l', 'b'),
            ('自社', '不特定多数の人', 'クラウドソーシング', 'インターネットを通じて発注', 'r', 'a')]
    for i, (a, b, nm, d, dirn, col) in enumerate(rows):
        y = 4 + i * 50
        _box(o, 2, y + 10, 54, 28, a, size=10.5)
        _box(o, 266, y + 10, 92, 28, b, size=9.5)
        if dirn == 'r':
            o.append(ARROW([(60, y + 24), (262, y + 24)], col=col, sw=1.8, head=7))
        else:
            o.append(ARROW([(262, y + 24), (60, y + 24)], col=col, sw=1.8, head=7))
        o.append(T(160, y + 18, nm, 'middle', size=10.5, bold=True, col=col))
        ls = wrap(d, 196, 9.5)
        for k, ln in enumerate(ls):
            o.append(T(160, y + 37 + k * 12, ln, 'middle', size=9.5))
    return _svg(360, 206, o, '外部の資源を活用する形態')


FIG['joho.outsrc'] = _outsrc()


def _opendata():
    o = []
    items = ['①営利・非営利を問わず\n二次利用できる\nルールを適用', '②機械判読に\n適する', '③無償で\n利用できる']
    for i, s in enumerate(items):
        x = 4 + i * 120
        _box(o, x, 4, 112, 56, s, col='b', size=10, bold0=False, op=0.16)
    brace(o, 4, 356, 72, 'すべてに当てはまる形で公開＝オープンデータ', col='b', size=11)
    o.append(T(4, 112, '個人情報を含むデータは、そのままでは公開できない', size=10, col='a', bold=True))
    return _svg(360, 118, o, 'オープンデータの条件')


FIG['joho.opendata'] = _opendata()


def _search():
    o = []
    defs = [('AND検索', 'すべての語を含む（絞り込む）', 'and'), ('OR検索', 'いずれかの語を含む（広げる）', 'or'), ('NOT検索', 'Aを含み、Bを含まない', 'not')]
    for k, (ttl, note, mode) in enumerate(defs):
        cx = 60 + k * 120
        ax, bx, cy, r = cx - 16, cx + 16, 56, 30
        o.append(T(cx, 14, ttl, 'middle', bold=True, size=11))
        cid = 'jh-srch-%d' % k
        o.append('<clipPath id="%s"><circle cx="%s" cy="%s" r="%s"/></clipPath>' % (cid, ax, cy, r))
        if mode == 'or':
            for x in (ax, bx):
                o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;fill-opacity:0.35;stroke:none"/>' % (x, cy, r, _c('b')))
        elif mode == 'and':
            o.append('<circle cx="%s" cy="%s" r="%s" clip-path="url(#%s)" style="fill:%s;fill-opacity:0.5;stroke:none"/>' % (bx, cy, r, cid, _c('b')))
        else:
            o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;fill-opacity:0.45;stroke:none"/>' % (ax, cy, r, _c('b')))
            o.append('<circle cx="%s" cy="%s" r="%s" clip-path="url(#%s)" style="fill:var(--sheet);stroke:none"/>' % (bx, cy, r, cid))
        for x in (ax, bx):
            o.append('<circle cx="%s" cy="%s" r="%s" style="fill:none;stroke:currentColor" stroke-width="1.2"/>' % (x, cy, r))
        o.append(T(ax - 12, cy + 4, 'A', 'middle', size=11, bold=True))
        o.append(T(bx + 12, cy + 4, 'B', 'middle', size=11, bold=True))
        for j, ln in enumerate(wrap(note, 112, 9.5)):
            o.append(T(cx, 104 + j * 13, ln, 'middle', size=9.5))
    return _svg(360, 126, o, 'AND検索、OR検索、NOT検索')


FIG['joho.search'] = _search()

FIG['joho.match'] = grid(['方式', '検索の語', '当てはまる例'],
                         [['前方一致', 'comput*', 'computer、computing'], ['後方一致', '*ware', 'software、hardware'], ['完全一致', 'computer', 'computerだけ']],
                         [90, 110, 160], align=['l', 'l', 'l'], title='一致の方式', size=10.5)


def _serp():
    o = []
    st = ['クローラが\nWebページを巡回', '集めた情報で\n索引をつくる', '検索の結果の\nページ（SERP）']
    for i, s in enumerate(st):
        _box(o, 2 + i * 122, 4, 108, 38, s, size=9.5, bold0=False)
        if i:
            o.append(ARROW([(2 + i * 122 - 12, 23), (2 + i * 122 - 2, 23)], sw=1.2, head=4))
    o.append(R(2, 54, 250, 172, fill='sheet', stroke='main', sw=1.2, rx=4))
    o.append(R(10, 62, 200, 20, fill='sheet', stroke='line', rx=10))
    o.append(T(20, 76, '新宿　カフェ', size=10))
    for k in range(2):
        y = 92 + k * 30
        o.append(R(8, y, 238, 26, fill='c', stroke=None, op=0.14, rx=2))
        o.append(T(14, y + 11, '広告', size=8.5, bold=True, col='c'))
        o.append(L(40, y + 8, 200, y + 8, col='c', sw=2.2))
        o.append(L(14, y + 18, 236, y + 18, col='line', sw=1.2))
    for k in range(3):
        y = 156 + k * 22
        o.append(L(14, y + 2, 180, y + 2, col='b', sw=2.2))
        o.append(L(14, y + 11, 236, y + 11, col='line', sw=1.2))
    o.append(T(258, 104, 'リスティング広告', size=10, bold=True, col='c'))
    o.append(T(258, 118, '（検索の結果に', size=9.5))
    o.append(T(258, 131, '　表示する広告）', size=9.5))
    o.append(T(258, 172, '自然検索の結果', size=10, bold=True, col='b'))
    o.append(T(258, 186, 'SEOで上位を', size=9.5))
    o.append(T(258, 199, '目指す', size=9.5))
    o.append(T(4, 244, 'SEM（検索エンジンマーケティング）＝SEO＋リスティング広告', size=10.5, bold=True))
    return _svg(360, 250, o, '検索エンジンとSEO・SEM')


FIG['joho.serp'] = _serp()


def _price():
    gs = []
    for k, (ttl, kind) in enumerate([('サブスクリプション', 'flat'), ('従量課金', 'lin'), ('フリーミアム', 'frm')]):
        g = G(xmax=10, ymax=10, w=118, h=140, ox=k * 121, pl=14, pr=6, pt=16, pb=30, cap=ttl, ccol='b' if k != 2 else 'c',
              xlab='', ylab='料金', origin='', size=10)
        if kind == 'flat':
            g.line([(0, 5), (10, 5)], col='b', sw=2.4)
            g.text(5, 6.6, '期間あたり定額', 'middle', 'main', False, 9.5)
            g.text(5, -1.6, '利用量', 'middle', 'main', False, 9.5)
        elif kind == 'lin':
            g.line([(0, 0), (10, 8.5)], col='b', sw=2.4)
            g.text(4.6, 6.4, '使った量に応じる', 'middle', 'main', False, 9.5)
            g.text(5, -1.6, '利用量', 'middle', 'main', False, 9.5)
        else:
            g.rect(1, 0, 4, 0.4, col='c', op=0.5)
            g.rect(6, 0, 9, 6.5, col='c', op=0.35)
            g.text(2.5, 2.2, '無料', 'middle', 'c', True, 10)
            g.text(7.5, 7.8, '有料', 'middle', 'c', True, 10)
            g.text(2.5, -1.6, '基本の機能', 'middle', 'main', False, 9)
            g.text(7.5, -1.6, '付加的な機能', 'middle', 'main', False, 9)
        gs.append(g)
    return panels(gs, 'サービスの課金の方式', h=142)


FIG['joho.price'] = _price()

# ------------------------------------------------ 1.3.1 データベースの種類と構成


def _dbmodel():
    o = []
    for k, t in enumerate(['階層型', 'ネットワーク型', '関係型']):
        o.append(T(58 + k * 122, 14, t, 'middle', bold=True, size=11))

    def node(x, y, s, col='b'):
        o.append(R(x - 17, y - 10, 34, 20, fill=col, stroke=col, op=0.22, rx=3, sw=1.1))
        o.append(T(x, y + 4, s, 'middle', size=9.5, bold=True))
    tree = {(58, 38): [(30, 76), (86, 76)], (30, 76): [(16, 112), (44, 112)], (86, 76): [(72, 112), (100, 112)]}
    for p, chs in tree.items():
        for c in chs:
            o.append(L(p[0], p[1] + 10, c[0], c[1] - 10, col='main', sw=1.1))
    node(58, 38, '部')
    for x, s in [(30, '課A'), (86, '課B')]:
        node(x, 76, s)
    for x in (16, 44, 72, 100):
        o.append(R(x - 12, 102, 24, 20, fill='c', stroke='c', op=0.22, rx=3, sw=1))
        o.append(T(x, 116, '人', 'middle', size=9.5, bold=True))
    o.append(T(58, 142, '子は1つの親だけ', 'middle', size=9.5, col='a', bold=True))
    par = [(152, 44), (212, 44)]
    chs = [(152, 106), (212, 106)]
    for p in par:
        o.append(L(p[0], p[1] + 10, chs[0][0], chs[0][1] - 10, col='main', sw=1.1))
    o.append(L(212, 54, 212, 96, col='main', sw=1.1))
    node(152, 44, '親1')
    node(212, 44, '親2')
    node(152, 106, '子1', 'c')
    node(212, 106, '子2', 'c')
    o.append(T(180, 142, '子が複数の親を持てる', 'middle', size=9.5, col='b', bold=True))
    dtab(o, 246, 26, ['氏名', '部門'], [['佐藤', '10'], ['鈴木', '20']], [56, 46], size=9.5, rh=17, hl={(-1, 1): 'c'})
    dtab(o, 262, 92, ['部門', '名前'], [['10', '営業'], ['20', '総務']], [46, 46], size=9.5, rh=17, hl={(-1, 0): 'c'})
    o.append(L(325, 77, 325, 84, col='c', sw=1.4))
    o.append(L(285, 84, 325, 84, col='c', sw=1.4))
    o.append(L(285, 84, 285, 92, col='c', sw=1.4))
    o.append(T(302, 156, '共通の項目で関連づける', 'middle', size=9.5, col='b', bold=True))
    return _svg(360, 162, o, 'データベースのモデル')


FIG['joho.dbmodel'] = _dbmodel()


def _nosql():
    o = []
    pan = [(2, 4, 'キー・バリュー型', 'b'), (184, 4, 'ドキュメント型', 'c'), (2, 112, 'カラム指向型', 'a'), (184, 112, 'グラフ型', 'b')]
    for x, y, t, col in pan:
        o.append(R(x, y, 174, 100, fill=col, stroke=col, op=0.06, rx=6, sw=1))
        o.append(T(x + 8, y + 16, t, bold=True, size=10.5, col=col))
    for k, (a, b) in enumerate([('user:15', '佐藤'), ('cart:15', 'A, B')]):
        y = 30 + k * 28
        o.append(R(10, y, 70, 22, fill='b', stroke='b', op=0.2, rx=3))
        o.append('<text x="16" y="%s" font-size="10" style="fill:currentColor;font-family:%s">%s</text>' % (y + 15, MONO, a))
        o.append(ARROW([(82, y + 11), (100, y + 11)], sw=1.1, head=4))
        o.append(R(104, y, 64, 22, fill='sheet', stroke='line', rx=3))
        o.append(T(136, y + 15, b, 'middle', size=10))
    o.append(T(10, 98, 'キーで値を読み書き。速い', size=9.5))
    code(o, 192, 26, 158, ['{"name": "佐藤",', ' "tags": ["A", "B"]}'], size=9.5)
    o.append(T(192, 98, 'JSONなどの文書をそのまま', size=9.5))
    hd = ['ID', '地域', '売上']
    for j, h in enumerate(hd):
        x = 12 + j * 44
        o.append(R(x, 134, 38, 58, fill='a' if j == 2 else 'sheet', stroke='a' if j == 2 else 'line', op=0.2 if j == 2 else None, rx=3, sw=1.1))
        o.append(T(x + 19, 148, h, 'middle', size=9.5, bold=True))
        for i in range(3):
            o.append(L(x + 7, 160 + i * 10, x + 31, 160 + i * 10, col='line', sw=2))
    o.append(T(144, 160, '列ごと', size=9.5, col='a', bold=True))
    o.append(T(144, 173, 'に格納', size=9.5, col='a', bold=True))
    o.append(T(10, 206, '特定の列の集計が速い', size=9.5))
    pts = {'佐藤': (220, 150), '鈴木': (300, 138), '田中': (250, 180), '高橋': (330, 172)}
    for a, b in [('佐藤', '鈴木'), ('佐藤', '田中'), ('鈴木', '高橋'), ('田中', '高橋')]:
        o.append(L(pts[a][0], pts[a][1], pts[b][0], pts[b][1], col='b', sw=1.4))
    for s, (x, y) in pts.items():
        circ(o, x, y, 13.5, col='b', fill='b', op=0.22)
        o.append(T(x, y + 4, s, 'middle', size=9.5, bold=True))
    o.append(T(232, 206, 'ノードとエッジ（SNSの関係）', size=9.5))
    return _svg(360, 214, o, 'NoSQLの種類')


FIG['joho.nosql'] = _nosql()


def _schema3():
    o = []
    _box(o, 2, 4, 116, 40, '外部スキーマ\n利用者Aのビュー', col='c', size=10, c0='c')
    _box(o, 130, 4, 116, 40, '外部スキーマ\nアプリBのビュー', col='c', size=10, c0='c')
    _box(o, 2, 70, 244, 40, '概念スキーマ\nデータベース全体の論理的な構造（表の定義など）', col='b', size=10, c0='b')
    _box(o, 2, 136, 244, 40, '内部スキーマ\n記憶装置への物理的な格納の方法', col='a', size=10, c0='a')
    for x in (60, 188):
        o.append(ARROW([(x, 46), (x, 68)], sw=1.2, head=5))
    o.append(ARROW([(124, 112), (124, 134)], sw=1.2, head=5))
    cyl(o, 300, 156, w=46, h=38, col='a')
    o.append(T(256, 74, 'データの独立性', size=10.5, bold=True, col='b'))
    for k, s in enumerate(['物理的な格納の', '方法を変えても、', '利用者の側に', '影響が及ばない']):
        o.append(T(256, 92 + k * 13, s, size=9.5))
    return _svg(360, 182, o, '3層スキーマ')


FIG['joho.schema3'] = _schema3()


def _datakind():
    o = []
    for k, (t, col) in enumerate([('構造化データ', 'b'), ('半構造化データ', 'c'), ('非構造化データ', 'a')]):
        o.append(T(58 + k * 122, 14, t, 'middle', bold=True, size=10.5, col=col))
    dtab(o, 4, 24, ['ID', '氏名', '点'], [['1', '佐藤', '80'], ['2', '鈴木', '72']], [30, 52, 32], size=9.5, rh=18)
    o.append(T(58, 104, '行と列の表', 'middle', size=9.5))
    o.append(T(58, 117, '（関係データベース）', 'middle', size=9.5))
    code(o, 124, 24, 112, ['{"id": 1,', ' "name": "佐藤"}'], size=9.5)
    o.append(T(180, 104, 'タグやキーで', 'middle', size=9.5))
    o.append(T(180, 117, '構造の一部を示す', 'middle', size=9.5))
    o.append(T(180, 130, '（JSON、XML、YAML）', 'middle', size=9.5))
    o.append(R(254, 26, 30, 38, fill='sheet', stroke='main', sw=1.1, rx=2))
    for i in range(4):
        o.append(L(259, 34 + i * 7, 279, 34 + i * 7, col='line', sw=1.4))
    o.append(R(292, 26, 34, 30, fill='sheet', stroke='main', sw=1.1, rx=2))
    o.append('<path d="M294 54 L304 40 L312 50 L317 45 L324 54 Z" style="fill:%s;fill-opacity:0.6"/>' % _c('a'))
    o.append('<path d="M332 44 q4 -10 8 0 t8 0 t8 0" style="fill:none;stroke:%s" stroke-width="1.6"/>' % _c('a'))
    o.append(T(302, 82, '文書、画像、', 'middle', size=9.5))
    o.append(T(302, 95, '音声、動画', 'middle', size=9.5))
    o.append(T(302, 117, '決まった構造がない', 'middle', size=9.5))
    return _svg(360, 136, o, 'データの種類')


FIG['joho.datakind'] = _datakind()

# ------------------------------------------------ 1.3.2 データベース管理システム


def _keys():
    o = []
    dtab(o, 4, 26, ['顧客番号', '顧客名'], [['C01', '佐藤商店'], ['C02', '鈴木商事']], [64, 80], name='顧客', size=10, rh=20, pk=(0,))
    dtab(o, 168, 26, ['注文番号', '顧客番号', '金額'], [['O1', 'C01', '5,000'], ['O2', 'C02', '3,000'], ['O3', 'C09', '2,000']],
         [62, 62, 64], name='注文', size=10, rh=20, pk=(0,), fk=(1,), hl={(2, 1): 'a'}, align=['c', 'c', 'r'])
    o.append(ARROW([(261, 41), (261, 12), (40, 12), (40, 40)], col='b', sw=1.2, head=5))
    o.append(T(150, 8, '参照', 'middle', size=9.5, col='b', bold=True))
    o.append(T(168, 138, 'C09は顧客の表にない', size=10, col='a', bold=True))
    o.append(T(168, 152, '→ 参照整合性に反する', size=10, col='a', bold=True))
    o.append(T(4, 120, '実線の下線＝主キー', size=10))
    o.append(T(4, 134, '（同じ値も空の値も不可）', size=9.5))
    o.append(T(4, 152, '点線の下線＝外部キー', size=10))
    o.append(T(4, 166, '（他の表の主キーを参照）', size=9.5))
    return _svg(360, 172, o, '主キー、外部キー、参照整合性')


FIG['joho.keys'] = _keys()

FIG['joho.acid'] = quad(('', ''), ('', ''), [[('原子性（Atomicity）', 'すべて実行されるか、まったく実行されないか。振込の途中で障害→出金も取り消す', 'a'),
                                               ('一貫性（Consistency）', '処理の前後で整合性が保たれる（口座の合計額が変わらない）', 'b')],
                                              [('独立性（Isolation）', '同時に実行しても互いに影響しない。順番に実行したときと同じ結果', 'c'),
                                               ('耐久性（Durability）', 'コミットした結果は、その後に障害が起きても失われない', 'b')]], 'ACID特性', size=10.5)


def _lost():
    o = []
    dtab(o, 4, 4, ['', '利用者A（＋50）', '利用者B（－30）', '在庫'],
         [['1', '在庫を読む：100', '', '100'], ['2', '', '在庫を読む：100', '100'], ['3', '100＋50＝150を書く', '', '150'], ['4', '', '100－30＝70を書く', '70']],
         [26, 130, 130, 64], size=10, rh=22, hl={(3, None): 'a'})
    o.append(T(4, 140, 'Aの更新が失われた（正しくは120）', size=10.5, col='a', bold=True))
    o.append(T(4, 158, 'Aが更新を終えるまで、データにロックをかけてBを待たせれば防げる', size=10, col='b'))
    return _svg(360, 164, o, '更新が失われる例')


FIG['joho.lost'] = _lost()


def _deadlock():
    o = []
    _box(o, 2, 66, 100, 40, 'トランザクション1', col='b', size=10, c0='b')
    _box(o, 258, 66, 100, 40, 'トランザクション2', col='c', size=10, c0='c')
    cyl(o, 180, 30, w=70, h=40, inside='データX')
    cyl(o, 180, 142, w=70, h=40, inside='データY')
    o.append(ARROW([(144, 30), (50, 30), (50, 64)], col='b', sw=1.8, head=6))
    o.append(T(96, 24, 'ロック済み', 'middle', size=9.5, col='b', bold=True))
    o.append(ARROW([(50, 108), (50, 142), (142, 142)], col='b', sw=1.4, head=6, dash='5 3'))
    o.append(T(96, 156, '待つ', 'middle', size=9.5, col='b', bold=True))
    o.append(ARROW([(216, 142), (310, 142), (310, 108)], col='c', sw=1.8, head=6))
    o.append(T(264, 156, 'ロック済み', 'middle', size=9.5, col='c', bold=True))
    o.append(ARROW([(310, 64), (310, 30), (218, 30)], col='c', sw=1.4, head=6, dash='5 3'))
    o.append(T(264, 24, '待つ', 'middle', size=9.5, col='c', bold=True))
    o.append(T(180, 92, '互いに待ち、', 'middle', size=10, col='a', bold=True))
    o.append(T(180, 106, 'どちらも進めない', 'middle', size=10, col='a', bold=True))
    return _svg(360, 170, o, 'デッドロック')


FIG['joho.deadlock'] = _deadlock()

FIG['joho.lock'] = grid(['ロック', '他の利用者の読み取り', '他の利用者の更新'],
                        [['共有ロック', 'できる', 'できない'], ['専有ロック（排他ロック）', 'できない', 'できない']],
                        [140, 110, 110], align=['l', 'c', 'c'], title='ロックの種類', size=10.5, tcol={'できる': 'b', 'できない': 'a'})

FIG['joho.lockgr'] = grid(['ロックの粒度', '管理', '待ちと同時の処理'],
                          [['大きい（表全体など）', '簡単', '待ちが増え、同時に処理できる量が減る'], ['小さい（行など）', '手間が増える', '同時に処理しやすい']],
                          [120, 76, 164], align=['l', 'c', 'l'], title='ロックの粒度', size=10.5)


def _recover():
    o = []
    X = lambda t: 24 + t * 2.9
    o.append(ARROW([(X(0), 40), (X(104), 40)], col='line', sw=1.1, head=5))
    for t, s, col, an in [(0, 'バックアップ', 'b', 'start'), (100, '障害', 'a', 'middle')]:
        o.append(L(X(t), 30, X(t), 50, col=col, sw=2))
        o.append(T(X(t) - (10 if an == 'start' else 0), 22, s, an, size=10, bold=True, col=col))
    o.append(L(X(38), 34, X(38), 46, col='main', sw=1.2, dash='2 2'))
    o.append(T(X(38), 22, 'チェックポイント', 'middle', size=9.5))
    trs = [('T1', 10, 34, True), ('T2', 28, 70, True), ('T3', 64, 100, False)]
    for i, (nm, a, b, cm) in enumerate(trs):
        y = 62 + i * 22
        col = 'b' if cm else 'a'
        o.append(R(X(a), y, X(b) - X(a), 14, fill=col, stroke=col, op=0.25, rx=3, sw=1))
        o.append(T(X(a) - 4, y + 11, nm, 'end', size=10, bold=True))
        if cm:
            circ(o, X(b), y + 7, 4.5, col='b', fill='b', op=1)
        else:
            o.append(T(X(b) + 4, y + 11, '未確定', size=9.5, col='a', bold=True))
    o.append(T(X(70) + 8, 80, '●＝コミット（確定）', size=9.5, col='b'))
    o.append(T(4, 148, 'トランザクションの途中の障害：ロールバック', bold=True, size=10.5, col='a'))
    o.append(ARROW([(X(100), 160), (X(64), 160)], col='a', sw=1.8, head=6))
    o.append(T(X(100), 178, '更新前ログで、未確定のT3を取り消す', 'end', size=10))
    o.append(T(4, 204, 'ディスクの故障：ロールフォワード', bold=True, size=10.5, col='b'))
    o.append(ARROW([(X(0), 216), (X(70), 216)], col='b', sw=1.8, head=6))
    o.append(T(4, 236, 'バックアップから復元し、更新後ログでT1・T2をやり直す', size=10))
    return _svg(360, 242, o, 'ロールバックとロールフォワード')


FIG['joho.recover'] = _recover()

FIG['joho.2pc'] = seq([('調整役', 'c'), ('DBサーバ1', None), ('DBサーバ2', None)],
                      [(0, 0, '第1相：確定の準備ができたかを確かめる'), (0, 1, '準備は？'), (0, 2, '準備は？'), (1, 0, 'OK', 'b', True), (2, 0, 'OK', 'b', True),
                       (0, 0, '第2相：すべてOKなら一斉に確定（1つでもOKでなければ、すべて取り消す）'), (0, 1, '確定', 'b'), (0, 2, '確定', 'b')],
                      '2相コミット', rowh=30, size=10)


def _norm0():
    o = []
    o.append(T(4, 14, '非正規形：1つの行の中に、商品が繰り返し現れる', bold=True, size=10.5, col='a'))
    dtab(o, 4, 22, ['受注番号', '受注日', '顧客名', '商品（繰り返し項目）'],
         [['1001', '5/1', '佐藤商店', 'P1 ボールペン 10、P2 ノート 5'], ['1002', '5/2', '鈴木商事', 'P1 ボールペン 3']],
         [58, 46, 66, 182], size=9.5, rh=20, hl={(0, 3): 'a', (1, 3): 'a'}, align=['c', 'c', 'c', 'l'])
    o.append(ARROW([(180, 88), (180, 106)], sw=1.5, head=6))
    o.append(T(4, 124, '第1正規形：1つの欄に1つの値（一部の列を省略）', bold=True, size=10.5, col='b'))
    dtab(o, 4, 132, ['受注番号', '受注日', '顧客名', '商品コード', '商品名', '数量'],
         [['1001', '5/1', '佐藤商店', 'P1', 'ボールペン', '10'], ['1001', '5/1', '佐藤商店', 'P2', 'ノート', '5'], ['1002', '5/2', '鈴木商事', 'P1', 'ボールペン', '3']],
         [58, 46, 66, 62, 72, 46], size=9.5, rh=20, pk=(0, 3), hl={(0, 2): 'c', (1, 2): 'c'})
    o.append(T(4, 228, '顧客名などの重複は残る → 第2・第3正規形でなくす', size=10, col='c', bold=True))
    return _svg(360, 234, o, '非正規形と第1正規形')


FIG['joho.norm0'] = _norm0()


def _normfd():
    o = []
    o.append(_dashrect(4, 6, 96, 168, col='main', rx=8))
    o.append(T(52, 190, '主キー（2つの組）', 'middle', size=10, bold=True))
    _box(o, 12, 16, 80, 30, '受注番号', col='b', size=10.5, c0='b')
    _box(o, 12, 134, 80, 30, '商品コード', col='b', size=10.5, c0='b')
    items = {'受注日': (172, 6), '顧客番号': (172, 40), '数量': (172, 74), '商品名': (172, 110), '単価': (172, 144)}
    for nm, (x, y) in items.items():
        _box(o, x, y, 74, 26, nm, size=10.5)
    _box(o, 278, 40, 78, 26, '顧客名', size=10.5)
    o.append(ARROW([(92, 26), (170, 19)], col='c', sw=1.5, head=6))
    o.append(ARROW([(92, 34), (170, 53)], col='c', sw=1.5, head=6))
    o.append(ARROW([(100, 87), (170, 87)], col='b', sw=1.8, head=6))
    o.append(ARROW([(92, 144), (170, 123)], col='c', sw=1.5, head=6))
    o.append(ARROW([(92, 152), (170, 157)], col='c', sw=1.5, head=6))
    o.append(ARROW([(246, 53), (276, 53)], col='a', sw=1.8, head=6))
    o.append(L(6, 206, 30, 206, col='b', sw=1.8))
    o.append(T(36, 210, '主キー全体で決まる（数量）', size=10))
    o.append(L(6, 224, 30, 224, col='c', sw=1.8))
    o.append(T(36, 228, '主キーの一部で決まる＝部分関数従属 → 第2正規形で分ける', size=10))
    o.append(L(6, 242, 30, 242, col='a', sw=1.8))
    o.append(T(36, 246, '主キー以外で決まる＝推移的関数従属 → 第3正規形で分ける', size=10))
    return _svg(360, 252, o, '関数従属')


FIG['joho.normfd'] = _normfd()


def _norm3():
    o = []
    dtab(o, 4, 4, ['受注番号', '受注日', '顧客番号'], [['1001', '5/1', 'C01'], ['1002', '5/2', 'C02']], [60, 46, 60], name='受注', size=9.5, rh=19,
         pk=(0,), fk=(2,))
    dtab(o, 200, 4, ['顧客番号', '顧客名'], [['C01', '佐藤商店'], ['C02', '鈴木商事']], [62, 92], name='顧客', size=9.5, rh=19, pk=(0,))
    dtab(o, 4, 104, ['受注番号', '商品コード', '数量'], [['1001', 'P1', '10'], ['1001', 'P2', '5'], ['1002', 'P1', '3']], [60, 62, 44],
         name='受注明細', size=9.5, rh=19, pk=(0, 1), fk=(0, 1))
    dtab(o, 200, 104, ['商品コード', '商品名', '単価'], [['P1', 'ボールペン', '100'], ['P2', 'ノート', '200']], [62, 60, 32], name='商品', size=9.5,
         rh=19, pk=(0,))
    o.append(ARROW([(170, 37), (198, 37)], col='c', sw=1.3, head=5))
    o.append(ARROW([(34, 118), (34, 102), (24, 102), (24, 82)], col='c', sw=1.3, head=5))
    o.append(ARROW([(170, 147), (198, 147)], col='c', sw=1.3, head=5))
    o.append(T(4, 216, '下線＝主キー、点線の下線＝外部キー（矢印の先の主キーを参照）', size=10))
    o.append(T(4, 234, '受注ごとの合計金額（導出項目）を残すなら、受注の表に置く', size=10, col='b', bold=True))
    return _svg(360, 240, o, '第3正規形（4つの表）')


FIG['joho.norm3'] = _norm3()


def _sqlsel():
    o = []
    code(o, 4, 4, 352, ["SELECT 氏名, 給与 FROM 社員 WHERE 部署 = '営業'"], size=10.5)
    rows = [['1', '佐藤', '営業', '30'], ['2', '鈴木', '総務', '28'], ['3', '高橋', '営業', '35'], ['4', '田中', '経理', '26']]
    hl = {}
    for i, r in enumerate(rows):
        if r[2] == '営業':
            hl[(i, None)] = 'c'
            hl[(i, 1)] = 'b'
            hl[(i, 3)] = 'b'
    dtab(o, 4, 40, ['社員番号', '氏名', '部署', '給与'], rows, [56, 50, 50, 44], name='社員', size=10, rh=20, hl=hl)
    o.append(ARROW([(210, 104), (238, 104)], sw=1.5, head=6))
    dtab(o, 246, 66, ['氏名', '給与'], [['佐藤', '30'], ['高橋', '35']], [56, 52], name='結果', size=10, rh=20, ncol='b')
    o.append(T(4, 180, 'WHEREで条件に合う行（オレンジ）、SELECTで列（緑）を取り出す', size=10))
    return _svg(360, 186, o, 'SELECT文の基本')


FIG['joho.sqlsel'] = _sqlsel()

FIG['joho.like'] = grid(['条件', '当てはまる', '当てはまらない'],
                        [["LIKE '03-3%'", '03-3123-4567', '03-5123-4567'], ["LIKE '_山%'", '小山、丸山田', '山田（1文字目が山）'],
                         ['BETWEEN 10 AND 20', '10、15、20', '9、21'], ["IN ('A', 'B')", 'A、B', 'C']],
                        [124, 112, 124], align=['l', 'l', 'l'], title='条件の書き方の例', size=10.5)

FIG['joho.sqlorder'] = _flow(['FROM\n表を選ぶ', ('WHERE\n行を絞る（グループ化の前）', 'c'), 'GROUP BY\n同じ値の行をまとめる',
                              ('HAVING\nグループを絞る（グループ化の後）', 'b'), 'SELECT\n列を取り出す・集計する', 'ORDER BY\n並べ替える'],
                             'SELECT文が処理される順序', per_row=3, size=10)


def _groupby():
    o = []
    rows = [['S1', 'A', '3'], ['S2', 'A', '5'], ['S1', 'B', '4'], ['S3', 'A', '2'], ['S2', 'B', '6'], ['S1', 'A', '1']]
    cmap = {'S1': 'b', 'S2': 'c', 'S3': 'a'}
    hl = {(i, 0): cmap[r[0]] for i, r in enumerate(rows)}
    dtab(o, 4, 4, ['販売店ID', '商品ID', '個数'], rows, [62, 52, 40], name='売上', size=10, rh=19, hl=hl)
    o.append(ARROW([(162, 80), (184, 80)], sw=1.5, head=6))
    dtab(o, 190, 4, ['販売店ID', '合計個数'], [['S2', '11'], ['S1', '8'], ['S3', '2']], [70, 70], name='合計（多い順）', size=10, rh=19,
         hl={(0, 0): 'c', (1, 0): 'b', (2, 0): 'a'}, ncol='b')
    dtab(o, 190, 104, ['販売店ID', '商品Aだけ'], [['S1', '4'], ['S2', '5'], ['S3', '2']], [70, 70], name='CASEで条件つきの合計', size=10, rh=19,
         hl={(0, 0): 'b', (1, 0): 'c', (2, 0): 'a'}, ncol='c')
    o.append(T(4, 172, 'GROUP BY 販売店IDで、', size=10))
    o.append(T(4, 186, '同じ販売店の行をまとめる', size=10))
    return _svg(360, 206, o, 'GROUP BYによる集計')


FIG['joho.groupby'] = _groupby()


def _count():
    o = []
    dtab(o, 4, 4, ['来店ID', '顧客', 'クーポン'], [['1', '佐藤', '10%'], ['2', '鈴木', 'NULL'], ['3', '佐藤', '5%'], ['4', '田中', 'NULL'], ['5', '鈴木', '10%']],
         [50, 56, 64], name='来店', size=10, rh=19, hl={(1, 2): 'a', (3, 2): 'a'})
    res = [('COUNT(*)', '5', '行の数'), ('COUNT(クーポン)', '3', '空（NULL）でない行の数'), ('COUNT(DISTINCT 顧客)', '3', '重複を除いた顧客の人数')]
    for i, (a, b, c) in enumerate(res):
        y = 20 + i * 44
        o.append('<text x="184" y="%s" font-size="10.5" style="fill:currentColor;font-family:%s">%s</text>' % (y + 4, MONO, a))
        o.append(T(184, y + 22, '＝ ' + b + '　' + c, size=10.5, bold=True, col='b'))
    return _svg(360, 150, o, 'COUNTの違い')


FIG['joho.count'] = _count()


def _join():
    o = []
    dtab(o, 4, 4, ['顧客番号', '顧客名'], [['C1', '佐藤'], ['C2', '鈴木'], ['C3', '田中']], [60, 52], name='顧客', size=10, rh=19)
    dtab(o, 190, 4, ['注文番号', '顧客番号'], [['O1', 'C1'], ['O2', 'C1'], ['O3', 'C2']], [60, 60], name='注文', size=10, rh=19)
    dtab(o, 4, 112, ['顧客名', '注文番号'], [['佐藤', 'O1'], ['佐藤', 'O2'], ['鈴木', 'O3']], [56, 60], name='内部結合（3行）', size=10, rh=19, ncol='c')
    dtab(o, 190, 112, ['顧客名', '注文番号'], [['佐藤', 'O1'], ['佐藤', 'O2'], ['鈴木', 'O3'], ['田中', 'NULL']], [56, 60], name='左外部結合（4行）', size=10,
         rh=19, ncol='b', hl={(3, None): 'b', (3, 1): 'a'})
    o.append(T(4, 244, '田中さんは注文がないので、内部結合では消える', size=10, col='c'))
    o.append(T(4, 262, '左外部結合のあと顧客ごとに数えると', size=10))
    o.append(T(4, 278, 'COUNT(注文番号)：田中＝0 ○', size=10, col='b', bold=True))
    o.append(T(180, 278, 'COUNT(*)：田中＝1 ×', size=10, col='a', bold=True))
    return _svg(360, 284, o, '内部結合と左外部結合')


FIG['joho.join'] = _join()


def _selfjoin():
    o = []
    dtab(o, 4, 4, ['取引ID', '商品ID'], [['T1', 'A'], ['T1', 'B'], ['T1', 'C'], ['T2', 'A'], ['T2', 'B']], [52, 52], name='明細', size=10, rh=19,
         hl={(0, None): 'b', (1, None): 'b', (2, None): 'b', (3, None): 'c', (4, None): 'c'})
    o.append(ARROW([(116, 70), (134, 70)], sw=1.4, head=5))
    dtab(o, 140, 4, ['取引', 'a.商品', 'b.商品'], [['T1', 'A', 'B'], ['T1', 'A', 'C'], ['T1', 'B', 'C'], ['T2', 'A', 'B']], [40, 46, 46],
         name='a.商品ID < b.商品ID の組', size=10, rh=19, hl={(0, None): 'b', (1, None): 'b', (2, None): 'b', (3, None): 'c'})
    o.append(ARROW([(278, 70), (294, 70)], sw=1.4, head=5))
    dtab(o, 298, 22, ['組', '件数'], [['A・B', '2'], ['A・C', '1'], ['B・C', '1']], [32, 26], size=10, rh=19)
    o.append(T(4, 148, '同じ取引の明細どうしを組み合わせ、組ごとに数えて多い順に並べる', size=10))
    o.append(T(4, 166, '「<>」にすると、A・BとB・Aを別々に数えてしまう', size=10, col='a', bold=True))
    return _svg(360, 172, o, '自己結合による併売の分析')


FIG['joho.selfjoin'] = _selfjoin()

# ------------------------------------------------ 1.3.3 データベース関連技術


def _dwh():
    o = []
    for i, s in enumerate(['販売', '会計', '人事']):
        cyl(o, 26, 30 + i * 46, w=40, h=34, inside=s, isize=9.5, col='sub')
    o.append(T(26, 172, '業務システム', 'middle', size=9.5))
    _box(o, 58, 46, 78, 70, 'ETL\n取り出す\n→ 変換\n→ 書き込む', col='c', size=9.5, c0='c')
    o.append(T(97, 128, 'クレンジング', 'middle', size=9.5, col='c', bold=True))
    o.append(T(97, 141, '（誤り・重複・', 'middle', size=9))
    o.append(T(97, 153, '表記のゆれを直す）', 'middle', size=9))
    for i in range(3):
        o.append(ARROW([(46, 30 + i * 46), (56, 82)], sw=1, head=4))
    o.append(ARROW([(138, 82), (153, 82)], sw=1.4, head=5))
    cyl(o, 192, 82, w=74, h=70, inside='DWH\n統合・時系列', isize=9.5, col='b')
    for i, s in enumerate(['営業部用', '経理部用']):
        cyl(o, 278, 52 + i * 60, w=52, h=36, inside=s, isize=8.5, col='b')
        o.append(ARROW([(230, 82), (250, 52 + i * 60)], sw=1.1, head=4))
    o.append(T(278, 156, 'データマート', 'middle', size=9.5, col='b', bold=True))
    o.append(T(340, 78, 'BI', 'middle', size=10, bold=True))
    o.append(T(340, 92, 'OLAP', 'middle', size=10, bold=True))
    o.append(ARROW([(306, 72), (326, 72)], sw=1, head=4))
    o.append(ARROW([(306, 112), (326, 96)], sw=1, head=4))
    o.append(L(4, 182, 356, 182, col='line', sw=0.8, dash='3 3'))
    o.append(T(4, 200, 'データレイク：構造化データも非構造化データ（文書・画像・ログなど）も、', size=10, col='a'))
    o.append(T(4, 214, '加工しない元の形式のまま蓄積する。目的が決まってから構造を与える', size=10, col='a'))
    return _svg(360, 220, o, 'データウェアハウス')


FIG['joho.dwh'] = _dwh()

FIG['joho.lake'] = grid(['', '蓄積するデータ', '特徴'],
                        [['データウェアハウス', '複数の業務システムのデータ', '主題ごとに統合し、時系列で蓄積。原則として更新・削除しない'],
                         ['データマート', 'DWHから切り出したデータ', '特定の部門や目的に合わせる'],
                         ['データレイク', '構造化・非構造化のデータ', '加工しない元の形式のまま。目的が決まってから構造を与える'],
                         ['データスワンプ', '管理されないデータレイク', 'どこに何があるか分からない']],
                        [96, 116, 148], align=['l', 'l', 'l'], title='データの蓄積の形の違い', size=10)


def _olap():
    o = []
    s, dx, dy, x0, y0 = 84, 34, -24, 30, 60
    n = 3

    def P(i, j, k):
        return (x0 + i * s / n + k * dx / n, y0 + s - j * s / n + k * dy / n)
    front = [P(0, 0, 0), P(n, 0, 0), P(n, n, 0), P(0, n, 0)]
    top = [P(0, n, 0), P(n, n, 0), P(n, n, n), P(0, n, n)]
    right = [P(n, 0, 0), P(n, 0, n), P(n, n, n), P(n, n, 0)]
    poly(o, top, col='main', fill='b', op=0.12)
    poly(o, right, col='main', fill='b', op=0.2)
    poly(o, front, col='c', fill='c', op=0.35, sw=1.8)
    for t in range(1, n):
        a, b = P(t, 0, 0), P(t, n, 0)
        o.append(L(a[0], a[1], b[0], b[1], col='main', sw=0.8))
        a, b = P(0, t, 0), P(n, t, 0)
        o.append(L(a[0], a[1], b[0], b[1], col='main', sw=0.8))
        a, b = P(t, n, 0), P(t, n, n)
        o.append(L(a[0], a[1], b[0], b[1], col='main', sw=0.8))
        a, b = P(0, n, t), P(n, n, t)
        o.append(L(a[0], a[1], b[0], b[1], col='main', sw=0.8))
        a, b = P(n, t, 0), P(n, t, n)
        o.append(L(a[0], a[1], b[0], b[1], col='main', sw=0.8))
        a, b = P(n, 0, t), P(n, n, t)
        o.append(L(a[0], a[1], b[0], b[1], col='main', sw=0.8))
    o.append(T(x0 + s / 2, y0 + s + 16, '商品', 'middle', size=10.5, bold=True))
    o.append(T(x0 - 6, y0 + s / 2 + 4, '地域', 'end', size=10.5, bold=True))
    o.append(T(x0 + s + dx + 4, y0 + dy - 2, '期間', size=10.5, bold=True))
    o.append(T(x0 + s / 2, y0 + s + 34, '手前の面＝2026年だけ', 'middle', size=10, col='c', bold=True))
    o.append(T(x0 + s / 2, y0 + s + 48, '（スライシング）', 'middle', size=10, col='c', bold=True))
    ops = [('スライシング', '1つの軸の値を固定して輪切り'), ('ダイシング', '軸を入れ替える・一部を切り出す'), ('ドリルダウン', '集計の単位を細かく（年→月）'),
           ('ドリルアップ', '集計の単位を粗く（ロールアップ）'), ('ドリルスルー', '集計値のもとの明細などを参照')]
    for i, (a, b) in enumerate(ops):
        y = 14 + i * 34
        o.append(T(176, y, a, size=10.5, bold=True, col='c' if i == 0 else 'b'))
        o.append(T(176, y + 15, b, size=9.5))
    return _svg(360, 194, o, 'OLAPの操作')


FIG['joho.olap'] = _olap()


def _drill():
    o = []
    for k, (ttl, lv) in enumerate([('期間', ['年', '四半期', '月']), ('地域', ['全国', '地方', '都道府県'])]):
        x0 = 30 + k * 130
        o.append(T(x0 + 40, 14, ttl, 'middle', bold=True, size=11))
        for i, s in enumerate(lv):
            _box(o, x0, 24 + i * 40, 80, 28, s, col='b', size=10.5, c0='b', op=0.12 + i * 0.06)
            if i:
                o.append(L(x0 + 40, 24 + i * 40 - 12, x0 + 40, 24 + i * 40, col='main', sw=1.1))
    o.append(ARROW([(300, 30), (300, 130)], col='c', sw=1.8, head=6))
    o.append(T(306, 74, 'ドリル', size=10, bold=True, col='c'))
    o.append(T(306, 88, 'ダウン', size=10, bold=True, col='c'))
    o.append(ARROW([(342, 130), (342, 30)], col='a', sw=1.8, head=6))
    o.append(T(338, 150, 'ドリルアップ', 'end', size=10, bold=True, col='a'))
    return _svg(360, 156, o, 'ドリルダウンとドリルアップ')


FIG['joho.drill'] = _drill()

FIG['joho.3v'] = _hub('ビッグデータ\nの3つのV', [('Volume\n量', 'b'), ('Variety\n種類の多さ', 'c'), ('Velocity\n発生の速さ', 'a')], 'ビッグデータの特徴',
                      bw=110, ccol='main')

FIG['joho.textmine'] = _flow(['文章のデータ\n「配送が早くて満足」', '形態素解析\n配送／が／早く／て／満足', '単語の出現の頻度を数える', ('一緒に現れる単語の関係を分析', 'b')],
                             'テキストマイニング', per_row=2, size=10.5)
