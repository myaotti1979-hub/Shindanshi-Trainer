# 経営情報システムの図表（1.4 通信ネットワーク、1.5 システムの性能・信頼性・経済性）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, htree, gantt, ARROW, R, T, L, _svg, _c, wrap, tw)
from kit import (_lines, _dashrect, _box, _lists, _flow, _rowflow, _nest, _hub, _pmap)
from ekit import G, txt, eq, panels
from jkit import stack, tiles, dtab, lab, pc, srv, cyl, cloud, person, rtr, brace, code, seq, r1, MONO

FIG = {}


def circ(o, x, y, r, col='main', fill=None, op=0.16, sw=1.3):
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:var(--sheet);stroke:none"/>' % (r1(x), r1(y), r))
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="%s"/>' % (
        r1(x), r1(y), r, _c(fill or 'sheet'), op if fill else 1, _c(col), sw))


def mono(o, x, y, s, size=11, anchor='start', col='main', bold=False):
    a = ' text-anchor="%s"' % anchor if anchor != 'start' else ''
    b = ' font-weight="bold"' if bold else ''
    o.append('<text x="%s" y="%s"%s%s font-size="%s" xml:space="preserve" style="fill:%s;white-space:pre;font-family:%s">%s</text>' % (
        r1(x), r1(y), a, b, size, _c(col), MONO, s.replace('&', '&amp;').replace('<', '&lt;')))


# ------------------------------------------------ 1.4.1 通信ネットワークの種類と構成
def _netkind():
    o = []
    for k, (ttl, cl, ccol, note) in enumerate([('インターネットVPN', 'インターネット', 'sub', '暗号化などで仮想的な専用の回線をつくる'),
                                              ('IP-VPN', '通信事業者の\n閉じた網', 'c', '通信事業者の閉じた網の上につくる')]):
        y = 8 + k * 92
        o.append(T(4, y + 6, ttl, bold=True, size=11, col='b' if k == 0 else 'c'))
        _box(o, 2, y + 16, 62, 44, '本社の\nLAN', size=10)
        _box(o, 296, y + 16, 62, 44, '支社の\nLAN', size=10)
        cloud(o, 180, y + 38, 150, 62, None if k == 0 else cl, col=ccol, size=10.5)
        if k == 0:
            o.append(T(180, y + 32, cl, 'middle', size=10.5, bold=True))
            o.append('<path d="M64 %s L296 %s" style="fill:none;stroke:%s" stroke-width="7" stroke-opacity="0.35"/>' % (y + 46, y + 46, _c('b')))
            o.append(L(64, y + 46, 296, y + 46, col='b', sw=1.4, dash='5 3'))
        else:
            o.append(L(64, y + 38, 108, y + 38, col='c', sw=1.8))
            o.append(L(252, y + 38, 296, y + 38, col='c', sw=1.8))
        o.append(T(180, y + 82, note, 'middle', size=10))
    o.append(T(4, 196, 'LAN：建物や敷地の中。WAN：離れた拠点の間を、通信事業者の回線でつなぐ', size=10))
    return _svg(360, 202, o, 'LAN、WAN、VPN')


FIG['joho.netkind'] = _netkind()


def _topo():
    o = []
    for k, t in enumerate(['スター型', 'バス型', 'リング型']):
        o.append(T(60 + k * 120, 14, t, 'middle', bold=True, size=11))
    cx, cy = 60, 70
    for i in range(5):
        a = -math.pi / 2 + 2 * math.pi * i / 5
        x, y = cx + 38 * math.cos(a), cy + 38 * math.sin(a)
        o.append(L(cx, cy, x, y, col='main', sw=1.2))
        circ(o, x, y, 7, col='b', fill='b', op=0.3)
    o.append(R(cx - 10, cy - 8, 20, 16, fill='c', stroke='c', op=0.4, rx=2))
    o.append(T(60, 132, '中央の機器（ハブ）', 'middle', size=9.5))
    o.append(L(132, 70, 228, 70, col='main', sw=2.2))
    for i, x in enumerate((144, 168, 192, 216)):
        y = 46 if i % 2 == 0 else 94
        o.append(L(x, 70, x, y, col='main', sw=1.2))
        circ(o, x, y, 7, col='b', fill='b', op=0.3)
    o.append(T(180, 132, '1本の線に各機器', 'middle', size=9.5))
    o.append('<circle cx="300" cy="70" r="36" style="fill:none;stroke:currentColor" stroke-width="1.6"/>')
    for i in range(5):
        a = -math.pi / 2 + 2 * math.pi * i / 5
        circ(o, 300 + 36 * math.cos(a), 70 + 36 * math.sin(a), 7, col='b', fill='b', op=0.3)
    o.append(T(300, 132, '輪の形につなぐ', 'middle', size=9.5))
    return _svg(360, 138, o, 'トポロジー')


FIG['joho.topo'] = _topo()

FIG['joho.csma'] = _rowflow([('CSMA/CD\n有線のイーサネット', 'b', ['送信する', '衝突（コリジョン）を検知する', '送り直す']),
                             ('CSMA/CA\n無線LAN', 'c', ['空きを確かめ、ランダムな時間待つ', '送信する', 'ACKがなければ送り直す'])],
                            '衝突への対応', lw=84, size=10, bold0=False)

FIG['joho.wifiband'] = grid(['周波数帯', '主な規格', '障害物', '電波の干渉', '速さ'],
                            [['2.4GHz帯', 'IEEE802.11b、g、n、ax', '強い（遠くまで届く）', '受けやすい（電子レンジ、Bluetooth）', ''],
                             ['5GHz帯', 'IEEE802.11a、n、ac、ax', '弱い', '受けにくい', '速い']],
                            [58, 92, 72, 96, 42], align=['l', 'l', 'l', 'l', 'c'], title='無線LANの周波数帯', size=10,
                            tcol={'受けやすい（電子レンジ、Bluetooth）': 'a', '受けにくい': 'b', '弱い': 'a', '強い（遠くまで届く）': 'b'})


def _ssid():
    o = []
    o.append(R(10, 50, 50, 30, fill='c', stroke='c', op=0.25, rx=4, sw=1.3))
    o.append(L(24, 50, 18, 34, col='c', sw=1.6))
    o.append(L(46, 50, 52, 34, col='c', sw=1.6))
    o.append(T(35, 70, 'AP', 'middle', size=11, bold=True))
    o.append(T(35, 98, 'アクセスポイント', 'middle', size=9.5))
    o.append(T(35, 111, '（1台）', 'middle', size=9.5))
    for k, (ss, who, dest, col) in enumerate([('SSID：staff', '社員用', '社内のネットワーク', 'b'), ('SSID：guest', '来客用', 'インターネットだけ', 'a')]):
        y = 22 + k * 64
        o.append(ARROW([(64, 65), (110, y + 16)], col=col, sw=1.6, head=6))
        _box(o, 114, y, 104, 34, ss + '\n' + who, col=col, size=10, c0=col)
        o.append(ARROW([(220, y + 17), (246, y + 17)], col=col, sw=1.4, head=5))
        _box(o, 250, y, 106, 34, dest, size=10)
    o.append(T(4, 140, '1台のアクセスポイントで複数のSSIDを使い分ける（マルチSSID）', size=10))
    return _svg(360, 146, o, 'マルチSSID')


FIG['joho.ssid'] = _ssid()

FIG['joho.wifisec'] = grid(['方式', 'ポイント'],
                           [['WEP', '脆弱性があり、使うべきではない'], ['WPA2', 'AESによる暗号化'], ['WPA3', 'WPA2より安全'],
                            ['MACアドレスフィルタリング', '登録した機器のMACアドレスにだけ接続を許す']],
                           [150, 210], align=['l', 'l'], title='無線LANのセキュリティ', size=10.5, tcol={'WEP': 'a'})

FIG['joho.5g'] = _hub('5Gの特徴', [('超高速・大容量\neMBB', 'b'), ('超低遅延・高信頼\nURLLC', 'c'), ('多数の同時接続\nmMTC', 'a')], '5Gの3つの特徴', bw=118, ccol='main')

FIG['joho.radio'] = _pmap([(-0.78, -0.45, 'NFC（10cm程度）', 'c'), (-0.5, 0.3, 'Bluetooth', 'b'), (-0.3, -0.75, 'ZigBee', 'b'), (0.3, 0.55, '無線LAN', 'b'),
                           (0.6, -0.65, 'LPWA（数km以上）', 'a'), (0.72, 0.85, '5G', 'b')],
                          '通信距離 短い', '長い', '速度 遅い', '速い', '無線通信の位置づけ（目安）', h=230)


def _osi():
    o = []
    rows = [('7', 'アプリケーション層', 'HTTP、SMTP、DNSなど', 'ゲートウェイ\n（第4層以上）'), ('6', 'プレゼンテーション層', '文字コード、圧縮の形式', ''),
            ('5', 'セッション層', '通信の開始と終了の管理', ''), ('4', 'トランスポート層', 'TCP、UDP', ''), ('3', 'ネットワーク層', 'IP', 'ルータ、\nレイヤ3スイッチ'),
            ('2', 'データリンク層', 'イーサネット', 'ブリッジ、\nスイッチングハブ'), ('1', '物理層', 'ケーブル、電気の信号', 'リピータ\n（リピータハブ）')]
    colw = [24, 112, 124, 100]
    xs = [0]
    for c in colw:
        xs.append(xs[-1] + c)
    hd = ['層', '名前', '主な役割・プロトコル', '中継する機器']
    o.append(R(0, 0, 360, 22, fill='paper', stroke='line'))
    for j, h in enumerate(hd):
        o.append(T(xs[j] + colw[j] / 2, 15, h, 'middle', bold=True, size=10))
    rh = 30
    for i, (n, a, b, c) in enumerate(rows):
        y = 22 + i * rh
        col = 'b' if n in '321' else ('c' if n == '4' else 'sub')
        o.append(R(0, y, 360, rh, fill='sheet', stroke='line', sw=0.6))
        o.append(R(0, y, 24, rh, fill=col, stroke=None, op=0.3))
        o.append(T(12, y + 19, n, 'middle', bold=True, size=11))
        o.append(T(xs[1] + 5, y + 19, a, size=10, bold=True))
        o.append(T(xs[2] + 5, y + 19, b, size=9.5))
        cl = c.split('\n') if c else []
        for k, ln in enumerate(cl):
            o.append(T(xs[3] + 5, y + 19 + (k - (len(cl) - 1) / 2) * 12.5, ln, size=9.5, bold=True, col='a'))
    for j in range(1, 4):
        o.append(L(xs[j], 0, xs[j], 22 + 7 * rh, col='line', sw=0.8))
    return _svg(360, 22 + 7 * rh + 2, o, 'OSI基本参照モデル')


FIG['joho.osi'] = _osi()


def _tcpip():
    o = []
    names = ['アプリケーション層', 'プレゼンテーション層', 'セッション層', 'トランスポート層', 'ネットワーク層', 'データリンク層', '物理層']
    rh = 22
    o.append(T(80, 12, 'OSI基本参照モデル', 'middle', bold=True, size=10.5))
    o.append(T(270, 12, 'TCP/IPの階層モデル', 'middle', bold=True, size=10.5))
    for i, s in enumerate(names):
        y = 20 + i * rh
        o.append(R(4, y, 152, rh - 3, fill='sheet', stroke='line', rx=3))
        o.append(T(80, y + 14, '%d %s' % (7 - i, s), 'middle', size=10))
    groups = [(0, 3, 'アプリケーション層', 'sub'), (3, 4, 'トランスポート層', 'c'), (4, 5, 'インターネット層', 'b'), (5, 7, 'ネットワーク\nインタフェース層', 'b')]
    for a, b, s, col in groups:
        y0, y1 = 20 + a * rh, 20 + b * rh - 3
        o.append(R(196, y0, 160, y1 - y0, fill=col, stroke=col if col != 'sub' else 'line', op=0.2, rx=3, sw=1))
        ls = s.split('\n')
        for k, ln in enumerate(ls):
            o.append(T(276, (y0 + y1) / 2 + 4 + (k - (len(ls) - 1) / 2) * 13, ln, 'middle', size=10.5, bold=True))
        o.append(L(158, (y0 + y1) / 2, 194, (y0 + y1) / 2, col='line', sw=1, dash='3 2'))
    return _svg(360, 20 + 7 * rh + 2, o, 'OSI基本参照モデルとTCP/IP')


FIG['joho.tcpip'] = _tcpip()


def _hubsw():
    o = []
    for k, (ttl, col) in enumerate([('リピータハブ（第1層）', 'sub'), ('スイッチングハブ（第2層）', 'b'), ('ルータ（第3層）', 'c')]):
        o.append(T(60 + k * 120, 14, ttl, 'middle', bold=True, size=10, col=col if col != 'sub' else 'main'))
    for k in range(2):
        cx = 60 + k * 120
        o.append(R(cx - 40, 60, 80, 22, fill='b' if k else 'sub', stroke='b' if k else 'line', op=0.25 if k else 0.12, rx=3, sw=1.2))
        pos = [(cx - 42, 30), (cx + 42, 30), (cx - 42, 112), (cx + 42, 112)]
        for i, (x, y) in enumerate(pos):
            o.append(L(cx - 30 + i * 20, 71, x, y, col='line', sw=1))
            circ(o, x, y, 9, col='main')
            o.append(T(x, y + 4, 'ABCD'[i], 'middle', size=10, bold=True))
        if k == 0:
            for (x, y) in pos[1:]:
                o.append(ARROW([(cx, 71), (x + (-9 if x > cx else 9), y + (9 if y < 71 else -9))], col='a', sw=1.4, head=5))
            o.append(T(cx, 138, 'すべてのポートに流す', 'middle', size=9.5))
        else:
            o.append(ARROW([(cx, 71), (pos[2][0] + 8, pos[2][1] - 9)], col='b', sw=1.8, head=6))
            o.append(T(cx, 138, 'MACアドレスを見て、', 'middle', size=9.5))
            o.append(T(cx, 151, '宛先のポートだけ', 'middle', size=9.5))
    cx = 300
    rtr(o, cx, 71, col='c', text='R')
    for k, (y, s) in enumerate([(32, '192.168.1.0'), (112, '192.168.2.0')]):
        o.append(R(cx - 54, y - 12, 108, 24, fill='sheet', stroke='line', rx=4))
        o.append(T(cx, y + 4, s, 'middle', size=9.5))
        o.append(L(cx, y + (12 if k == 0 else -12), cx, 71 + (-14 if k == 0 else 14), col='c', sw=1.6))
    o.append(T(cx, 138, 'IPアドレスを見て、', 'middle', size=9.5))
    o.append(T(cx, 151, '経路を選ぶ', 'middle', size=9.5))
    o.append(T(4, 172, '矢印：A（左上）から送ったデータの行き先', size=9.5, col='sub'))
    return _svg(360, 178, o, 'ネットワークの機器')


FIG['joho.hubsw'] = _hubsw()

# ------------------------------------------------ 1.4.2 通信プロトコル
FIG['joho.tcpudp'] = grid(['', 'TCP', 'UDP'],
                          [['接続', '先に確立する（コネクション型）', '確立しない（コネクションレス型）'], ['届いたことの確認・再送', 'する', 'しない'],
                           ['順序の並べ直し', 'する', 'しない'], ['特徴', '信頼性が高い', '信頼性は低いが速い'],
                           ['使い道', 'Web、電子メールなど', '音声や動画の配信、DNSの問い合わせ']],
                          [110, 125, 125], align=['l', 'c', 'c'], title='TCPとUDP（どちらも第4層）', size=10.5, tcol={'する': 'b', 'しない': 'a'})

FIG['joho.ports'] = grid(['プロトコル', 'ポート番号', '用途'],
                         [['HTTP', '80', 'Webページのやり取り'], ['HTTPS', '443', 'HTTPをSSL/TLSで暗号化'], ['SMTP', '25', 'メールの送信・転送'],
                          ['POP3', '110', 'メールの受信（ダウンロード）'], ['IMAP', '143', 'メールをサーバに置いたまま管理'], ['DNS', '53', '名前解決'],
                          ['SSH', '22', '暗号化した遠隔ログイン']],
                         [90, 80, 190], align=['l', 'c', 'l'], title='主なポート番号', size=10.5)


def _mail():
    o = []
    pc(o, 22, 44, label='送信者')
    srv(o, 120, 44, label='送信側の\nメールサーバ', col='b')
    srv(o, 232, 44, label='受信側の\nメールサーバ', col='b')
    pc(o, 330, 44, label='受信者')
    o.append(ARROW([(40, 40), (104, 40)], col='b', sw=1.8, head=6))
    o.append(T(72, 32, 'SMTP', 'middle', size=10.5, bold=True, col='b'))
    o.append(ARROW([(136, 40), (216, 40)], col='b', sw=1.8, head=6))
    o.append(T(176, 32, 'SMTP（転送）', 'middle', size=10.5, bold=True, col='b'))
    o.append(ARROW([(248, 40), (312, 40)], col='c', sw=1.8, head=6))
    o.append(T(280, 32, '受信', 'middle', size=10.5, bold=True, col='c'))
    rows = [('POP3', '端末にダウンロードして受信。受信したメールは、通常はサーバから削除'), ('IMAP', 'サーバの上に置いたまま閲覧・管理。複数の端末から同じメールを見られる')]
    for i, (a, b) in enumerate(rows):
        y = 108 + i * 34
        o.append(R(4, y, 54, 26, fill='c', stroke='c', op=0.22, rx=4))
        o.append(T(31, y + 18, a, 'middle', size=11, bold=True))
        for k, ln in enumerate(wrap(b, 290, 10)):
            o.append(T(66, y + 11 + k * 13, ln, size=10))
    o.append(T(4, 186, 'MIME：日本語や添付ファイルを扱う。S/MIME：メールの暗号化と電子署名', size=10))
    return _svg(360, 192, o, '電子メールのプロトコル')


FIG['joho.mail'] = _mail()

FIG['joho.names'] = _rowflow([('DNS', 'b', ['ドメイン名\nwww.example.com', 'IPアドレス\n203.0.113.10']),
                              ('ARP', 'c', ['IPアドレス\n192.168.1.20', 'MACアドレス\n00-1A-2B-3C-4D-5E']),
                              ('DHCP', 'a', ['ネットワークに\nつないだ機器', 'IPアドレス、サブネットマスク、デフォルトゲートウェイ、DNSサーバのアドレスを自動で割り当て'])],
                             '名前とアドレスを扱うプロトコル', lw=50, size=10, bold0=False)


def _cast():
    o = []
    defs = [('ユニキャスト', '1対1', [3]), ('マルチキャスト', '特定のグループ', [1, 3, 4]), ('ブロードキャスト', '同じネットワークのすべて', [0, 1, 2, 3, 4, 5])]
    for k, (ttl, sub, to) in enumerate(defs):
        x0 = k * 120
        o.append(T(x0 + 60, 14, ttl, 'middle', bold=True, size=10.5))
        o.append(T(x0 + 60, 28, sub, 'middle', size=9.5))
        sx, sy = x0 + 18, 80
        circ(o, sx, sy, 8, col='a', fill='a', op=0.8)
        pts = [(x0 + 70 + (i % 2) * 34, 44 + (i // 2) * 36) for i in range(6)]
        if k == 1:
            o.append(_dashrect(x0 + 52, 56, 70, 82, col='c', rx=8))
        for i, (x, y) in enumerate(pts):
            hit = i in to
            if hit:
                o.append(ARROW([(sx + 8, sy), (x - 8, y)], col='a', sw=1.2, head=4))
            circ(o, x, y, 7, col='b' if hit else 'line', fill='b' if hit else None, op=0.45)
    return _svg(360, 140, o, 'ユニキャスト、マルチキャスト、ブロードキャスト')


FIG['joho.cast'] = _cast()

FIG['joho.stdorg'] = grid(['団体', '定める標準'],
                          [['ISO', '工業製品や管理の仕組みなど広い分野の国際規格（OSI基本参照モデルも）'], ['ITU', '電気通信の国際規格'],
                           ['IEEE', 'LANの規格（イーサネットIEEE802.3、無線LAN IEEE802.11）'], ['IETF', 'インターネットの技術の標準（RFCで公開）'],
                           ['W3C', 'Webの技術の標準（HTML、CSS、XML）']],
                          [60, 300], align=['l', 'l'], title='標準化の団体', size=10.5)

FIG['joho.stdkind'] = grid(['標準', '決まり方'],
                           [['デジュール標準', '公的な標準化の機関が定めた'], ['デファクト標準', '市場で広く使われた結果、事実上の標準になった'], ['フォーラム標準', '複数の企業などが集まって定めた']],
                           [110, 250], align=['l', 'l'], title='標準の種類', size=10.5)

# ------------------------------------------------ 1.4.3 ネットワーク関連技術


def _ipv4():
    o = []
    octs = [192, 168, 1, 10]
    for i, v in enumerate(octs):
        x = 4 + i * 89
        net = i < 3
        col = 'b' if net else 'c'
        o.append(R(x, 6, 84, 26, fill=col, stroke=col, op=0.22, rx=3, sw=1.1))
        o.append(T(x + 42, 24, str(v), 'middle', size=12, bold=True))
        mono(o, x + 42, 50, format(v, '08b'), size=11, anchor='middle')
    brace(o, 4, 263, 60, 'ネットワーク部（先頭の24ビット）', col='b', size=10)
    brace(o, 271, 355, 60, 'ホスト部（8ビット）', col='c', size=10)
    o.append(T(4, 104, 'IPv4は32ビット（8ビットずつ4つに区切り、10進数で表す）', size=10))
    o.append(T(4, 120, 'IPv6は128ビット（16ビットずつ8つに区切り、16進数で表す）', size=10))
    return _svg(360, 126, o, 'IPアドレスの構成（例：/24）')


FIG['joho.ipv4'] = _ipv4()


def _subnet():
    o = []
    o.append(T(4, 16, '172.16.16.32/27（最後の8ビットに注目）', bold=True, size=11))
    rows = [('サブネットマスク', '255.255.255.224', '11100000', None), ('ネットワークアドレス', '172.16.16.32', '00100000', 3)]
    for i, (a, b, bits, split) in enumerate(rows):
        y = 30 + i * 30
        o.append(T(4, y + 15, a, size=10, bold=True))
        o.append(T(122, y + 15, b, size=10))
        for j, ch in enumerate(bits):
            x = 232 + j * 15.5
            col = 'b' if j < 3 else 'c'
            o.append(R(x, y + 1, 14, 20, fill=col, stroke=col, op=0.25 if split is not None else 0.1, sw=0.8))
            mono(o, x + 7, y + 15, ch, size=11, anchor='middle', bold=True)
    o.append(R(4, 94, 10, 10, fill='b', stroke='b', op=0.4))
    o.append(T(18, 103, 'ネットワーク部（27ビット）の続き', size=9.5, col='b', bold=True))
    o.append(R(196, 94, 10, 10, fill='c', stroke='c', op=0.4))
    o.append(T(210, 103, 'ホスト部（5ビット）', size=9.5, col='c', bold=True))
    segs = [('.32', 'ネットワーク\nアドレス（全部0）', 'sub', 96), ('.33 〜 .62', '機器に割り当てる\n2の5乗－2＝30個', 'b', 158), ('.63', 'ブロードキャスト\nアドレス（全部1）', 'sub', 96)]
    x = 4
    for s, d, col, w in segs:
        w = w * 352 / 350
        o.append(R(x, 116, w - 2, 28, fill=col, stroke=col if col != 'sub' else 'line', op=0.25 if col != 'sub' else 0.14, rx=3, sw=1))
        o.append(T(x + w / 2, 135, s, 'middle', size=11, bold=True))
        for k, ln in enumerate(d.split('\n')):
            o.append(T(x + w / 2, 160 + k * 13, ln, 'middle', size=9.5, col='b' if col == 'b' else 'main', bold=(col == 'b' and k == 1)))
        x += w
    return _svg(360, 182, o, 'サブネットの計算')


FIG['joho.subnet'] = _subnet()

FIG['joho.private'] = grid(['プライベートIPアドレスの範囲'],
                           [['10.0.0.0 〜 10.255.255.255'], ['172.16.0.0 〜 172.31.255.255'], ['192.168.0.0 〜 192.168.255.255']],
                           [360], align=['c'], title='プライベートIPアドレス', size=11)


def _napt():
    o = []
    pc(o, 30, 30, label=None)
    pc(o, 30, 92, label=None)
    o.append(T(54, 30, '192.168.1.2', size=9.5))
    o.append(T(54, 43, ':5000', size=9.5))
    o.append(T(54, 92, '192.168.1.3', size=9.5))
    o.append(T(54, 105, ':5001', size=9.5))
    rtr(o, 168, 62, col='c', text='NAPT', r=22)
    o.append(ARROW([(110, 34), (148, 52)], sw=1.3, head=5))
    o.append(ARROW([(110, 94), (148, 74)], sw=1.3, head=5))
    cloud(o, 300, 62, 104, 64, 'インターネット', col='sub', size=10)
    o.append(ARROW([(192, 62), (246, 62)], sw=1.5, head=6))
    o.append(T(219, 52, '203.0.113.5', 'middle', size=9))
    o.append(T(60, 132, 'プライベートIPアドレス', 'middle', size=9.5, col='c', bold=True))
    o.append(T(356, 110, 'グローバルIPアドレス1つで共用', 'end', size=9.5, col='b', bold=True))
    dtab(o, 30, 144, ['内側（プライベート）', '外側（グローバル）'], [['192.168.1.2 : 5000', '203.0.113.5 : 61001'], ['192.168.1.3 : 5001', '203.0.113.5 : 61002']],
         [150, 150], size=10, rh=20, hl={(-1, 0): 'c', (-1, 1): 'b'})
    o.append(T(4, 228, 'NATはアドレスだけを変換。NAPTはポート番号も変換して共用する', size=10))
    return _svg(360, 234, o, 'NAPT（IPマスカレード）')


FIG['joho.napt'] = _napt()


def _url():
    o = []
    segs = [('https://', 'スキーム', 'c', 74), ('www.example.com', 'ホスト名', 'b', 134), ('/news/index.html', 'パス', 'a', 146)]
    x = 4
    for s, l, col, w in segs:
        o.append(R(x, 8, w - 2, 28, fill=col, stroke=col, op=0.2, rx=3, sw=1))
        mono(o, x + w / 2 - 1, 27, s, size=11, anchor='middle')
        o.append(T(x + w / 2 - 1, 52, l, 'middle', size=10.5, bold=True, col=col))
        x += w
    o.append(T(4, 76, 'ドメイン名の部分は、大文字と小文字を区別しない', size=10))
    dtab(o, 4, 90, ['', 'ドメイン名の例'], [['正規', 'www.example.com'], ['よく似た文字列', 'www.examp1e.com（lが1）'],
                                       ['正規の名前を一部に含む', 'www.example.com.secure-login.jp']],
         [126, 226], size=10, rh=21, hl={(1, None): 'a', (2, None): 'a'}, align=['l', 'l'])
    o.append(T(4, 196, '下の2つは別のドメイン（フィッシングに注意）', size=10, col='a', bold=True))
    return _svg(360, 202, o, 'URLの構成とフィッシングの対策')


FIG['joho.url'] = _url()


def _netperf():
    o = []
    o.append(T(4, 22, '送る側', size=10, bold=True))
    o.append(T(4, 122, '受ける側', size=10, bold=True))
    o.append(L(52, 18, 352, 18, col='main', sw=1.4))
    o.append(L(52, 118, 352, 118, col='main', sw=1.4))
    sends = [64, 112, 160, 208, 256]
    arr = [96, 152, 186, None, 300]
    for i, (s, a) in enumerate(zip(sends, arr)):
        circ(o, s, 18, 4, col='b', fill='b', op=0.9)
        if a is None:
            o.append(ARROW([(s, 22), (s + 20, 66)], col='a', sw=1.4, head=5))
            o.append(T(s + 24, 76, '×', 'middle', size=14, bold=True, col='a'))
            o.append(T(s + 34, 92, 'パケットロス', size=9.5, col='a', bold=True))
        else:
            o.append(ARROW([(s, 22), (a, 114)], col='b', sw=1.4, head=5))
    brace(o, 64, 96, 132, 'レイテンシ（届くまでの時間）', col='c', size=9.5)
    o.append(T(4, 172, '届くまでの時間がばらつく＝ジッタ', size=10, col='c', bold=True))
    o.append(T(4, 190, '送る間隔は同じでも、届く時間が乱れると、音声や動画の品質が落ちる', size=9.5))
    return _svg(360, 196, o, 'レイテンシ、ジッタ、パケットロス')


FIG['joho.netperf'] = _netperf()


def _bw():
    o = []
    o.append(R(4, 10, 300, 44, fill='sub', stroke='main', op=0.1, rx=22, sw=1.4))
    o.append(R(4, 18, 240, 28, fill='b', stroke='b', op=0.35, rx=14, sw=1))
    o.append(T(124, 37, 'スループット：実際に送れた量', 'middle', size=10, bold=True))
    o.append(T(310, 30, '帯域幅', size=10.5, bold=True))
    o.append(T(310, 44, '（上限）', size=9.5))
    o.append(T(4, 72, '帯域幅：理論の上で送れる量の上限（bps）', size=10))
    return _svg(360, 78, o, '帯域幅とスループット')


FIG['joho.bw'] = _bw()

FIG['joho.xfer'] = eq([[('データ量', 'c'), '＝', '100Mバイト', '×', '8', '＝', '800Mビット'],
                       [('実際の速度', 'c'), '＝', '100Mbps', '×', '0.8', '＝', '80Mbps'],
                       [('転送時間', 'a'), '＝', '800Mビット', '÷', '80Mbps', '＝', ('10秒', 'a')]], 'データの転送時間の計算', size=10.5)


def _chain():
    o = []
    blocks = [('ブロック1', '取引の記録', 'ハッシュ値 7a3f', 'a'), ('ブロック2', '7a3f（前のハッシュ値）', 'ハッシュ値 c91e', None), ('ブロック3', 'c91e（前のハッシュ値）', 'ハッシュ値 52d0', None)]
    for i, (nm, rec, hv, col) in enumerate(blocks):
        x = 4 + i * 122
        o.append(R(x, 6, 108, 92, fill='sheet', stroke='main', sw=1.3, rx=4))
        o.append(R(x, 6, 108, 22, fill='b', stroke=None, op=0.2, rx=4))
        o.append(T(x + 54, 21, nm, 'middle', size=10.5, bold=True))
        if i == 0:
            o.append(R(x + 4, 32, 100, 22, fill='a', stroke='a', op=0.18, rx=2))
            o.append(T(x + 54, 47, '取引の記録を改ざん', 'middle', size=9.5, bold=True, col='a'))
        else:
            o.append(T(x + 54, 47, rec, 'middle', size=9.5))
        o.append(T(x + 54, 68, '取引の記録・ナンス', 'middle', size=9.5) if i else T(x + 54, 68, 'ナンス', 'middle', size=9.5))
        o.append(T(x + 54, 90, hv if i else 'ハッシュ値が変化', 'middle', size=9.5, bold=True, col='a' if i == 0 else 'main'))
        if i < 2:
            o.append(ARROW([(x + 108, 86), (x + 126, 46)], col='a' if i == 0 else 'b', sw=1.4, head=5))
    o.append(T(126, 120, '×', 'middle', size=16, bold=True, col='a'))
    o.append(T(140, 118, 'ブロック2に記録した「7a3f」と合わない', size=10, col='a', bold=True))
    o.append(T(4, 142, '直前のブロックのハッシュ値を含めて鎖のようにつなぐ。', size=10))
    o.append(T(4, 157, '多数の参加者が同じ記録を持つ（分散型台帳）ため、改ざんを検出しやすい', size=10))
    return _svg(360, 164, o, 'ブロックチェーンのしくみ')


FIG['joho.chain'] = _chain()

FIG['joho.bctype'] = grid(['型', '管理', '参加者'],
                          [['パブリック型', '中央の管理者がいない', '誰でも参加できる（暗号資産など）'], ['プライベート型', '1つの組織が管理', '限定する'],
                           ['コンソーシアム型', '複数の組織が共同で管理', '限定する']],
                          [100, 130, 130], align=['l', 'l', 'l'], title='ブロックチェーンの種類', size=10.5)

FIG['joho.pow'] = _lists([('PoW（プルーフ・オブ・ワーク）', 'c', ['条件を満たすハッシュ値になるナンスを、膨大な計算で最初に見つけた参加者がブロックを追加']),
                          ('PoS（プルーフ・オブ・ステーク）', 'b', ['保有する量などに応じて、ブロックを追加する参加者を選ぶ'])], 'コンセンサスアルゴリズム', size=10.5)


def _metcalfe():
    o = []
    for k, n in enumerate([2, 3, 4, 5]):
        cx, cy, r = 45 + k * 90, 48, 26
        pts = [(cx + r * math.cos(-math.pi / 2 + 2 * math.pi * i / n), cy + r * math.sin(-math.pi / 2 + 2 * math.pi * i / n)) for i in range(n)]
        for i in range(n):
            for j in range(i + 1, n):
                o.append(L(pts[i][0], pts[i][1], pts[j][0], pts[j][1], col='b', sw=1.2))
        for (x, y) in pts:
            circ(o, x, y, 5.5, col='b', fill='b', op=0.5)
        o.append(T(cx, 96, '利用者%d人' % n, 'middle', size=10))
        o.append(T(cx, 111, 'つながり%d' % (n * (n - 1) // 2), 'middle', size=10, bold=True, col='b'))
    o.append(T(4, 136, 'ネットワークの価値は、利用者の数の2乗に比例する（経験則）', size=10.5, bold=True))
    return _svg(360, 142, o, 'メトカーフの法則')


FIG['joho.metcalfe'] = _metcalfe()


def _scalefree():
    o = []
    hubs = [(110, 70), (250, 76)]
    leaves = []
    for k, (hx, hy) in enumerate(hubs):
        n = 9 if k == 0 else 7
        for i in range(n):
            a = 2 * math.pi * i / n + k * 0.3
            x, y = hx + 52 * math.cos(a), hy + 44 * math.sin(a)
            leaves.append((x, y))
            o.append(L(hx, hy, x, y, col='line', sw=1))
    o.append(L(hubs[0][0], hubs[0][1], hubs[1][0], hubs[1][1], col='a', sw=1.6))
    o.append(L(leaves[2][0], leaves[2][1], leaves[12][0], leaves[12][1], col='line', sw=1))
    for (x, y) in leaves:
        circ(o, x, y, 4.5, col='b', fill='b', op=0.4)
    for (x, y) in hubs:
        circ(o, x, y, 11, col='a', fill='a', op=0.5)
    o.append(T(110, 74, 'ハブ', 'middle', size=9, bold=True))
    o.append(T(250, 80, 'ハブ', 'middle', size=9, bold=True))
    o.append(T(4, 146, '少数のハブが非常に多くのつながりを持ち、多くのノードはわずかなつながり', size=10))
    o.append(T(4, 161, '（つながりの数の分布がべき乗の法則に従う。Webのリンクの構造など）', size=10))
    return _svg(360, 168, o, 'スケールフリー・ネットワーク')


FIG['joho.scalefree'] = _scalefree()

# ------------------------------------------------ 1.5.1 システムの性能


def _rtt():
    o = []
    o.append(T(4, 14, '対話型の処理', bold=True, size=10.5, col='b'))
    o.append(R(40, 44, 130, 10, fill='b', stroke='b', op=0.45, rx=2))
    o.append(R(170, 44, 130, 10, fill='sub', stroke='line', op=0.2, rx=2))
    o.append(ARROW([(4, 60), (356, 60)], col='line', sw=1, head=5))
    for x, s_ in [(40, '入力を終える'), (170, '応答を返し始める'), (300, '出力が終わる')]:
        o.append(L(x, 52, x, 68, col='main', sw=1.6))
        o.append(T(x, 82, s_, 'middle', size=9.5))
    brace(o, 40, 170, 38, 'レスポンスタイム', col='b', up=True, size=10.5)
    o.append(T(4, 110, 'バッチ処理', bold=True, size=10.5, col='c'))
    o.append(R(40, 140, 260, 10, fill='c', stroke='c', op=0.45, rx=2))
    o.append(ARROW([(4, 156), (356, 156)], col='line', sw=1, head=5))
    for x, s_ in [(40, '仕事を依頼する'), (300, '結果がすべて返る')]:
        o.append(L(x, 148, x, 164, col='main', sw=1.6))
        o.append(T(x, 178, s_, 'middle', size=9.5))
    brace(o, 40, 300, 134, 'ターンアラウンドタイム', col='c', up=True, size=10.5)
    return _svg(360, 184, o, 'レスポンスタイムとターンアラウンドタイム')


FIG['joho.rtt'] = _rtt()


def _bneck():
    o = []
    st = [('Webサーバ', 500, 'b'), ('APサーバ', 300, 'b'), ('DBサーバ', 100, 'a')]
    for i, (nm, cap, col) in enumerate(st):
        x = 4 + i * 100
        h = cap / 500 * 70
        o.append(R(x, 50 - h / 2, 92, h, fill=col, stroke=col, op=0.3, rx=3, sw=1.2))
        o.append(T(x + 46, 104, nm, 'middle', size=10.5, bold=True))
        o.append(T(x + 46, 120, '%d件/秒' % cap, 'middle', size=10.5, col=col, bold=True))
    o.append(ARROW([(304, 50), (322, 50)], sw=1.5, head=6))
    o.append(T(340, 40, '全体', 'middle', size=10.5, bold=True))
    o.append(T(340, 56, '100件', 'middle', size=10.5, bold=True, col='a'))
    o.append(T(340, 70, '/秒', 'middle', size=10.5, bold=True, col='a'))
    o.append(T(4, 146, '最も遅いDBサーバ（ボトルネック）が全体の性能を決める', size=10.5, bold=True, col='a'))
    return _svg(360, 152, o, 'ボトルネック')


FIG['joho.bneck'] = _bneck()


def _multi():
    g = G(xmax=10, ymax=10, h=206, xlab='多重度', ylab='', origin='', pb=46, pl=20, xlpos='above')
    g.fn(lambda x: 8.6 * (1 - math.exp(-x / 2.2)), 0, 10, col='b', sw=2.4)
    g.fn(lambda x: 1 + 0.07 * x * x, 0, 10, col='a', sw=2.4)
    g.text(6.2, 9.3, '全体のスループット', 'middle', 'b', True, 10.5)
    g.text(8.3, 5.2, '1件ごとの応答時間', 'middle', 'a', True, 10.5)
    g.raw(txt(g.X(0) - 16, g.Y(0) + 20, '多重度を上げると、全体の処理量は増えるが頭打ちになり、', size=9.5, halo=False))
    g.raw(txt(g.X(0) - 16, g.Y(0) + 35, '1件ごとの応答は遅くなる（模式図）', size=9.5, halo=False))
    return g.svg('多重度と性能')


FIG['joho.multi'] = _multi()

# ------------------------------------------------ 1.5.2 システムの信頼性・経済性
FIG['joho.rasis'] = grid(['', '指標', '意味', '表し方'],
                         [['R', '信頼性', '故障しにくさ', 'MTBF'], ['A', '可用性', '使いたいときに使える', '稼働率'], ['S', '保守性', '故障したときの直しやすさ', 'MTTR'],
                          ['I', '完全性（保全性）', 'データが正しく、矛盾なく保たれる', ''], ['S', '安全性', '不正な利用や情報の漏えいを防げる', '']],
                         [26, 104, 170, 60], align=['c', 'l', 'l', 'c'], title='RASIS', size=10.5)


def _mtbf():
    o = []
    segs = [('稼働', 90), ('修理', 10), ('稼働', 80), ('修理', 6), ('稼働', 100), ('修理', 14)]
    x = 4
    k = 352 / 300
    for s, v in segs:
        w = v * k
        col = 'b' if s == '稼働' else 'a'
        o.append(R(x, 20, w, 26, fill=col, stroke=col, op=0.3 if col == 'b' else 0.45, sw=0.8))
        if s == '稼働':
            o.append(T(x + w / 2, 37, '稼働%dh' % v, 'middle', size=10, bold=True))
        else:
            o.append(T(x + w / 2, 62, '%d' % v, 'middle', size=10, bold=True, col='a'))
        x += w
    o.append(T(4, 12, '緑＝稼働、赤＝故障してから修理を終えるまで（時間）', size=9.5))
    o.append(T(4, 88, 'MTBF＝（90＋80＋100）÷3＝90時間（平均の稼働時間）', size=10.5))
    o.append(T(4, 106, 'MTTR＝（10＋6＋14）÷3＝10時間（平均の修理時間）', size=10.5))
    o.append(T(4, 128, '稼働率＝MTBF÷（MTBF＋MTTR）＝90÷100＝0.9', size=11, bold=True, col='b'))
    return _svg(360, 136, o, 'MTBF、MTTR、稼働率')


FIG['joho.mtbf'] = _mtbf()


def _avail():
    o = []

    def blk(x, y, s='0.9'):
        o.append(R(x, y, 40, 22, fill='sheet', stroke=None, rx=3))
        o.append(R(x, y, 40, 22, fill='b', stroke='b', op=0.22, rx=3, sw=1.2))
        o.append(T(x + 20, y + 15, s, 'middle', size=10.5, bold=True))
    o.append(T(4, 16, '直列', bold=True, size=11))
    y = 26
    o.append(L(4, y + 11, 200, y + 11, col='main', sw=1.2))
    blk(40, y)
    blk(120, y)
    o.append(T(212, y + 16, '0.9×0.9＝0.81', size=11, bold=True, col='a'))
    o.append(T(4, 80, '並列', bold=True, size=11))
    y = 88
    o.append(L(4, y + 25, 60, y + 25, col='main', sw=1.2))
    o.append(L(60, y + 11, 60, y + 39, col='main', sw=1.2))
    o.append(L(140, y + 11, 140, y + 39, col='main', sw=1.2))
    o.append(L(140, y + 25, 200, y + 25, col='main', sw=1.2))
    for yy in (y, y + 28):
        o.append(L(60, yy + 11, 140, yy + 11, col='main', sw=1.2))
        blk(80, yy)
    o.append(T(212, y + 21, '1－0.1×0.1＝0.99', size=11, bold=True, col='b'))
    o.append(T(4, 164, '組み合わせ', bold=True, size=11))
    y = 172
    o.append(L(4, y + 25, 60, y + 25, col='main', sw=1.2))
    o.append(L(60, y + 11, 60, y + 39, col='main', sw=1.2))
    o.append(L(140, y + 11, 140, y + 39, col='main', sw=1.2))
    o.append(L(140, y + 25, 200, y + 25, col='main', sw=1.2))
    for yy in (y, y + 28):
        o.append(L(60, yy + 11, 140, yy + 11, col='main', sw=1.2))
        blk(80, yy)
    blk(156, y + 14)
    o.append(T(212, y + 21, '0.99×0.9＝0.891', size=11, bold=True, col='c'))
    o.append(T(4, 236, '並列は個々より高く、直列は個々より低くなる', size=10))
    return _svg(360, 242, o, '直列と並列の稼働率')


FIG['joho.avail'] = _avail()


def _avail2():
    o = []
    segs = [('計画停止\n200', 'sub', 64), ('故障で停止\n142', 'a', 70), ('稼働 8,418', 'b', 218)]
    x = 4
    for s, col, w in segs:
        o.append(R(x, 28, w, 34, fill=col, stroke=col if col != 'sub' else 'line', op=0.3 if col != 'sub' else 0.15, sw=1))
        ls = s.split('\n')
        for k, ln in enumerate(ls):
            o.append(T(x + w / 2, 46 + 4 + (k - (len(ls) - 1) / 2) * 13, ln, 'middle', size=10, bold=True))
        x += w
    brace(o, 4, 356, 22, '1年＝8,760時間（目盛りは模式的）', col='main', up=True, size=10)
    brace(o, 68, 356, 70, '運転を予定した時間＝8,760－200＝8,560', col='c', size=10)
    o.append(T(4, 112, '稼働率＝8,418÷8,560≒0.983', size=11.5, bold=True, col='b'))
    o.append(T(4, 130, '計画停止を、運転を予定する時間に含めるかどうかで答えが変わる', size=10))
    return _svg(360, 136, o, '計画停止がある場合の稼働率')


FIG['joho.avail2'] = _avail2()

FIG['joho.fault'] = grid(['考え方', 'ねらい', '例'],
                         [['フォールトアボイダンス', '故障そのものを起こさない', '品質の高い部品、点検の徹底'],
                          ['フォールトトレランス', '冗長にして、故障しても止めない', '二重化した構成'],
                          ['フェイルセーフ', '故障したら安全な側に止める', '信号機がすべて赤'],
                          ['フェイルソフト', '故障した部分を切り離し、機能を落としても動かし続ける', 'フォールバック（縮退運転）'],
                          ['フォールトマスキング', '故障の影響が外に現れないように隠す', '誤り訂正の符号'],
                          ['フェイルオーバ', '本番系の故障時に、自動で待機系に切り替える', '処理を引き継ぐ'],
                          ['フールプルーフ', '人の誤った操作でも事故にしない', 'ふたを閉めないと動かない']],
                         [116, 146, 98], align=['l', 'l', 'l'], title='信頼性を高める考え方', size=10)


def _backup():
    o = []
    days = ['日', '月', '火', '水']
    dcol = {'月': 'b', '火': 'c', '水': 'a'}
    o.append(T(4, 12, '水曜日に障害。復元に使うもの：', size=10, bold=True))
    for r, (nm, mode) in enumerate([('差分', 'diff'), ('増分', 'inc')]):
        y0 = 28 + r * 96
        o.append(T(4, y0 + 46, nm, size=11, bold=True, col='b' if r == 0 else 'c'))
        for i, d in enumerate(days):
            x = 46 + i * 50
            o.append(T(x + 20, y0 + 84, d, 'middle', size=10))
            if d == '日':
                o.append(R(x, y0 + 14, 40, 58, fill='sub', stroke='line', op=0.25, sw=1))
                o.append(T(x + 20, y0 + 47, 'フル', 'middle', size=10, bold=True))
                continue
            parts = days[1:i + 1] if mode == 'diff' else [d]
            yy = y0 + 72
            for p in parts:
                o.append(R(x + 6, yy - 14, 28, 14, fill=dcol[p], stroke=dcol[p], op=0.4, sw=0.8))
                o.append(T(x + 20, yy - 3.5, p, 'middle', size=9, bold=True))
                yy -= 14
        use = 'フル（日）＋水の差分の2つ' if mode == 'diff' else 'フル（日）＋月・火・水の増分すべて'
        o.append(R(252, y0 + 22, 106, 44, fill='b' if r == 0 else 'c', stroke=None, op=0.12, rx=4))
        for k, ln in enumerate(wrap(use, 98, 10)):
            o.append(T(305, y0 + 40 + k * 14, ln, 'middle', size=10, bold=True))
    o.append(T(4, 228, '差分：毎回の量が増えていくが、復元は2つで済む', size=10))
    o.append(T(4, 244, '増分：毎回の量は最も少ないが、復元にはすべてが必要', size=10))
    return _svg(360, 250, o, '差分バックアップと増分バックアップ')


FIG['joho.backup'] = _backup()

FIG['joho.site'] = grid(['代替の拠点', '用意しておくもの', '切り替え'],
                        [['ホットサイト', '本番と同じ設備を稼働させておく', 'すぐに切り替えられる'], ['ウォームサイト', '設備を用意しておく', '一定の準備の時間がかかる'],
                         ['コールドサイト', '場所や電源などだけ', '最も時間がかかる']],
                        [96, 150, 114], align=['l', 'l', 'l'], title='代替の拠点', size=10.5)


def _rpo():
    o = []
    o.append(ARROW([(4, 70), (356, 70)], col='line', sw=1.2, head=6))
    for x, s, col in [(70, '最後のバックアップ', 'b'), (190, '障害の発生', 'a'), (310, '復旧', 'b')]:
        o.append(L(x, 58, x, 82, col=col, sw=2))
        o.append(T(x, 98, s, 'middle', size=10, bold=True, col=col))
    o.append(ARROW([(188, 46), (72, 46)], col='c', sw=1.8, head=6))
    o.append(T(4, 14, 'RPO（目標復旧時点）', size=10.5, bold=True, col='c'))
    o.append(T(4, 30, 'どの時点までのデータを取り戻すか', size=9.5))
    o.append(ARROW([(192, 46), (308, 46)], col='a', sw=1.8, head=6))
    o.append(T(356, 14, 'RTO（目標復旧時間）', 'end', size=10.5, bold=True, col='a'))
    o.append(T(356, 30, 'どれだけの時間で復旧させるか', 'end', size=9.5))
    return _svg(360, 106, o, 'RPOとRTO')


FIG['joho.rpo'] = _rpo()


def _tco():
    g = G(xmax=150, ymax=1800, h=236, xlab='アカウント数', ylab='5年間の費用（万円）', pl=46, pb=40, pt=18, xlpos='low')
    g.line([(0, 0), (150, 1800)], col='b', sw=2.4, label='A案（クラウド）＝12万円×アカウント数', at=(8, 1640), lsize=10)
    g.line([(0, 1100), (150, 1100)], col='c', sw=2.4, label='B案（オンプレミス）＝1,100万円', at=(2, 1190), lsize=10)
    for v in (0, 600, 1100, 1800):
        g.yt(v, '{:,}'.format(v), size=9.5)
    for v in (50, 92, 150):
        g.xt(v, str(v), size=9.5, bold=(v == 92), col='a' if v == 92 else 'main')
    g.guide(50, 600, h=True, v=True)
    g.dot(50, 600, col='b', r=4, label='50のとき600', pos='se', size=9.5)
    g.dot(91.7, 1100, col='a', r=4.5)
    g.text(100, 940, '92以上でA案の方が高い', 'start', 'a', True, 10)
    return g.svg('クラウドとオンプレミスの総額の比較')


FIG['joho.tco'] = _tco()

FIG['joho.tcoeq'] = eq([[('A案', 'b'), '＝', '2,000円', '×', '50', '×', '12か月', '×', '5年', '＝', ('600万円', 'b')],
                        [('B案', 'c'), '＝', '初期600万円', '＋', '100万円', '×', '5年', '＝', ('1,100万円', 'c')]], '50アカウントで5年間使う場合', size=10.5)


def _pue():
    o = []
    o.append(R(4, 10, 220, 30, fill='b', stroke='b', op=0.3, sw=1))
    o.append(T(114, 30, 'IT機器 1,000kW', 'middle', size=10.5, bold=True))
    o.append(R(224, 10, 110, 30, fill='c', stroke='c', op=0.3, sw=1))
    o.append(T(279, 30, '空調など 500kW', 'middle', size=10, bold=True))
    brace(o, 4, 334, 46, 'データセンター全体 1,500kW', size=10)
    o.append(T(4, 92, 'PUE＝全体の消費電力÷IT機器の消費電力＝1,500÷1,000＝1.5', size=10.5, bold=True, col='b'))
    o.append(T(4, 110, '1に近いほど、空調などの設備の電力が少なく、効率がよい（数値は例）', size=10))
    return _svg(360, 116, o, 'PUE')


FIG['joho.pue'] = _pue()

FIG['joho.green'] = _lists([('Green of IT', 'b', ['IT機器そのものの省エネルギー']), ('Green by IT', 'c', ['ITを使って社会や業務の省エネルギーを進める（テレワーク、ペーパーレスなど）'])],
                           'グリーンIT', size=10.5)
