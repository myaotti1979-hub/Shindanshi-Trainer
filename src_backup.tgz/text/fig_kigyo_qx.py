# 企業経営理論の演習（マーケティング論）の解説専用の図表（問題の数値に合わせた図）
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, chart, R, T, _svg)

FIG = {}


def _markup(cost, rate):
    # 原価 cost の商品を、売価値入率 rate と原価値入率 rate で売る場合の比較（帯の長さ＝金額）
    w = 360
    o = []
    p1 = round(cost / (1 - rate))
    m1 = p1 - cost
    p2 = round(cost * (1 + rate))
    m2 = p2 - cost
    pc = int(round(rate * 100))
    rows = [('売価値入率%d％' % pc, p1, m1, 'a', '%s÷（1－%s）＝%s円：値入額%s円は売価の%d％' % (format(cost, ','), rate, format(p1, ','), m1, pc)),
            ('原価値入率%d％' % pc, p2, m2, 'c', '%s×%s＝%s円：値入額%s円は原価の%d％' % (format(cost, ','), 1 + rate, format(p2, ','), m2, pc))]
    x0 = 6
    sc = 250.0 / p1
    y = 6
    for nm, price, mk, col, note in rows:
        o.append(T(x0, y + 12, nm, size=10.5, bold=True, col=col))
        o.append(R(x0, y + 18, cost * sc, 26, fill='sub', stroke='line', op=0.18, sw=1))
        o.append(R(x0 + cost * sc, y + 18, mk * sc, 26, fill=col, stroke=col, op=0.3, sw=1))
        o.append(T(x0 + cost * sc / 2, y + 36, '原価%s円' % format(cost, ','), 'middle', size=10.5, bold=True))
        o.append(T(x0 + cost * sc + mk * sc + 4, y + 36, '売価%s円' % format(price, ','), size=10.5, bold=True, col=col))
        o.append(T(x0, y + 60, note, size=10))
        y += 72
    return _svg(w, y, o, '売価値入率と原価値入率のちがい（原価%s円）' % format(cost, ','))


FIG['kigyo.qx_markup840'] = _markup(840, 0.3)

FIG['kigyo.qx_weber200'] = chart([([(0, 0), (2200, 220)], 'a', False)], 0, 2300, 0, 250, xlab='元の価格（円）', ylab='気づかせるのに必要な値下げ幅（円）',
                                 dots=[(200, 20, 'a'), (2000, 200, 'a')], xticks=[(200, '200'), (1000, '1,000'), (2000, '2,000')],
                                 yticks=[(20, '20'), (100, '100'), (200, '200')],
                                 labels=[(330, 12, '200円の商品：20円引きで気づく', 'start', 'main'), (1960, 214, '2,000円の商品：200円引きが必要', 'end', 'a')],
                                 title='ウェーバーの法則（元の価格の10％で気づく場合）', h=210)

FIG['kigyo.qx_prem3000'] = grid(['取引価額3,000円のとき', '景品の上限'],
                                [['総付景品（購入者全員に渡す）', '3,000円×10分の2＝600円'], ['一般懸賞（くじなどで当たる）', '3,000円×20倍＝6万円']],
                                [190, 170], align=['l', 'l'], title='事例：取引価額3,000円の場合', size=10.5, hl_rows=(0,))
