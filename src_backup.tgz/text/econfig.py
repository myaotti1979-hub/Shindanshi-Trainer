# 経済学のテキスト用の図（1行のSVG文字列を返す）。色はページのCSS変数に合わせ、ダークモードでも読めるようにする
# 座標は「データ座標」（x: 0〜xmax, y: 0〜ymax）で指定する
import math

COL = {'main': 'currentColor', 'a': 'var(--drop)', 'b': 'var(--good)', 'c': 'var(--warn)', 'sub': 'var(--ink-3)'}

def fig(lines=(), labels=(), guides=(), areas=(), dots=(), xlab='', ylab='', xmax=10, ymax=10, w=360, h=250, title=''):
    L, R, T, B = 38, 14, 14, 30
    pw, ph = w - L - R, h - T - B
    def X(x): return round(L + x / xmax * pw, 1)
    def Y(y): return round(T + ph - y / ymax * ph, 1)
    out = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" role="img" aria-label="%s" font-size="12">' % (w, h, title or '図')]
    for pts, col in areas:
        d = ' '.join('%s,%s' % (X(a), Y(b)) for a, b in pts)
        out.append('<polygon points="%s" style="fill:%s;opacity:.22;stroke:none"/>' % (d, COL.get(col, col)))
    # 軸
    out.append('<path d="M%s %sV%sH%s" fill="none" stroke="currentColor" stroke-width="1.4"/>' % (X(0), Y(ymax) - 4, Y(0), X(xmax) + 4))
    out.append('<path d="M%s %sl-3 6h6z M%s %sl-6 -3v6z" fill="currentColor"/>' % (X(0), Y(ymax) - 6, X(xmax) + 7, Y(0)))
    if ylab: out.append('<text x="%s" y="%s" fill="currentColor">%s</text>' % (X(0) + 6, Y(ymax) + 4, ylab))
    if xlab: out.append('<text x="%s" y="%s" text-anchor="end" fill="currentColor">%s</text>' % (X(xmax) + 4, Y(0) + 20, xlab))
    out.append('<text x="%s" y="%s" text-anchor="end" fill="currentColor">0</text>' % (X(0) - 4, Y(0) + 14))
    for (x1, y1, x2, y2) in guides:
        out.append('<path d="M%s %sL%s %s" fill="none" stroke="currentColor" stroke-width="1" stroke-dasharray="3 3" opacity=".6"/>' % (X(x1), Y(y1), X(x2), Y(y2)))
    for ln in lines:
        pts, col = ln[0], ln[1]
        dash = ln[2] if len(ln) > 2 else ''
        d = 'M' + ' L'.join('%s %s' % (X(a), Y(b)) for a, b in pts)
        out.append('<path d="%s" fill="none" style="stroke:%s" stroke-width="2"%s stroke-linecap="round" stroke-linejoin="round"/>' % (d, COL.get(col, col), ' stroke-dasharray="6 4"' if dash else ''))
    for (x, y, col) in dots:
        out.append('<circle cx="%s" cy="%s" r="3.2" style="fill:%s"/>' % (X(x), Y(y), COL.get(col, col)))
    for lb in labels:
        x, y, t = lb[0], lb[1], lb[2]
        anc = lb[3] if len(lb) > 3 else 'start'
        col = lb[4] if len(lb) > 4 else 'main'
        out.append('<text x="%s" y="%s" text-anchor="%s" style="fill:%s">%s</text>' % (X(x), Y(y) + 4, anc, COL.get(col, col), t))
    out.append('</svg>')
    return ''.join(out)

def curve(f, x0, x1, n=40):
    return [(x0 + (x1 - x0) * i / n, f(x0 + (x1 - x0) * i / n)) for i in range(n + 1)]

def table(rows, w=360, colw=None, title=''):
    # 簡単な表（利得行列など）。rows は文字列の2次元リスト。1行目・1列目は見出し
    nr, nc = len(rows), len(rows[0])
    colw = colw or [w / nc] * nc
    rh = 30; h = rh * nr + 2
    out = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" role="img" aria-label="%s" font-size="12">' % (w, h, title or '表')]
    y = 1
    for i, r in enumerate(rows):
        x = 1
        for j, c in enumerate(r):
            head = (i == 0 or j == 0)
            out.append('<rect x="%s" y="%s" width="%s" height="%s" style="fill:%s;stroke:var(--ink-3)" stroke-width="1"/>' % (round(x, 1), y, round(colw[j] - 2, 1), rh, 'var(--paper)' if head else 'var(--sheet)'))
            out.append('<text x="%s" y="%s" text-anchor="middle" fill="currentColor"%s>%s</text>' % (round(x + (colw[j] - 2) / 2, 1), y + 19, ' font-weight="bold"' if head else '', c))
            x += colw[j]
        y += rh
    out.append('</svg>')
    return ''.join(out)
