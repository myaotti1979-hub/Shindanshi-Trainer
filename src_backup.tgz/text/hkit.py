# 経営法務の図表の部品：当事者の関係図（箱と矢印）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import ARROW, R, T, L, _svg, wrap, tw
from kit import _box
from ekit import txt


def _clip(cx, cy, bw, bh, dx, dy, pad=3):
    # 箱の中心 (cx, cy) から向き (dx, dy) に進んだときの、箱の縁との交点（少し外側）
    tx = (bw / 2 + pad) / abs(dx) if dx else 1e9
    ty = (bh / 2 + pad) / abs(dy) if dy else 1e9
    t = min(tx, ty)
    return cx + dx * t, cy + dy * t


def rel(nodes, edges, title, w=360, h=None, size=10.5, notes=(), lsize=10):
    """当事者の関係図。
    nodes: {key: (x, y, 幅, 高さ, 文字, 色)}（x, y は左上。文字は \\n で改行、1行目を太字）
    edges: [(from, to, 文字, 色, 点線か, ずらし量, (文字のx方向のずれ, y方向のずれ))]。ずらし量は矢印を左右に平行移動する量
           （往復の矢印を分けるとき）。文字は矢印の中ほどに、背景を抜いて置く。文字は \\n で改行できる
    notes: [(x, y, 文字, 色, 揃え, 太字か)]"""
    o = []
    for k, (x, y, bw, bh, s, col) in nodes.items():
        _box(o, x, y, bw, bh, s, col=col, size=size)
    for e in edges:
        a, b, s = e[0], e[1], e[2]
        col = e[3] if len(e) > 3 else 'main'
        dash = e[4] if len(e) > 4 else False
        off = e[5] if len(e) > 5 else 0
        ax, ay, aw, ah = nodes[a][:4]
        bx, by, bw2, bh2 = nodes[b][:4]
        c1 = (ax + aw / 2, ay + ah / 2)
        c2 = (bx + bw2 / 2, by + bh2 / 2)
        dx, dy = c2[0] - c1[0], c2[1] - c1[1]
        n = math.hypot(dx, dy) or 1
        ux, uy = dx / n, dy / n
        px, py = -uy * off, ux * off
        p1 = _clip(c1[0] + px, c1[1] + py, aw, ah, ux, uy)
        p2 = _clip(c2[0] + px, c2[1] + py, bw2, bh2, -ux, -uy)
        o.append(ARROW([p1, p2], col=col, sw=1.5, head=6, dash='5 3' if dash else None))
        if s:
            sh = e[6] if len(e) > 6 else (0, 0)
            mx, my = (p1[0] + p2[0]) / 2 + sh[0], (p1[1] + p2[1]) / 2 + sh[1]
            ls = s.split('\n')
            for j, ln in enumerate(ls):
                o.append(txt(mx, my + 4 + (j - (len(ls) - 1) / 2) * (lsize + 3), ln, 'middle', col, True, lsize))
    for nt in notes:
        x, y, s = nt[0], nt[1], nt[2]
        col = nt[3] if len(nt) > 3 else 'main'
        anc = nt[4] if len(nt) > 4 else 'start'
        bold = nt[5] if len(nt) > 5 else False
        for j, ln in enumerate(s.split('\n')):
            o.append(txt(x, y + j * 14, ln, anc, col, bold, 10.5))
    if h is None:
        h = max(v[1] + v[3] for v in nodes.values()) + 6
        if notes:
            h = max(h, max(nt[1] + 14 * len(nt[2].split('\n')) for nt in notes))
    return _svg(w, h, o, title)
