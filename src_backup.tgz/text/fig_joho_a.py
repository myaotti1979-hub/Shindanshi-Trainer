# 経営情報システムの図表（1.1 ハードウェア、ソフトウェア、プログラム設計、ソフトウェア開発）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, htree, ARROW, R, T, L, _svg, _c, wrap, tw)
from kit import (_lines, _dashrect, _box, _lists, _flow, _rowflow, _nest)
from ekit import G, txt, eq
from jkit import stack, tiles, dtab, lab, pc, srv, cyl, person, brace, code, r1, MONO

FIG = {}


def poly(o, pts, col='main', fill=None, op=0.16, sw=1.3, dash=None):
    d = 'M' + ' L'.join('%s %s' % (r1(a), r1(b)) for a, b in pts) + ' Z'
    ds = ' stroke-dasharray="%s"' % dash if dash else ''
    if fill:
        o.append('<path d="%s" style="fill:var(--sheet);stroke:none"/>' % d)
        o.append('<path d="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="%s"%s/>' % (d, _c(fill), op, _c(col), sw, ds))
    else:
        o.append('<path d="%s" style="fill:var(--sheet);stroke:%s" stroke-width="%s"%s/>' % (d, _c(col), sw, ds))


# ------------------------------------------------ 1.1.1 ハードウェア
def _five():
    o = []
    _box(o, 6, 20, 80, 40, '入力装置', size=11)
    _box(o, 150, 20, 90, 40, '記憶装置\n（主記憶）', size=11)
    _box(o, 274, 20, 80, 40, '出力装置', size=11)
    o.append(_dashrect(96, 92, 172, 82, col='a'))
    o.append(T(48, 128, 'CPU', 'middle', size=11, bold=True, col='a'))
    o.append(T(48, 143, '中央処理装置', 'middle', size=10, col='a'))
    _box(o, 104, 118, 74, 44, '制御装置', col='a', size=11, c0='a')
    _box(o, 190, 118, 72, 44, '演算装置', col='a', size=11, c0='a')
    o.append(ARROW([(88, 40), (148, 40)], sw=1.8))
    o.append(ARROW([(242, 40), (272, 40)], sw=1.8))
    o.append(ARROW([(205, 62), (205, 116)], sw=1.8))
    o.append(ARROW([(232, 116), (232, 62)], sw=1.8))
    o.append(ARROW([(120, 116), (120, 80), (46, 80), (46, 62)], col='a', sw=1.3, dash='4 3', head=6))
    o.append(ARROW([(160, 116), (160, 62)], col='a', sw=1.3, dash='4 3', head=6))
    o.append(ARROW([(140, 164), (140, 186), (314, 186), (314, 62)], col='a', sw=1.3, dash='4 3', head=6))
    o.append(ARROW([(178, 140), (188, 140)], col='a', sw=1.3, dash='4 3', head=5))
    o.append(L(10, 206, 36, 206, col='main', sw=1.8))
    o.append(T(42, 210, 'データの流れ', size=10.5))
    o.append(L(130, 206, 156, 206, col='a', sw=1.3, dash='4 3'))
    o.append(T(162, 210, '制御の流れ（制御装置が指示する）', size=10.5, col='a'))
    return _svg(360, 218, o, 'コンピュータの5大装置')


FIG['joho.five'] = _five()


def _bus():
    o = []
    _box(o, 4, 10, 76, 110, 'CPU', col='a', size=12, c0='a')
    _box(o, 280, 10, 76, 110, '主記憶', size=12)
    rows = [('アドレスバス', '記憶場所の番地を運ぶ', 'one'), ('データバス', 'データそのものを運ぶ', 'two'), ('制御バス', '制御信号を運ぶ', 'two')]
    for i, (a, b, k) in enumerate(rows):
        y = 34 + i * 32
        if k == 'one':
            o.append(ARROW([(84, y), (276, y)], sw=1.8))
        else:
            o.append(ARROW([(110, y), (276, y)], sw=1.8))
            o.append(ARROW([(250, y), (84, y)], sw=1.8))
        o.append(txt(180, y - 5, a + '：' + b, 'middle', size=10.5, bold=(False)))
    return _svg(360, 126, o, 'バス')


FIG['joho.bus'] = _bus()

FIG['joho.cpucalc'] = eq([[('1命令の平均実行時間', 'c'), '＝', 'CPI　4', '÷', 'クロック周波数\n2GHz（1秒に20億回）', '＝', ('2ナノ秒', 'a')],
                          [('1秒に実行できる命令', 'c'), '＝', '1秒', '÷', '2ナノ秒', '＝', ('5億個\n＝500MIPS', 'b')]],
                         'CPUの性能の計算', size=10.5)


def _memhier():
    o = []
    lv = [('レジスタ', 'a', 'CPUの中'), ('キャッシュメモリ', 'a', 'SRAM。CPUと主記憶の速度の差を埋める'),
          ('主記憶', 'c', 'DRAM。電源を切ると消える（揮発性）'), ('補助記憶', 'b', 'SSD、HDDなど。電源を切っても残る')]
    pw, lh = 170, 40
    for i, (s, col, note) in enumerate(lv):
        wt, wb = pw * (0.22 + 0.78 * i / 4), pw * (0.22 + 0.78 * (i + 1) / 4)
        cx, y = 2 + pw / 2, 18 + i * lh
        poly(o, [(cx - wt / 2, y), (cx + wt / 2, y), (cx + wb / 2, y + lh - 3), (cx - wb / 2, y + lh - 3)], col=col, fill=col, op=0.22, sw=1.2)
        o.append(T(cx, y + lh / 2 + 3, s, 'middle', size=10.5, bold=True))
        for k, ln in enumerate(wrap(note, 132, 10)):
            o.append(T(180, y + 14 + k * 13, ln, size=10))
    o.append(ARROW([(346, 172), (346, 6)], col='a', sw=1.6, head=6))
    o.append(T(338, 12, '速い・高い', 'end', size=10.5, bold=True, col='a'))
    o.append(T(356, 192, '遅い・容量が大きい・容量あたり安い', 'end', size=10.5, bold=True, col='b'))
    return _svg(360, 198, o, '記憶の階層')


FIG['joho.memhier'] = _memhier()

FIG['joho.memtype'] = htree(('半導体\nメモリ', None, [
    ('RAM\n電源を切ると消える（揮発性）', 'a', [('DRAM\n主記憶に使う', 'a', []), ('SRAM\n高速。キャッシュメモリに使う', 'a', [])]),
    ('ROM\n電源を切っても消えない（不揮発性）', 'b', [('EPROM\n紫外線を当てて消去する', 'b', []),
                                         ('フラッシュメモリ\n電気的に消去・書換え。回数に上限', 'b', [
                                             ('NAND型\n大容量。データの保存（USBメモリ、SSD）', 'b', []),
                                             ('NOR型\n読み出しが速い。プログラムの格納', 'b', [])])])]),
    '半導体メモリの種類', colw=(50, 82, 100, 104), gapx=7, size=10)


def _raid():
    o = []
    pan = [('RAID0', 'ストライピング', [['A1', 'A3', 'A5'], ['A2', 'A4', 'A6']], '1台の故障でデータを失う', 'a'),
           ('RAID1', 'ミラーリング', [['A1', 'A2', 'A3'], ['A1', 'A2', 'A3']], '1台が故障しても読める。容量は半分', 'b'),
           ('RAID5', 'パリティを分散', [['A1', 'B1', 'P'], ['A2', 'P', 'C1'], ['P', 'B2', 'C2']], '1台の故障までは復旧できる', 'b')]
    for k, (nm, sub, disks, note, nc) in enumerate(pan):
        x0 = 2 + k * 120
        o.append(T(x0 + 58, 14, nm, 'middle', bold=True, size=12))
        o.append(T(x0 + 58, 29, sub, 'middle', size=10.5))
        n = len(disks)
        dw = 30 if n == 3 else 34
        gap = (116 - n * dw) / (n + 1)
        for j, blocks in enumerate(disks):
            dx = x0 + gap + j * (dw + gap)
            o.append(R(dx, 38, dw, 82, fill='sheet', stroke='main', sw=1.2, rx=5))
            for b, s in enumerate(blocks):
                par = s == 'P'
                o.append(R(dx + 3, 44 + b * 25, dw - 6, 21, fill='c' if par else 'b', stroke=None, op=0.35 if par else 0.18, rx=2))
                o.append(T(dx + dw / 2, 58 + b * 25, s, 'middle', size=10.5, bold=par))
        for i, ln in enumerate(wrap(note, 112, 10)):
            o.append(T(x0 + 58, 136 + i * 13, ln, 'middle', size=10, col=nc, bold=True))
    o.append(T(4, 172, 'A1、A2…：データを分けたもの。P：パリティ（誤りを訂正するための情報）', size=10))
    return _svg(360, 178, o, 'RAIDのしくみ')


FIG['joho.raid'] = _raid()

FIG['joho.raidtbl'] = grid(['方式', 'しくみ', '最低の台数', '使える容量（n台）', '耐える故障'],
                           [['RAID0', 'ストライピング', '2台', 'n台分', '0台'],
                            ['RAID1', 'ミラーリング', '2台', '半分（2台なら1台分）', '1台'],
                            ['RAID5', 'パリティを分散', '3台', 'n－1台分', '1台'],
                            ['RAID6', 'パリティを2種類', '4台', 'n－2台分', '2台'],
                            ['RAID10', 'ミラーをストライピング', '4台', '半分', '組ごとに1台']],
                           [50, 100, 50, 90, 70], align=['l', 'l', 'c', 'c', 'c'], title='RAIDの比較', size=10.5,
                           tcol={'0台': 'a'})


def _stor():
    o = []
    rows = [('DAS', 18), ('NAS', 92), ('SAN', 172)]
    for nm, y in rows:
        _box(o, 2, y - 14, 44, 30, nm, col='c', size=11, c0='c', op=0.22)
    # DAS
    srv(o, 82, 22)
    cyl(o, 160, 22, w=30, h=32)
    o.append(L(96, 22, 144, 22, col='main', sw=2.4))
    o.append(T(120, 15, '直結', 'middle', size=10))
    o.append(txt(196, 18, 'サーバに直接つなぐ', size=10.5, halo=False))
    o.append(txt(196, 33, '（そのサーバ専用）', size=10.5, halo=False))
    # NAS
    o.append(L(62, 104, 186, 104, col='b', sw=2))
    o.append(T(124, 122, 'LAN', 'middle', size=10, col='b', bold=True))
    for x in (74, 112):
        pc(o, x, 82)
        o.append(L(x, 95, x, 104, col='b', sw=1.4))
    cyl(o, 166, 80, w=30, h=30, inside='NAS', isize=9)
    o.append(L(166, 95, 166, 104, col='b', sw=1.4))
    o.append(txt(196, 88, 'LANにつなぎ、', size=10.5, halo=False))
    o.append(txt(196, 103, 'ファイル単位で共有', size=10.5, halo=False, bold=True))
    o.append(txt(196, 118, '（ファイルサーバ）', size=10.5, halo=False))
    # SAN
    for y in (156, 196):
        srv(o, 74, y)
    o.append(R(108, 168, 30, 16, fill='a', stroke='a', op=0.25, rx=3))
    o.append(T(123, 180, 'SW', 'middle', size=9, bold=True, col='a'))
    for y in (156, 196):
        o.append(L(86, y, 108, 176, col='a', sw=2))
        cyl(o, 170, y, w=28, h=28)
        o.append(L(138, 176, 156, y, col='a', sw=2))
    o.append(txt(196, 168, '専用の高速なネットワーク', size=10.5, halo=False))
    o.append(txt(196, 183, 'ブロック単位で読み書き', size=10.5, halo=False, bold=True))
    return _svg(360, 218, o, 'ストレージの接続')


FIG['joho.stor'] = _stor()


def _thin():
    o = []
    rows = [('シックプロビジョニング', 'a', 100, '最初から物理的に確保'), ('シンプロビジョニング', 'b', 30, '使った分だけ物理的に割り当て')]
    for i, (nm, col, phys, note) in enumerate(rows):
        y = 6 + i * 70
        o.append(T(4, y + 12, nm, bold=True, size=11, col=col))
        x0, W = 4, 300
        o.append(_dashrect(x0, y + 20, W, 30, col='main', rx=3))
        o.append(R(x0, y + 20, W * phys / 100, 30, fill=col, stroke=col, op=0.18, rx=3))
        o.append(R(x0, y + 20, W * 0.3, 30, fill=col, stroke=None, op=0.4, rx=3))
        o.append(T(x0 + W * 0.15, y + 39, '使用中30GB', 'middle', size=10, bold=True))
        o.append(T(x0 + W + 6, y + 32, '割当て', size=10))
        o.append(T(x0 + W + 6, y + 45, '100GB', size=10))
        o.append(T(x0 + W * phys / 100 - 4 if phys == 100 else x0 + W * 0.3 + 6, y + 64, note, 'end' if phys == 100 else 'start', size=10, col=col))
    return _svg(360, 146, o, 'シンプロビジョニング')


FIG['joho.thin'] = _thin()


def _serpar():
    o = []
    o.append(T(4, 14, 'シリアル伝送：1本の線で1ビットずつ順に送る', bold=True, size=11, col='b'))
    _box(o, 2, 22, 40, 30, '送る', size=10)
    _box(o, 318, 22, 40, 30, '受ける', size=10)
    o.append(L(42, 37, 318, 37, col='b', sw=1.6))
    for k, b in enumerate('10110010'):
        x = 70 + k * 30
        o.append('<circle cx="%s" cy="37" r="9" style="fill:var(--sheet);stroke:%s" stroke-width="1.2"/>' % (x, _c('b')))
        o.append(T(x, 41, b, 'middle', size=10.5, bold=True))
    o.append(T(4, 72, '例：USB、SATA、e-SATA、PCI Express、IEEE1394、HDMI', size=10.5))
    o.append(T(4, 98, 'パラレル伝送：複数の線で同時に送る', bold=True, size=11, col='c'))
    _box(o, 2, 106, 40, 104, '送る', size=10)
    _box(o, 318, 106, 40, 104, '受ける', size=10)
    offs = [0, 6, -4, 10, 2, -6, 8, 4]
    for k, b in enumerate('10110010'):
        y = 113 + k * 12.5
        o.append(L(42, y, 318, y, col='c', sw=1.2))
        x = 180 + offs[k] * 3
        o.append(R(x - 7, y - 5.5, 14, 11, fill='sheet', stroke='c', sw=1, rx=2))
        o.append(T(x, y + 3.6, b, 'middle', size=9, bold=True))
    o.append(T(4, 228, '高速にすると、線の間で信号のずれが生じやすい', size=10.5, col='a'))
    o.append(T(4, 244, '例：SCSI、IEEE1284（プリンタ用）、パラレルATA（IDE）', size=10.5))
    return _svg(360, 250, o, 'シリアル伝送とパラレル伝送')


FIG['joho.serpar'] = _serpar()


def _usb():
    o = []
    # Type-C
    o.append(R(14, 18, 62, 24, fill='sheet', stroke='main', sw=1.6, rx=12))
    o.append(R(28, 27, 34, 6, fill='main', stroke=None, rx=3, op=0.6))
    o.append(T(45, 60, 'Type-C', 'middle', bold=True, size=11))
    o.append(txt(96, 24, '上下の向きがない', col='b', bold=True, size=11, halo=False))
    o.append(txt(96, 41, 'どちら向きでも差し込める。映像の出力に', size=10.5, halo=False))
    o.append(txt(96, 56, '対応する機器もある', size=10.5, halo=False))
    # Standard-A
    o.append(R(12, 84, 66, 26, fill='sheet', stroke='main', sw=1.6, rx=2))
    o.append(R(16, 88, 58, 9, fill='main', stroke=None, op=0.6))
    o.append(T(45, 128, 'Standard-A', 'middle', bold=True, size=11))
    o.append(txt(96, 90, '上下の向きがある', col='a', bold=True, size=11, halo=False))
    o.append(txt(96, 107, '決まった向きでしか差し込めない。2.0と', size=10.5, halo=False))
    o.append(txt(96, 122, '3.xは同じ形で、互いに差し込める', size=10.5, halo=False))
    o.append(L(4, 140, 356, 140, col='line', sw=0.8))
    o.append(txt(4, 158, '形の違うコネクタどうし（Standard-AのプラグとType-Cの', size=10.5, halo=False))
    o.append(txt(4, 173, '受け口など）は、変換アダプタなしでは差し込めない', size=10.5, halo=False))
    return _svg(360, 180, o, 'USBのコネクタ')


FIG['joho.usb'] = _usb()

FIG['joho.usbf'] = tiles([('ホットプラグ\n電源を入れたまま抜き差しできる', 'b'), ('バスパワー\nケーブルで電力を供給。USB PDはより大きな電力', 'b'),
                          ('速度\n規格の違う機器をつなぐと、遅い方の規格の速度', 'c')], 'USBの特徴', cols=3, size=10.5)

FIG['joho.touch'] = grid(['方式', '位置の検出', '手袋・ペン', '同時に複数の点'],
                         [['抵抗膜（感圧式）', '押された圧力', '使える', '向かない'],
                          ['静電容量', '表面の電荷の変化', '素手か専用のペン', '向く'],
                          ['赤外線', '赤外線が遮られた位置', '使える', '対応できる']],
                         [84, 118, 82, 76], align=['l', 'l', 'c', 'c'], title='タッチパネルの方式', size=10.5,
                         tcol={'向く': 'b', '対応できる': 'b', '向かない': 'a', '使える': 'b', '素手か専用のペン': 'c'})

FIG['joho.sensor'] = grid(['センサー', '測るもの・わかること'],
                          [['加速度センサー', '傾きや動き、重力加速度'], ['ジャイロセンサー', '回転の速さ（角速度）'],
                           ['磁気センサー', '地磁気から方位（電子コンパス）'], ['近接センサー', '顔が近づいたこと'],
                           ['照度センサー', '周囲の明るさ'], ['GPS', '現在の位置'], ['サーミスタ', '温度（温度で電気抵抗が変わる素子）']],
                          [120, 240], align=['l', 'l'], title='センサーの例', size=10.5)


def _qr():
    o = []
    m, x0, y0, n = 5, 8, 8, 21
    o.append(R(x0 - 4, y0 - 4, n * m + 8, n * m + 8, fill='sheet', stroke='line', sw=0.8))
    seed = 7
    cells = set()
    for i in range(n):
        for j in range(n):
            seed = (seed * 1103515245 + 12345) % 2147483648
            if (seed >> 16) % 2:
                cells.add((i, j))
    def finder(fi, fj):
        for i in range(-1, 8):
            for j in range(-1, 8):
                cells.discard((fi + i, fj + j))
        for i in range(7):
            for j in range(7):
                if i in (0, 6) or j in (0, 6) or (2 <= i <= 4 and 2 <= j <= 4):
                    cells.add((fi + i, fj + j))
    for fi, fj in ((0, 0), (0, 14), (14, 0)):
        finder(fi, fj)
    for (i, j) in cells:
        if 0 <= i < n and 0 <= j < n:
            fin = (i < 7 and j < 7) or (i < 7 and j >= 14) or (i >= 14 and j < 7)
            o.append('<rect x="%s" y="%s" width="%s" height="%s" style="fill:%s"/>' % (x0 + j * m, y0 + i * m, m, m, _c('a') if fin else 'currentColor'))
    o.append(ARROW([(150, 20), (118, 20)], col='a', sw=1.3, head=5))
    o.append(txt(156, 16, '切り出しシンボル（3つの角）', col='a', bold=True, size=10.5, halo=False))
    o.append(txt(156, 31, '位置と向きを検出する', size=10.5, halo=False))
    for k, s in enumerate(['縦と横の2方向に情報を持つ', '数字・英字・かな・漢字', '誤り訂正の機能（汚れや破損', 'があっても読める）']):
        o.append(txt(156, 60 + k * 16, ('・' if k < 3 else '　') + s, size=10.5, halo=False))
    return _svg(360, 128, o, 'QRコード')


FIG['joho.qr'] = _qr()

FIG['joho.autoid'] = grid(['', 'しくみ', '特徴'],
                          [['QRコード', '2次元コードを読み取る', '誤り訂正。切り出しシンボルで位置と向きを検出'],
                           ['RFID', 'ICタグを電波で非接触で読み書き', '箱の中や複数のタグを一括で読める。パッシブタグ（電池なし）とアクティブタグ（電池内蔵）'],
                           ['NFC', '13.56MHz帯。通信距離は10cm程度', '交通系ICカード、電子マネー、スマートフォンの決済、マイナンバーカードの読み取り']],
                          [62, 118, 180], align=['l', 'l', 'l'], title='自動認識の技術', size=10.5)

FIG['joho.display'] = grid(['方式', '光り方', '特徴'],
                           [['液晶：TN', 'バックライトが必要', '応答速度が速い。視野角が狭い'], ['液晶：IPS', 'バックライトが必要', '視野角が広い。色の再現性がよい'],
                            ['液晶：VA', 'バックライトが必要', 'コントラスト比が高い'], ['有機EL', '素子が自ら光る（バックライト不要）', '薄くできる。コントラストが高い']],
                           [70, 128, 162], align=['l', 'l', 'l'], title='ディスプレイの方式', size=10.5, tcol={'バックライトが必要': 'c'})

FIG['joho.printer'] = grid(['プリンタ', 'しくみと特徴'],
                           [['インクジェット', 'インクの細かい粒を紙に吹き付ける'], ['レーザ', '感光ドラムのトナーを紙に写し、熱で定着。速く、静か'],
                            ['ドットインパクト', '細いピンでインクリボンをたたく。カーボン紙の複写伝票に印字できる'], ['熱転写', '熱でインクリボンのインクを溶かして写す']],
                           [100, 260], align=['l', 'l'], title='プリンタの方式', size=10.5)

FIG['joho.bits'] = grid(['ビット数', '表せる数', '例'],
                        [['1ビット', '2通り（0か1）', '情報の最小の単位'], ['7ビット', '2の7乗＝128通り', 'ASCII（英数字と記号）'],
                         ['8ビット', '2の8乗＝256通り', '1バイト。GIFの色の数の上限'],
                         ['24ビット', '256の3乗＝約1,677万通り', 'フルカラー（RGBの各色を8ビット）']],
                        [66, 150, 144], align=['l', 'l', 'l'], title='ビット数と表せる数', size=10.5)


def _utf8():
    o = []
    rows = [('A', '1バイト', ['41'], 'b'), ('é', '2バイト', ['C3', 'A9'], 'c'), ('あ', '3バイト', ['E3', '81', '82'], 'a')]
    for i, (ch, nb, bs, col) in enumerate(rows):
        y = 4 + i * 34
        o.append(R(4, y, 30, 28, fill='sheet', stroke='main', sw=1.2, rx=4))
        o.append(T(19, y + 20, ch, 'middle', size=15, bold=True))
        o.append(ARROW([(40, y + 14), (66, y + 14)], sw=1.4, head=5))
        for k, b in enumerate(bs):
            o.append(R(72 + k * 38, y + 2, 34, 24, fill=col, stroke=col, op=0.2, rx=3))
            o.append(T(89 + k * 38, y + 19, b, 'middle', size=11, bold=True))
        o.append(T(232, y + 19, nb, size=11, bold=True, col=col))
    o.append(T(4, 120, 'UTF-8は1文字を1〜4バイトの可変長で表す（16進数で表記）', size=10.5))
    return _svg(360, 126, o, 'UTF-8の例')


FIG['joho.utf8'] = _utf8()


def _rgbcmy():
    o = []
    defs = [('光の3原色（加法混色）', 54, [('R', '#e53935'), ('G', '#43a047'), ('B', '#1e88e5')], ['Y', 'M', 'C', '白'],
             '混ぜるほど明るくなる。ディスプレイ'),
            ('色の3原色（減法混色）', 234, [('C', '#00acc1'), ('M', '#d81b60'), ('Y', '#fdd835')], ['青', '緑', '赤', '黒'],
             '混ぜるほど暗くなる。印刷（＋黒でCMYK）')]
    for ttl, x0, cs, mix, note in defs:
        cx, cy, r, d = x0 + 36, 92, 34, 21
        pos = [(cx - d, cy - d * 0.6), (cx + d, cy - d * 0.6), (cx, cy + d * 0.75)]
        o.append(T(cx, 14, ttl, 'middle', bold=True, size=11))
        for (x, y), (nm, colr) in zip(pos, cs):
            o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;fill-opacity:0.32;stroke:%s" stroke-width="1.4"/>' % (r1(x), r1(y), r, colr, colr))
        lp = [(cx - d - 16, cy - d * 0.6 - 10), (cx + d + 16, cy - d * 0.6 - 10), (cx, cy + d * 0.75 + 22)]
        for (x, y), (nm, colr) in zip(lp, cs):
            o.append(T(x, y + 4, nm, 'middle', size=12, bold=True))
        mp = [(cx, cy - d * 0.95), (cx - d * 0.95, cy + d * 0.35), (cx + d * 0.95, cy + d * 0.35), (cx, cy + 1)]
        for (x, y), s in zip(mp, mix):
            o.append(T(x, y + 4, s, 'middle', size=10, bold=True))
        for k, ln in enumerate(wrap(note, 170, 10.5)):
            o.append(T(cx, 160 + k * 14, ln, 'middle', size=10.5))
    return _svg(360, 184, o, '光の3原色と色の3原色')


FIG['joho.rgbcmy'] = _rgbcmy()

FIG['joho.imgfmt'] = grid(['形式', '圧縮', '色', '特徴'],
                          [['BMP', '圧縮しない', '', 'ラスタ形式'], ['JPEG', '非可逆', 'フルカラー', '写真に向く'],
                           ['GIF', '可逆', '256色まで', '透過、アニメーション'], ['PNG', '可逆', 'フルカラー', '透過'],
                           ['SVG', '', '', 'ベクタ形式。拡大しても画質が落ちない']],
                          [52, 74, 80, 154], align=['l', 'c', 'c', 'l'], title='静止画のファイル形式', size=10.5,
                          tcol={'非可逆': 'a', '可逆': 'b', '256色まで': 'a'})


def _rastvec():
    o = []
    o.append(T(80, 14, 'ラスタ形式', 'middle', bold=True, size=11, col='c'))
    o.append(T(270, 14, 'ベクタ形式', 'middle', bold=True, size=11, col='b'))
    cx, cy, r, m = 80, 74, 42, 7
    for i in range(-7, 7):
        for j in range(-7, 7):
            px, py = j * m + m / 2, i * m + m / 2
            dd = math.hypot(px, py)
            if r - m * 1.2 < dd < r + 1:
                o.append('<rect x="%s" y="%s" width="%s" height="%s" style="fill:%s;fill-opacity:0.7"/>' % (r1(cx + j * m), r1(cy + i * m), m, m, _c('c')))
    o.append('<circle cx="270" cy="74" r="40" style="fill:none;stroke:%s" stroke-width="5"/>' % _c('b'))
    o.append(T(80, 136, '点（画素）の集まり', 'middle', size=10.5))
    o.append(T(80, 151, '拡大すると粗くなる', 'middle', size=10.5, col='a'))
    o.append(T(270, 136, '座標や線の情報', 'middle', size=10.5))
    o.append(T(270, 151, '拡大しても画質が落ちない', 'middle', size=10.5, col='b'))
    return _svg(360, 158, o, 'ラスタ形式とベクタ形式')


FIG['joho.rastvec'] = _rastvec()

FIG['joho.avfmt'] = grid(['', '形式', 'ポイント'],
                         [['音声', 'WAV', '非圧縮で使われることが多い'], ['音声', 'MP3、AAC', '非可逆圧縮'],
                          ['動画', 'MP4、AVI', '映像・音声・字幕をまとめて格納する形式（コンテナ）。中身はH.264やAACなどで圧縮（非可逆）']],
                         [44, 86, 230], align=['c', 'l', 'l'], title='音声と動画の形式', size=10.5)


def _pcm():
    f = lambda x: 3.5 + 3.2 * math.sin(2 * math.pi * x / 8)
    g = G(xmax=8, ymax=7.6, h=262, pl=30, pt=10, pb=84, xlab='時間', ylab='', origin='', xlpos='above')
    for lv in range(8):
        g.seg(0, lv, 8, lv, col='line', dash='2 3', sw=0.7, op=0.8)
        g.yt(lv, str(lv), size=9.5)
    g.fn(f, 0, 8, col='sub', sw=1.6)
    codes = []
    for k in range(8):
        x = k + 0.5
        q = int(round(f(x)))
        g.seg(x, 0, x, f(x), col='b', dash='3 2', sw=1)
        g.dot(x, f(x), col='sub', r=2.6)
        g.dot(x, q, col='a', r=4)
        codes.append(format(q, '03b'))
        g.text(x, -0.9, format(q, '03b'), 'middle', 'a', True, 10.5)
    g.raw(txt(g.X(0) + 4, g.Y(0) + 40, '↑ 符号化：段階を2進数で表す', col='a', bold=True, size=10.5, halo=False))
    g.raw(txt(g.X(0) + 4, g.Y(0) + 58, '灰色の線＝元の音。緑の点線＝標本化（一定の間隔で測る）', size=10, halo=False))
    g.raw(txt(g.X(0) + 4, g.Y(0) + 73, '赤い点＝量子化（8段階＝3ビットに当てはめる）', size=10, halo=False))
    return g.svg('PCMのしくみ')


FIG['joho.pcm'] = _pcm()

FIG['joho.pcmeq'] = eq([['44,100Hz', '×', '16ビット', '×', '2チャネル', '×', '300秒', '÷', '8'],
                        [('データ量', 'c'), '＝', ('52,920,000バイト（約53MB）', 'a')]], 'PCMのデータ量の計算', size=11)

# ------------------------------------------------ 1.1.2 ソフトウェア
FIG['joho.swlayer'] = stack([('アプリケーション\n（応用ソフトウェア）', 'b', '利用者の目的に応じた処理（業務処理、表計算、文書作成など）'),
                             ('ミドルウェア', 'c', 'OSとアプリケーションの間で、共通の機能を提供（DBMS、Webサーバ、アプリケーションサーバ）'),
                             ('OS（基本ソフトウェア）', 'a', 'ハードウェアや資源を管理（カーネル、シェル、デバイスドライバ）'),
                             ('ファームウェア', 'sub', '機器のROMやフラッシュメモリに書かれ、ハードウェアを直接制御（BIOS・UEFI）'),
                             ('ハードウェア', None, 'CPU、メモリ、周辺機器')], 'ソフトウェアの階層', bw=128)

FIG['joho.kernel'] = _nest([('利用者・アプリケーション', 'c'), ('シェル：利用者の命令を受け取り、カーネルに伝える', 'b'),
                            ('カーネル（OSの中核）：メモリ、プロセス（タスク）、入出力を管理', 'a'), ('ハードウェア', 'sub')], 'カーネルとシェル')


def _vmem():
    o = []
    hd = [(4, 'プログラム', '（ページに分ける）'), (140, '主記憶', '（必要なページだけ）'), (276, '補助記憶', '')]
    for x, a, b in hd:
        o.append(T(x + 40, 14, a, 'middle', bold=True, size=11))
        if b:
            o.append(T(x + 40, 28, b, 'middle', size=9.5))
    inmem = ['P1', 'P4', 'P2']
    for i in range(6):
        p = 'P%d' % (i + 1)
        col = 'b' if p in inmem else 'sub'
        o.append(R(4, 36 + i * 24, 80, 20, fill=col, stroke=col if col != 'sub' else 'line', op=0.25 if col != 'sub' else 0.1, rx=3))
        o.append(T(44, 50 + i * 24, p, 'middle', size=10.5, bold=True))
    for i, p in enumerate(inmem):
        o.append(R(140, 36 + i * 24, 80, 20, fill='b', stroke='b', op=0.25, rx=3))
        o.append(T(180, 50 + i * 24, p, 'middle', size=10.5, bold=True))
    for i, p in enumerate(['P3', 'P5', 'P6']):
        o.append(R(276, 36 + i * 24, 80, 20, fill='sub', stroke='line', op=0.1, rx=3))
        o.append(T(316, 50 + i * 24, p, 'middle', size=10.5, bold=True))
    o.append(ARROW([(274, 112), (222, 112)], col='b', sw=1.6, head=6))
    o.append(T(248, 128, 'ページイン', 'middle', size=10, col='b', bold=True))
    o.append(ARROW([(222, 146), (274, 146)], col='a', sw=1.6, head=6))
    o.append(T(248, 162, 'ページアウト', 'middle', size=10, col='a', bold=True))
    o.append(T(4, 190, '主記憶より大きなプログラムも動かせる（仮想記憶）', size=10.5))
    return _svg(360, 196, o, '仮想記憶とページング')


FIG['joho.vmem'] = _vmem()


def _memmgmt():
    o = []

    def bar(y, segs):
        x = 4
        for s, wv, kind in segs:
            ww = wv * 3.4
            if kind == 'use':
                o.append(R(x, y, ww, 24, fill='b', stroke='b', op=0.3, sw=1))
            elif kind == 'free':
                o.append(R(x, y, ww, 24, fill='sheet', stroke='line', sw=1))
            else:
                o.append(R(x, y, ww, 24, fill='a', stroke='a', op=0.2, sw=1))
            o.append(T(x + ww / 2, y + 16, s, 'middle', size=10, bold=kind != 'free'))
            x += ww
    o.append(T(4, 14, 'コンパクション：細切れの空き領域を詰め直す', bold=True, size=11, col='b'))
    bar(22, [('A', 16, 'use'), ('空き', 12, 'free'), ('B', 18, 'use'), ('空き', 10, 'free'), ('C', 20, 'use'), ('空き', 14, 'free')])
    o.append(ARROW([(54, 50), (54, 66)], col='b', sw=1.6, head=6))
    bar(70, [('A', 16, 'use'), ('B', 18, 'use'), ('C', 20, 'use'), ('連続した空き', 36, 'free')])
    o.append(T(4, 122, 'ガーベージコレクション：使い終わった領域を自動で解放する', bold=True, size=11, col='c'))
    bar(130, [('A', 22, 'use'), ('使い終わった', 30, 'done'), ('B', 22, 'use'), ('空き', 16, 'free')])
    o.append(ARROW([(54, 158), (54, 174)], col='c', sw=1.6, head=6))
    bar(178, [('A', 22, 'use'), ('空き（再び使える）', 30, 'free'), ('B', 22, 'use'), ('空き', 16, 'free')])
    return _svg(360, 206, o, 'コンパクションとガーベージコレクション')


FIG['joho.memmgmt'] = _memmgmt()

FIG['joho.spool'] = _flow(['CPU\n印刷のデータをつくる', ('スプール（補助記憶）\nいったんためる', 'c'), 'プリンタ\n自分の速さで印刷'],
                          'スプーリング', per_row=3, size=10.5)

FIG['joho.compile'] = _rowflow([('コンパイラ', 'b', ['ソース\nプログラム', 'コンパイラが\nまとめて\n機械語に翻訳', '目的\nプログラム']),
                                ('リンカ', 'b', ['目的プログラム\n＋ライブラリ', 'リンカが結合', 'ロード\nモジュール\n（実行できる）']),
                                ('インタプリタ', 'c', ['ソース\nプログラム', 'インタプリタが\n1命令ずつ解釈\nしながら実行', '事前の翻訳は\nいらない。実行は\n遅くなりやすい'])],
                               'プログラムの翻訳と実行', lw=64, size=10, gapx=12, bold0=False)

FIG['joho.license'] = grid(['ライセンス', '改変したものを配布するとき', 'コピーレフト'],
                           [['GPL', 'GPLのもとで、ソースコードを公開しなければならない', 'である'],
                            ['LGPL', 'ライブラリとして利用するだけなら、利用する側のソースコードの公開は求めない', '条件を緩めた'],
                            ['BSD・MIT・Apache', '著作権の表示などを守れば、ソースコードを公開しない製品に組み込める', 'ではない'],
                            ['MySQL（例）', 'GPLと商用のデュアルライセンス。非公開の製品に組み込む利用者には商用', '']],
                           [86, 204, 70], align=['l', 'l', 'c'], title='OSSのライセンス', size=10.5,
                           tcol={'である': 'a', '条件を緩めた': 'c', 'ではない': 'b'})

FIG['joho.freesw'] = grid(['名前', '意味'],
                          [['OSS', 'ソースコードを公開し、利用・改変・再配布を認める。無償とは限らない'],
                           ['フリーソフトウェア', '利用・研究・改変・再配布の「自由」を保障する。「無料」の意味ではない'],
                           ['フリーウェア', '「無料」で使える。ソースコードの公開は限らない。著作権は作者に残る'],
                           ['シェアウェア', '一定の期間は試用でき、使い続けるなら料金を払う'],
                           ['PDS', '著作権を放棄。自由に利用・改変・配布できる']],
                          [110, 250], align=['l', 'l'], title='「フリー」と付くソフトウェアの違い', size=10.5)

FIG['joho.cc'] = tiles([('BY（表示）\n作者の名前などを表示する', 'b'), ('NC（非営利）\n営利目的では使わない', 'c'),
                        ('ND（改変禁止）\n作品を改変しない', 'a'), ('SA（継承）\n改変したら、同じ条件で公開する', 'b')],
                       'クリエイティブ・コモンズの条件', cols=2, size=10.5)


def _path():
    o = []
    nodes = [('/（ルート）', 0, 0), ('home', 1, 1), ('user', 2, 2), ('docs', 3, 3), ('a.txt', 4, 4), ('img', 3, 5), ('b.png', 4, 6)]
    pos = {}
    for nm, d, r in nodes:
        x, y = 6 + d * 26, 8 + r * 24
        pos[nm] = (x, y)
        file = '.' in nm and nm != '/（ルート）'
        cur = nm == 'docs'
        w = tw(nm, 10.5) + 14
        o.append(R(x, y, w, 19, fill='c' if cur else ('sheet' if file else 'b'), stroke='c' if cur else ('line' if file else 'b'),
                   op=0.3 if cur else (None if file else 0.18), rx=3, sw=1.1))
        o.append(T(x + 7, y + 14, nm, size=10.5, bold=not file))
    par = {'home': '/（ルート）', 'user': 'home', 'docs': 'user', 'a.txt': 'docs', 'img': 'user', 'b.png': 'img'}
    for ch, p in par.items():
        (px, py), (cx, cy) = pos[p], pos[ch]
        o.append(L(px + 10, py + 19, px + 10, cy + 9.5, col='line', sw=1.1))
        o.append(L(px + 10, cy + 9.5, cx, cy + 9.5, col='line', sw=1.1))
    o.append(T(130, 94, '← カレントディレクトリ', size=10.5, col='c', bold=True))
    rows = [('絶対パス', '/home/user/img/b.png', 'ルートから書く'), ('相対パス', '../img/b.png', 'docsから。..は1つ上'),
            ('相対パス', './a.txt', '.は現在のディレクトリ')]
    for i, (a, b, c) in enumerate(rows):
        y = 186 + i * 20
        o.append(T(6, y, a, size=10.5, bold=True, col='b' if i == 0 else 'c'))
        o.append('<text x="70" y="%s" font-size="10.5" style="fill:currentColor;font-family:%s">%s</text>' % (y, MONO, b))
        o.append(T(222, y, c, size=10))
    return _svg(360, 234, o, '絶対パスと相対パス')


FIG['joho.path'] = _path()


def _csv():
    o = []
    h = code(o, 4, 18, 140, ['商品,単価,数量', 'りんご,120,3', 'みかん,80,5'], size=11)
    o.append(T(4, 12, 'CSV（テキスト）', bold=True, size=10.5))
    o.append(ARROW([(150, 18 + h / 2), (178, 18 + h / 2)], sw=1.6, head=6))
    o.append(T(186, 12, '表として読み込む', bold=True, size=10.5))
    dtab(o, 186, 18, ['商品', '単価', '数量'], [['りんご', '120', '3'], ['みかん', '80', '5']], [64, 52, 52], size=10.5, rh=20)
    o.append(T(4, 100, '項目はカンマ（,）で、レコードは改行で区切る', size=10.5))
    return _svg(360, 106, o, 'CSV')


FIG['joho.csv'] = _csv()


def _absref():
    o = []
    dtab(o, 4, 4, ['', 'A', 'B', 'C'], [['1', 'レート', '150', ''], ['2', '10', '', '=A2*$B$1　→ 1,500'], ['3', '20', '', '=A3*$B$1　→ 3,000'],
                                       ['4', '30', '', '=A4*$B$1　→ 4,500']],
         [26, 70, 56, 200], size=10.5, rh=22, hl={(0, 2): 'b', (1, 3): 'c', (2, 3): 'c', (3, 3): 'c'}, align=['c', 'c', 'c', 'l'])
    o.append(T(4, 132, 'C2を下に複写しても、$B$1（レート）は変わらない', size=10.5, col='b', bold=True))
    o.append(T(4, 150, 'B1を相対参照にすると、C3は「=A3*B2」になり、空のセルを参照する', size=10.5, col='a'))
    return _svg(360, 158, o, '絶対参照の例')


FIG['joho.absref'] = _absref()

FIG['joho.refkind'] = grid(['書き方', '複写したとき'],
                           [['A1（相対参照）', '行も列も、複写先に合わせてずれる'], ['$A$1（絶対参照）', '行も列も変わらない'],
                            ['$A1（複合参照）', '列だけ固定（行はずれる）'], ['A$1（複合参照）', '行だけ固定（列はずれる）']],
                           [130, 230], align=['l', 'l'], title='参照の種類', size=10.5)

FIG['joho.rank'] = grid(['点数', '自分より大きい値の数', '＋1＝順位'],
                        [['80', '1（95）', '2位'], ['95', '0', '1位'], ['70', '2（80と95）', '3位']],
                        [80, 160, 120], align=['c', 'c', 'c'], title='COUNTIF関数で順位を求める', size=11)

# ------------------------------------------------ 1.1.3 プログラム設計


def _struct3():
    o = []
    for k, ttl in enumerate(['順次', '選択', '繰返し']):
        o.append(T(60 + k * 120, 14, ttl, 'middle', bold=True, size=12, col='b'))
    # 順次
    _box(o, 20, 34, 80, 30, '処理1', size=10.5)
    _box(o, 20, 92, 80, 30, '処理2', size=10.5)
    o.append(ARROW([(60, 22), (60, 32)], sw=1.3, head=5))
    o.append(ARROW([(60, 64), (60, 90)], sw=1.4, head=6))
    o.append(ARROW([(60, 122), (60, 150)], sw=1.4, head=6))
    # 選択
    cx = 180
    poly(o, [(cx, 26), (cx + 34, 46), (cx, 66), (cx - 34, 46)], col='c', fill='c', op=0.18)
    o.append(T(cx, 50, '条件', 'middle', size=10.5, bold=True))
    _box(o, 124, 84, 46, 28, '処理A', size=10)
    _box(o, 190, 84, 46, 28, '処理B', size=10)
    o.append(ARROW([(cx - 34, 46), (147, 46), (147, 82)], sw=1.3, head=5))
    o.append(ARROW([(cx + 34, 46), (213, 46), (213, 82)], sw=1.3, head=5))
    o.append(T(140, 40, '真', 'middle', size=10, col='b', bold=True))
    o.append(T(220, 40, '偽', 'middle', size=10, col='a', bold=True))
    o.append(L(147, 112, 147, 130, sw=1.3, col='main'))
    o.append(L(213, 112, 213, 130, sw=1.3, col='main'))
    o.append(L(147, 130, 213, 130, sw=1.3, col='main'))
    o.append(ARROW([(cx, 130), (cx, 150)], sw=1.4, head=6))
    # 繰返し
    cx = 300
    poly(o, [(cx, 26), (cx + 34, 46), (cx, 66), (cx - 34, 46)], col='c', fill='c', op=0.18)
    o.append(T(cx, 50, '条件', 'middle', size=10.5, bold=True))
    _box(o, cx - 30, 86, 60, 28, '処理', size=10.5)
    o.append(ARROW([(cx, 66), (cx, 84)], sw=1.3, head=5))
    o.append(T(cx + 8, 79, '真', size=10, col='b', bold=True))
    o.append(ARROW([(cx, 114), (cx, 124), (cx - 44, 124), (cx - 44, 46), (cx - 36, 46)], sw=1.3, head=5))
    o.append(ARROW([(cx + 34, 46), (cx + 46, 46), (cx + 46, 140), (cx, 140), (cx, 150)], sw=1.3, head=5))
    o.append(T(cx + 50, 40, '偽', size=10, col='a', bold=True))
    return _svg(360, 156, o, '3つの基本構造')


FIG['joho.struct3'] = _struct3()


def _module():
    o = []
    for k, (x0, nm) in enumerate([(8, 'モジュールA'), (208, 'モジュールB')]):
        o.append(_dashrect(x0, 20, 144, 96, col='b', rx=10))
        o.append(T(x0 + 72, 14, nm, 'middle', bold=True, size=11, col='b'))
        pts = [(x0 + 40, 50), (x0 + 104, 50), (x0 + 72, 92)]
        for i in range(3):
            for j in range(i + 1, 3):
                o.append(L(pts[i][0], pts[i][1], pts[j][0], pts[j][1], col='b', sw=3.2))
        for (x, y) in pts:
            o.append('<circle cx="%s" cy="%s" r="9" style="fill:var(--sheet);stroke:%s" stroke-width="1.6"/>' % (x, y, _c('b')))
    o.append(L(112, 92, 248, 92, col='a', sw=1, dash='4 3'))
    o.append(T(180, 86, '間は弱く', 'middle', size=10.5, col='a', bold=True))
    o.append(T(180, 138, '中の結びつきは強く（モジュール強度が高い）', 'middle', size=10.5, col='b', bold=True))
    o.append(T(180, 156, 'モジュールの間は弱く（モジュール結合度が低い）', 'middle', size=10.5, col='a', bold=True))
    return _svg(360, 164, o, 'モジュール分割の考え方')


FIG['joho.module'] = _module()


def _cls(o, x, y, w, name, attrs, meths, col='main', obj=False):
    lh = 15
    h1, h2, h3 = 22, max(1, len(attrs)) * lh + 6, max(1, len(meths)) * lh + 6
    if not meths:
        h3 = 0
    o.append(R(x, y, w, h1 + h2 + h3, fill='sheet', stroke=col, sw=1.4))
    o.append(R(x, y, w, h1, fill=col, stroke=None, op=0.2))
    o.append(T(x + w / 2, y + 15, name, 'middle', bold=True, size=11))
    if obj:
        o.append(L(x + w / 2 - tw(name, 11) / 2, y + 18, x + w / 2 + tw(name, 11) / 2, y + 18, col='main', sw=1))
    o.append(L(x, y + h1, x + w, y + h1, col=col, sw=1))
    for i, a in enumerate(attrs):
        o.append(T(x + 6, y + h1 + 15 + i * lh, a, size=10.5))
    if meths:
        o.append(L(x, y + h1 + h2, x + w, y + h1 + h2, col=col, sw=1))
        for i, m in enumerate(meths):
            o.append(T(x + 6, y + h1 + h2 + 15 + i * lh, m, size=10.5))
    return h1 + h2 + h3


def _oop():
    o = []
    h = _cls(o, 125, 6, 110, '動物', ['名前'], ['鳴く()'], col='b')
    o.append(T(244, 22, 'スーパークラス', size=10, col='b', bold=True))
    for x, nm, snd in [(22, '犬', 'ワン'), (228, '猫', 'ニャー')]:
        _cls(o, x, 104, 110, nm, ['（名前を引き継ぐ）'], ['鳴く() →「%s」' % snd], col='c')
        cx = x + 55
        o.append(L(cx, 104, cx, 88, col='main', sw=1.2))
        o.append(L(cx, 88, 180, 88, col='main', sw=1.2))
    o.append(L(180, 88, 180, 6 + h + 9, col='main', sw=1.2))
    poly(o, [(180, 6 + h), (173, 6 + h + 10), (187, 6 + h + 10)], col='main')
    o.append(T(190, 98, '継承', size=10.5, bold=True))
    o.append(T(4, 98, 'サブクラス', size=10, col='c', bold=True))
    o.append(R(22, 190, 110, 26, fill='sheet', stroke='main', sw=1.2))
    o.append(T(77, 207, 'ポチ：犬', 'middle', size=10.5, bold=True))
    o.append(L(77 - 22, 210, 77 + 22, 210, col='main', sw=1))
    o.append(ARROW([(77, 172), (77, 188)], sw=1.2, head=5, dash='3 2'))
    o.append(T(140, 202, '← インスタンス（クラスから', size=10))
    o.append(T(140, 216, '　 つくった具体的なオブジェクト）', size=10))
    o.append(T(4, 238, '同じ「鳴く()」でも、クラスによって動作が違う＝多相性', size=10.5, col='a', bold=True))
    o.append(T(4, 254, '共通の部分を上へまとめる＝汎化、上を具体化する＝特化', size=10.5))
    return _svg(360, 262, o, 'クラス、継承、多相性')


FIG['joho.oop'] = _oop()


def _store(o, x, y, w, s):
    o.append(L(x, y, x + w, y, col='main', sw=1.4))
    o.append(L(x, y + 24, x + w, y + 24, col='main', sw=1.4))
    o.append(T(x + w / 2, y + 16, s, 'middle', size=10.5))


def _dfd():
    o = []
    o.append(R(6, 8, 46, 24, fill='sheet', stroke='main', sw=1.4))
    o.append(T(60, 25, '外部実体', size=10.5))
    o.append('<circle cx="140" cy="20" r="13" style="fill:var(--sheet);stroke:%s" stroke-width="1.4"/>' % _c('b'))
    o.append(T(158, 25, 'プロセス（処理）', size=10.5))
    o.append(ARROW([(6, 50), (46, 50)], sw=1.4, head=6))
    o.append(T(52, 54, 'データフロー', size=10.5))
    _store(o, 130, 38, 40, '')
    o.append(T(176, 55, 'データストア', size=10.5))
    o.append(L(4, 72, 356, 72, col='line', sw=0.8))
    o.append(R(6, 96, 56, 30, fill='sheet', stroke='main', sw=1.4))
    o.append(T(34, 116, '顧客', 'middle', size=11, bold=True))
    o.append('<circle cx="160" cy="111" r="30" style="fill:var(--sheet);stroke:%s" stroke-width="1.4"/>' % _c('b'))
    o.append('<circle cx="160" cy="111" r="30" style="fill:%s;fill-opacity:0.12;stroke:none"/>' % _c('b'))
    o.append(T(160, 115, '受注処理', 'middle', size=10.5, bold=True))
    o.append(R(290, 96, 62, 30, fill='sheet', stroke='main', sw=1.4))
    o.append(T(321, 116, '倉庫', 'middle', size=11, bold=True))
    o.append(ARROW([(62, 111), (128, 111)], sw=1.5, head=6))
    o.append(T(95, 105, '注文', 'middle', size=10.5))
    o.append(ARROW([(190, 111), (288, 111)], sw=1.5, head=6))
    o.append(T(240, 105, '出荷指示', 'middle', size=10.5))
    _store(o, 120, 168, 80, '受注ファイル')
    o.append(ARROW([(160, 141), (160, 166)], sw=1.5, head=6))
    o.append(T(166, 158, '受注データ', size=10.5))
    o.append(T(4, 214, '処理の順序や、条件による分岐は表さない', size=10.5, col='a', bold=True))
    return _svg(360, 222, o, 'DFDの記号と例')


FIG['joho.dfd'] = _dfd()


def _er():
    o = []
    rows = [('社員', '1', '1', '社員証', '1対1'), ('顧客', '1', '多', '注文', '1対多'), ('学生', '多', '多', '科目', '多対多')]
    for i, (a, ma, mb, b, k) in enumerate(rows):
        y = 6 + i * 42
        o.append(R(6, y, 70, 28, fill='b', stroke='b', op=0.18, sw=1.3))
        o.append(T(41, y + 19, a, 'middle', size=11, bold=True))
        o.append(R(196, y, 70, 28, fill='b', stroke='b', op=0.18, sw=1.3))
        o.append(T(231, y + 19, b, 'middle', size=11, bold=True))
        o.append(L(76, y + 14, 196, y + 14, col='main', sw=1.4))
        o.append(T(84, y + 10, ma, size=11, bold=True, col='a'))
        o.append(T(188, y + 10, mb, 'end', size=11, bold=True, col='a'))
        o.append(T(282, y + 19, k, size=11, bold=True))
    o.append(T(4, 140, '四角＝実体（エンティティ）、線＝関連（リレーションシップ）', size=10.5))
    return _svg(360, 146, o, 'E-R図と多重度')


FIG['joho.er'] = _er()

FIG['joho.dtable'] = grid(['', '規則1', '規則2', '規則3', '規則4'],
                          [['条件：会員である', 'Y', 'Y', 'N', 'N'], ['条件：購入額が1万円以上', 'Y', 'N', 'Y', 'N'],
                           ['動作：10％引き', 'X', '－', '－', '－'], ['動作：5％引き', '－', 'X', 'X', '－'], ['動作：割引なし', '－', '－', '－', 'X']],
                          [160, 50, 50, 50, 50], align=['l', 'c', 'c', 'c', 'c'], title='決定表の例', size=10.5, hl_rows=(2, 3, 4),
                          tcol={'X': 'a'})


def _state():
    o = []
    st = {'停止中': (8, 84), '運転中': (244, 14), '一時停止中': (244, 156)}
    for nm, (x, y) in st.items():
        o.append(R(x, y, 106, 34, fill='c', stroke='c', op=0.2, rx=17, sw=1.4))
        o.append(T(x + 53, y + 22, nm, 'middle', size=11, bold=True))
    o.append(ARROW([(90, 84), (90, 31), (242, 31)], sw=1.4, head=6))
    o.append(T(150, 25, '開始ボタン', 'middle', size=10.5, col='b', bold=True))
    o.append(ARROW([(244, 42), (102, 42), (102, 82)], sw=1.4, head=6))
    o.append(T(170, 56, '停止ボタン', 'middle', size=10.5, col='a', bold=True))
    o.append(ARROW([(280, 48), (280, 154)], sw=1.4, head=6))
    o.append(T(274, 104, '一時停止', 'end', size=10.5, bold=True))
    o.append(ARROW([(320, 154), (320, 48)], sw=1.4, head=6))
    o.append(T(326, 104, '再開', size=10.5, bold=True))
    o.append(ARROW([(244, 173), (60, 173), (60, 120)], sw=1.4, head=6))
    o.append(T(150, 167, '停止ボタン', 'middle', size=10.5, col='a', bold=True))
    o.append(T(4, 210, '角の丸い箱＝状態、矢印＝状態を変えるきっかけ（イベント）', size=10.5))
    return _svg(360, 218, o, '状態遷移図の例')


FIG['joho.state'] = _state()

FIG['joho.uml'] = htree(('UML', None, [
    ('構造を表す図', 'b', [('クラス図：クラスの属性・操作、クラスの間の関連', 'b', []), ('オブジェクト図：ある時点のインスタンスの関係', 'b', []),
                       ('コンポーネント図：部品の構成と依存関係', 'b', []), ('配置図：物理的な構成と、ソフトウェアの配置', 'b', [])]),
    ('振る舞いを表す図', 'c', [('ユースケース図：アクターから見た機能', 'c', []), ('アクティビティ図：処理の流れ（分岐・並行も）', 'c', []),
                         ('ステートマシン図：オブジェクトの状態の遷移', 'c', []), ('シーケンス図：メッセージのやり取りを時間の順に', 'c', []),
                         ('コミュニケーション図：つながりとメッセージ', 'c', [])])]),
    'UMLの図の種類', colw=(44, 74, 222), gapx=9, size=10.5)


def _mult():
    o = []
    o.append(R(10, 10, 96, 30, fill='b', stroke='b', op=0.18, sw=1.3))
    o.append(T(58, 30, '従業員', 'middle', size=11, bold=True))
    o.append(R(254, 10, 96, 30, fill='b', stroke='b', op=0.18, sw=1.3))
    o.append(T(302, 30, '修理', 'middle', size=11, bold=True))
    o.append(L(106, 25, 254, 25, col='main', sw=1.4))
    o.append(T(114, 20, '1', size=12, bold=True, col='a'))
    o.append(T(246, 20, '0..*', 'end', size=12, bold=True, col='a'))
    o.append(T(10, 62, '修理1件から見ると、担当する従業員は「1」＝ちょうど1人', size=10.5))
    o.append(T(10, 78, '従業員1人から見ると、担当する修理は「0..*」＝0件以上', size=10.5))
    dtab(o, 10, 92, ['書き方', '意味'], [['1', 'ちょうど1'], ['0..1', '0か1'], ['0..* または *', '0以上'], ['1..*', '1以上']],
         [110, 120], size=10.5, rh=19)
    return _svg(360, 194, o, '多重度の読み方')


FIG['joho.mult'] = _mult()

FIG['joho.code'] = grid(['コード', '付け方', '例'],
                        [['順番（連番）', '発生・登録の順に番号', '1、2、3…（分類は分からない）'],
                         ['区分（ブロック）', '範囲ごとに分類を割り当てる', '100番台＝食品、200番台＝日用品'],
                         ['桁別（グループ分類）', '桁ごとに意味を持たせる', '1桁目＝地域、2〜3桁目＝部門'],
                         ['十進分類', '十進数で順に細かくする', '日本十進分類法：3社会科学→33経済→336経営管理'],
                         ['表意（ニモニック）', '略称や記号を使う', 'JP、US'],
                         ['チェックディジット', '各桁から計算した数字を末尾に付ける', '入力の誤りを検出する']],
                        [100, 124, 136], align=['l', 'l', 'l'], title='コード設計', size=10)

FIG['joho.regex'] = _lists([('正規表現を使う', 'b', ['メールアドレスや日付などの形式のチェック', '文字列の検索や置換', '一部の文字を伏字に置き換える']),
                            ('正規表現を使わない', 'a', ['データの並べ替え', '上位の何件かの抽出'])], '正規表現の用途', size=10.5)


def _regexex():
    o = []
    o.append(T(4, 14, 'パターンの例（郵便番号の形式）', bold=True, size=10.5))
    code(o, 4, 20, 352, ['^[0-9]{3}-[0-9]{4}$'], size=12)
    o.append(T(4, 66, '数字3けた、ハイフン、数字4けた', size=10.5))
    for i, (s, ok) in enumerate([('123-4567', True), ('1234567', False), ('12-34567', False)]):
        x = 6 + i * 118
        o.append(R(x, 78, 110, 26, fill='b' if ok else 'a', stroke='b' if ok else 'a', op=0.16, rx=4))
        o.append('<text x="%s" y="96" font-size="11" style="fill:currentColor;font-family:%s">%s</text>' % (x + 8, MONO, s))
        o.append(T(x + 100, 96, '○' if ok else '×', 'end', size=12, bold=True, col='b' if ok else 'a'))
    return _svg(360, 110, o, '正規表現の例')


FIG['joho.regexex'] = _regexex()

# ------------------------------------------------ 1.1.4 ソフトウェア開発


def _java():
    o = []
    _box(o, 2, 50, 74, 40, 'ソース\nプログラム', size=10.5)
    o.append(ARROW([(78, 70), (106, 70)], sw=1.5, head=6))
    o.append(T(92, 63, '翻訳', 'middle', size=9.5))
    _box(o, 108, 44, 92, 52, 'バイトコード\n（中間コード）', col='c', size=10.5, c0='c')
    for i, os_ in enumerate(['Windows', 'Linux', 'macOS']):
        y = 8 + i * 44
        _box(o, 242, y, 114, 36, 'JVM\n' + os_, col='b', size=10, c0='b')
        o.append(ARROW([(202, 70), (240, y + 18)], sw=1.3, head=5))
    o.append(T(4, 150, '同じバイトコードを、各OSのJava仮想マシン（JVM）が実行', size=10.5, bold=True, col='b'))
    o.append(T(4, 166, '→ OSの種類に依存せずに動く', size=10.5))
    return _svg(360, 172, o, 'Javaの実行のしくみ')


FIG['joho.java'] = _java()


def _pydict():
    o = []
    code(o, 4, 6, 352, ['score = {"経済学": 100, "財務": 90}', 'print(score["財務"])'], size=11)
    for i, (k, v) in enumerate([('"経済学"', '100'), ('"財務"', '90')]):
        y = 70 + i * 34
        hl = i == 1
        o.append(R(30, y, 96, 26, fill='c' if hl else 'sub', stroke='c' if hl else 'line', op=0.22 if hl else 0.1, rx=3))
        o.append(T(78, y + 18, k, 'middle', size=11, bold=True))
        o.append(ARROW([(128, y + 13), (156, y + 13)], sw=1.3, head=5))
        o.append(R(160, y, 60, 26, fill='b' if hl else 'sub', stroke='b' if hl else 'line', op=0.22 if hl else 0.1, rx=3))
        o.append(T(190, y + 18, v, 'middle', size=11, bold=True))
    o.append(T(30, 64, 'キー', size=10, col='c', bold=True))
    o.append(T(160, 64, '値', size=10, col='b', bold=True))
    o.append(T(232, 122, '→ 90 と表示', size=11, bold=True, col='b'))
    return _svg(360, 138, o, 'Pythonの辞書')


FIG['joho.pydict'] = _pydict()


def _web():
    o = []
    o.append(_dashrect(2, 6, 140, 196, col='c', rx=8))
    o.append(T(72, 22, 'Webブラウザ', 'middle', bold=True, size=11, col='c'))
    for i, (a, b) in enumerate([('HTML', '文書の構造'), ('CSS', '見た目'), ('JavaScript', '動き・入力のチェック')]):
        _box(o, 10, 32 + i * 40, 124, 34, a + '\n' + b, size=10)
    _box(o, 10, 156, 124, 38, 'Cookie\nブラウザに保存する小さなデータ', col='c', size=9.5, c0='c')
    o.append(_dashrect(218, 6, 140, 196, col='b', rx=8))
    o.append(T(288, 22, 'Webサーバ', 'middle', bold=True, size=11, col='b'))
    _box(o, 226, 32, 124, 50, 'サーバサイドの処理\nPHP、Perl、Rubyなど', size=10)
    cyl(o, 288, 124, w=60, h=44, inside='DB', isize=11, col='b')
    o.append(ARROW([(144, 52), (216, 52)], sw=1.5, head=6))
    o.append(T(180, 46, 'リクエスト', 'middle', size=9.5))
    o.append(ARROW([(216, 80), (144, 80)], sw=1.5, head=6))
    o.append(T(180, 74, 'レスポンス', 'middle', size=9.5))
    o.append(ARROW([(144, 128), (216, 128)], col='a', sw=1.4, head=6, dash='4 3'))
    o.append(ARROW([(216, 140), (144, 140)], col='a', sw=1.4, head=6, dash='4 3'))
    o.append(T(180, 122, 'Ajax', 'middle', size=10, col='a', bold=True))
    o.append(T(4, 222, 'Ajax：ページ全体を読み込み直さずに、非同期に通信して一部だけ書き換える', size=10))
    return _svg(360, 230, o, 'Webのしくみ')


FIG['joho.web'] = _web()

FIG['joho.rest'] = grid(['HTTPのメソッド', '操作', '例（URLで資源を表す）'],
                        [['GET', '取得', 'GET /items/15'], ['POST', '作成', 'POST /items'], ['PUT', '更新', 'PUT /items/15'], ['DELETE', '削除', 'DELETE /items/15']],
                        [110, 60, 190], align=['l', 'c', 'l'], title='RESTの操作', size=11)


def _jsonxml():
    o = []
    o.append(T(4, 14, 'JSON：キーと値の組', bold=True, size=10.5, col='b'))
    code(o, 4, 20, 166, ['{', '  "name": "佐藤",', '  "age": 30', '}'], size=10.5)
    o.append(T(186, 14, 'XML：タグを自由に定義', bold=True, size=10.5, col='c'))
    code(o, 186, 20, 170, ['<person>', '  <name>佐藤</name>', '  <age>30</age>', '</person>'], size=10.5)
    o.append(T(4, 104, '同じデータを、データ交換用のテキスト形式で表した例', size=10.5))
    return _svg(360, 110, o, 'JSONとXML')


FIG['joho.jsonxml'] = _jsonxml()


def _cicd():
    o = []
    st = [('コードを\n変更', None), ('ビルドと\nテストを自動', 'b'), ('いつでも本番に\n出せる状態', 'c'), ('本番環境に\n反映', 'a')]
    bw = 80
    for i, (s, col) in enumerate(st):
        x = 2 + i * 92
        _box(o, x, 8, bw, 44, s, col=col, size=10, c0=col)
        if i:
            o.append(ARROW([(x - 10, 30), (x - 2, 30)], sw=1.4, head=5))
    brace(o, 2, 174, 62, '継続的インテグレーション（CI）', col='b', size=10)
    brace(o, 2, 266, 98, '継続的デリバリー（本番への反映は人が判断）', col='c', size=10)
    brace(o, 2, 358, 134, '継続的デプロイメント（本番への反映まで自動）', col='a', size=10)
    return _svg(360, 170, o, 'CI/CD')


FIG['joho.cicd'] = _cicd()


def _bbwb():
    o = []
    o.append(T(88, 14, 'ブラックボックステスト', 'middle', bold=True, size=11))
    o.append(R(50, 30, 76, 60, fill='main', stroke='main', op=0.75, rx=4))
    o.append(ARROW([(8, 60), (46, 60)], sw=1.5, head=6))
    o.append(ARROW([(130, 60), (168, 60)], sw=1.5, head=6))
    o.append(T(14, 52, '入力', size=10))
    o.append(T(134, 52, '出力', size=10))
    o.append(T(88, 108, '内部は見ずに、仕様どおりの', 'middle', size=10.5))
    o.append(T(88, 123, '出力が得られるかを確かめる', 'middle', size=10.5))
    o.append(T(272, 14, 'ホワイトボックステスト', 'middle', bold=True, size=11))
    o.append(R(224, 30, 96, 60, fill='sheet', stroke='main', sw=1.4, rx=4))
    poly(o, [(262, 36), (276, 46), (262, 56), (248, 46)], col='c', fill='c', op=0.2)
    o.append(L(248, 46, 238, 46, col='main', sw=1.1))
    o.append(L(238, 46, 238, 78, col='main', sw=1.1))
    o.append(L(276, 46, 300, 46, col='main', sw=1.1))
    o.append(L(300, 46, 300, 78, col='main', sw=1.1))
    o.append(R(229, 62, 18, 12, fill='b', stroke='b', op=0.3))
    o.append(R(291, 62, 18, 12, fill='b', stroke='b', op=0.3))
    o.append(ARROW([(196, 60), (222, 60)], sw=1.5, head=6))
    o.append(ARROW([(322, 60), (352, 60)], sw=1.5, head=6))
    o.append(T(272, 108, '命令や分岐（内部の構造）が', 'middle', size=10.5))
    o.append(T(272, 123, '実行されるようにテストする', 'middle', size=10.5))
    return _svg(360, 130, o, 'ブラックボックステストとホワイトボックステスト')


FIG['joho.bbwb'] = _bbwb()


def _boundary():
    o = []
    pos = {-5: 36, -1: 76, 0: 104, 50: 180, 100: 256, 101: 284, 115: 326}
    o.append(T(4, 14, '例：0〜100点を有効な入力とするプログラム（目盛りは模式的）', bold=True, size=10.5))
    for a, b, s, col in [(4, 90, '無効', 'a'), (90, 270, '有効（同値クラス）', 'b'), (270, 356, '無効', 'a')]:
        o.append(R(a, 30, b - a, 26, fill=col, stroke=col, op=0.18, sw=1))
        o.append(T((a + b) / 2, 48, s, 'middle', size=10.5, bold=True, col=col))
    o.append(ARROW([(4, 70), (352, 70)], sw=1.2, head=6))
    o.append(L(90, 62, 90, 78, col='main', sw=0.8, dash='2 2'))
    o.append(L(270, 62, 270, 78, col='main', sw=0.8, dash='2 2'))
    for v in (-5, 50, 115):
        o.append('<circle cx="%s" cy="92" r="5" style="fill:%s"/>' % (pos[v], _c('c')))
        o.append(T(pos[v], 110, str(v), 'middle', size=10.5, bold=True, col='c'))
    o.append(T(4, 130, '● 同値分割：各クラスの代表の値（例：-5、50、115）', size=10.5, col='c', bold=True))
    for v in (-1, 0, 100, 101):
        x = pos[v]
        o.append('<path d="M%s 142 L%s 152 L%s 152 Z" style="fill:%s"/>' % (x, x - 5, x + 5, _c('a')))
        o.append(T(x, 168, str(v), 'middle', size=10.5, bold=True, col='a'))
    o.append(T(4, 188, '▲ 境界値分析：境目とその前後の値（-1、0、100、101）', size=10.5, col='a', bold=True))
    return _svg(360, 196, o, '同値分割と境界値分析')


FIG['joho.boundary'] = _boundary()


def _cover():
    o = []
    cx = 62

    def dia(y, s):
        poly(o, [(cx, y), (cx + 30, y + 16), (cx, y + 32), (cx - 30, y + 16)], col='c', fill='c', op=0.18)
        o.append(T(cx, y + 20, s, 'middle', size=10.5, bold=True))
    o.append(ARROW([(cx, 2), (cx, 12)], sw=1.2, head=4))
    dia(12, 'A?')
    _box(o, cx + 44, 50, 52, 24, '処理X', size=10)
    o.append(ARROW([(cx + 30, 28), (cx + 70, 28), (cx + 70, 48)], sw=1.2, head=5))
    o.append(T(cx + 36, 24, '真', size=10, col='b', bold=True))
    o.append(L(cx, 44, cx, 86, col='main', sw=1.2))
    o.append(T(cx - 14, 64, '偽', size=10, col='a', bold=True))
    o.append(L(cx + 70, 74, cx + 70, 86, col='main', sw=1.2))
    o.append(L(cx, 86, cx + 70, 86, col='main', sw=1.2))
    o.append(ARROW([(cx, 86), (cx, 98)], sw=1.2, head=4))
    dia(98, 'B?')
    _box(o, cx + 44, 136, 52, 24, '処理Y', size=10)
    o.append(ARROW([(cx + 30, 114), (cx + 70, 114), (cx + 70, 134)], sw=1.2, head=5))
    o.append(T(cx + 36, 110, '真', size=10, col='b', bold=True))
    o.append(L(cx, 130, cx, 172, col='main', sw=1.2))
    o.append(T(cx - 14, 150, '偽', size=10, col='a', bold=True))
    o.append(L(cx + 70, 160, cx + 70, 172, col='main', sw=1.2))
    o.append(L(cx, 172, cx + 70, 172, col='main', sw=1.2))
    o.append(ARROW([(cx, 172), (cx, 184)], sw=1.2, head=4))
    dtab(o, 176, 8, ['基準', '必要なテスト'], [['命令網羅', '（A真、B真）'], ['', '1件でX、Yを実行'], ['分岐網羅', '（A真、B真）'], ['', '（A偽、B偽）の2件']],
         [66, 112], size=10, rh=21, hl={(0, None): 'c', (1, None): 'c', (2, None): 'b', (3, None): 'b'}, align=['c', 'l'])
    o.append(T(176, 140, 'すべての命令を1回以上', size=10))
    o.append(T(176, 155, '＝命令網羅', size=10, col='c', bold=True))
    o.append(T(176, 172, 'すべての分岐の真と偽を', size=10))
    o.append(T(176, 187, '1回以上＝分岐網羅', size=10, col='b', bold=True))
    return _svg(360, 192, o, '命令網羅と分岐網羅')


FIG['joho.cover'] = _cover()

FIG['joho.testlv'] = _flow(['単体テスト\nモジュールごと。主に開発者がホワイトボックステストで', '結合テスト\nモジュールの間のインタフェース',
                            'システムテスト（総合テスト）\n全体が要件を満たすか。性能・負荷・セキュリティも', ('受入れテスト（運用テスト）\n発注者や利用者が、業務で使えるか', 'b')],
                           'テストの進め方', per_row=2, size=10.5)


def _stub():
    o = []
    for k, (ttl, top_real, col) in enumerate([('トップダウンテスト', True, 'b'), ('ボトムアップテスト', False, 'c')]):
        x0 = 2 + k * 182
        o.append(T(x0 + 88, 14, ttl, 'middle', bold=True, size=11, col=col))
        boxes = [('A（上位）', x0 + 52, 26, top_real), ('B（下位）', x0 + 2, 96, not top_real), ('C（下位）', x0 + 92, 96, not top_real)]
        for nm, x, y, real in boxes:
            if real:
                _box(o, x, y, 80, 34, nm, col=col, size=10.5, c0=col, op=0.22)
            else:
                o.append(_dashrect(x, y, 80, 34, col='a', rx=6))
                o.append(T(x + 40, y + 15, 'スタブ' if top_real else 'ドライバ', 'middle', size=10.5, bold=True, col='a'))
                o.append(T(x + 40, y + 28, '（仮の下位）' if top_real else '（仮の上位）', 'middle', size=9.5, col='a'))
        o.append(L(x0 + 92, 60, x0 + 42, 94, col='main', sw=1.2))
        o.append(L(x0 + 92, 60, x0 + 132, 94, col='main', sw=1.2))
        note = '上位から結合。未完成の下位の代わりにスタブ' if top_real else '下位から結合。未完成の上位の代わりにドライバ'
        for j, ln in enumerate(wrap(note, 170, 10)):
            o.append(T(x0 + 88, 148 + j * 14, ln, 'middle', size=10))
    return _svg(360, 178, o, 'スタブとドライバ')


FIG['joho.stub'] = _stub()

FIG['joho.abtest'] = _rowflow([('A案', 'c', ['利用者を無作為に分けた半分', 'A案のページを見せる', '購入率 3.0％']),
                               ('B案', 'b', ['残りの半分', 'B案のページを見せる', ('購入率 3.6％\n成果のよい案を選ぶ', 'b')])],
                              'A/Bテストの例', lw=44, size=10.5)
