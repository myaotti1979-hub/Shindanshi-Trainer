# テキスト用の図表（1行のSVG文字列を返す）。色はページのCSS変数に合わせ、明暗どちらでも読めるようにする。
# 文字はページのフォント（Noto Sans JP）を継承する。
import math

COL = {'main': 'currentColor', 'a': 'var(--drop)', 'b': 'var(--good)', 'c': 'var(--warn)', 'sub': 'var(--ink-3)',
       'paper': 'var(--paper)', 'sheet': 'var(--sheet)', 'line': 'var(--ink-3)'}


def _c(k):
    return COL.get(k, k)


def _esc(s):
    return str(s).replace('\u200b', '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def _svg(w, h, body, title, minw=None):
    st = ' style="min-width:%dpx"' % minw if minw else ''
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" role="img" aria-label="%s" font-size="12"%s>' % (math.ceil(w), math.ceil(h), _esc(title), st)
            + ''.join(body) + '</svg>')


def T(x, y, s, anchor='start', col='main', bold=False, size=None, op=None):
    a = ' text-anchor="%s"' % anchor if anchor != 'start' else ''
    b = ' font-weight="bold"' if bold else ''
    z = ' font-size="%s"' % size if size else ''
    o = ' opacity="%s"' % op if op else ''
    return '<text x="%s" y="%s"%s%s%s%s style="fill:%s">%s</text>' % (round(x, 1), round(y, 1), a, b, z, o, _c(col), _esc(s))


def R(x, y, w, h, fill='none', stroke='line', sw=1, op=None, rx=0):
    o = ';fill-opacity:%s' % op if op is not None else ''
    r = ' rx="%s"' % rx if rx else ''
    st = 'none' if stroke is None else _c(stroke)
    return '<rect x="%s" y="%s" width="%s" height="%s"%s style="fill:%s%s;stroke:%s" stroke-width="%s"/>' % (round(x, 1), round(y, 1), round(w, 1), round(h, 1), r, _c(fill), o, st, sw)


def L(x1, y1, x2, y2, col='line', sw=1, dash=None):
    d = ' stroke-dasharray="%s"' % dash if dash else ''
    return '<path d="M%s %sL%s %s" style="stroke:%s" stroke-width="%s"%s fill="none"/>' % (round(x1, 1), round(y1, 1), round(x2, 1), round(y2, 1), _c(col), sw, d)


def ARROW(pts, col='main', sw=1.6, dash=None, head=7):
    # 折れ線の矢印。pts=[(x,y),...]。最後の点に矢じりを付ける
    d = 'M' + ' L'.join('%s %s' % (round(x, 1), round(y, 1)) for x, y in pts)
    ds = ' stroke-dasharray="%s"' % dash if dash else ''
    (x1, y1), (x2, y2) = pts[-2], pts[-1]
    ang = math.atan2(y2 - y1, x2 - x1)
    p1 = (x2 - head * math.cos(ang - 0.42), y2 - head * math.sin(ang - 0.42))
    p2 = (x2 - head * math.cos(ang + 0.42), y2 - head * math.sin(ang + 0.42))
    return ('<path d="%s" fill="none" style="stroke:%s" stroke-width="%s"%s stroke-linejoin="round"/>' % (d, _c(col), sw, ds)
            + '<path d="M%s %sL%s %sL%s %sZ" style="fill:%s;stroke:none"/>' % (round(x2, 1), round(y2, 1), round(p1[0], 1), round(p1[1], 1), round(p2[0], 1), round(p2[1], 1), _c(col)))


def yen(v):
    if v is None or v == '':
        return ''
    if isinstance(v, (int, float)):
        return '{:,}'.format(int(v)) if float(v).is_integer() else '{:,}'.format(v)
    return str(v)


# ---------------------------------------------------------------- 仕訳
def journal(rows, title='仕訳'):
    """rows: [(借方科目, 金額, 貸方科目, 金額), ...]。片側が空の行は None または ''"""
    w = 360
    xs = [0, 112, 180, 292, 360]  # 借方科目｜金額‖貸方科目｜金額
    hh, rh = 22, 24
    h = hh + rh * len(rows) + 2
    o = [R(1, 1, w - 2, hh, fill='paper', stroke=None)]
    o.append(T(90, 16, '借方', 'middle', bold=True))
    o.append(T(270, 16, '貸方', 'middle', bold=True))
    for i, (dn, da, cn, ca) in enumerate(rows):
        y = hh + 1 + i * rh
        if i:
            o.append(L(1, y, w - 1, y, sw=0.6, dash='2 2'))
        if dn:
            o.append(T(8, y + 16, dn))
        if da not in (None, ''):
            o.append(T(xs[2] - 8, y + 16, yen(da), 'end'))
        if cn:
            o.append(T(xs[2] + 8, y + 16, cn))
        if ca not in (None, ''):
            o.append(T(w - 8, y + 16, yen(ca), 'end'))
    o.append(L(1, hh + 1, w - 1, hh + 1))
    o.append(L(xs[2], 1, xs[2], h - 1, sw=1.6))
    o.append(R(1, 1, w - 2, h - 2))
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- T字勘定
def taccounts(accts, cols=2, title='勘定'):
    """accts: [{'name':'現金','dr':[('資本金',1000)],'cr':[('給料',100)],'bal':('dr',1000)}]
    bal は残高の側（'dr' 借方残高 / 'cr' 貸方残高）と金額。残高は勘定の下に示す"""
    w, gap = 360, 16
    aw = (w - gap * (cols - 1)) / cols
    rh = 19
    blocks = []
    for a in accts:
        n = max(len(a.get('dr', [])), len(a.get('cr', [])), 1)
        blocks.append(22 + 6 + n * rh + (20 if a.get('bal') else 4))
    rows = [blocks[i:i + cols] for i in range(0, len(blocks), cols)]
    h = sum(max(r) for r in rows) + 8 * (len(rows) - 1) + 4
    o = []
    y0 = 2
    for ri in range(len(rows)):
        rowh = max(rows[ri])
        for ci in range(cols):
            k = ri * cols + ci
            if k >= len(accts):
                break
            a = accts[k]
            x0 = ci * (aw + gap)
            cx = x0 + aw / 2
            o.append(T(cx, y0 + 15, a['name'], 'middle', bold=True))
            o.append(L(x0 + 2, y0 + 22, x0 + aw - 2, y0 + 22, col='main', sw=1.4))
            n = max(len(a.get('dr', [])), len(a.get('cr', [])), 1)
            yb = y0 + 22 + 6 + n * rh
            o.append(L(cx, y0 + 22, cx, yb, col='main', sw=1.4))
            for j, (lb, amt) in enumerate(a.get('dr', [])):
                yy = y0 + 22 + 4 + (j + 1) * rh - 5
                o.append(T(x0 + 4, yy, lb, size=11))
                o.append(T(cx - 5, yy, yen(amt), 'end', size=11))
            for j, (lb, amt) in enumerate(a.get('cr', [])):
                yy = y0 + 22 + 4 + (j + 1) * rh - 5
                o.append(T(cx + 5, yy, lb, size=11))
                o.append(T(x0 + aw - 4, yy, yen(amt), 'end', size=11))
            if a.get('bal'):
                side, amt = a['bal']
                s = '借方残高 ' if side == 'dr' else '貸方残高 '
                o.append(T(cx, yb + 15, s + yen(amt), 'middle', col='a', size=11, bold=True))
        y0 += rowh + 8
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- 試算表
def trial_balance(rows, title='残高試算表', total=True):
    """rows: [(借方, 勘定科目, 貸方), ...]"""
    w = 360
    xs = [0, 110, 250, 360]
    hh, rh = 22, 21
    n = len(rows) + (1 if total else 0)
    h = hh + rh * n + 4
    o = [R(1, 1, w - 2, hh, fill='paper', stroke=None)]
    for x, s in ((55, '借方'), (180, '勘定科目'), (305, '貸方')):
        o.append(T(x, 16, s, 'middle', bold=True))
    sd = sc = 0
    for i, (d, nm, c) in enumerate(rows):
        y = hh + 1 + i * rh
        if i:
            o.append(L(1, y, w - 1, y, sw=0.5, dash='2 2'))
        if d not in (None, ''):
            o.append(T(xs[1] - 8, y + 15, yen(d), 'end'))
            sd += d if isinstance(d, (int, float)) else 0
        o.append(T(180, y + 15, nm, 'middle'))
        if c not in (None, ''):
            o.append(T(w - 8, y + 15, yen(c), 'end'))
            sc += c if isinstance(c, (int, float)) else 0
    if total:
        y = hh + 1 + len(rows) * rh
        o.append(L(1, y, w - 1, y, col='main', sw=1))
        o.append(L(1, y + 2.5, w - 1, y + 2.5, col='main', sw=1))
        o.append(T(xs[1] - 8, y + 17, yen(sd), 'end', bold=True))
        o.append(T(180, y + 17, '合計', 'middle', bold=True))
        o.append(T(w - 8, y + 17, yen(sc), 'end', bold=True))
    o.append(L(1, hh + 1, w - 1, hh + 1))
    o.append(L(xs[1], 1, xs[1], h - 2))
    o.append(L(xs[2], 1, xs[2], h - 2))
    o.append(R(1, 1, w - 2, h - 2))
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- 文字の幅と折り返し
_NOHEAD = set('、。，．）」』】〕・ー：；？！ゃゅょっャュョッぁぃぅぇぉァィゥェォ％')


def tw(s, size):
    """文字列のおおよその幅（px）。全角は1文字＝size、半角は約0.56×size"""
    w = 0
    for ch in str(s):
        o = ord(ch)
        if ch == '\u200b':
            continue
        w += size * (0.56 if o < 0x2E80 and ch not in '−×÷＝' else 1.0)
    return w


_OPEN = set('（「『【〔［')


def _tokens(para):
    """折り返しの単位に分ける。半角の英数字の並び（数字・金額）は分けない。
    閉じ括弧・句読点は前に、開き括弧は後ろにくっつける"""
    toks = []
    buf = ''
    for ch in para:
        if ord(ch) < 128 and ch != ' ':
            buf += ch
            continue
        if buf:
            toks.append(buf)
            buf = ''
        toks.append(ch)
    if buf:
        toks.append(buf)
    out = []
    carry = ''
    for i, t in enumerate(toks):
        if carry:
            t = carry + t
            carry = ''
        if t in _OPEN or (t in '－＋△' and i + 1 < len(toks) and toks[i + 1][:1].isdigit()):
            carry = t
            continue
        if out and (t[0] in _NOHEAD or t == ' '):
            out[-1] += t
        else:
            out.append(t)
    if carry:
        out.append(carry)
    return out


def _greedy(toks, maxw, size):
    lines = []
    line = ''
    for t in toks:
        if line and tw((line + t).rstrip(), size) > maxw:
            lines.append(line.rstrip())
            line = t.lstrip()
        else:
            line += t
    lines.append(line.rstrip())
    return lines


_GOOD_END = set('、・）」，。：')
_OPS = set('＋－×÷＝／')


def _cls(ch):
    o = ord(ch)
    if 0x3040 <= o <= 0x309F:
        return 'h'
    if 0x30A0 <= o <= 0x30FF:
        return 'k'
    if 0x4E00 <= o <= 0x9FFF or ch == '々':
        return 'K'
    if o < 128:
        return 'a'
    return 'o'


def _brk(p, q):
    """p（行末の文字）と q（次の行頭の文字）の間で改行するときの悪さ。0がよい切れ目"""
    if p in _GOOD_END or q in _OPEN or p == ' ' or p == '\u200b' or q == '\u200b':
        return 0
    if p in _OPS or q in _OPS:
        return 0.3
    a, b = _cls(p), _cls(q)
    if a == 'h' and b in 'Kka':
        return 0.3
    if (a, b) in (('k', 'K'), ('K', 'k')):
        return 0.5
    return 1.0


def _layout(toks, maxw, size):
    """最少の行数か1行多い行数で、語の途中で切らず、切れ目のよい所で改行する（動的計画法）"""
    n = len(_greedy(toks, maxw, size))
    if n == 1:
        return [''.join(toks).strip()]
    c1, l1 = _layout_n(toks, maxw, size, n)
    c2, l2 = _layout_n(toks, maxw, size, n + 1)
    if l2 is not None and (l1 is None or c2 + 0.4 < c1):
        return l2
    return l1 if l1 is not None else _greedy(toks, maxw, size)


def _layout_n(toks, maxw, size, n):
    T = len(toks)
    if n > T:
        return float('inf'), None
    target = tw(''.join(toks).strip(), size) / n
    INF = float('inf')
    f = [[INF] * (n + 1) for _ in range(T + 1)]
    back = [[0] * (n + 1) for _ in range(T + 1)]
    f[0][0] = 0
    for k in range(1, n + 1):
        for i in range(1, T + 1):
            for j in range(k - 1, i):
                if f[j][k - 1] == INF:
                    continue
                seg = ''.join(toks[j:i]).strip()
                if not seg:
                    continue
                wd = tw(seg, size)
                if wd > maxw and i - j > 1:
                    continue
                c = 0.1 * ((wd - target) / target) ** 2
                if i < T:
                    nxt = toks[i].lstrip()[:1] or ' '
                    c += _brk(''.join(toks[j:i])[-1:], nxt)
                elif n > 1 and len(seg) <= 2:
                    c += 0.5
                if f[j][k - 1] + c < f[i][k]:
                    f[i][k] = f[j][k - 1] + c
                    back[i][k] = j
    if f[T][n] == INF:
        return INF, None
    out = []
    i = T
    for k in range(n, 0, -1):
        j = back[i][k]
        out.append(''.join(toks[j:i]).strip())
        i = j
    return f[T][n], out[::-1]


def wrap(s, maxw, size, balance=True):
    """折り返し。行頭に句読点や閉じ括弧が来ないようにし、数字の並びは切らない。
    balance=True なら、行数を変えずに各行の長さをそろえ、切れ目のよい所で改行する"""
    out = []
    for para in str(s).split('\n'):
        toks = _tokens(para)
        if not toks:
            out.append('')
            continue
        out.extend(_layout(toks, maxw, size) if balance else _greedy(toks, maxw, size))
    return out


# ---------------------------------------------------------------- 汎用の表（見出し行あり、列の揃えを指定。長い文は折り返す）
def grid(head, rows, colw, align=None, title='表', size=12, minw=None, head2=None, hl_rows=(), total_rows=(), tcol=None):
    """head: 見出しの行。head2: その上の見出し（[(文字, 何列分)]）。align: 'l','c','r' の並び"""
    w = sum(colw)
    hh = 22
    lh = round(size * 1.38, 1)
    top = hh if head2 else 0
    align = align or ['l'] + ['r'] * (len(colw) - 1)
    xs = [0]
    for c in colw:
        xs.append(xs[-1] + c)
    cells = []
    heights = []
    for r in rows:
        cl = []
        n = 1
        for j, s in enumerate(r):
            if s in (None, ''):
                cl.append([])
                continue
            txt = yen(s)
            lines = [txt] if align[j] == 'r' else wrap(txt, colw[j] - 12, size)
            cl.append(lines)
            n = max(n, len(lines))
        cells.append(cl)
        heights.append(max(21, n * lh + 7))
    # 見出しも折り返す
    hlines = [wrap(sx, colw[j] - 8, size) for j, sx in enumerate(head)]
    hh = max(22, max(len(x) for x in hlines) * lh + 7)
    h = top + hh + sum(heights) + 2
    o = [R(1, 1, w - 2, top + hh, fill='paper', stroke=None)]
    if head2:
        ci = 0
        for sx, span in head2:
            x1, x2 = xs[ci], xs[ci + span]
            if sx:
                o.append(T((x1 + x2) / 2, 16, sx, 'middle', bold=True, size=size))
            if ci:
                o.append(L(x1, 1, x1, h - 2))
            ci += span
        o.append(L(1, top, w - 1, top))
    for j, ls in enumerate(hlines):
        y0 = top + hh / 2 - (len(ls) - 1) * lh / 2 + size * 0.36
        for k, ln in enumerate(ls):
            o.append(T((xs[j] + xs[j + 1]) / 2, y0 + k * lh, ln, 'middle', bold=True, size=size))
    y = top + hh + 1
    for i, cl in enumerate(cells):
        rh = heights[i]
        if i in hl_rows:
            o.append(R(1, y, w - 2, rh, fill='c', stroke=None, op=0.14))
        if i in total_rows:
            o.append(L(1, y, w - 1, y, col='main'))
        elif i:
            o.append(L(1, y, w - 1, y, sw=0.5, dash='2 2'))
        for j, ls in enumerate(cl):
            if not ls:
                continue
            a = align[j]
            y0 = y + rh / 2 - (len(ls) - 1) * lh / 2 + size * 0.36
            cc = (tcol or {}).get(rows[i][j] if isinstance(rows[i][j], str) else None)
            bd = (i in total_rows) or bool(cc)
            cc = cc or 'main'
            for k, ln in enumerate(ls):
                yy = y0 + k * lh
                if a == 'l':
                    o.append(T(xs[j] + 6, yy, ln, size=size, bold=bd, col=cc))
                elif a == 'c':
                    o.append(T((xs[j] + xs[j + 1]) / 2, yy, ln, 'middle', size=size, bold=bd, col=cc))
                else:
                    o.append(T(xs[j + 1] - 6, yy, ln, 'end', size=size, bold=bd, col=cc))
        y += rh
    o.append(L(1, top + hh + 1, w - 1, top + hh + 1))
    for x in xs[1:-1]:
        o.append(L(x, top, x, h - 2, sw=0.6))
    o.append(R(1, 1, w - 2, h - 2))
    return _svg(w, h, o, title, minw)


# ---------------------------------------------------------------- 箱の図（貸借対照表・損益計算書など）
def boxes(groups, title='図', unit_h=None, total_h=150, link=None, same_scale=False):
    """groups: [(見出し, [左の列, 右の列]), ...]。列は [(名前, 金額, 色), ...] を上から順に。
    すべての列の高さを同じ尺度で描く（金額の大小が高さに出る）。
    link: ((群,列,箱),(群,列,箱),'文字') で、2つの箱を点線の矢印で結ぶ"""
    w = 360
    ng = len(groups)
    gap = 26
    gw = (w - gap * (ng - 1)) / ng
    cw = gw / 2
    mx = max(sum(b[1] for b in col) for g in groups for col in g[1])
    top = 22
    h = top + total_h + 8
    o = []
    pos = {}
    for gi, (gt, cols) in enumerate(groups):
        x0 = gi * (gw + gap)
        gmx = max(sum(b[1] for b in col) for col in cols)
        k = total_h / (mx if same_scale else gmx)
        o.append(T(x0 + gw / 2, 15, gt, 'middle', bold=True))
        for ci, col in enumerate(cols):
            xx = x0 + ci * cw
            yy = top
            for bi, (nm, v, c) in enumerate(col):
                bh = v * k
                o.append(R(xx + 1, yy, cw - 2, bh, fill=c, stroke=c, op=0.2, sw=1.2))
                ls = wrap(nm, cw - 8, 11.5)
                if bh >= len(ls) * 14 + 16:
                    y0 = yy + bh / 2 - (len(ls) * 14 + 14) / 2 + 11
                    for j, ln in enumerate(ls):
                        o.append(T(xx + cw / 2, y0 + j * 14, ln, 'middle', bold=True, size=11.5))
                    o.append(T(xx + cw / 2, y0 + len(ls) * 14 + 1, yen(v), 'middle', size=11))
                elif bh >= 15:
                    one = nm.replace('\n', '') + ' ' + yen(v)
                    if tw(one, 10.5) > cw - 6:
                        one = nm.replace('\n', '')
                    fs = 10.5
                    while tw(one, fs) > cw - 6 and fs > 8.6:
                        fs -= 0.5
                    if tw(one, fs) <= cw - 6:
                        o.append(T(xx + cw / 2, yy + bh / 2 + 4, one, 'middle', size=fs, bold=True))
                pos[(gi, ci, bi)] = (xx, yy, cw, bh)
                yy += bh
    if link:
        (a, b, lab) = link
        xa, ya, wa, ha = pos[a]
        xb, yb, wb, hb = pos[b]
        if xa > xb:
            p1, p2 = (xa, ya + ha / 2), (xb + wb, yb + hb / 2)
        else:
            p1, p2 = (xa + wa, ya + ha / 2), (xb, yb + hb / 2)
        midx = (p1[0] + p2[0]) / 2
        o.append(ARROW([p1, (midx, p1[1]), (midx, p2[1]), p2], col='b', dash='4 3', sw=1.4))
        if lab:
            o.append(T(midx + 4, (p1[1] + p2[1]) / 2, lab, size=10.5, col='b'))
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- 流れ図（手順）
def flow(steps, per_row=3, title='流れ', bw=None, bh=42):
    """steps: 文字列のリスト（\\n で2行に分けられる）。左から右へ、行の終わりで次の行の先頭へ折り返す"""
    w = 360
    gapx = 22
    bw = bw or (w - gapx * (per_row - 1) - 4) / per_row
    gapy = 26
    nl = max(len([1 for ln in st.split('\n') for _ in wrap(ln, bw - 10, 11.5)]) for st in steps)
    bh = max(bh, nl * 15 + 14)
    nrows = (len(steps) + per_row - 1) // per_row
    h = nrows * bh + (nrows - 1) * gapy + 4
    o = []
    cen = []
    for i, s in enumerate(steps):
        r, c = divmod(i, per_row)
        x = 2 + c * (bw + gapx)
        y = 2 + r * (bh + gapy)
        o.append(R(x, y, bw, bh, fill='sheet', stroke='main', sw=1.2, rx=6))
        lines = [ln2 for ln in s.split('\n') for ln2 in wrap(ln, bw - 10, 11.5)]
        for j, ln in enumerate(lines):
            yy = y + bh / 2 + 4 + (j - (len(lines) - 1) / 2) * 15
            o.append(T(x + bw / 2, yy, ln, 'middle', size=11.5, bold=(j == 0)))
        cen.append((x, y))
    for i in range(len(steps) - 1):
        (x1, y1), (x2, y2) = cen[i], cen[i + 1]
        if y1 == y2:
            o.append(ARROW([(x1 + bw + 2, y1 + bh / 2), (x2 - 2, y2 + bh / 2)], sw=1.4, head=6))
        else:
            o.append(ARROW([(x1 + bw / 2, y1 + bh + 1), (x1 + bw / 2, y1 + bh + gapy / 2), (x2 + bw / 2, y1 + bh + gapy / 2), (x2 + bw / 2, y2 - 2)], sw=1.4, head=6))
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- 2×2のマトリクス（PPMなど）
def matrix2(cells, xlab, ylab, xends=('高', '低'), yends=('高', '低'), arrows=(), title='マトリクス'):
    """cells: {(行,列): (名前, 色, [説明の行])}。行0が上、列0が左。
    arrows: [((x,y),(x,y),'solid'|'dash','色')]。座標は格子の単位（左上(0,0)〜右下(2,2)）"""
    x0, y0, cw, ch = 44, 8, 150, 104
    w, h = x0 + 2 * cw + 8, y0 + 2 * ch + 40
    o = []
    for (r, c), (nm, col, desc) in cells.items():
        x, y = x0 + c * cw, y0 + r * ch
        o.append(R(x, y, cw, ch, fill=col, stroke='line', op=0.13))
        o.append(T(x + cw / 2, y + 26, nm, 'middle', col=col, bold=True, size=14))
        for j, d in enumerate(desc):
            o.append(T(x + cw / 2, y + 46 + j * 16, d, 'middle', size=11))
    o.append(R(x0, y0, 2 * cw, 2 * ch, stroke='main', sw=1.4))
    # 縦軸
    o.append(T(x0 - 8, y0 + 14, yends[0], 'end', bold=True))
    o.append(T(x0 - 8, y0 + 2 * ch - 4, yends[1], 'end', bold=True))
    o.append('<text x="%s" y="%s" text-anchor="middle" transform="rotate(-90 %s %s)" style="fill:currentColor">%s</text>' % (x0 - 16, y0 + ch, x0 - 16, y0 + ch, _esc(ylab)))
    # 横軸
    o.append(T(x0 + 10, y0 + 2 * ch + 16, xends[0], bold=True))
    o.append(T(x0 + 2 * cw - 10, y0 + 2 * ch + 16, xends[1], 'end', bold=True))
    o.append(T(x0 + cw, y0 + 2 * ch + 32, xlab, 'middle'))

    def P(p):
        return (x0 + p[0] * cw, y0 + p[1] * ch)
    for (a, b, st, col) in arrows:
        o.append(ARROW([P(a), P(b)], col=col, dash='5 4' if st == 'dash' else None, sw=2))
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- 棚卸減耗損と商品評価損の図
def inv_loss(cost, nrv, book, act, title='棚卸減耗損と商品評価損'):
    w, h = 360, 214
    x0, y0, pw, ph = 66, 14, 214, 150
    X = lambda q: x0 + q / book * pw
    Y = lambda p: y0 + ph - p / cost * ph
    o = []
    o.append(R(X(0), Y(nrv), X(act) - X(0), Y(0) - Y(nrv), fill='b', stroke='main', op=0.18))
    o.append(R(X(0), Y(cost), X(act) - X(0), Y(nrv) - Y(cost), fill='c', stroke='main', op=0.22))
    o.append(R(X(act), Y(cost), X(book) - X(act), Y(0) - Y(cost), fill='a', stroke='main', op=0.2))
    cx = (X(0) + X(act)) / 2
    o.append(T(cx, (Y(nrv) + Y(0)) / 2 - 6, '期末商品（貸借対照表）', 'middle', bold=True, size=11.5))
    o.append(T(cx, (Y(nrv) + Y(0)) / 2 + 12, '%s×%s個＝%s' % (yen(nrv), yen(act), yen(nrv * act)), 'middle', size=11))
    o.append(T(cx, (Y(cost) + Y(nrv)) / 2 - 3, '商品評価損', 'middle', bold=True, size=11.5))
    o.append(T(cx, (Y(cost) + Y(nrv)) / 2 + 12, '（%s－%s）×%s個＝%s' % (yen(cost), yen(nrv), yen(act), yen((cost - nrv) * act)), 'middle', size=10.5))
    xr = X(book) + 8
    o.append(T(xr, Y(cost / 2) - 8, '棚卸減耗損', size=11.5, bold=True, col='a'))
    o.append(T(xr, Y(cost / 2) + 8, '%s×%s個' % (yen(cost), yen(book - act)), size=10.5))
    o.append(T(xr, Y(cost / 2) + 23, '＝%s' % yen(cost * (book - act)), size=10.5))
    # 目盛り
    o.append(T(x0 - 6, Y(cost) + 4, '原価 %s' % yen(cost), 'end', size=10.5))
    o.append(T(x0 - 6, Y(nrv) + 4, '正味売却', 'end', size=10.5))
    o.append(T(x0 - 6, Y(nrv) + 17, '価額 %s' % yen(nrv), 'end', size=10.5))
    o.append(T(X(act), Y(0) + 16, '実地 %s個' % yen(act), 'end', size=10.5))
    o.append(T(X(book), Y(0) + 16, '帳簿 %s個' % yen(book), 'start', size=10.5))
    o.append(L(X(act), Y(0), X(act), Y(0) + 5, col='main'))
    o.append(T(x0 - 6, Y(0) + 4, '0', 'end', size=10.5))
    o.append(T(X(book / 2), h - 6, '数量', 'middle', size=11))
    o.append('<text x="12" y="%s" text-anchor="middle" font-size="11" transform="rotate(-90 12 %s)" style="fill:currentColor">単価</text>' % (Y(cost / 2), Y(cost / 2)))
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- 折れ線のグラフ（負の値も描ける）
def chart(series, xmin, xmax, ymin, ymax, xlab='', ylab='', labels=(), vlines=(), bands=(), dots=(), w=360, h=230, title='グラフ', xticks=(), yticks=(), zero=True):
    """series: [(点のリスト, 色, 点線か)]。labels: [(x,y,文字,揃え,色)]。vlines: [(x, 文字)] 縦の点線と上部の文字。
    bands: [(x1,x2,文字)] 区間の名前（上部に表示）。xticks/yticks: [(値,文字)]"""
    L0, R0, T0, B0 = 40, 12, 22 if (vlines or bands) else 12, (40 if (xlab and xticks) else 30)
    pw, ph = w - L0 - R0, h - T0 - B0
    X = lambda x: L0 + (x - xmin) / (xmax - xmin) * pw
    Y = lambda y: T0 + ph - (y - ymin) / (ymax - ymin) * ph
    o = []
    for (x1, x2, s) in bands:
        o.append(T((X(x1) + X(x2)) / 2, 14, s, 'middle', size=11, bold=True))
    for (x, s) in vlines:
        o.append(L(X(x), T0 - 4, X(x), Y(ymin), dash='3 3', sw=0.8))
        if s:
            o.append(T(X(x), T0 - 8, s, 'middle', size=10.5, bold=True))
    # 軸
    o.append(L(X(xmin), Y(ymin), X(xmin), T0 - 2, col='main', sw=1.3))
    o.append(L(X(xmin), Y(max(ymin, 0) if ymin < 0 else ymin), X(xmax) + 2, Y(max(ymin, 0) if ymin < 0 else ymin), col='main', sw=1.3))
    if ymin < 0:
        o.append(T(X(xmin) - 4, Y(0) + 4, '0', 'end', size=10.5))
    elif zero:
        o.append(T(X(xmin) - 4, Y(ymin) + 14, '0', 'end', size=10.5))
    if ylab:
        o.append(T(X(xmin) + 5, T0 + (14 if bands else 2), ylab, size=11))
    if xlab:
        o.append(T(X(xmax), Y(ymin) + (32 if xticks else 22), xlab, 'end', size=11))
    for v, s in xticks:
        o.append(T(X(v), Y(ymin) + 14, s, 'middle', size=10.5))
    for v, s in yticks:
        o.append(T(X(xmin) - 4, Y(v) + 4, s, 'end', size=10.5))
    for pts, col, dash in series:
        d = 'M' + ' L'.join('%s %s' % (round(X(a), 1), round(Y(b), 1)) for a, b in pts)
        o.append('<path d="%s" fill="none" style="stroke:%s" stroke-width="2.2"%s stroke-linecap="round" stroke-linejoin="round"/>' % (d, _c(col), ' stroke-dasharray="6 4"' if dash else ''))
    for (x, y, col) in dots:
        o.append('<circle cx="%s" cy="%s" r="3.4" style="fill:%s"/>' % (round(X(x), 1), round(Y(y), 1), _c(col)))
    for lb in labels:
        x, y, s = lb[0], lb[1], lb[2]
        anc = lb[3] if len(lb) > 3 else 'start'
        col = lb[4] if len(lb) > 4 else 'main'
        o.append(T(X(x), Y(y) + 4, s, anc, col=col, size=11.5, bold=(col != 'main')))
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- 時間の流れ（目盛りつきの矢印）
def timeline(points, title='時間の流れ', w=360, h=None, spans=()):
    """points: [(位置0〜1, 上の文字, 下の文字, 色)]。文字は \\n で改行できる。
    spans: [(位置1, 位置2, 文字, 色)] 区間を矢印の下に括弧で示す"""
    ntop = max([len(p[1].split('\n')) if p[1] else 0 for p in points] + [0])
    nbot = max([len(p[2].split('\n')) if p[2] else 0 for p in points] + [0])
    y = 10 + ntop * 15 + 8
    hh = h or (y + 14 + nbot * 15 + (30 if spans else 0) + 4)
    X = lambda p: 44 + p * (w - 96)
    o = [ARROW([(6, y), (w - 6, y)], col='main', sw=1.6, head=7)]
    for (p, top, bot, col) in points:
        x = X(p)
        o.append('<circle cx="%s" cy="%s" r="4.2" style="fill:%s"/>' % (round(x, 1), y, _c(col)))
        if top:
            ls = top.split('\n')
            for j, ln in enumerate(ls):
                o.append(T(x, y - 10 - (len(ls) - 1 - j) * 15, ln, 'middle', col=col, bold=True, size=11.5))
        if bot:
            for j, ln in enumerate(bot.split('\n')):
                o.append(T(x, y + 19 + j * 15, ln, 'middle', size=11))
    for (p1, p2, s, col) in spans:
        yb = y + 14 + nbot * 15 + 6
        x1, x2 = X(p1), X(p2)
        o.append('<path d="M%s %sV%sH%sV%s" fill="none" style="stroke:%s" stroke-width="1.3"/>' % (round(x1, 1), yb - 5, yb, round(x2, 1), yb - 5, _c(col)))
        o.append(T((x1 + x2) / 2, yb + 15, s, 'middle', col=col, size=11, bold=True))
    return _svg(w, hh, o, title)


# ---------------------------------------------------------------- 仕訳の流れ（時点ごとの仕訳を1つの表に）
def jflow(rows, title='仕訳の流れ', colw=(118, 121, 121), size=11.5, hl_rows=()):
    """rows: [(時点, 借方（科目と金額）, 貸方（科目と金額）)]"""
    return grid(['時点', '借方', '貸方'], [list(r) for r in rows], list(colw), align=['l', 'l', 'l'], title=title, size=size, hl_rows=hl_rows)


# ---------------------------------------------------------------- 判定の流れ（はい→右の結論、いいえ→下の問い）
def dtree(steps, final, title='判定の流れ', qw=196, lw=128):
    """steps: [(問い, はいの結論, 色)]。final: (最後のいいえの結論, 色)。文字は \\n で改行できる"""
    w = 360
    gap = 26
    nl = max([len([1 for ln in t.split('\n') for _ in wrap(ln, qw - 10, 11.5)]) for t, _, _ in steps]
             + [len([1 for ln in t.split('\n') for _ in wrap(ln, lw - 10, 11.5)]) for _, t, _ in steps] + [1])
    bh = max(44, nl * 15 + 14)
    n = len(steps)
    h = (n + 1) * bh + n * gap + 6
    o = []
    xq, xl = 2, w - lw - 2

    def box(x, y, bw, s, col, fill='sheet', bold=False):
        o.append(R(x, y, bw, bh, fill=fill if col is None else col, stroke='main' if col is None else col, sw=1.2, rx=6, op=None if col is None else 0.16))
        ls = [ln2 for ln in s.split('\n') for ln2 in wrap(ln, bw - 10, 11.5)]
        for j, ln in enumerate(ls):
            o.append(T(x + bw / 2, y + bh / 2 + 4 + (j - (len(ls) - 1) / 2) * 15, ln, 'middle', size=11.5, bold=bold, col='main'))
    for i, (q, yes, col) in enumerate(steps):
        y = 2 + i * (bh + gap)
        box(xq, y, qw, q, None)
        box(xl, y, lw, yes, col, bold=True)
        o.append(ARROW([(xq + qw + 1, y + bh / 2), (xl - 2, y + bh / 2)], sw=1.4, head=6))
        o.append(T((xq + qw + xl) / 2, y + bh / 2 - 6, 'はい', 'middle', size=10.5))
        o.append(ARROW([(xq + qw / 2, y + bh + 1), (xq + qw / 2, y + bh + gap - 2)], sw=1.4, head=6))
        o.append(T(xq + qw / 2 + 8, y + bh + gap / 2 + 4, 'いいえ', size=10.5))
    y = 2 + n * (bh + gap)
    box(xq, y, qw, final[0], final[1], bold=True)
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- 増減の内訳（ウォーターフォール。横向きの棒）
def waterfall(items, title='増減の内訳', w=360, lw=132, vw=56, size=11, fmt=None):
    """items: [(名前, 値, 種類)]。種類: 'start'（0からの棒）、'delta'（前の残高からの増減。増は緑、減は赤）、
    'total'（0からの棒。値が None なら、そこまでの累計）"""
    vals = []
    run = 0
    for nm, v, k in items:
        if k == 'start':
            a, b = 0, v
        elif k == 'total':
            v = run if v is None else v
            a, b = 0, v
        else:
            a, b = run, run + v
        run = b
        vals.append((a, b, v))
    lo = min([0] + [min(a, b) for a, b, _ in vals])
    hi = max(max(a, b) for a, b, _ in vals)
    x0, x1 = lw, w - vw - 4
    X = lambda v: x0 + (v - lo) / ((hi - lo) or 1) * (x1 - x0)
    o = []
    y = 4
    prev = None
    for (nm, _, k), (a, b, v) in zip(items, vals):
        ls = wrap(nm, lw - 12, size)
        rh = max(26, len(ls) * 15 + 10)
        bh = 16
        by = y + (rh - bh) / 2
        col = 'sub' if k != 'delta' else ('b' if v >= 0 else 'a')
        xa, xb = X(min(a, b)), X(max(a, b))
        o.append(R(xa, by, max(2, xb - xa), bh, fill=col, stroke=col, op=0.3 if k == 'delta' else 0.22))
        for j, ln in enumerate(ls):
            o.append(T(lw - 8, y + rh / 2 + 4 + (j - (len(ls) - 1) / 2) * 15, ln, 'end', size=size, bold=(k != 'delta')))
        vv = round(v, 2) if isinstance(v, float) else v
        if isinstance(vv, float) and vv.is_integer():
            vv = int(vv)
        num = fmt(abs(vv)) if fmt else yen(abs(vv))
        txt = ('－' if vv < 0 else '') + num if k != 'delta' else ('＋' if vv >= 0 else '－') + num
        o.append(T(w - 4, y + rh / 2 + 4, txt, 'end', size=size, bold=(k != 'delta')))
        if prev is not None:
            o.append(L(prev[0], prev[1], prev[0], by, dash='2 2', sw=0.8))
        prev = (X(b), by + bh)
        y += rh
    if lo < 0:
        o.append(L(X(0), 2, X(0), y, sw=0.8))
    return _svg(w, y + 4, o, title)


# ---------------------------------------------------------------- 2行2列の対照表（各マスに見出しと説明）
def quad(rows, cols, cells, title='対照表', lw=60, size=11, w=360):
    """rows: 行の見出し2つ。cols: 列の見出し2つ。cells[r][c] = (見出し, 説明, 色)"""
    if not any(rows):
        lw = 0
    cw = (w - lw) / 2
    hh = 26 if any(cols) else 0
    o = [R(1, 1, w - 2, hh, fill='paper', stroke=None)] if hh else []
    for c, s in enumerate(cols):
        if s:
            o.append(T(lw + cw * c + cw / 2, 18, s, 'middle', bold=True, size=size))
    y = hh
    for r, rs in enumerate(rows):
        bodies = [wrap(cells[r][c][1], cw - 14, size) for c in range(2)]
        rh = max(len(b) for b in bodies) * 15 + 34
        for c in range(2):
            hd, body, col = cells[r][c]
            x = lw + cw * c
            o.append(R(x + 3, y + 3, cw - 6, rh - 6, fill=col, stroke=col, op=0.12, rx=5))
            o.append(T(x + cw / 2, y + 20, hd, 'middle', bold=True, col=col, size=size + 1))
            for j, ln in enumerate(bodies[c]):
                o.append(T(x + 9, y + 38 + j * 15, ln, size=size))
        rl = wrap(rs, lw - 10, size)
        for j, ln in enumerate(rl):
            o.append(T(lw / 2, y + rh / 2 + 4 + (j - (len(rl) - 1) / 2) * 15, ln, 'middle', bold=True, size=size))
        if y:
            o.append(L(1, y, w - 1, y))
        y += rh
    if lw:
        o.append(L(lw, 1, lw, y - 1))
    if hh or lw:
        o.append(R(1, 1, w - 2, y - 2))
    return _svg(w, y, o, title)


# ---------------------------------------------------------------- 積み上げの階段（原価の構成など）
def stairs(cols, title='構成', H=190, w=360, gap=8, show_values=False):
    """cols: [(見出し, [(名前, 値, 色), ...])]。各列は下から積み上げる"""
    n = len(cols)
    cw = (w - gap * (n - 1) - 2) / n
    mx = max(sum(b[1] for b in c[1]) for c in cols)
    top = 8 + max(len(wrap(c[0], cw - 4, 11.5)) for c in cols) * 14
    o = []
    for i, (hd, blocks) in enumerate(cols):
        x = 1 + i * (cw + gap)
        tot = sum(b[1] for b in blocks)
        y = top + H
        hl = wrap(hd, cw - 4, 11.5)
        ytop = top + H - tot / mx * H
        for j, ln in enumerate(hl):
            o.append(T(x + cw / 2, ytop - 6 - (len(hl) - 1 - j) * 14, ln, 'middle', bold=True, size=11.5))
        for nm, v, c in blocks:
            bh = v / mx * H
            y -= bh
            o.append(R(x, y, cw, bh, fill=c, stroke=c, op=0.2, sw=1.1))
            ls = wrap(nm, cw - 8, 10.5)
            if show_values:
                ls = ls + [yen(v)]
            if bh >= len(ls) * 13 + 4:
                for j, ln in enumerate(ls):
                    o.append(T(x + cw / 2, y + bh / 2 + 4 + (j - (len(ls) - 1) / 2) * 13, ln, 'middle', size=10.5,
                               bold=(j < len(ls) - (1 if show_values else 0))))
    return _svg(w, top + H + 4, o, title)


# ---------------------------------------------------------------- 仕掛品などのボックス図（数量と金額）
def wipbox(cols, title='ボックス図', H=150, w=360, gap=14):
    """cols: [(見出し, 左の箱, 右の箱)]。箱は [(名前, 説明（\nで改行）, 重み, 色)] を上から順に。
    高さは重みに比例させるが、文字が収まる高さは確保する"""
    n = len(cols)
    cw = (w - gap * (n - 1) - 2) / n
    top = 20
    o = []
    hmax = 0
    for i, (hd, left, right) in enumerate(cols):
        x = 1 + i * (cw + gap)
        o.append(T(x + cw / 2, 14, hd, 'middle', bold=True, size=11.5))
        sides = []
        for items in (left, right):
            tot = sum(it[2] for it in items)
            hs = []
            for nm, sub, wt, c in items:
                nl = 1 + len(wrap(sub, cw / 2 - 8, 10.5)) if sub else 1
                hs.append(max(wt / tot * H, nl * 13 + 10))
            sides.append(hs)
        HH = max(sum(sides[0]), sum(sides[1]))
        for hs in sides:
            d = HH - sum(hs)
            k = hs.index(max(hs))
            hs[k] += d
        for si, items in enumerate((left, right)):
            xx = x + si * cw / 2
            y = top
            for (nm, sub, wt, c), bh in zip(items, sides[si]):
                o.append(R(xx, y, cw / 2, bh, fill=c, stroke='main', op=0.16, sw=1))
                ls = [(nm, True)] + ([(ln, False) for ln in wrap(sub, cw / 2 - 8, 10.5)] if sub else [])
                for j, (ln, b) in enumerate(ls):
                    o.append(T(xx + cw / 4, y + bh / 2 + 4 + (j - (len(ls) - 1) / 2) * 13, ln, 'middle', size=10.5, bold=b))
                y += bh
        o.append(R(x, top, cw, HH, stroke='main', sw=1.3))
        hmax = max(hmax, HH)
    return _svg(w, top + hmax + 3, o, title)


# ---------------------------------------------------------------- 標準原価の差異（価格×数量の長方形。大きさは模式的）
def variance_box(sp, ap, sq, aq, texts, title='差異分析', plab='価格', qlab='数量', w=360, h=236):
    """sp/ap: 標準と実際の価格、sq/aq: 標準と実際の数量。texts: (標準原価の文字, 価格差異の文字, 数量差異の文字)。
    大きさは比例させず、標準の長方形を左下に、差異を上と右の帯で示す（実際が標準より大きい場合の形）"""
    x0, x1 = 74, w - 8
    y0, y1 = 16, h - 40
    xs, ys = x0 + 0.66 * (x1 - x0), y1 - 0.64 * (y1 - y0)
    o = []
    unf_p = ap > sp
    unf_q = aq > sq
    o.append(R(x0, ys, xs - x0, y1 - ys, fill='sub', stroke='main', op=0.14, sw=1.1))
    o.append(R(x0, y0, x1 - x0, ys - y0, fill='a' if unf_p else 'b', stroke='main', op=0.2, sw=1.1))
    o.append(R(xs, ys, x1 - xs, y1 - ys, fill='a' if unf_q else 'b', stroke='main', op=0.2, sw=1.1))
    o.append(L(x0, y1, x1 + 4, y1, col='main', sw=1.3))
    o.append(L(x0, y1, x0, y0 - 8, col='main', sw=1.3))
    o.append(T(x0 - 6, ys + 4, '標準 ' + yen(sp), 'end', size=10.5))
    o.append(T(x0 - 6, y0 + 4, '実際 ' + yen(ap), 'end', size=10.5))
    o.append(T(x0 - 6, y0 - 4 + (y1 - y0) / 2 + 30, plab, 'end', size=10.5, bold=True))
    o.append(T(xs, y1 + 14, '標準 ' + yen(sq), 'middle', size=10.5))
    o.append(T(x1, y1 + 14, '実際 ' + yen(aq), 'end', size=10.5))
    o.append(T(x0 + 4, y1 + 30, qlab, size=10.5, bold=True))

    def put(cx, cy, maxw, txt):
        ls = wrap(txt, maxw, 10.5)
        for j, ln in enumerate(ls):
            o.append(T(cx, cy + 4 + (j - (len(ls) - 1) / 2) * 13.5, ln, 'middle', size=10.5, bold=(j == 0)))
    put((x0 + xs) / 2, (ys + y1) / 2, xs - x0 - 10, texts[0])
    put((x0 + x1) / 2, (y0 + ys) / 2, x1 - x0 - 10, texts[1])
    put((xs + x1) / 2, (ys + y1) / 2, x1 - xs - 8, texts[2])
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- 指標の分解（上の箱＝下の箱の掛け算）
def decomp(top, rows, title='指標の分解', w=360, op='×', note_between='または', bh=None):
    """top: 上の箱の文字（\nで改行）。rows: 分解のしかたのリスト。各分解は箱の文字のリスト。
    上の箱から各分解へ線を引き、箱の間に op（×など）を置く"""
    size = 11
    lh = 14

    def lines(sx, bw):
        # (行, 最初の段落か) のリスト。最初の段落は折り返しても太字にする
        return [(l2, i == 0) for i, l1 in enumerate(sx.split('\n')) for l2 in wrap(l1, bw - 10, size)]
    tw_ = min(w - 40, 240)
    tl = lines(top, tw_)
    th = len(tl) * lh + 14
    o = []
    tx = (w - tw_) / 2
    o.append(R(tx, 2, tw_, th, fill='a', stroke='a', op=0.14, rx=6, sw=1.3))
    for j, (ln, b) in enumerate(tl):
        o.append(T(w / 2, 2 + th / 2 + 4 + (j - (len(tl) - 1) / 2) * lh, ln, 'middle', size=size + 0.5, bold=b))
    y = 2 + th + 26
    for ri, boxes_ in enumerate(rows):
        n = len(boxes_)
        gap = 20
        bw = (w - 4 - gap * (n - 1)) / n
        ls = [lines(b, bw) for b in boxes_]
        hh = bh or max(len(x) for x in ls) * lh + 14
        if ri == 0:
            o.append(L(w / 2, 2 + th, w / 2, y - 6, col='main', sw=1.2))
            o.append(T(w / 2 + 6, y - 10, '＝', size=12, bold=True))
        else:
            o.append(T(w / 2, y - 8, note_between, 'middle', size=10.5, col='sub', bold=True))
        for k, b in enumerate(boxes_):
            x = 2 + k * (bw + gap)
            o.append(R(x, y, bw, hh, fill='sheet', stroke='main', sw=1.1, rx=6))
            for j, (ln, b) in enumerate(ls[k]):
                o.append(T(x + bw / 2, y + hh / 2 + 4 + (j - (len(ls[k]) - 1) / 2) * lh, ln, 'middle', size=size, bold=b))
            if k < n - 1:
                o.append(T(x + bw + gap / 2, y + hh / 2 + 5, op, 'middle', size=14, bold=True))
        y += hh + 24
    return _svg(w, y - 18, o, title)


# ---------------------------------------------------------------- 分類の木（左から右へ枝分かれ）
def htree(root, title='分類', colw=(60, 82, 190), gapx=12, gapy=8, size=10.5, w=360):
    """root: (文字, 色, [子ノード])。子ノードも同じ形。葉は子ノードを空にする。文字は \\n で改行できる"""
    lh = 13.5
    pos = []

    def lines(txt, d):
        return [l2 for l1 in txt.split('\n') for l2 in wrap(l1, colw[d] - 10, size)]

    def hgt(txt, d):
        return max(28, len(lines(txt, d)) * lh + 10)

    def lay(node, d, y):
        txt, col, ch = node
        if not ch:
            hh = hgt(txt, d)
            pos.append((node, d, y, hh))
            return y + hh + gapy, y + hh / 2
        y0 = y
        cys = []
        for c in ch:
            y, cy = lay(c, d + 1, y)
            cys.append(cy)
        hh = hgt(txt, d)
        cy = (cys[0] + cys[-1]) / 2
        pos.append((node, d, cy - hh / 2, hh))
        return y, cy
    yend, _ = lay(root, 0, 2)
    xs = [2]
    for c in colw[:-1]:
        xs.append(xs[-1] + c + gapx)
    o = []
    where = {}
    for node, d, y, hh in pos:
        where[id(node)] = (xs[d], y, colw[d], hh)
    for node, d, y, hh in pos:
        txt, col, ch = node
        x = xs[d]
        o.append(R(x, y, colw[d], hh, fill=col, stroke=col if col != 'sheet' else 'main', op=0.16 if col != 'sheet' else None, rx=5, sw=1.1))
        ls = lines(txt, d)
        for j, ln in enumerate(ls):
            o.append(T(x + colw[d] / 2, y + hh / 2 + 4 + (j - (len(ls) - 1) / 2) * lh, ln, 'middle', size=size, bold=(d < 2 or j == 0 and len(ls) > 1 and False)))
        for c in ch:
            cx, cy0, cw, ch_ = where[id(c)]
            px, py = x + colw[d], y + hh / 2
            mx = px + gapx / 2
            o.append('<path d="M%s %sH%sV%sH%s" fill="none" style="stroke:var(--ink-3)" stroke-width="1.2"/>' % (round(px, 1), round(py, 1), round(mx, 1), round(cy0 + ch_ / 2, 1), round(cx, 1)))
    return _svg(w, yend - gapy + 2, o, title)


# ---------------------------------------------------------------- 棒グラフ（パレート図・P-Q分析・ピッチダイヤグラムなど）
def barchart(vals, labels, title='棒グラフ', w=360, h=220, colors=None, hline=None, hlabel='', cum=False, zones=(), ylab='',
             vfmt=None, ymax=None, lsize=10):
    """vals: 棒の値。labels: 棒の下の文字。hline: 横の点線の値（サイクルタイム、能力など）。cum: 累積比率の折れ線（右軸0〜100％）。
    zones: [(最初の棒, 最後の棒, 文字, 色)] 背景の帯と上の文字"""
    n = len(vals)
    x0, x1 = 40, w - (34 if cum else 10)
    top = 26 if zones else 14
    y1 = h - 32
    mx = ymax or max(list(vals) + ([hline] if hline else [])) * 1.12
    Y = lambda v: y1 - v / mx * (y1 - top)
    cw = (x1 - x0) / n
    bw = cw * 0.68
    o = []
    for (a, b, s, col) in zones:
        o.append(R(x0 + a * cw, top - 12, (b - a + 1) * cw, y1 - top + 12, fill=col, stroke=None, op=0.1))
        o.append(T(x0 + (a + b + 1) / 2 * cw, top - 2, s, 'middle', size=10, bold=True, col=col))
    o.append(L(x0, y1, x1, y1, col='main', sw=1.3))
    o.append(L(x0, y1, x0, top - 6, col='main', sw=1.3))
    if ylab and zones:
        o.append('<text x="12" y="%s" text-anchor="middle" font-size="10" transform="rotate(-90 12 %s)" style="fill:currentColor">%s</text>' % ((top + y1) / 2, (top + y1) / 2, _esc(ylab)))
    elif ylab:
        o.append(T(x0 + 4, top - 2, ylab, size=10))
    for i, v in enumerate(vals):
        x = x0 + i * cw + (cw - bw) / 2
        col = (colors[i] if colors else 'sub')
        o.append(R(x, Y(v), bw, y1 - Y(v), fill=col, stroke=col if col != 'sub' else 'main', op=0.3 if col != 'sub' else 0.18, sw=1))
        ty = Y(v) - 4
        if hline is not None and v < hline and Y(v) - Y(hline) < 16 and y1 - Y(v) > 20:
            ty = Y(v) + 13  # 横の点線と重なるときは、棒の中に書く
        o.append(T(x + bw / 2, ty, vfmt(v) if vfmt else yen(v), 'middle', size=10))
        ls = wrap(labels[i], cw - 2, lsize)
        for j, ln in enumerate(ls[:2]):
            o.append(T(x0 + i * cw + cw / 2, y1 + 13 + j * 12, ln, 'middle', size=lsize))
    if hline is not None:
        o.append(L(x0, Y(hline), x1, Y(hline), col='a', sw=1.4, dash='5 3'))
        if hlabel:
            o.append(T(x1, Y(hline) - 5, hlabel, 'end', size=10.5, col='a', bold=True))
    if cum:
        tot = float(sum(vals))
        acc = 0
        pts = [(x0, y1)]
        for i, v in enumerate(vals):
            acc += v
            pts.append((x0 + (i + 1) * cw, y1 - acc / tot * (y1 - top)))
        o.append('<path d="M%s" fill="none" style="stroke:var(--warn)" stroke-width="2"/>' % ' L'.join('%s %s' % (round(a, 1), round(b, 1)) for a, b in pts))
        for (a, b) in pts[1:]:
            o.append('<circle cx="%s" cy="%s" r="2.6" style="fill:var(--warn)"/>' % (round(a, 1), round(b, 1)))
        o.append(L(x1, y1, x1, top, col='c', sw=1))
        for p in (0, 50, 100):
            o.append(T(x1 + 3, y1 - p / 100 * (y1 - top) + 4, '%d％' % p, size=9.5, col='c'))
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- 線表（ガントチャート）
def gantt(rows, tmax, title='ガントチャート', w=360, lw=70, rh=28, ticks=None, marks=(), tlabel=''):
    """rows: [(行の名前, [(文字, 開始, 終了, 色)])]。marks: [(時刻, 文字)] 縦の点線"""
    x0, x1 = lw, w - 8
    top = 18 if marks else 6
    X = lambda t: x0 + t / tmax * (x1 - x0)
    o = []
    y = top
    for nm, bars in rows:
        ls = wrap(nm, lw - 8, 10.5)
        for j, ln in enumerate(ls):
            o.append(T(lw - 6, y + rh / 2 + 4 + (j - (len(ls) - 1) / 2) * 13, ln, 'end', size=10.5, bold=True))
        o.append(L(x0, y + rh, x1, y + rh, sw=0.5, dash='2 2'))
        for (s, a, b, col) in bars:
            o.append(R(X(a), y + 4, X(b) - X(a), rh - 8, fill=col, stroke=col if col != 'sub' else 'main', op=0.3 if col != 'sub' else 0.16, sw=1))
            if s and tw(s, 10) < X(b) - X(a) - 2:
                o.append(T((X(a) + X(b)) / 2, y + rh / 2 + 4, s, 'middle', size=10, bold=True))
        y += rh
    o.append(L(x0, top, x0, y, col='main', sw=1.2))
    o.append(L(x0, y, x1, y, col='main', sw=1.2))
    for t in (ticks if ticks is not None else range(0, int(tmax) + 1, max(1, int(tmax) // 10))):
        o.append(L(X(t), y, X(t), y + 3, col='main'))
        o.append(T(X(t), y + 14, str(t), 'middle', size=9.5))
    if tlabel:
        o.append(T(x1, y + 27, tlabel, 'end', size=10))
    for (t, s) in marks:
        o.append(L(X(t), top - 4, X(t), y, col='a', sw=1.2, dash='4 3'))
        o.append(T(X(t), top - 7, s, 'middle', size=10, col='a', bold=True))
    return _svg(w, y + (32 if tlabel else 20), o, title)


# ---------------------------------------------------------------- 循環（PDCAなど）
def cycle(steps, title='サイクル', w=360, h=230, bw=118, bh=42, center=''):
    """steps: 文字のリスト（\\nで改行）。上から時計回りに並べ、矢印でつなぐ"""
    n = len(steps)
    cx, cy = w / 2, h / 2
    rx, ry = w / 2 - bw / 2 - 4, h / 2 - bh / 2 - 4
    pos = []
    for i in range(n):
        a = -math.pi / 2 + 2 * math.pi * i / n
        pos.append((cx + rx * math.cos(a), cy + ry * math.sin(a)))
    o = []
    if center:
        for j, ln in enumerate(center.split('\n')):
            o.append(T(cx, cy + 4 + (j - (len(center.split('\n')) - 1) / 2) * 15, ln, 'middle', size=12, bold=True, col='a'))

    def edge(p, q):
        # 箱の中心 p から q へ向かう線が、箱の縁と交わる点
        dx, dy = q[0] - p[0], q[1] - p[1]
        k = min((bw / 2 + 3) / abs(dx) if dx else 1e9, (bh / 2 + 3) / abs(dy) if dy else 1e9)
        return (p[0] + dx * k, p[1] + dy * k)
    for i in range(n):
        p, q = pos[i], pos[(i + 1) % n]
        o.append(ARROW([edge(p, q), edge(q, p)], col='a', sw=1.6, head=6))
    for i, (x, y) in enumerate(pos):
        o.append(R(x - bw / 2, y - bh / 2, bw, bh, fill='sheet', stroke='main', sw=1.2, rx=8))
        ls = [l2 for l1 in steps[i].split('\n') for l2 in wrap(l1, bw - 10, 11)]
        for j, ln in enumerate(ls):
            o.append(T(x, y + 4 + (j - (len(ls) - 1) / 2) * 14, ln, 'middle', size=11, bold=(j == 0)))
    return _svg(w, h, o, title)


# ---------------------------------------------------------------- ピラミッド（優先順位・階層）
def pyramid(levels, title='階層', w=360, lh=34, inverted=False, notes=None):
    """levels: 上から順に [(文字, 色)]。inverted=True なら上が広い（逆三角形）。notes: 右側の注記（levels と同じ数、なければ None）"""
    n = len(levels)
    pw = w * (0.62 if notes else 1.0) - 4
    o = []
    for i, (s, col) in enumerate(levels):
        if inverted:
            wt, wb = pw * (1 - i / n * 0.75), pw * (1 - (i + 1) / n * 0.75)
        else:
            wt, wb = pw * (0.25 + 0.75 * i / n), pw * (0.25 + 0.75 * (i + 1) / n)
        cx = 2 + pw / 2
        y = 2 + i * lh
        o.append('<path d="M%s %sL%s %sL%s %sL%s %sZ" style="fill:%s;fill-opacity:0.22;stroke:%s" stroke-width="1.2"/>' % (
            round(cx - wt / 2, 1), y, round(cx + wt / 2, 1), y, round(cx + wb / 2, 1), y + lh - 2, round(cx - wb / 2, 1), y + lh - 2, _c(col), _c(col)))
        o.append(T(cx, y + lh / 2 + 3, s, 'middle', size=11, bold=True))
        if notes and notes[i]:
            o.append(T(pw + 10, y + lh / 2 + 3, notes[i], size=10.5))
    return _svg(w, n * lh + 4, o, title)
