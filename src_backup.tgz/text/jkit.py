# 経営情報システムの図表の部品（積み重ね、タイル、データの表、機器のアイコン、シーケンス図）。fig_joho_*.py から使う
import math
from vis import ARROW, R, T, L, _svg, _c, _esc, wrap, tw
from kit import _box, _lines, _dashrect


def r1(v):
    return round(v, 1)


# アプリの等幅の文字と同じ指定（日本語は Noto Sans JP で表示する）
MONO = "ui-monospace,Menlo,Consolas,'Noto Sans JP','Noto Sans CJK JP','Hiragino Sans','Yu Gothic','Meiryo',monospace"


def stack(layers, title, w=360, bw=None, size=10.5, gap=4, nsize=10.5, minh=30, op=0.2):
    """上から積んだ層。layers: [(文字, 色, 注記)]（注記は省略可）。注記があれば箱の右に書く"""
    lh = round(size * 1.34, 1)
    nlh = round(nsize * 1.32, 1)
    hasn = any(len(l) > 2 and l[2] for l in layers)
    bw = bw or (150 if hasn else w - 4)
    nw = w - bw - 14
    o = []
    y = 2
    for l in layers:
        s, col = l[0], l[1]
        note = l[2] if len(l) > 2 else ''
        nl = len(_lines(s, bw - 10, size))
        ls = [x for p in note.split('\n') for x in wrap(p, nw, nsize)] if note else []
        h = max(minh, nl * lh + 10, len(ls) * nlh + 8)
        _box(o, 2, y, bw, h, s, col=col, size=size, c0=col, op=op)
        for j, ln in enumerate(ls):
            o.append(T(bw + 12, y + h / 2 + nsize * 0.36 + (j - (len(ls) - 1) / 2) * nlh, ln, size=nsize))
        y += h + gap
    return _svg(w, y - gap + 2, o, title)


def tiles(items, title, cols=3, w=360, size=10.5, gap=6, bh=None, op=0.16):
    """タイルを並べる。items: 文字（\\n の前を太字）か (文字, 色)。最後の行は中央に寄せる"""
    n = len(items)
    rows = (n + cols - 1) // cols
    bw = (w - 4 - gap * (cols - 1)) / cols
    lh = round(size * 1.34, 1)
    txt = [i[0] if isinstance(i, tuple) else i for i in items]
    nl = max(len(_lines(s, bw - 10, size)) for s in txt)
    h = bh or max(34, nl * lh + 12)
    o = []
    for i, it in enumerate(items):
        r, c = divmod(i, cols)
        inrow = min(cols, n - r * cols)
        off = (cols - inrow) * (bw + gap) / 2
        col = it[1] if isinstance(it, tuple) else None
        _box(o, 2 + off + c * (bw + gap), 2 + r * (h + gap), bw, h, txt[i], col=col, size=size, c0=col, op=op)
    return _svg(w, rows * h + (rows - 1) * gap + 4, o, title)


def dtab(o, x, y, head, rows, colw, name=None, size=10, rh=19, hl=None, pk=(), fk=(), ncol='main', align=None, hh=None):
    """データの表を描き、高さを返す。hl: {(行, 列): 色}（行 -1 は見出し、列 None は行全体）。pk・fk: 下線を引く列の番号。
    セルの文字は \\n で改行できない（列の幅で調整する）"""
    hl = hl or {}
    hh = hh or rh
    yy = y
    if name:
        o.append(T(x + 1, y + size + 1, name, bold=True, size=size + 0.5, col=ncol))
        yy += size + 6
    W = sum(colw)
    xs = [x]
    for c in colw:
        xs.append(xs[-1] + c)
    align = align or ['c'] * len(colw)
    o.append(R(x, yy, W, hh, fill='paper', stroke=None))
    for j, hd in enumerate(head):
        col = hl.get((-1, j))
        if col:
            o.append(R(xs[j], yy, colw[j], hh, fill=col, stroke=None, op=0.28))
        ls = str(hd).split('\n')
        for k, ln in enumerate(ls):
            o.append(T(xs[j] + colw[j] / 2, yy + hh / 2 + size * 0.36 + (k - (len(ls) - 1) / 2) * (size + 2), ln, 'middle', bold=True, size=size))
        if j in pk:
            o.append(L(xs[j] + 3, yy + hh - 3, xs[j + 1] - 3, yy + hh - 3, col='main', sw=1.3))
        if j in fk:
            o.append(L(xs[j] + 3, yy + hh - 3, xs[j + 1] - 3, yy + hh - 3, col='main', sw=1.3, dash='3 2'))
    for i, row in enumerate(rows):
        ry = yy + hh + i * rh
        o.append(R(x, ry, W, rh, fill='sheet', stroke=None))
        rc = hl.get((i, None))
        if rc:
            o.append(R(x, ry, W, rh, fill=rc, stroke=None, op=0.2))
        for j, v in enumerate(row):
            cc = hl.get((i, j))
            if cc:
                o.append(R(xs[j], ry, colw[j], rh, fill=cc, stroke=None, op=0.28))
            a = align[j]
            tx = xs[j] + colw[j] / 2 if a == 'c' else (xs[j] + 4 if a == 'l' else xs[j + 1] - 4)
            o.append(T(tx, ry + rh / 2 + size * 0.36, v, {'c': 'middle', 'l': 'start', 'r': 'end'}[a], size=size))
    H = hh + rh * len(rows)
    o.append(R(x, yy, W, H, fill='none', stroke='line', sw=1))
    for j in range(1, len(colw)):
        o.append(L(xs[j], yy, xs[j], yy + H, col='line', sw=0.8))
    for i in range(len(rows) + 1):
        o.append(L(x, yy + hh + i * rh, x + W, yy + hh + i * rh, col='line', sw=0.8 if i else 1.1))
    return yy + H - y


# ---------------------------------------------------------------- 機器のアイコン（中心の座標で置く）
def lab(o, cx, y, s, col='main', size=10, bold=False):
    for k, ln in enumerate(str(s).split('\n')):
        o.append(T(cx, y + k * (size + 2.5), ln, 'middle', col=col, size=size, bold=bold))


def pc(o, cx, cy, label=None, col='main', op=0.14):
    o.append(R(cx - 15, cy - 13, 30, 20, fill='sheet', stroke=None, rx=2))
    o.append(R(cx - 15, cy - 13, 30, 20, fill=col, stroke=col, sw=1.3, rx=2, op=op))
    o.append(L(cx, cy + 7, cx, cy + 11, col=col, sw=1.6))
    o.append(L(cx - 8, cy + 12, cx + 8, cy + 12, col=col, sw=1.6))
    if label:
        lab(o, cx, cy + 25, label, col)


def srv(o, cx, cy, label=None, col='main', op=0.14):
    o.append(R(cx - 12, cy - 17, 24, 34, fill='sheet', stroke=None, rx=2))
    o.append(R(cx - 12, cy - 17, 24, 34, fill=col, stroke=col, sw=1.3, rx=2, op=op))
    for k in range(3):
        o.append(L(cx - 7, cy - 9 + k * 7, cx + 7, cy - 9 + k * 7, col=col, sw=1.1))
    o.append('<circle cx="%s" cy="%s" r="1.8" style="fill:%s"/>' % (r1(cx), r1(cy + 11), _c(col)))
    if label:
        lab(o, cx, cy + 30, label, col)


def cyl(o, cx, cy, w=34, h=36, label=None, col='main', op=0.16, inside=None, isize=10):
    rx, ry = w / 2, 5
    x0, y0, y1 = cx - rx, cy - h / 2 + ry, cy + h / 2 - ry
    d = 'M%s %s L%s %s A%s %s 0 0 0 %s %s L%s %s' % (r1(x0), r1(y0), r1(x0), r1(y1), r1(rx), ry, r1(x0 + w), r1(y1), r1(x0 + w), r1(y0))
    o.append('<path d="%s Z" style="fill:var(--sheet);stroke:none"/>' % d)
    o.append('<path d="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="1.3"/>' % (d, _c(col), op, _c(col)))
    o.append('<ellipse cx="%s" cy="%s" rx="%s" ry="%s" style="fill:var(--sheet);stroke:%s" stroke-width="1.3"/>' % (r1(cx), r1(y0), r1(rx), ry, _c(col)))
    o.append('<ellipse cx="%s" cy="%s" rx="%s" ry="%s" style="fill:%s;fill-opacity:%s;stroke:none"/>' % (r1(cx), r1(y0), r1(rx), ry, _c(col), op))
    if inside:
        lab(o, cx, cy + 6 - (len(inside.split('\n')) - 1) * 6, inside, 'main', isize, True)
    if label:
        lab(o, cx, cy + h / 2 + 13, label, col)


_CLOUD = [(25, 55), [(10, 55, 4, 45, 10, 37), (2, 30, 9, 17, 22, 20), (24, 7, 42, 4, 50, 13), (56, 3, 76, 5, 78, 19),
                     (91, 17, 98, 30, 91, 40), (98, 50, 89, 58, 77, 55)]]


def cloud(o, cx, cy, w, h, label=None, col='sub', op=0.12, size=10.5, bold=True, lcol='main'):
    X = lambda v: r1(cx - w / 2 + v * w / 100)
    Y = lambda v: r1(cy - h / 2 + v * h / 60)
    (sx, sy), segs = _CLOUD
    d = 'M%s %s' % (X(sx), Y(sy)) + ''.join(' C%s %s %s %s %s %s' % (X(a), Y(b), X(c), Y(dd), X(e), Y(f)) for a, b, c, dd, e, f in segs) + ' Z'
    o.append('<path d="%s" style="fill:var(--sheet);stroke:none"/>' % d)
    o.append('<path d="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="1.3"/>' % (d, _c(col), op, _c(col if col != 'sub' else 'line')))
    if label:
        ls = str(label).split('\n')
        for k, ln in enumerate(ls):
            o.append(T(cx, cy + 6 + (k - (len(ls) - 1) / 2) * (size + 3), ln, 'middle', col=lcol, size=size, bold=bold and k == 0))


def person(o, cx, cy, label=None, col='main'):
    o.append('<circle cx="%s" cy="%s" r="5.5" style="fill:var(--sheet);stroke:%s" stroke-width="1.4"/>' % (r1(cx), r1(cy - 9), _c(col)))
    o.append('<path d="M%s %s Q%s %s %s %s" style="fill:none;stroke:%s" stroke-width="1.4"/>' % (
        r1(cx - 10), r1(cy + 11), r1(cx), r1(cy - 12), r1(cx + 10), r1(cy + 11), _c(col)))
    if label:
        lab(o, cx, cy + 25, label, col)


def rtr(o, cx, cy, label=None, col='main', text='', op=0.14, r=14):
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:var(--sheet);stroke:none"/>' % (r1(cx), r1(cy), r))
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="1.3"/>' % (r1(cx), r1(cy), r, _c(col), op, _c(col)))
    if text:
        o.append(T(cx, cy + 3.6, text, 'middle', size=9.5, bold=True, col=col))
    else:
        o.append(ARROW([(cx - 8, cy - 3), (cx + 8, cy - 3)], col=col, sw=1.2, head=4))
        o.append(ARROW([(cx + 8, cy + 3), (cx - 8, cy + 3)], col=col, sw=1.2, head=4))
    if label:
        lab(o, cx, cy + r + 12, label, col)


def brace(o, x1, x2, y, s, col='main', up=False, size=10, bold=True):
    """横向きの括弧と文字。up=True なら括弧の上に文字"""
    d = -5 if up else 5
    o.append('<path d="M%s %s L%s %s L%s %s L%s %s" style="fill:none;stroke:%s" stroke-width="1.2"/>' % (
        r1(x1), r1(y - d), r1(x1), r1(y), r1(x2), r1(y), r1(x2), r1(y - d), _c(col)))
    ls = str(s).split('\n')
    for k, ln in enumerate(ls):
        yy = (y - 6 - (len(ls) - 1 - k) * (size + 2.5)) if up else (y + size + 4 + k * (size + 2.5))
        o.append(T((x1 + x2) / 2, yy, ln, 'middle', col=col, size=size, bold=bold))


def seq(actors, msgs, title, w=360, rowh=34, size=10.5, bw=None, endpad=10):
    """シーケンス図。actors: [(名前, 色)]。msgs: [(送る側, 受ける側, 文字, 色, 点線)]（色・点線は省略可）。
    送る側と受ける側が同じなら、その線の上に注記の箱を置く"""
    n = len(actors)
    xs = [(w / n) * (i + 0.5) for i in range(n)]
    bw = bw or min(w / n - 8, 110)
    lh = round(size * 1.3, 1)
    o = []
    hb = max(len(_lines(a[0], bw - 8, size)) for a in actors) * lh + 12
    body = []
    y = hb + 26
    for m in msgs:
        a, b, s = m[0], m[1], m[2]
        col = m[3] if len(m) > 3 and m[3] else 'main'
        dash = m[4] if len(m) > 4 else False
        if a == b:
            nw = min(w - 8, max(90, w / n + 20))
            ls = _lines(s, nw - 12, size)
            hh = len(ls) * lh + 10
            x = min(max(4, xs[a] - nw / 2), w - 4 - nw)
            _box(body, x, y - 6, nw, hh, s, col=None if col == 'main' else col, size=size, bold0=False, op=0.12)
            y += hh + 12
            continue
        span = abs(xs[b] - xs[a]) - 10
        ls = [x for p in s.split('\n') for x in wrap(p, span, size)]
        y += (len(ls) - 1) * lh
        for k, ln in enumerate(ls):
            body.append(T((xs[a] + xs[b]) / 2, y - 6 - (len(ls) - 1 - k) * lh, ln, 'middle', size=size, col=col if col != 'main' else 'main',
                          bold=False))
        d = 4 if xs[b] > xs[a] else -4
        body.append(ARROW([(xs[a] + d, y), (xs[b] - d, y)], col=col, sw=1.5, head=6, dash='5 3' if dash else None))
        y += rowh - 6
    H = y + endpad
    for i, (nm, col) in enumerate(actors):
        o.append(L(xs[i], hb + 2, xs[i], H - 2, col='line', sw=1, dash='4 3'))
        _box(o, xs[i] - bw / 2, 2, bw, hb, nm, col=col, size=size, c0=col, op=0.2)
    return _svg(w, H, o + body, title)


def code(o, x, y, w, lines, size=10.5, lh=None, col='sub', hl=None):
    """等幅風の文字の箱（行のリスト）。hl: {行の番号: 色}。高さを返す"""
    lh = lh or round(size * 1.45, 1)
    h = len(lines) * lh + 10
    o.append(R(x, y, w, h, fill='paper', stroke='line', rx=4))
    hl = hl or {}
    for i, ln in enumerate(lines):
        if i in hl:
            o.append(R(x + 2, y + 5 + i * lh, w - 4, lh, fill=hl[i], stroke=None, op=0.22))
        o.append('<text x="%s" y="%s" font-size="%s" xml:space="preserve" style="fill:currentColor;white-space:pre;font-family:%s">%s</text>'
                 % (r1(x + 7), r1(y + 5 + i * lh + lh * 0.72), size, MONO, _esc(ln)))
    return h
