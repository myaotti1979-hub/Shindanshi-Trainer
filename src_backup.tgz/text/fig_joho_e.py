# 経営情報システムの図表（2.2 情報システムの開発、2.3 情報システムの運用管理：組織・人材・プロジェクト・セキュリティ）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, htree, gantt, pyramid, quad, ARROW, R, T, L, _svg, _c, wrap, tw)
from kit import (_lines, _dashrect, _box, _lists, _flow, _rowflow, _nest, _hub, _cycle, _ladder)
from ekit import G, txt, eq, panels
from jkit import stack, tiles, dtab, lab, pc, srv, cyl, cloud, person, rtr, brace, code, seq, r1, MONO

FIG = {}


def poly(o, pts, col='main', fill=None, op=0.16, sw=1.3, dash=None):
    d = 'M' + ' L'.join('%s %s' % (r1(a), r1(b)) for a, b in pts) + ' Z'
    ds = ' stroke-dasharray="%s"' % dash if dash else ''
    o.append('<path d="%s" style="fill:var(--sheet);stroke:none"/>' % d)
    o.append('<path d="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="%s"%s/>' % (d, _c(fill or 'sheet'), op if fill else 1, _c(col), sw, ds))


def circ(o, x, y, r, col='main', fill=None, op=0.16, sw=1.3):
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:var(--sheet);stroke:none"/>' % (r1(x), r1(y), r))
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="%s"/>' % (
        r1(x), r1(y), r, _c(fill or 'sheet'), op if fill else 1, _c(col), sw))


def key(o, x, y, col='main', s=1.0):
    """鍵のアイコン（左端の円の中心を x, y に置く）"""
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:none;stroke:%s" stroke-width="2"/>' % (r1(x), r1(y), 5 * s, _c(col)))
    o.append(L(x + 5 * s, y, x + 17 * s, y, col=col, sw=2))
    o.append(L(x + 13 * s, y, x + 13 * s, y + 4 * s, col=col, sw=2))
    o.append(L(x + 17 * s, y, x + 17 * s, y + 5 * s, col=col, sw=2))


# ------------------------------------------------ 2.2.1 ウォーターフォール型開発
def _wf():
    o = []
    st = ['要件定義', '外部設計（基本設計）', '内部設計（詳細設計）', 'プログラミング', 'テスト', '移行・運用']
    for i, s in enumerate(st):
        x, y = 4 + i * 44, 6 + i * 30
        _box(o, x, y, 128, 24, s, col='b' if i < 3 else ('c' if i < 5 else None), size=10, c0=None)
        if i < 5:
            o.append(ARROW([(x + 128, y + 12), (x + 152, y + 12), (x + 152, y + 28)], sw=1.3, head=5))
    o.append(ARROW([(180, 138), (18, 138), (18, 32)], col='a', sw=1.4, head=6, dash='5 3'))
    o.append(T(26, 98, '後で誤りが', size=10, bold=True, col='a'))
    o.append(T(26, 112, '見つかると', size=10, bold=True, col='a'))
    o.append(T(26, 126, '手戻りが大きい', size=10, bold=True, col='a'))
    o.append(T(4, 206, '前の工程の成果物を確定させてから、次の工程に進む。', size=10))
    o.append(T(4, 222, '区切りが明確で管理しやすく、大規模な開発に向く。', size=10))
    o.append(T(4, 238, '仕様の変更に対応しにくい', size=10, col='a'))
    return _svg(360, 244, o, 'ウォーターフォール型開発')


FIG['joho.wf'] = _wf()


def _vmodel():
    o = []
    left = ['要件定義', '外部設計（基本設計）', '内部設計（詳細設計）', 'プログラム設計']
    right = ['受入れテスト（運用テスト）', 'システムテスト（総合テスト）', '結合テスト', '単体テスト']
    for i in range(4):
        y = 6 + i * 38
        x1 = 4 + i * 14
        x2 = 356 - 140 - i * 14
        _box(o, x1, y, 140, 28, left[i], col='b', size=10, c0=None)
        _box(o, x2, y, 140, 28, right[i], col='c', size=10, c0=None)
        o.append(L(x1 + 140, y + 14, x2, y + 14, col='line', sw=1, dash='4 3'))
        if i < 3:
            o.append(ARROW([(x1 + 30, y + 30), (x1 + 44, y + 36)], sw=1.2, head=4))
            o.append(ARROW([(x2 + 96, y + 36), (x2 + 110, y + 30)], sw=1.2, head=4))
    _box(o, 120, 160, 120, 28, 'プログラミング', size=10.5)
    o.append(ARROW([(84, 148), (118, 168)], sw=1.2, head=4))
    o.append(ARROW([(242, 168), (276, 148)], sw=1.2, head=4))
    o.append(T(180, 206, '点線：上流の文書が、対応するテストで確かめる基準になる', 'middle', size=10))
    return _svg(360, 212, o, 'V字モデル')


FIG['joho.vmodel'] = _vmodel()

FIG['joho.nfr'] = _hub('非機能要求グレード\n6つの大項目', ['可用性', '性能・拡張性', '運用・保守性', '移行性', 'セキュリティ', 'システム環境・\nエコロジー'], '非機能要求グレード',
                       bw=96, cw=132, ccol='b')

FIG['joho.nfrmodel'] = tiles([('社会的影響がほとんどないシステム', 'b'), ('社会的影響が限定されるシステム', 'c'), ('社会的影響が極めて大きいシステム', 'a')],
                             '3つのモデルシステム', cols=3, size=10)

FIG['joho.sigma'] = _flow([('企画プロセス\nシステム化構想の立案→システム化計画の立案', 'c'), ('要件定義プロセス\n要件を識別・評価し、利害関係者と合意', 'b'),
                           'システム開発プロセス', 'ソフトウェア実装プロセス', '運用・保守のプロセス'], '共通フレーム2013のプロセス（一部）', per_row=3, size=10)

FIG['joho.contract'] = grid(['', '請負契約', '準委任契約', '労働者派遣'],
                            [['約束するもの', '仕事の完成', '作業を行うこと（事務の処理）', '労働者を派遣する'],
                             ['完成の義務', 'ある（成果物が契約に合わなければ契約不適合責任）', 'ない（善良な管理者の注意をもって作業）', ''],
                             ['作業者への指示', '受注者が行う', '受注者が行う', '派遣先（発注者）が直接行う'],
                             ['向く工程', '成果物を明確にできる工程（内部設計からテストなど）', '成果物を事前に明確にしにくい工程（要件定義など）', '']],
                            [70, 100, 100, 90], align=['l', 'l', 'l', 'l'], title='開発の契約', size=9.5)


def _migrate():
    o = []
    X = lambda t: 96 + t * 25.4
    defs = [('一斉移行', [('全体', [(0, 5, 'o'), (5, 10, 'n')])]),
            ('段階的移行', [('業務A', [(0, 3, 'o'), (3, 10, 'n')]), ('業務B', [(0, 6, 'o'), (6, 10, 'n')])]),
            ('並行運用', [('旧', [(0, 7, 'o')]), ('新', [(3, 10, 'n')])]),
            ('パイロット\n移行', [('一部', [(0, 3, 'o'), (3, 10, 'n')]), ('全体', [(0, 7, 'o'), (7, 10, 'n')])])]
    y = 4
    for nm, rows in defs:
        nl = nm.split('\n')
        for k, ln in enumerate(nl):
            o.append(T(4, y + 12 + (len(rows) - 1) * 9 + (k - (len(nl) - 1) / 2) * 13, ln, size=10.5, bold=True))
        for lb, segs in rows:
            o.append(T(92, y + 12, lb, 'end', size=9))
            for a, b, k in segs:
                col = 'sub' if k == 'o' else 'b'
                o.append(R(X(a), y + 2, X(b) - X(a), 14, fill=col, stroke=col if col != 'sub' else 'line', op=0.3 if col == 'b' else 0.18, sw=0.8))
            y += 18
        if nm == '並行運用':
            o.append(R(X(3), y - 36, X(7) - X(3), 34, fill='none', stroke='c', sw=1.4, rx=2))
            o.append(T(X(5), y + 8, '照らし合わせる', 'middle', size=9, col='c', bold=True))
            y += 8
        y += 10
    o.append(R(96, y, 14, 10, fill='sub', stroke='line', op=0.18))
    o.append(T(114, y + 9, '旧システム', size=9.5))
    o.append(R(190, y, 14, 10, fill='b', stroke='b', op=0.3))
    o.append(T(208, y + 9, '新システム', size=9.5))
    return _svg(360, y + 16, o, 'システムの移行の方式')


FIG['joho.migrate'] = _migrate()


def _proto():
    o = []
    st = ['試作品を\nつくる', '利用者が\n確かめる', '要件を\n明確にする']
    for i, s in enumerate(st):
        x = 4 + i * 120
        _box(o, x, 8, 100, 38, s, col='c' if i == 0 else None, size=10, c0='c' if i == 0 else None)
        if i:
            o.append(ARROW([(x - 18, 27), (x - 2, 27)], sw=1.3, head=5))
    o.append(ARROW([(294, 48), (294, 60), (54, 60), (54, 48)], col='c', sw=1.2, head=5, dash='4 3'))
    o.append(T(174, 74, '繰り返す', 'middle', size=9.5, col='c'))
    _box(o, 4, 86, 172, 38, '使い捨て型\n確認の後に捨てる', size=10)
    _box(o, 184, 86, 172, 38, '進化型\n改良して本番のシステムに育てる', col='b', size=10, c0='b')
    return _svg(360, 128, o, 'プロトタイピングモデル')


FIG['joho.proto'] = _proto()


def _spiral():
    o = []
    cx, cy = 120, 104
    o.append(L(cx - 100, cy, cx + 100, cy, col='line', sw=1))
    o.append(L(cx, cy - 92, cx, cy + 92, col='line', sw=1))
    pts = []
    for k in range(0, 361 * 3, 6):
        a = math.radians(k)
        r = 8 + k / 360 * 26
        pts.append((cx + r * math.cos(a - math.pi), cy + r * math.sin(a - math.pi)))
    o.append('<path d="M%s" style="fill:none;stroke:%s" stroke-width="2"/>' % (' L'.join('%s %s' % (r1(a), r1(b)) for a, b in pts), _c('b')))
    a, b = pts[-2], pts[-1]
    o.append(ARROW([a, b], col='b', sw=2, head=7))
    for (x, y, s) in [(cx - 60, cy - 70, 'リスクの分析'), (cx + 60, cy - 70, '設計・試作'), (cx + 60, cy + 82, '評価'), (cx - 60, cy + 82, '次の計画')]:
        o.append(T(x, y, s, 'middle', size=10, bold=True))
    o.append(T(240, 70, 'リスクを分析しながら、', size=10))
    o.append(T(240, 86, 'サイクルを繰り返し、', size=10))
    o.append(T(240, 102, 'システムを徐々に', size=10))
    o.append(T(240, 118, '完成させる', size=10))
    return _svg(360, 200, o, 'スパイラルモデル')


FIG['joho.spiral'] = _spiral()

# ------------------------------------------------ 2.2.2 インクリメンタル型開発


def _incr():
    o = []
    o.append(T(4, 14, 'インクリメンタル型：機能を分けて、優先度の高い順に追加', bold=True, size=10.5, col='b'))
    o.append(T(4, 112, '反復型：全体を短い期間で繰り返し改良', bold=True, size=10.5, col='c'))
    for r in range(3):
        x0 = 4 + r * 120
        o.append(T(x0 + 54, 92, 'リリース%d' % (r + 1), 'middle', size=9.5))
        for j, nm in enumerate('ABC'):
            x = x0 + j * 36
            if j <= r:
                o.append(R(x, 26, 32, 52, fill='b', stroke='b', op=0.4, rx=3, sw=1))
                o.append(T(x + 16, 57, nm, 'middle', size=11, bold=True))
            else:
                o.append(_dashrect(x, 26, 32, 52, col='line', rx=3, sw=1))
        o.append(T(x0 + 54, 190, '版%d' % (r + 1), 'middle', size=9.5))
        for j, nm in enumerate('ABC'):
            x = x0 + j * 36
            o.append(R(x, 124, 32, 52, fill='c', stroke='c', op=0.12 + r * 0.16, rx=3, sw=1))
            o.append(T(x + 16, 155, nm, 'middle', size=11, bold=True))
    o.append(T(4, 212, '色の濃さ＝完成の度合い。両者を組み合わせることも多い', size=9.5))
    return _svg(360, 218, o, 'インクリメンタル型と反復型')


FIG['joho.incr'] = _incr()

FIG['joho.devmodels'] = grid(['開発のモデル', '進め方'],
                             [['ウォーターフォール型', '工程を一度だけ順に進める'], ['インクリメンタル型', '機能を分けて、順に開発・リリースして増やす'],
                              ['反復型（イテレーティブ型）', '設計・実装・テストを短い期間で繰り返し、全体を改良'], ['進化型', '利用者の評価を受けながら段階的に進化させる'],
                              ['プロトタイピング', '試作品で要件を明確にする'], ['スパイラル', 'リスクを分析しながらサイクルを繰り返す'], ['RAD', '少人数で支援ツールやプロトタイプを使い、短期間で開発']],
                             [140, 220], align=['l', 'l'], title='開発のモデルの比較', size=10)

# ------------------------------------------------ 2.2.3 アジャイル型開発
FIG['joho.manifesto'] = grid(['より価値を置く（左）', '', '価値は認める（右）'],
                             [['個人と対話', '＞', 'プロセスやツール'], ['動くソフトウェア', '＞', '包括的なドキュメント'], ['顧客との協調', '＞', '契約交渉'], ['変化への対応', '＞', '計画に従うこと']],
                             [160, 40, 160], align=['c', 'c', 'c'], title='アジャイルソフトウェア開発宣言の4つの価値', size=11,
                             tcol={'個人と対話': 'b', '動くソフトウェア': 'b', '顧客との協調': 'b', '変化への対応': 'b'})


def _scrum():
    o = []
    arts = [('プロダクトバックログ', '必要な作業の一覧（POが優先順位）'), ('スプリントバックログ', 'スプリントで行う作業の一覧'), ('インクリメント', '使える状態の成果物')]
    for i, (a, b) in enumerate(arts):
        x = 4 + i * 120
        _box(o, x, 18, 112, 44, a + '\n' + b, col='c', size=9.5, c0='c')
        if i:
            o.append(ARROW([(x - 6, 40), (x - 1, 40)], sw=1.2, head=4))
    o.append(T(4, 12, '成果物', size=10, bold=True, col='c'))
    o.append(R(2, 78, 356, 92, fill='b', stroke='b', op=0.08, rx=10, sw=1.2))
    o.append(T(10, 94, 'スプリント（1か月以内の決まった長さ）', size=10.5, bold=True, col='b'))
    evs = ['スプリント\nプランニング', '開発\n（デイリー\nスクラム）', 'スプリント\nレビュー', 'スプリント\nレトロスペクティブ']
    for i, s in enumerate(evs):
        x = 10 + i * 87
        _box(o, x, 102, 80, 56, s, col='b', size=9, c0=None, bold0=False)
        if i:
            o.append(ARROW([(x - 6, 130), (x - 1, 130)], sw=1.2, head=4))
    o.append(ARROW([(352, 172), (352, 182), (8, 182), (8, 172)], col='b', sw=1.3, head=5, dash='4 3'))
    o.append(T(180, 196, '次のスプリントへ', 'middle', size=9.5, col='b'))
    o.append(T(4, 214, 'デイリースクラム：開発者が毎日15分以内で進み具合を確かめ、', size=9.5))
    o.append(T(4, 228, 'その日の計画を調整する', size=9.5))
    return _svg(360, 234, o, 'スクラム')


FIG['joho.scrum'] = _scrum()

FIG['joho.roles'] = _lists([('プロダクトオーナー', 'c', ['プロダクトの価値を最大にする', 'プロダクトバックログに優先順位をつけて管理']),
                            ('スクラムマスター', 'b', ['スクラムがうまく機能するようにチームを支援', '妨げを取り除く', '指示や命令をする管理者ではない']),
                            ('開発者', 'a', ['使える状態の成果物をつくる', '自己管理型、職能横断'])], 'スクラムの役割', size=10)

FIG['joho.xp'] = tiles([('ペアプログラミング\n2人1組で、1人が書き、もう1人がその場で確かめる', 'b'), ('テスト駆動開発\nプログラムより先にテストを書く', 'b'),
                        ('リファクタリング\n動作を変えずに内部の構造を改善', 'b'), ('継続的インテグレーション\nこまめに統合し、テストを自動で', 'c'),
                        ('コードの共同所有\n誰でも、どのコードでも修正できる', 'c'), ('持続可能なペース\n残業に頼らず週40時間程度', 'c')], 'XPの主なプラクティス', cols=2, size=10)


def _burndown():
    g = G(xmax=10, ymax=100, h=210, xlab='日', ylab='残っている作業の量', pb=38, pl=36, origin='', xlpos='low', pt=24)
    g.line([(0, 100), (10, 0)], col='sub', dash=True, sw=1.8, label='計画（理想）', at=(6.2, 44), lsize=10)
    act = [(0, 100), (1, 96), (2, 90), (3, 86), (4, 74), (5, 68), (6, 56), (7, 46), (8, 32), (9, 20), (10, 6)]
    g.line(act, col='a', sw=2.4, label='実績', at=(5.4, 80), lsize=10.5)
    for v in (0, 50, 100):
        g.yt(v, str(v), size=9.5)
    for v in (0, 5, 10):
        g.xt(v, str(v), size=9.5)
    return g.svg('バーンダウンチャート')


FIG['joho.burndown'] = _burndown()


def _kanban():
    o = []
    cols = [('未着手', ['画面A', 'API', '帳票'], 'sub'), ('作業中（上限3）', ['ログイン', '検索'], 'c'), ('完了', ['設計', 'DB'], 'b')]
    for i, (nm, cards, col) in enumerate(cols):
        x = 4 + i * 120
        o.append(R(x, 4, 112, 132, fill=col, stroke=col if col != 'sub' else 'line', op=0.08, rx=6, sw=1))
        o.append(T(x + 56, 22, nm, 'middle', size=10.5, bold=True))
        for k, c in enumerate(cards):
            o.append(R(x + 12, 32 + k * 32, 88, 26, fill='sheet', stroke='main', sw=1, rx=3))
            o.append(T(x + 56, 49 + k * 32, c, 'middle', size=10))
    o.append(T(4, 154, '作業の流れを見える化し、同時に進める作業の量を制限する', size=10))
    return _svg(360, 160, o, 'かんばん')


FIG['joho.kanban'] = _kanban()

FIG['joho.devops'] = _cycle([('計画・開発', 'b'), ('ビルド・テスト\n（CI）', 'b'), ('リリース\n（CD）', 'b'), ('運用', 'c'), ('監視・\nフィードバック', 'c')],
                            'DevOps', h=220, bw=96, bh=40, center='DevOps\n開発と運用が協力', ccol='b')


def _story():
    o = []
    o.append(R(4, 6, 352, 56, fill='c', stroke='c', op=0.14, rx=6, sw=1.2))
    o.append(T(14, 26, '〈誰〉として、〈何〉をしたい。それは〈なぜ〉だから。', size=11, bold=True))
    o.append(T(14, 48, '例：会員として、注文の履歴を見たい。同じ商品をすぐに買い直せるから。', size=10))
    o.append(T(4, 82, 'ベロシティ：1回のスプリントでチームが完了できる作業の量（計画の目安）', size=10))
    return _svg(360, 88, o, 'ユーザーストーリー')


FIG['joho.story'] = _story()

# ------------------------------------------------ 2.3.1 組織と人材（プロジェクトとITサービスの管理）
FIG['joho.dss'] = htree(('デジタル\nスキル標準\n（DSS）', None, [
    ('DXリテラシー標準\nすべてのビジネスパーソン', 'c', [('Why：DXの背景', 'c', []), ('What：データと技術', 'c', []), ('How：データと技術の活用', 'c', []),
                                             ('マインド・スタンス（土台）', 'c', [])]),
    ('DX推進スキル標準\nDXを推進する人材', 'b', [('ビジネスアーキテクト', 'b', []), ('デザイナー', 'b', []), ('データサイエンティスト', 'b', []),
                                         ('ソフトウェアエンジニア', 'b', []), ('サイバーセキュリティ', 'b', []), ('データマネジメント（ver.2.0で追加）', 'a', [])])]),
    'デジタルスキル標準', colw=(72, 112, 158), gapx=8, size=10)

FIG['joho.skillstd'] = grid(['名前', '定めるもの'],
                            [['ITSS（ITスキル標準）', 'IT人材の職種と専門分野ごとのスキルの水準（レベル1〜7）'],
                             ['iCD（iコンピテンシ ディクショナリ）', '業務（タスク）と、それに必要なスキルを体系的に整理した辞書'],
                             ['DSS（デジタルスキル標準）', 'DXを進めるための人材のスキルの標準']],
                            [130, 230], align=['l', 'l'], title='IT人材のスキルの標準', size=10)

FIG['joho.wbs'] = htree(('システム開発\nプロジェクト', None, [
    ('1 要件定義', 'b', [('1.1 ヒアリング', 'b', []), ('1.2 要件定義書の作成', 'b', [])]),
    ('2 設計', 'c', [('2.1 外部設計', 'c', []), ('2.2 内部設計', 'c', [])]),
    ('3 開発・テスト', 'a', [('3.1 プログラミング', 'a', []), ('3.2 テスト', 'a', [])])]), 'WBSの例', colw=(92, 96, 150), gapx=10, size=10.5)


def _ganttfig():
    o = []
    X = lambda t: 96 + t * 25
    rows = [('要件定義', 0, 2, 0, 2), ('外部設計', 2, 4, 2, 4.5), ('内部設計', 4, 6, 4.5, 7), ('プログラミング', 6, 8, 7, None), ('テスト', 8, 10, None, None)]
    for t in range(0, 11, 2):
        o.append(L(X(t), 14, X(t), 20 + len(rows) * 28, col='line', sw=0.6, dash='2 3'))
        o.append(T(X(t), 10, '%d週' % t if t else '0', 'middle', size=9))
    for i, (nm, a, b, ra, rb) in enumerate(rows):
        y = 18 + i * 28
        o.append(T(90, y + 15, nm, 'end', size=10))
        o.append(R(X(a), y + 2, X(b) - X(a), 9, fill='none', stroke='b', sw=1.2))
        if ra is not None:
            end = rb if rb is not None else 7.5
            o.append(R(X(ra), y + 13, X(end) - X(ra), 9, fill='c', stroke='c', op=0.5, sw=0.8))
    o.append(L(X(7.5), 14, X(7.5), 20 + len(rows) * 28, col='a', sw=1.4))
    o.append(T(X(7.5), 168, '現在', 'middle', size=9.5, col='a', bold=True))
    xm = X(10)
    o.append('<path d="M%s %s L%s %s L%s %s L%s %s Z" style="fill:%s"/>' % (xm, 152, xm + 6, 158, xm, 164, xm - 6, 158, _c('a')))
    o.append(R(96, 176, 14, 8, fill='none', stroke='b', sw=1.2))
    o.append(T(114, 184, '予定', size=9.5))
    o.append(R(160, 176, 14, 8, fill='c', stroke='c', op=0.5))
    o.append(T(178, 184, '実績', size=9.5))
    o.append(T(220, 184, '◆ マイルストーン', size=9.5, col='a'))
    o.append(T(4, 204, '作業の予定と実績は見やすいが、作業の間の依存関係は表しにくい', size=10))
    return _svg(360, 210, o, 'ガントチャート')


FIG['joho.gantt'] = _ganttfig()


def _pert():
    o = []
    nd = {1: (24, 90), 2: (130, 36), 3: (130, 144), 4: (240, 90), 5: (334, 90)}
    eds = [(1, 2, 'A 3日', False), (1, 3, 'B 2日', True), (2, 4, 'C 4日', False), (3, 4, 'D 6日', True), (4, 5, 'E 2日', True)]
    for a, b, s, crit in eds:
        (x1, y1), (x2, y2) = nd[a], nd[b]
        dx, dy = x2 - x1, y2 - y1
        d = math.hypot(dx, dy)
        sx, sy = x1 + dx / d * 15, y1 + dy / d * 15
        ex, ey = x2 - dx / d * 15, y2 - dy / d * 15
        o.append(ARROW([(sx, sy), (ex, ey)], col='a' if crit else 'main', sw=2.6 if crit else 1.4, head=7))
        lp = {'A': (62, 54), 'B': (62, 140), 'C': (204, 54), 'D': (204, 140), 'E': (287, 80)}[s[0]]
        o.append(T(lp[0], lp[1], s, 'middle', size=10.5, bold=True, col='a' if crit else 'main'))
    for n, (x, y) in nd.items():
        circ(o, x, y, 14, col='main')
        o.append(T(x, y + 4.5, str(n), 'middle', size=11, bold=True))
    o.append(T(4, 186, 'A→C→E＝3＋4＋2＝9日', size=10.5))
    o.append(T(4, 204, 'B→D→E＝2＋6＋2＝10日 ← 最も長い＝クリティカルパス', size=10.5, bold=True, col='a'))
    o.append(T(4, 222, 'プロジェクト全体は10日。D（6日）が遅れると全体が遅れる', size=10))
    return _svg(360, 228, o, 'アローダイアグラムとクリティカルパス')


FIG['joho.pert'] = _pert()


def _crash():
    o = []
    X = lambda t: 110 + t * 30
    rows = [('元の計画', [(0, 4, 'A', 'sub'), (4, 8, 'B', 'sub')], ''), ('クラッシング', [(0, 3, 'A', 'b'), (3, 7, 'B', 'sub')], 'Aに人員を追加して短縮（費用が増える）'),
            ('ファスト\nトラッキング', [(0, 4, 'A', 'sub'), (3, 7, 'B', 'c')], 'AとBを並行して進める（手戻りのリスク）')]
    y = 6
    for nm, segs, note in rows:
        ls = nm.split('\n')
        for k, ln in enumerate(ls):
            o.append(T(4, y + 16 + (k - (len(ls) - 1) / 2) * 13, ln, size=10.5, bold=True))
        for i, (a, b, s, col) in enumerate(segs):
            yy = y + (12 if (nm.startswith('ファスト') and i == 1) else 0)
            o.append(R(X(a), yy + 4, X(b) - X(a) - 1, 18 if not nm.startswith('ファスト') else 12, fill=col, stroke=col if col != 'sub' else 'line',
                       op=0.3 if col != 'sub' else 0.18, sw=1, rx=2))
            o.append(T((X(a) + X(b)) / 2, yy + 15 if not nm.startswith('ファスト') else yy + 13, s, 'middle', size=9.5, bold=True))
        if note:
            o.append(T(110, y + 42, note, size=9.5, col='b' if 'クラッシング' == nm else 'c'))
        y += 56
    o.append(L(X(8), 4, X(8), y - 10, col='a', sw=1, dash='3 3'))
    o.append(T(X(8) - 4, 14, '元の完了', 'end', size=9, col='a'))
    return _svg(360, y - 6, o, 'クラッシングとファストトラッキング')


FIG['joho.crash'] = _crash()


def _evm():
    g = G(xmax=10, ymax=1100, h=236, xlab='月', ylab='金額（万円）', pl=44, pb=30, pt=16)
    g.line([(0, 0), (10, 1000)], col='b', dash=True, sw=1.8)
    g.text(8.2, 900, 'PV（計画）', 'end', 'b', True, 10)
    g.line([(0, 0), (1, 90), (2, 190), (3, 290), (4, 390), (5, 500)], col='a', sw=2.2)
    g.line([(0, 0), (1, 80), (2, 160), (3, 240), (4, 320), (5, 400)], col='c', sw=2.2)
    g.vl(5, col='line', y0=0, y1=1050, sw=1, dash='3 3')
    g.text(5, 1060, '現在', 'middle', 'main', True, 9.5)
    g.hl(1000, col='line', x0=0, x1=10, sw=1, dash='3 3')
    g.text(0.3, 1040, 'BAC 1,000', 'start', 'main', True, 9.5)
    g.dot(5, 500, col='a', r=4, label='PV＝AC＝500', pos='nw', size=9.5)
    g.dot(5, 400, col='c', r=4, label='EV＝400', pos='e', size=9.5)
    g.text(5.4, 300, 'EV（出来高）', 'start', 'c', True, 9.5)
    g.text(2.4, 330, 'AC（実コスト）', 'end', 'a', True, 9.5)
    g.vspan(5.6, 400, 500, '差＝－100（CV・SV）', col='a', size=9.5)
    for v in (0, 500, 1000):
        g.yt(v, '{:,}'.format(v), size=9)
    return g.svg('EVMのグラフ')


FIG['joho.evm'] = _evm()

FIG['joho.evmeq'] = eq([[('CPI', 'c'), '＝', 'EV 400', '÷', 'AC 500', '＝', ('0.8 予算超過', 'a')], [('SPI', 'c'), '＝', 'EV 400', '÷', 'PV 500', '＝', ('0.8 遅れ', 'a')],
                        [('EAC', 'b'), '＝', 'BAC 1,000', '÷', 'CPI 0.8', '＝', ('1,250万円', 'b')]], 'EVMの計算', size=10.5)

FIG['joho.estimate'] = htree(('見積もり\nの手法', None, [
    ('類推法\n過去の似たプロジェクトの実績から。初期の段階でも使える', 'b', []),
    ('パラメトリック法\n規模などの変数と工数の関係の数式で', 'c', [('COCOMO\n規模から工数を求めるモデル', 'c', []), ('LOC法\nプログラムの行数から', 'c', [])]),
    ('ボトムアップ法\nWBSの作業ごとに積み上げ。精度は高いが手間', 'a', [('標準タスク法\n作業の種類ごとの標準の工数', 'a', [])])]),
    '見積もりの手法の分類', colw=(58, 150, 132), gapx=8, size=10)

FIG['joho.fp'] = _flow(['機能の数を数える\n外部入力、外部出力、外部照会、内部論理ファイル、外部インタフェースファイル', '複雑さで重みをつけて合計',
                        ('補正係数で調整\n→ 規模', 'b')], 'ファンクションポイント法', per_row=3, size=9.5)


def _sla():
    o = []
    _box(o, 4, 60, 76, 40, '顧客', col='c', size=11, c0='c')
    _box(o, 136, 60, 96, 40, 'サービスの\n提供者', col='b', size=10.5, c0='b')
    _box(o, 276, 14, 80, 40, '社内の\n他部門', size=10)
    _box(o, 276, 108, 80, 40, '外部の\n供給者', size=10)
    o.append(L(80, 80, 136, 80, col='c', sw=2.2))
    o.append(T(108, 72, 'SLA', 'middle', size=11, bold=True, col='c'))
    o.append(L(232, 72, 276, 34, col='main', sw=1.6))
    o.append(T(250, 44, 'OLA', 'end', size=10.5, bold=True))
    o.append(L(232, 88, 276, 128, col='main', sw=1.6))
    o.append(T(250, 126, 'UC', 'end', size=10.5, bold=True))
    o.append(T(4, 172, 'SLA：サービスの内容と水準（稼働率、応答時間、復旧時間など）と、', size=10))
    o.append(T(4, 187, '守れなかったときの扱いを合意。OLAは組織の内部、UCは外部との取り決め', size=10))
    return _svg(360, 194, o, 'SLA、OLA、UC')


FIG['joho.sla'] = _sla()

FIG['joho.itsm'] = _flow(['サービスデスク\n問い合わせを一元的に受け付ける', ('インシデント管理\nサービスをできるだけ早く元に戻す', 'c'), ('問題管理\n根本の原因を突き止め、再発を防ぐ', 'a'),
                          ('変更管理\n変更を評価・承認し、安全に行う', 'b'), '構成管理\n機器やソフトウェアの情報を正確に管理'], 'ITサービスマネジメントの主な活動', per_row=3, size=9.5)

# ------------------------------------------------ 2.3.2 情報セキュリティ


def _cia():
    o = []
    A, B, C = (180, 30), (70, 160), (290, 160)
    poly(o, [A, B, C], col='b', fill='b', op=0.08)
    for (x, y), nm, d in [(A, '機密性', '許可された人だけが使える'), (B, '完全性', '正確で改ざんされていない'), (C, '可用性', '必要なときに使える')]:
        _box(o, x - 70, y - 22, 140, 44, nm + '\n' + d, col='b', size=10, c0='b', op=0.22)
    o.append(T(180, 118, '情報セキュリティの', 'middle', size=10, bold=True))
    o.append(T(180, 132, '3つの要素', 'middle', size=10, bold=True))
    o.append(T(4, 204, 'ほかに：真正性、責任追跡性、否認防止、信頼性', size=10))
    return _svg(360, 210, o, '機密性・完全性・可用性')


FIG['joho.cia'] = _cia()

FIG['joho.malware'] = _lists([('ウイルス', 'a', ['他のプログラムに寄生して増える']), ('ワーム', 'c', ['単独で、ネットワークを通じて自ら増える']),
                              ('トロイの木馬', 'b', ['役に立つソフトウェアを装って侵入する'])], '増え方の違い', size=10.5)


def _sqli():
    o = []
    o.append(T(4, 14, '入力欄に不正な文字列を入れる', size=10.5, bold=True))
    o.append(R(4, 22, 70, 24, fill='paper', stroke='line', rx=3))
    o.append(T(10, 39, 'ID：', size=10.5))
    o.append(R(74, 22, 140, 24, fill='a', stroke='a', op=0.15, rx=3))
    o.append('<text x="80" y="39" font-size="11" xml:space="preserve" style="fill:currentColor;white-space:pre;font-family:%s">%s</text>' % (MONO, "' OR '1'='1"))
    o.append(T(4, 66, 'できあがるSQLの文', size=10, bold=True))
    code(o, 4, 72, 352, ["SELECT * FROM 会員", "WHERE ID = '' OR '1'='1'"], size=10.5, hl={1: 'a'})
    o.append(T(4, 132, '「1=1」は常に真 → 全員のデータが取り出される', size=10.5, bold=True, col='a'))
    o.append(T(4, 154, '対策：プレースホルダ（入力をSQLの文として解釈させない）', size=10.5, bold=True, col='b'))
    code(o, 4, 160, 352, ["SELECT * FROM 会員 WHERE ID = ?"], size=10.5, hl={0: 'b'})
    return _svg(360, 196, o, 'SQLインジェクション')


FIG['joho.sqli'] = _sqli()

FIG['joho.webatk'] = _rowflow([('XSS', 'a', ['脆弱なサイトに不正なスクリプトを埋め込む', '閲覧した利用者のブラウザで実行される', ('対策：出力時のエスケープ処理', 'b')]),
                               ('CSRF', 'a', ['ログイン中の利用者に罠のページを開かせる', '意図しない処理（書き込み、送金）をサイトに送らせる', ('対策：秘密の値（トークン）、パスワードの再入力', 'b')]),
                               ('クリック\nジャッキング', 'a', ['透明にしたページを重ねる', '意図しないボタンをクリックさせる', ('対策：枠（フレーム）の中に表示させない（X-Frame-Options）', 'b')])],
                              'Webアプリケーションへの攻撃と対策', lw=62, size=9.5, bold0=False)


def _dmz():
    o = []
    cloud(o, 46, 90, 84, 60, 'インター\nネット', col='sub', size=10)
    for x in (110, 252):
        o.append(R(x, 64, 22, 52, fill='a', stroke='a', op=0.3, rx=3, sw=1.2))
        o.append(T(x + 11, 94, 'FW', 'middle', size=9, bold=True))
    o.append(ARROW([(90, 90), (108, 90)], sw=1.3, head=5))
    o.append(R(146, 8, 92, 166, fill='c', stroke='c', op=0.1, rx=8, sw=1.2))
    o.append(T(192, 26, 'DMZ', 'middle', size=11, bold=True, col='c'))
    srv(o, 170, 62, label='Web', col='c')
    o.append(R(186, 46, 40, 16, fill='b', stroke='b', op=0.3, rx=2))
    o.append(T(206, 58, 'WAF', 'middle', size=8.5, bold=True))
    srv(o, 210, 116, label='メール', col='c')
    o.append(ARROW([(134, 90), (150, 90)], sw=1.3, head=5))
    o.append(ARROW([(234, 90), (250, 90)], sw=1.3, head=5))
    o.append(R(286, 8, 72, 166, fill='b', stroke='b', op=0.1, rx=8, sw=1.2))
    o.append(T(322, 26, '内部', 'middle', size=11, bold=True, col='b'))
    cyl(o, 322, 70, w=34, h=34, label='DB', col='b')
    pc(o, 322, 130, label='PC', col='b')
    o.append(ARROW([(276, 90), (290, 90)], sw=1.3, head=5))
    o.append(T(4, 196, 'DMZ：外部に公開するサーバ（Web、メール）を置く中間の区域', size=10))
    o.append(T(4, 212, '顧客の情報を保管するDBサーバは、DMZではなく内部に置く', size=10, col='a', bold=True))
    return _svg(360, 218, o, 'ファイアウォールとDMZ')


FIG['joho.dmz'] = _dmz()

FIG['joho.idsips'] = _rowflow([('IDS', 'c', ['不正な通信を検知する', ('管理者に知らせる', 'c')]), ('IPS', 'a', ['不正な通信を検知する', ('遮断まで行う', 'a')])],
                              'IDSとIPS', lw=50, size=10.5)

FIG['joho.secdev'] = grid(['製品・仕組み', '役割'],
                          [['ファイアウォール', 'IPアドレスやポート番号で、通信を許可・遮断する'], ['WAF', 'Webアプリケーションへの通信の中身を検査（SQLインジェクション、XSS）'],
                           ['UTM', 'ファイアウォール、ウイルス対策、IPSなどを1台に'], ['SIEM', 'さまざまな機器のログを集めて関連づけ、異常を検知'],
                           ['サンドボックス', '隔離した環境で疑わしいプログラムを動かして確かめる'], ['EPP', 'マルウェアの感染を防ぐ（ウイルス対策ソフトなど）'],
                           ['EDR', '侵入された後の不審な動きを検知し、隔離などの対応を支援']],
                          [96, 264], align=['l', 'l'], title='防御の製品・仕組み', size=10)


def _zerotrust():
    o = []
    o.append(T(86, 14, '境界型の防御', 'middle', bold=True, size=11, col='c'))
    o.append(R(16, 26, 140, 92, fill='b', stroke='b', op=0.08, rx=6, sw=2.4))
    o.append(T(86, 44, '社内は安全とみなす', 'middle', size=9.5, col='b', bold=True))
    for x in (46, 86, 126):
        pc(o, x, 76, col='b')
    o.append(R(150, 62, 12, 22, fill='c', stroke='c', op=0.6))
    person(o, 190, 74, col='a')
    o.append(T(86, 140, '境界で1回だけ確かめる', 'middle', size=9.5))
    o.append(T(270, 14, 'ゼロトラスト', 'middle', bold=True, size=11, col='b'))
    for i, (x, y) in enumerate([(220, 50), (220, 100), (320, 50), (320, 100)]):
        pc(o, x, y, col='main')
    srv(o, 270, 76, col='b')
    for (x, y) in [(238, 50), (238, 100), (302, 50), (302, 100)]:
        o.append(L(x, y, 270 + (-12 if x < 270 else 12), 76, col='b', sw=1.2))
        o.append('<circle cx="%s" cy="%s" r="5" style="fill:%s"/>' % (r1((x + 270) / 2), r1((y + 76) / 2), _c('c')))
    o.append(T(270, 140, 'すべてのアクセスを、そのつど', 'middle', size=9.5))
    o.append(T(270, 153, '認証・認可して判断する', 'middle', size=9.5, bold=True))
    o.append(T(4, 176, '●＝確認の地点。背景：クラウドの利用やテレワークの広がり', size=9.5))
    return _svg(360, 182, o, '境界型の防御とゼロトラスト')


FIG['joho.zerotrust'] = _zerotrust()


def _mfa():
    o = []
    fs = [('知識', 'パスワード、暗証番号', 'b'), ('所持', 'スマートフォン、ICカード', 'c'), ('生体', '指紋、顔', 'a')]
    for i, (a, b, col) in enumerate(fs):
        _box(o, 4 + i * 120, 6, 112, 40, a + '\n' + b, col=col, size=10, c0=col)
    rows = [('○', 'パスワード＋スマートフォンのワンタイムパスワード', '知識＋所持＝多要素認証', 'b'),
            ('×', 'パスワード＋秘密の質問', '知識＋知識＝2段階認証だが、多要素認証ではない', 'a')]
    for i, (m, a, b, col) in enumerate(rows):
        y = 64 + i * 42
        o.append(T(12, y + 16, m, 'middle', size=14, bold=True, col=col))
        o.append(T(28, y + 10, a, size=10))
        o.append(T(28, y + 26, b, size=10, bold=True, col=col))
    return _svg(360, 150, o, '多要素認証')


FIG['joho.mfa'] = _mfa()

FIG['joho.chres'] = seq([('利用者', 'b'), ('サーバ', 'c')],
                        [(1, 0, 'チャレンジ（毎回異なる乱数）'), (0, 0, 'パスワードと乱数から値を計算'), (0, 1, 'レスポンス（計算した値）'), (1, 1, '同じ計算をして照合。パスワードそのものは流れない')],
                        'チャレンジレスポンス認証', rowh=30, size=10)


def _frrfar():
    g = G(xmax=10, ymax=10, h=200, xlab='判定の厳しさ', ylab='誤りの率', origin='', pb=28, pl=24)
    g.fn(lambda x: 9 * math.exp(-x / 2.4), 0, 10, col='a', sw=2.4)
    g.fn(lambda x: 9 * math.exp(-(10 - x) / 2.4), 0, 10, col='b', sw=2.4)
    g.text(1.2, 8.8, '他人受入率（FAR）', 'start', 'a', True, 10)
    g.text(8.8, 8.8, '本人拒否率（FRR）', 'end', 'b', True, 10)
    g.text(0.2, -1.1, '緩い', 'start', 'main', False, 9.5)
    g.raw(txt(g.X(5), g.Y(4), '厳しくすると、FARは下がり\nFRRは上がる（トレードオフ）', 'middle', size=9.5, halo=True))
    return g.svg('生体認証の2つの誤り')


FIG['joho.frrfar'] = _frrfar()

FIG['joho.passkey'] = seq([('利用者の端末\n（秘密鍵）', 'b'), ('サーバ\n（公開鍵を登録）', 'c')],
                          [(1, 0, 'チャレンジ'), (0, 0, '生体認証やPINで本人を確かめ、秘密鍵で署名'), (0, 1, '署名'), (1, 1, '登録した公開鍵で検証')],
                          'パスキー（FIDO）', rowh=30, size=10)


def _crypto():
    o = []
    for r, (ttl, k1, k2, c1, c2, note) in enumerate([('共通鍵暗号方式', '共通鍵', '同じ共通鍵', 'c', 'c', '速い。鍵を安全に渡すのが課題（AESなど）'),
                                                    ('公開鍵暗号方式', '受信者の公開鍵', '受信者の秘密鍵', 'b', 'a', '鍵の配送の問題はないが遅い（RSAなど）')]):
        y = 6 + r * 92
        o.append(T(4, y + 10, ttl, size=11, bold=True))
        _box(o, 4, y + 20, 58, 30, '平文', size=10)
        o.append(ARROW([(64, y + 35), (112, y + 35)], sw=1.4, head=5))
        key(o, 74, y + 26, col=c1)
        o.append(T(88, y + 58, k1 + 'で暗号化', 'middle', size=9, col=c1, bold=True))
        _box(o, 116, y + 20, 70, 30, '暗号文', col='sub', size=10)
        o.append(ARROW([(188, y + 35), (236, y + 35)], sw=1.4, head=5))
        key(o, 198, y + 26, col=c2)
        o.append(T(212, y + 58, k2 + 'で復号', 'middle', size=9, col=c2, bold=True))
        _box(o, 240, y + 20, 58, 30, '平文', size=10)
        o.append(T(4, y + 80, note, size=10))
    return _svg(360, 188, o, '共通鍵暗号方式と公開鍵暗号方式')


FIG['joho.crypto'] = _crypto()

FIG['joho.hybrid'] = _rowflow([('送信者', 'c', ['データをセッション鍵（共通鍵）で暗号化', 'セッション鍵を受信者の公開鍵で暗号化', '両方を送る']),
                               ('受信者', 'b', ['自分の秘密鍵でセッション鍵を取り出す', 'セッション鍵でデータを復号', ('速さと鍵の配送の両方を解決（SSL/TLS）', 'b')])],
                              'ハイブリッド暗号方式', lw=54, size=9.5, bold0=False)


def _hash():
    o = []
    rows = [('売上は100万円', '5d41 7c0a …'), ('売上は900万円', 'a9f3 02bb …')]
    for i, (a, b) in enumerate(rows):
        y = 8 + i * 42
        _box(o, 4, y, 112, 30, a, size=10.5, col='c' if i else None)
        o.append(ARROW([(118, y + 15), (150, y + 15)], sw=1.4, head=5))
        _box(o, 152, y, 74, 30, 'ハッシュ\n関数', col='b', size=9.5, c0='b')
        o.append(ARROW([(228, y + 15), (254, y + 15)], sw=1.4, head=5))
        o.append(R(256, y, 100, 30, fill='paper', stroke='line', rx=3))
        o.append('<text x="306" y="%s" text-anchor="middle" font-size="10.5" style="fill:currentColor;font-family:%s">%s</text>' % (y + 20, MONO, b))
    o.append(T(4, 108, '1文字違うだけで、まったく違う値になる → 改ざんの検出に使う', size=10, bold=True, col='b'))
    o.append(T(4, 124, '決まった長さの値。ハッシュ値から元のデータは求められない（値は例）', size=10))
    return _svg(360, 130, o, 'ハッシュ関数')


FIG['joho.hash'] = _hash()


def _sign():
    o = []
    o.append(T(4, 14, '送信者', size=11, bold=True, col='c'))
    _box(o, 4, 22, 58, 28, 'データ', size=10)
    o.append(ARROW([(64, 36), (86, 36)], sw=1.3, head=5))
    _box(o, 88, 22, 64, 28, 'ハッシュ値', size=10)
    o.append(ARROW([(154, 36), (176, 36)], sw=1.3, head=5))
    key(o, 160, 26, col='c')
    o.append(T(166, 62, '送信者の秘密鍵で暗号化', 'middle', size=9, col='c', bold=True))
    _box(o, 178, 22, 58, 28, '署名', col='c', size=10.5, c0='c')
    o.append(T(300, 34, 'データ＋署名を送る', 'middle', size=10, bold=True))
    o.append(ARROW([(300, 42), (300, 82)], sw=1.5, head=6))
    o.append(T(4, 96, '受信者', size=11, bold=True, col='b'))
    _box(o, 4, 106, 58, 28, '署名', col='c', size=10.5, c0='c')
    o.append(ARROW([(64, 120), (110, 120)], sw=1.3, head=5))
    key(o, 72, 110, col='b')
    o.append(T(86, 148, '送信者の公開鍵で復号', 'middle', size=9, col='b', bold=True))
    _box(o, 112, 106, 76, 28, 'ハッシュ値A', size=10)
    _box(o, 4, 160, 58, 28, 'データ', size=10)
    o.append(ARROW([(64, 174), (110, 174)], sw=1.3, head=5))
    _box(o, 112, 160, 76, 28, 'ハッシュ値B', size=10)
    o.append(L(188, 120, 206, 120, col='main', sw=1.2))
    o.append(L(188, 174, 206, 174, col='main', sw=1.2))
    o.append(L(206, 120, 206, 174, col='main', sw=1.2))
    o.append(ARROW([(206, 147), (222, 147)], sw=1.3, head=5))
    _box(o, 224, 124, 132, 46, '一致すれば\n本人であり、改ざんなし', col='b', size=10, c0='b')
    o.append(T(4, 210, 'デジタル署名だけでは、データは暗号化されない（機密性は守れない）', size=10, col='a', bold=True))
    return _svg(360, 216, o, 'デジタル署名のしくみ')


FIG['joho.sign'] = _sign()

FIG['joho.keyuse'] = grid(['目的', '送る側が使う鍵', '受け取る側が使う鍵', '守れるもの'],
                          [['暗号化', '受信者の公開鍵', '受信者の秘密鍵', '機密性'], ['デジタル署名', '送信者の秘密鍵', '送信者の公開鍵', '本人であること・改ざんがないこと']],
                          [74, 96, 96, 94], align=['l', 'c', 'c', 'l'], title='鍵の使い分け', size=10, tcol={'受信者の公開鍵': 'b', '送信者の秘密鍵': 'c'})


def _pki():
    o = []
    _box(o, 4, 10, 100, 40, '認証局（CA）', col='c', size=10.5, c0='c')
    o.append(ARROW([(106, 30), (150, 30)], col='c', sw=1.5, head=6))
    o.append(T(128, 22, '発行', 'middle', size=9.5, col='c', bold=True))
    o.append(R(152, 6, 120, 52, fill='paper', stroke='main', sw=1.2, rx=4))
    o.append(T(212, 22, '電子証明書', 'middle', size=10.5, bold=True))
    o.append(T(212, 37, '公開鍵＋持ち主', 'middle', size=9.5))
    o.append(T(212, 51, '＋認証局の署名', 'middle', size=9.5))
    o.append(T(4, 80, '公開鍵とその持ち主を結びつけ、公開鍵が本物であることを保証する', size=10))
    o.append(T(4, 98, 'タイムスタンプ：ある時刻に存在し、その後に改ざんされていないことを証明', size=10))
    return _svg(360, 104, o, 'PKI')


FIG['joho.pki'] = _pki()

FIG['joho.isms'] = _cycle(['Plan\nリスクを評価し\n対策を決める', 'Do\n対策を実施する', 'Check\n監視・評価する', 'Act\n改善する'], 'ISMSのPDCA', h=210, bw=112, bh=48,
                          center='ISMS', ccol='b')

FIG['joho.policy'] = pyramid([('基本方針', 'a'), ('対策の基準', 'c'), ('具体的な実施の手順', 'b')], '情報セキュリティポリシー', lh=40)


def _riskflow():
    o = []
    st = [('リスク特定', '発見し、認識し、記述する'), ('リスク分析', '特質を理解し、リスクレベルを決定'), ('リスク評価', 'リスク基準と比べ、受容できるかを決める')]
    for i, (a, b) in enumerate(st):
        x = 4 + i * 92
        _box(o, x, 26, 84, 70, a + '\n' + b, col='b', size=9.5, c0='b')
        if i:
            o.append(ARROW([(x - 7, 61), (x - 1, 61)], sw=1.2, head=4))
    brace(o, 4, 268, 18, 'リスクアセスメント', col='b', up=True, size=10.5)
    o.append(ARROW([(272, 61), (282, 61)], sw=1.2, head=4))
    _box(o, 284, 26, 72, 70, 'リスク対応\n回避・低減・移転・保有', col='c', size=9.5, c0='c')
    o.append(T(4, 116, 'リスクレベル＝結果と起こりやすさの組み合わせで表すリスクの大きさ', size=9.5))
    return _svg(360, 122, o, 'リスクアセスメント')


FIG['joho.riskflow'] = _riskflow()

FIG['joho.riskmat'] = quad(('影響が大きい', '影響が小さい'), ('起こりやすい', '起こりにくい'),
                           [[('回避', '原因となる活動をやめる（例：PCの持ち出しの禁止）', 'a'), ('移転', '他者と分け合う（例：保険への加入、外部への委託）', 'c')],
                            [('低減', '対策で可能性や影響を小さくする（例：ファイアウォール）', 'b'), ('保有（受容）', '対策をとらずに受け入れる', 'sub')]],
                           'リスクへの対応（選び方の目安）', lw=58, size=10)

FIG['joho.soccsirt'] = _flow([('SOC\nログを24時間365日監視', 'c'), ('SOC\n攻撃を検知して分析', 'c'), ('CSIRT\nインシデントの受付・分析・対応', 'b'),
                              ('CSIRT\n関係先との調整', 'b')], 'SOCとCSIRT', per_row=4, size=9.5, gapx=12)


def _fraud():
    o = []
    A, B, C = (180, 24), (70, 140), (290, 140)
    poly(o, [A, B, C], col='a', fill='a', op=0.08)
    for (x, y), nm in [(A, '動機（プレッシャー）'), (B, '機会'), (C, '正当化')]:
        _box(o, x - 64, y - 16, 128, 32, nm, col='a', size=10.5, c0='a', op=0.22)
    o.append(T(180, 96, '3つがそろうと', 'middle', size=10, bold=True))
    o.append(T(180, 110, '不正が起きやすい', 'middle', size=10, bold=True))
    o.append(T(4, 180, '機会への対策：アクセス権限を必要な人に限る、', size=9.5, col='b'))
    o.append(T(4, 194, '　アクセスログを記録して監視する、職務を分ける', size=9.5, col='b'))
    o.append(T(4, 210, '正当化への対策：情報倫理の教育など', size=9.5, col='b'))
    return _svg(360, 216, o, '不正のトライアングル')


FIG['joho.fraud'] = _fraud()

FIG['joho.sme6'] = tiles([('①OSやソフトウェアは常に最新の状態に', 'b'), ('②ウイルス対策ソフトを導入', 'b'), ('③パスワードを強化', 'b'), ('④共有設定を見直す', 'b'),
                          ('⑤バックアップを取る（第4.0版で追加）', 'a'), ('⑥脅威や攻撃の手口を知る', 'b')], '情報セキュリティ6か条', cols=2, size=10)

FIG['joho.sme37'] = _lists([('経営者が認識すべき3原則', 'c', ['経営者のリーダーシップで進める', '委託先の対策まで考慮する', '関係者と常にコミュニケーションをとる']),
                            ('重要7項目の取組', 'b', ['組織全体の対応方針', '予算や人材などの確保', '対策の検討と実行の指示', '対策の見直しの指示', '緊急時の対応や復旧の体制',
                                                 '委託や外部サービスの責任の明確化', '最新の動向の収集'])], '中小企業の情報セキュリティ対策ガイドライン', size=10)

FIG['joho.secaction'] = _ladder([('一つ星\n「情報セキュリティ6か条」に取り組むことを宣言', 'c'),
                                 ('二つ星\n状況を診断し、情報セキュリティ基本方針を定めて公開したことを宣言', 'b')], 'SECURITY ACTION', bw=250, size=10)

FIG['joho.telework'] = grid(['方式', 'しくみ', '端末の業務のデータ'],
                            [['VPN方式', 'VPNで社内のネットワークに接続', '残ることがある'], ['リモートデスクトップ', 'オフィスのPCの画面を遠隔で操作', '残らない'],
                             ['仮想デスクトップ（VDI）', 'サーバ上の仮想のデスクトップを操作', '残らない'], ['セキュアコンテナ', '端末の中の隔離した業務用の領域で作業', ''],
                             ['セキュアブラウザ', 'データを保存できない特別なブラウザ', '保存できない'], ['クラウドサービス', '社内のネットワークを経由せずクラウドへ', ''],
                             ['スタンドアロン', 'ネットワークに接続しない', '端末に保存して作業']],
                            [114, 160, 86], align=['l', 'l', 'c'], title='テレワークの方式', size=9.5, tcol={'残らない': 'b', '保存できない': 'b', '残ることがある': 'a'})

FIG['joho.mdm'] = _nest([('MDM：端末を管理（リモートロック、リモートワイプ）', 'b'), ('MAM：業務用のアプリケーションを管理', 'c'), ('MCM：業務用のデータ（コンテンツ）を管理', 'a')],
                        'MDM、MAM、MCM')

FIG['joho.byod'] = grid(['呼び方', '端末の所有', '使い方'], [['BYOD', '従業員（私物）', '私物の端末を業務に使う'], ['COPE', '会社', '会社の端末で、私的な利用も認める']],
                        [70, 110, 180], align=['l', 'l', 'l'], title='BYODとCOPE', size=10.5)

FIG['joho.ransom'] = _rowflow([('主な侵入の経路', 'a', ['VPNの機器、リモートデスクトップ（脆弱性、弱いパスワード）', '不審なメールや添付ファイル'], False),
                               ('備え', 'b', ['OSやソフトウェアを最新に保つ', 'バックアップをネットワークから切り離して保管し、復元できるか確かめる'], False),
                               ('感染が疑われたら', 'c', ['電源は切らずに、ネットワークから切り離す', '身代金を払っても、データが戻る保証はない'], False)],
                              'ランサムウェアへの備え', lw=80, size=9.5, bold0=False)
