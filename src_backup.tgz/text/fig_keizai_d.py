# 経済学・経済政策の図表（1.7 組織と戦略の経済学、1.8 所得分配）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, flow, chart, htree, quad, timeline, pyramid, barchart, waterfall, decomp, dtree, ARROW, R, T, L, _svg, _c, wrap, tw)
from kit import (_lines, _dashrect, _box, _lists, _flow, _rowflow, _bands, _hub, _nest, _ladder)
from ekit import G, panels, payoff, txt, hbars, stackbar, eq

FIG = {}


def _below(g, lines, y0=40):
    for k, (s, c) in enumerate(lines):
        g.raw(txt(6 + g.ox, g.Y(g.xaxis) + y0 + k * 18, s, size=10.5, bold=True, col=c))


# ------------------------------------------------ 1.7.1 情報の不完全性
FIG['keizai.asym'] = grid(['', '逆選択（アドバース・セレクション）', 'モラルハザード'],
                          [['いつ', '取引の前', '取引の後'], ['見えないもの', '質（相手のタイプ）', '行動（注意や努力）'],
                           ['例', '中古車のレモン市場、リスクの高い人ほど入る保険', '加入後に防火の注意を怠る、経営者が自分の利益を優先する'],
                           ['対策', 'シグナリング、スクリーニング、第三者の認証、評判、強制加入の保険', '成果に応じた報酬、監視（モニタリング）、自己負担（免責）']],
                          [64, 150, 146], align=['l', 'l', 'l'], title='逆選択とモラルハザード', size=10.5)

FIG['keizai.lemon'] = _flow(['良い車（価値100）と\n悪い車（価値40）が\n半分ずつ', '質が見分けられない\nので、買い手は平均\n70しか払わない', ('良い車の売り手は\n売らずに去る', 'a'),
                             ('悪い車（レモン）\nばかりが残る', 'a')], 'レモン市場（アカロフ）の例', per_row=2, size=10.5, gapx=24)

FIG['keizai.sigscr'] = _lists([('シグナリング', 'b', ['情報を持つ側が、自分の質を示す行動をとる', '学歴が能力を示す（スペンス）', '品質保証の提供、ブランドへの投資']),
                               ('スクリーニング', 'c', ['情報を持たない側が、相手に選ばせる仕組みをつくる', '保険料と補償の組合せを複数示し、加入者に自分のリスクに合うものを選ばせる'])],
                              '逆選択への対策')

FIG['keizai.pa'] = _rowflow([('', None, [('依頼人\n（株主）', 'b'), '経営を任せる', ('代理人\n（経営者）', 'c'), ('自分の利益を\n優先しがち', 'a')]),
                             ('', None, [('対策', 'b'), '成果に応じた\n報酬', '監視\n（モニタリング）', '自己負担\n（免責）'], False)],
                            'プリンシパル＝エージェント問題（行動が観察できない）', lw=0, size=10.5)

# ------------------------------------------------ 1.7.2 ゲーム理論
FIG['keizai.pd'] = payoff(['協調', '裏切り'], ['協調', '裏切り'], [[(3, 3), (0, 5)], [(5, 0), (1, 1)]], '囚人のジレンマ',
                          note='丸＝相手の戦略ごとの最適反応（Aは赤、Bは緑）。両方に丸がついたマスがナッシュ均衡')

FIG['keizai.pdsteps'] = grid(['Bの戦略', 'Aの利得の比較', 'Aの最適反応'],
                             [['協調', '協調3 ＜ 裏切り5', '裏切り'], ['裏切り', '協調0 ＜ 裏切り1', '裏切り']],
                             [80, 160, 120], align=['c', 'c', 'c'], title='Aにとって「裏切り」は支配戦略（Bも同じ）', size=11.5, tcol={'裏切り': 'a'})

FIG['keizai.coord'] = payoff(['規格X', '規格Y'], ['規格X', '規格Y'], [[(2, 2), (0, 0)], [(0, 0), (1, 1)]], 'ナッシュ均衡が2つある例（規格の選択）',
                             note='（X, X）と（Y, Y）の両方がナッシュ均衡。（X, X）のほうが2人とも得だが、（Y, Y）からは1人だけでは抜け出せない')

FIG['keizai.repeat'] = grid(['繰り返しのしかた', '協調'],
                            [['無限に（終わりが分からずに）繰り返す', '将来の報復を恐れて、保たれることがある（しっぺ返し戦略）'],
                             ['終わりが決まった有限回', '最後の回から逆に考えると、保たれにくい']],
                            [150, 210], align=['l', 'l'], title='繰り返しゲーム', size=11)


def _tree():
    w, h = 360, 262
    o = []
    P0 = (40, 96)
    P1 = (160, 60)
    out0 = (300, 168)
    a1, a2 = (300, 30), (300, 98)
    def node(p, s, col):
        o.append('<circle cx="%s" cy="%s" r="7" style="fill:%s"/>' % (p[0], p[1], _c(col)))
        o.append(txt(p[0], p[1] - 13, s, 'middle', col, True, 10.5))
    def edge(p, q, s, chosen, col):
        o.append('<path d="M%s %sL%s %s" style="stroke:%s" stroke-width="%s" fill="none"%s/>' % (
            p[0], p[1], q[0], q[1], _c(col if chosen else 'line'), 3 if chosen else 1.4, '' if chosen else ' stroke-dasharray="5 4"'))
        mx, my = (p[0] + q[0]) / 2, (p[1] + q[1]) / 2
        o.append(txt(mx, my + (14 if q[1] > p[1] else -6), s, 'middle', col if chosen else 'main', chosen, 10.5))
    edge(P0, P1, '参入する', True, 'b')
    edge(P0, out0, '参入しない', False, 'b')
    edge(P1, a1, '受け入れる', True, 'c')
    edge(P1, a2, '価格競争', False, 'c')
    node(P0, '参入企業', 'b')
    node(P1, '既存企業', 'c')
    for (p, s, best) in ((a1, '（3, 5）', True), (a2, '（－2, 2）', False), (out0, '（0, 10）', False)):
        o.append(txt(p[0] + 4, p[1] + 4, s, 'start', 'a' if best else 'main', True, 11.5))
    o.append(txt(4, 206, '利得は（参入企業, 既存企業）。後ろから考えると、既存企業は', size=10.5))
    o.append(txt(4, 222, '参入されたら「受け入れる」（5＞2）。だから参入企業は参入（3＞0）', size=10.5))
    o.append(txt(4, 242, '「参入したら価格競争をするぞ」は、実行すると自分が損をする空脅し', size=10.5, bold=True, col='a'))
    return _svg(w, h, o, 'ゲームの木と後ろ向き帰納法（参入阻止の例）')


FIG['keizai.tree'] = _tree()

# ------------------------------------------------ 1.7.3 独占の弊害と寡占化の協調行動


def _mono():
    g = G(xmax=10.5, ymax=10.5, h=300, xlab='数量 Q', ylab='価格', pr=26, pb=76)
    g.area([(0, 10), (0, 6), (4, 6)], 'a', op=0.24, label='消費者\n余剰8', at=(1.3, 7.3), lcol='a', size=10)
    g.rect(0, 2, 4, 6, col='b', op=0.26, label='独占の利潤\n（生産者余剰）16', lcol='b', size=10)
    g.area([(4, 6), (4, 2), (8, 2)], 'sub', op=0.5, label='死荷重8', at=(5.2, 3.3), lcol='main', size=10)
    g.line([(0, 10), (10, 0)], 'a', label='D', at=(10, 0.4), dx=2)
    g.line([(0, 10), (5, 0)], 'a', dash=True, label='MR', at=(5, 0.4), dx=4)
    g.hl(2, 'c', x0=0, x1=10.4, label='MC＝2', at=(10.4, 2), anchor='end', dy=-8)
    g.dot(4, 6, 'main', label='独占', pos='e').guide(4, 6, xt='4', yt='6').dot(4, 2, 'main')
    g.dot(8, 2, 'c', label='完全競争', pos='n').guide(8, 2, xt='8', h=False)
    _below(g, [('MR＝MCの数量4で、需要曲線上の価格6をつける', 'main'), ('完全競争（P＝MC）なら数量8、価格2', 'c'), ('（D：P＝10－Q、MR＝10－2Q）', 'main')], 38)
    return g.svg('独占の価格と死荷重')


FIG['keizai.mono'] = _mono()

FIG['keizai.monotbl'] = grid(['', '独占', '完全競争'],
                             [['数量', '4', '8'], ['価格', '6', '2'], ['消費者余剰', '8', '32'], ['生産者余剰', '16', '0'], ['死荷重', '8', '0'], ['総余剰', '24', '32']],
                             [120, 120, 120], align=['l', 'c', 'c'], title='独占と完全競争の比較（上の図の例）', size=11.5, hl_rows=(4,))

FIG['keizai.lerner'] = eq([[('ラーナーの独占度', 'c'), '＝', ('（価格－限界費用）\n÷価格', None), '＝', ('1÷需要の\n価格弾力性', None)],
                           [('上の例', 'c'), '＝', ('（6－2）÷6\n≒0.67', None), '＝', ('1÷1.5\n（P＝6、Q＝4）', None)]], 'ラーナーの独占度', size=10.5)


def _trmax():
    g = G(xmax=10.5, ymax=28, h=232, xlab='数量 Q', ylab='総収入', pr=26)
    g.fn(lambda q: 10 * q - q * q, 0, 10, 'b', label='総収入 TR', at=(9.0, 13.5), anchor='start')
    g.dot(5, 25, 'b', label='TR最大（MR＝0、弾力性1）', pos='n').guide(5, 25, xt='5', h=False)
    g.dot(4, 24, 'a', label='利潤最大', pos='w').guide(4, 24, xt='4', h=False)
    g.text(5.3, 9.0, 'MCがプラスなら、利潤が最大の数量は\n総収入が最大の数量より少ない', 'middle', 'main', True, 10.5)
    return g.svg('総収入の最大と利潤の最大（P＝10－Q、MC＝2）')


FIG['keizai.trmax'] = _trmax()

FIG['keizai.pdisc'] = grid(['市場', '需要の価格弾力性', '価格'],
                           [['一般の利用者', '小さい（値上げしても買う）', '高い'], ['学生', '大きい（値上げで離れやすい）', '安い（学生割引）']],
                           [96, 170, 94], align=['l', 'l', 'c'], title='第3種の価格差別', size=11)

FIG['keizai.oligo'] = grid(['モデル', '内容', '結果'],
                           [['クールノー', '相手の生産量を前提に、生産量を同時に決める', '独占と完全競争の中間'], ['ベルトラン', '同質の財で価格を競う', '価格＝限界費用'],
                            ['シュタッケルベルク', '先導者が先に生産量を決め、追随者が見て決める', '先導者が有利'], ['屈折需要曲線', '値上げには追随せず、値下げには追随すると予想', '価格が硬直的'],
                            ['カルテル', '協調して生産量を絞る', '抜け駆けの誘因で不安定'], ['プライス・リーダーシップ', '有力な企業が価格を決め、他社が追随する', '']],
                           [100, 160, 100], align=['l', 'l', 'l'], title='寡占のモデル', size=10.5)


def _kinked():
    g = G(xmax=10, ymax=9, h=262, xlab='数量 Q', ylab='価格・費用', pr=26)
    g.line([(0, 7.5), (5, 6)], 'a', sw=2.4)
    g.line([(5, 6), (10, 2)], 'a', sw=2.4, label='D', at=(10, 2.2), dx=2)
    g.line([(0, 7.5), (5, 4.5)], 'a', dash=True)
    g.seg(5, 4.5, 5, 2, 'a', dash='3 2', sw=2.2, op=1)
    g.line([(5, 2), (6.25, 0)], 'a', dash=True, label='MR', at=(6.25, 0.4), dx=3)
    g.fn(lambda q: 0.6 + 0.4 * q, 1, 9.5, 'b', label='MC1', at=(9.5, 0.6 + 3.8), dx=2)
    g.fn(lambda q: 1.8 + 0.4 * q, 1, 9.5, 'b', dash='6 3', label='MC2', at=(9.5, 1.8 + 3.8), dx=2)
    g.dot(5, 6, 'main', label='屈折点', pos='ne').guide(5, 6, yt='P*', bold=True)
    g.text(5.2, 8.4, 'MRが途切れる部分をMCが通る間は\n費用が変わっても価格は変わらない', 'middle', 'main', True, 10.5)
    return g.svg('屈折需要曲線と価格の硬直性')


FIG['keizai.kinked'] = _kinked()

# ------------------------------------------------ 1.7.4 製品差別化と独占的競争
ACm = lambda q: 3 + 0.12 * (q - 7) ** 2
MCm = lambda q: 3 + 0.12 * (q - 7) * (3 * q - 7)


def _mcomp():
    g = G(xmax=11, ymax=9, h=300, xlab='数量 Q', ylab='価格・費用', pr=26, pb=58)
    g.fn(ACm, 1.2, 11, 'b', label='AC', at=(11, ACm(11)), dx=2)
    g.fn(MCm, 1.6, 9.0, 'c', label='MC', at=(9.0, MCm(9.0)), dx=2)
    g.line([(0, 6.96), (9.6, 0.05)], 'a', label='D', at=(9.6, 0.4), dx=2)
    g.line([(0, 6.96), (4.8, 0.05)], 'a', dash=True, label='MR', at=(3.2, 1.5), anchor='end')
    g.dot(4, ACm(4), 'main', label='E（D とACが接する）', pos='ne').guide(4, ACm(4), xt='4', yt='P')
    g.dot(4, 1.2, 'c').dot(7, 3, 'b').guide(7, 3, xt='7', h=False)
    g.hspan(0.6, 4, 7, '過剰設備', 'b', dy=-9)
    _below(g, [('長期均衡：P＝AC（利潤ゼロ）、P＞MC', 'main'), ('ACの最低点（7）より少ない量で生産する', 'b')], 34)
    return g.svg('独占的競争の長期均衡')


FIG['keizai.mcomp'] = _mcomp()

FIG['keizai.mktcmp'] = grid(['', '完全競争', '独占的競争', '独占'],
                            [['企業の数', '多数', '多数', '1社'], ['製品', '同質', '差別化', '－'], ['参入・退出', '自由', '自由', '困難'],
                             ['長期の利潤', 'ゼロ', 'ゼロ', '残りうる'], ['価格と限界費用', 'P＝MC', 'P＞MC', 'P＞MC'], ['長期の生産量', 'ACの最低点', 'ACの最低点より少ない', '－']],
                            [96, 76, 112, 76], align=['l', 'c', 'c', 'c'], title='市場の形の比較', size=10.5, tcol={'ACの最低点より少ない': 'b'})


def _diffslope():
    g = G(xmax=10, ymax=10, h=212, xlab='数量', ylab='価格', pr=24)
    g.line([(0, 7.5), (10, 2.5)], 'sub', label='差別化の前', at=(10, 2.5), anchor='end', dy=-12, lcol='main')
    g.line([(2.5, 10), (7.5, 0)], 'a', label='差別化の後', at=(7.5, 0.4), dx=4)
    g.dot(5, 5, 'main')
    g.text(9.9, 8.4, '傾きが急になり\n（弾力性が小さくなり）\n値上げしても\n顧客が離れにくい', 'end', 'a', True, 10.5)
    return g.svg('製品差別化と需要曲線')


FIG['keizai.diffslope'] = _diffslope()

# ------------------------------------------------ 1.7.5 規模の経済性・範囲の経済性
FIG['keizai.econ5'] = grid(['名前', '何が増えると', '起きること'],
                           [['規模の経済', '一定期間の生産規模', '長期平均費用が下がる（固定費の分散、分業と専門化、大量購入）'],
                            ['範囲の経済', '一緒に生産する財の種類', '総費用が別々に作るより小さい（多角化の根拠）'], ['経験の経済', '累積の生産量', '習熟で単位当たりの費用が下がる（経験曲線）'],
                            ['集積の経済', '同じ地域の関連企業', '部品・人材・情報が集まり、費用が下がる'], ['ネットワーク外部性', '利用者の数', '財やサービスの価値が高まり、1社や1規格に集中しやすい']],
                           [92, 100, 168], align=['l', 'l', 'l'], title='経済性の種類', size=10.5)


def _mes():
    g = G(xmax=12, ymax=10, h=232, xlab='生産規模', ylab='長期平均費用', pr=24)
    f = lambda q: 3 + 0.35 * (4.5 - q) ** 2 if q < 4.5 else (3 if q < 8 else 3 + 0.25 * (q - 8) ** 2)
    g.fn(f, 0.4, 12, 'a', n=200, sw=2.4)
    g.dot(4.5, 3, 'a', label='最小効率規模', pos='s')
    g.text(2.0, 8.6, '規模の経済', 'middle', 'b', True, 10.5).text(10.6, 8.6, '規模の不経済', 'middle', 'a', True, 10.5)
    g.arrow(0.8, 7.8, 3.4, 7.8, 'b', sw=1.6, head=5).arrow(9.4, 7.8, 11.6, 7.8, 'a', sw=1.6, head=5)
    return g.svg('長期平均費用と最小効率規模')


FIG['keizai.mes'] = _mes()

FIG['keizai.scope'] = eq([[('C（X, Y）\n一緒に生産 90', 'b'), '＜', ('C（X, 0）\nXだけ 60', None), '＋', ('C（0, Y）\nYだけ 50', None)]], '範囲の経済（数値例）', size=10.5)


def _expc():
    g = G(xmax=17, ymax=110, h=232, xlab='累積の生産量', ylab='単位当たりの費用', pr=16, pb=40, xlpos='low')
    f = lambda n: 100 * 0.8 ** math.log(n, 2)
    g.fn(f, 1, 17, 'a', n=100)
    for n in (1, 2, 4, 8, 16):
        g.dot(n, f(n), 'a', label='%g' % round(f(n), 1), pos='ne', size=10)
        g.xt(n, str(n))
    g.text(9.0, 90, '累積の生産量が2倍になるごとに\n費用が20％下がる例（80％の経験曲線）', 'middle', 'main', True, 10.5)
    return g.svg('経験曲線')


FIG['keizai.expc'] = _expc()

# ------------------------------------------------ 1.8.1 公正性・公平性の概念


def _swf():
    g1 = G(xmax=10, ymax=10, w=176, h=206, ox=0, pl=22, pr=12, xlab='Aの効用', ylab='B', cap='ベンサム（功利主義）', ccol='b')
    g2 = G(xmax=10, ymax=10, w=176, h=206, ox=184, pl=22, pr=12, xlab='Aの効用', ylab='B', cap='ロールズ（マキシミン）', ccol='a')
    for k in (4, 7, 10):
        g1.line([(0, k), (k, 0)], 'b', sw=1.8)
    for k in (3, 5, 7):
        g2.line([(k, 10), (k, k), (10, k)], 'a', sw=1.8)
    g2.line([(0, 0), (10, 10)], 'sub', dash='4 3', sw=1)
    ex = [txt(4, 222, '効用の合計だけを見る（直線）', size=10.5, bold=True, col='b'), txt(188, 222, '最も恵まれない人を見る（L字型）', size=10.5, bold=True, col='a')]
    return panels([g1, g2], '社会的無差別曲線', h=228, extra=ex)


FIG['keizai.swf'] = _swf()

FIG['keizai.fair'] = grid(['考え方', '内容'],
                          [['水平的公平', '同じ経済力の人は、同じように扱う（同じ所得なら同じ税負担）'], ['垂直的公平', '経済力の大きい人は、より多く負担する（累進課税）'],
                           ['貢献に応じた分配', '生産性の高い人の所得が高くなる。働けない人の救済は難しい'], ['必要に応じた分配', '必要の大きい人に多く分配する'], ['平等な分配', '全員に同じように分配する']],
                          [112, 248], align=['l', 'l'], title='公平・公正の考え方', size=10.5, hl_rows=(0, 1))


def _lorenz():
    g = G(xmax=100, ymax=100, w=360, h=290, pl=44, pr=90, pb=38, xlab='人数の累積（％）', ylab='所得の累積（％）', xlpos='low')
    f = lambda x: 100 * (x / 100.0) ** 2.4
    g.area([(x, x) for x in range(0, 101, 5)] + [(x, f(x)) for x in range(100, -1, -5)], 'a', op=0.28)
    g.line([(0, 0), (100, 100)], 'b', label='均等分布線\n（45度線）', at=(100, 100), dx=4, lsize=10.5)
    g.fn(f, 0, 100, 'a', label='ローレンツ曲線', at=(100, 40), dx=4, lsize=10.5)
    g.line([(0, 0), (100, 0), (100, 100)], 'main', dash='5 4', sw=1.4)
    g.text(102, 12, '完全に不平等\nなときの線', 'start', 'main', True, 10)
    g.text(58, 40, '弓形の面積\n×2＝ジニ係数', 'middle', 'a', True, 10.5)
    g.xt(50, '50').xt(100, '100').yt(50, '50').yt(100, '100')
    return g.svg('ローレンツ曲線とジニ係数')


FIG['keizai.lorenz'] = _lorenz()

FIG['keizai.ginijp'] = hbars([('当初所得', 0.5855, 'a'), ('再分配所得（税と社会保障の後）', 0.3825, 'b')], '日本のジニ係数（所得再分配調査、令和5年調査）', lw=150, lo=0, hi=0.7,
                             fmt=lambda v: '%.4f' % v, vw=56, note='再分配による改善度は34.7％。当初所得のジニ係数は、高齢化などで上昇傾向')

# ------------------------------------------------ 1.8.2 生産要素市場と生産要素報酬


def _labmkt():
    g = G(xmax=10, ymax=10, h=290, xlab='雇用量 L', ylab='賃金 W', pr=24, pb=62)
    g.area([(0, 10), (0, 5), (5, 5)], 'c', op=0.26, label='企業の余剰', at=(1.6, 6.8), lcol='c', size=10.5)
    g.area([(0, 0), (0, 5), (5, 5)], 'b', op=0.26, label='労働者の\n余剰', at=(1.5, 3.4), lcol='b', size=10.5)
    g.line([(0, 10), (10, 0)], 'a', label='労働需要（限界生産物価値）', at=(10, 0.4), anchor='end', dy=-12)
    g.line([(0, 0), (10, 10)], 'b', label='労働供給', at=(9.6, 9.6), anchor='end', dy=-6)
    g.dot(5, 5, 'main', label='E', pos='e').guide(5, 5, xt='L*', yt='W*', bold=True)
    _below(g, [('賃金総額（企業の労働費用）＝W*×L*の長方形', 'main'), ('労働供給曲線の下の面積＝働くことの機会費用の合計', 'main')], 34)
    return g.svg('労働市場の均衡と余剰')


FIG['keizai.labmkt'] = _labmkt()


def _minw():
    g = G(xmax=10, ymax=10, h=262, xlab='雇用量 L', ylab='賃金 W', pr=24)
    g.area([(3, 7), (5, 5), (3, 3)], 'sub', op=0.5)
    g.line([(0, 10), (10, 0)], 'a', label='労働需要', at=(10, 0.4), anchor='end', dy=-12)
    g.line([(0, 0), (10, 10)], 'b', label='労働供給', at=(9.6, 9.6), anchor='end', dy=-6)
    g.hl(7, 'c', x0=0, x1=9.6, sw=1.8, label='最低賃金', at=(9.6, 7), anchor='end', dy=-8)
    g.hspan(7, 3, 7, '失業（超過供給）', 'c', dy=12)
    g.dot(5, 5, 'main', label='E', pos='e')
    g.guide(3, 7, xt='雇用', h=False)
    g.text(1.4, 2.0, '灰色の三角形＝死荷重', 'start', 'main', True, 10.5)
    return g.svg('競争的な労働市場の最低賃金')


FIG['keizai.minw'] = _minw()


def _monops():
    g = G(xmax=10, ymax=12, h=300, xlab='雇用量 L', ylab='賃金・費用', pr=26, pb=58)
    g.area([(4, 8), (6, 6), (4, 4)], 'sub', op=0.45)
    g.line([(0, 12), (10, 2)], 'a', label='限界生産物価値', at=(10, 2.2), anchor='end', dy=-10)
    g.line([(0, 0), (10, 10)], 'b', label='労働供給', at=(10, 10), anchor='end', dy=12)
    g.line([(0, 0), (6, 12)], 'c', label='労働の限界費用', at=(5.6, 11.6), anchor='end')
    g.dot(4, 8, 'c').dot(4, 4, 'c', label='買い手独占', pos='se').guide(4, 4, xt='4', yt='4')
    g.dot(6, 6, 'main', label='完全競争', pos='e').guide(6, 6, xt='6', yt='6')
    g.hl(5, 'a', x0=0, x1=5, dash='4 3', sw=1.4)
    g.dot(5, 5, 'a').guide(5, 5, xt='5', h=False)
    g.yt(5, '最低5', 'a', True)
    _below(g, [('買い手独占：雇用4、賃金4（完全競争より低い。灰色は死荷重）', 'c'), ('最低賃金5を定めると、雇用は5に増える', 'a')], 34)
    return g.svg('買い手独占（モノプソニー）と最低賃金')


FIG['keizai.monops'] = _monops()


def _leisure():
    g = G(xmax=24, ymax=120, h=346, xlab='余暇（時間）', ylab='所得（消費）', pr=22, pb=112, xlpos='low')
    U0 = 3.0 / 32
    U1 = 1.0 / 18 + 1.0 / 54
    g.line([(0, 96), (24, 0)], 'main', sw=1.8)
    g.line([(24 - 120 / 9.0, 120), (24, 0)], 'a', sw=2)
    lg = 4.0 / (3 * U0)
    g.line([(lg - (120 - 3 * lg) / 9.0, 120), (lg + 3 * lg / 9.0, 0)], 'c', dash='5 4', sw=1.4)
    g.fn(lambda l: 1.0 / (U0 - 1.0 / l), 11.4, 24, 'b', sw=1.6)
    g.fn(lambda l: 1.0 / (U1 - 1.0 / l), 14.9, 24, 'b', dash='6 3', sw=1.6)
    g.dot(16, 32, 'main', label='E', pos='sw').dot(lg, 3 * lg, 'c', label='G', pos='w').dot(18, 54, 'a', label='F', pos='ne')
    g.xt(24, '24')
    for x, s in ((lg, '14.2'), (16, '16'), (18, '18')):
        g.seg(x, 0, x, 120, 'main', dash='2 3', op=0.35)
        g.xt(x, s, size=9.5)
    _below(g, [('黒＝賃金4の予算線、赤＝賃金9、点線＝補助線（傾き9）', 'main'), ('E→G：代替効果（余暇が減り、働く時間が増える）', 'c'),
               ('G→F：所得効果（余暇が増え、働く時間が減る）', 'a'), ('この例では所得効果が大きく、余暇は16→18時間に増える', 'main')], 46)
    return g.svg('賃金の上昇と労働供給（横軸に余暇）')


FIG['keizai.leisure'] = _leisure()


def _backbend():
    g = G(xmax=10, ymax=10, h=212, xlab='労働時間', ylab='賃金', pr=24)
    pts = [(1.0, 0.8), (3.0, 2.6), (5.0, 4.6), (6.4, 6.4), (6.9, 7.6), (6.6, 8.6), (5.6, 9.6)]
    g.line(pts, 'b', sw=2.4, label='労働供給', at=(5.6, 9.6), anchor='end', dx=-6)
    g.text(5.6, 3.0, '代替効果が大きい\n賃金↑で労働↑', 'start', 'b', True, 10.5)
    g.text(7.2, 8.2, '所得効果が大きい\n賃金↑で労働↓', 'start', 'a', True, 10.5)
    return g.svg('後方屈折型の労働供給曲線')


FIG['keizai.backbend'] = _backbend()

FIG['keizai.labshift'] = grid(['シフト', '要因', '均衡賃金'],
                              [['労働需要が右へ', '生産物の価格の上昇、資本の増加、労働と補完的な技術の向上（限界生産物が増える）', '上がる'],
                               ['労働供給が右へ', '生産年齢人口の増加、移民の受け入れ、労働の限界不効用の低下', '下がる']],
                              [92, 208, 60], align=['l', 'l', 'c'], title='労働市場の均衡の変化', size=10.5, tcol={'上がる': 'b', '下がる': 'a'})


def _rent():
    g = G(xmax=10, ymax=10, h=212, xlab='土地の量', ylab='地代', pr=24)
    g.rect(0, 0, 5, 6, col='c', op=0.3, label='すべて経済的レント', lcol='c', size=10.5)
    g.vl(5, 'b', label='供給（固定）', at=(5.3, 9.4))
    g.line([(1, 10), (9, 2)], 'a', label='需要', at=(9, 2.2), dx=2)
    g.dot(5, 6, 'main').guide(5, 6, yt='地代')
    return g.svg('供給が固定的な土地の地代＝経済的レント')


FIG['keizai.rent'] = _rent()

# ------------------------------------------------ 1.8.3 所得再分配と税制・補助金


def _avgtax():
    g = G(xmax=1000, ymax=24, h=232, xlab='所得', ylab='税率（％）', pr=20, pb=40, xlpos='low')
    g.hl(20, 'a', dash='5 4', sw=1.6, label='限界税率20％', at=(1000, 20), anchor='end', dy=-8)
    g.fn(lambda y: 20 * (1 - 100.0 / y) if y > 100 else 0, 100, 1000, 'b', label='平均税率', at=(1000, 17.6), anchor='end', dy=12)
    g.line([(0, 0), (100, 0)], 'b', sw=2.2)
    for y in (200, 400, 800):
        v = 20 * (1 - 100.0 / y)
        g.dot(y, v, 'b', label='%g％' % v, pos='nw', size=10)
        g.xt(y, str(y))
    g.xt(100, '100')
    return g.svg('基礎控除があると平均税率は所得とともに上がる（税＝0.2×（所得－100））')


FIG['keizai.avgtax'] = _avgtax()

FIG['keizai.deduct'] = grid(['所得', '控除100の税', '控除150の税', '減税額'],
                            [['300', '0.2×200＝40', '0.2×150＝30', '10'], ['1,000', '0.2×900＝180', '0.2×850＝170', '10']],
                            [60, 112, 112, 76], align=['c', 'c', 'c', 'c'], title='基礎控除の引上げ（税率20％）：減税額は所得に関係なく同じ', size=10.5,
                            tcol={'10': 'b'})


def _inkind():
    g = G(xmax=14, ymax=12, h=236, xlab='給付される財（教育など）', ylab='他の財', pr=16)
    g.line([(0, 10), (10, 0)], 'main', sw=1.8, label='元の予算線', at=(6.0, 3.0), anchor='end', dy=4)
    g.line([(0, 10), (3, 10), (13, 0)], 'a', sw=2.4, label='無償の給付後', at=(9.0, 4.6), anchor='start')
    g.hspan(10.6, 0, 3, '無償分', 'a', dy=-9)
    g.text(5.0, 11.4, '水平に延び、元の予算線と平行に下がる折れ線', 'start', 'main', True, 10)
    return g.svg('現物給付の予算線')


FIG['keizai.inkind'] = _inkind()


def _nit():
    g = G(xmax=1000, ymax=1000, h=262, xlab='所得 Y', ylab='可処分所得', pr=24)
    g.area([(0, 0), (0, 100), (500, 500)], 'b', op=0.24, label='純給付', at=(130, 200), lcol='b', size=10.5)
    g.area([(500, 500), (1000, 1000), (1000, 900)], 'a', op=0.24)
    g.line([(0, 0), (1000, 1000)], 'sub', dash='4 3', sw=1.4, label='税も給付もない場合', at=(980, 1000), anchor='end', dy=-2, lcol='main', lsize=10.5)
    g.line([(0, 100), (1000, 900)], 'a', label='Y×（1－0.2）＋100', at=(1000, 900), anchor='end', dy=14)
    g.dot(0, 100, 'a', label='100', pos='e').dot(500, 500, 'main', label='所得500で一致（A÷t）', pos='nw').dot(800, 740, 'a')
    g.text(930, 760, '純負担', 'middle', 'a', True, 10.5)
    return g.svg('負の所得税（税率t＝0.2、定額給付A＝100）')


FIG['keizai.nit'] = _nit()

FIG['keizai.dwlrate'] = grid(['1単位当たりの税', '取引量', '死荷重', '税が1のときとの比'],
                             [['1', '4.5', '1×0.5÷2＝0.25', '1倍'], ['2', '4', '2×1÷2＝1', '4倍'], ['4', '3', '4×2÷2＝4', '16倍']],
                             [96, 64, 116, 84], align=['c', 'c', 'c', 'c'], title='超過負担は税率のほぼ2乗に比例（D：P＝10－Q、S：P＝Q）', size=10.5,
                             tcol={'4倍': 'a', '16倍': 'a'})

FIG['keizai.taxeff'] = grid(['税', '効率への影響'],
                            [['一括税（定額税）', '行動で税額が変わらないので、超過負担（死荷重）が生じない'], ['物品税・所得税', '価格や行動を変えるので、超過負担が生じる。弾力性が大きい財ほど大きい'],
                             ['ラムゼイ・ルール', '効率を重視すると、価格弾力性の小さい財ほど高い税率にする（必需品に重くなり、公平の面で問題）']],
                            [100, 260], align=['l', 'l'], title='課税と効率', size=10.5, tcol={'一括税（定額税）': 'b'})
