# 財務・会計の図表（1.8 投資の評価、1.9 ポートフォリオと資本市場）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import grid, chart, waterfall, ARROW, R, T, L, _svg, _c
from econfig import fig

FIG = {}

# ------------------------------------------------ 1.8.1 貨幣の時間価値


def _tv():
    # 割引率10％の将来価値と現在価値
    w, h = 360, 150
    xs = [40, 180, 320]
    y = 78
    o = [ARROW([(10, y), (350, y)], col='main', sw=1.5, head=6)]
    for x, t, v in zip(xs, ['今日', '1年後', '2年後'], ['100', '110', '121']):
        o.append('<circle cx="%s" cy="%s" r="4" style="fill:currentColor"/>' % (x, y))
        o.append(T(x, y + 20, t, 'middle', size=11))
        o.append(T(x, y - 10, v, 'middle', size=13, bold=True))
    for a, b in [(0, 1), (1, 2)]:
        xa, xb = xs[a] + 14, xs[b] - 14
        o.append('<path d="M%s %s Q%s %s %s %s" fill="none" style="stroke:var(--good)" stroke-width="1.6"/>' % (xa, y - 30, (xa + xb) / 2, y - 62, xb, y - 30))
        o.append(ARROW([(xb - 6, y - 36), (xb, y - 30)], col='b', sw=1.6, head=6))
        o.append(T((xa + xb) / 2, y - 50, '×1.1', 'middle', size=11, col='b', bold=True))
        o.append('<path d="M%s %s Q%s %s %s %s" fill="none" style="stroke:var(--drop)" stroke-width="1.6"/>' % (xb, y + 30, (xa + xb) / 2, y + 62, xa, y + 30))
        o.append(ARROW([(xa + 6, y + 36), (xa, y + 30)], col='a', sw=1.6, head=6))
        o.append(T((xa + xb) / 2, y + 58, '÷1.1', 'middle', size=11, col='a', bold=True))
    return _svg(w, h, o, '将来価値と現在価値（割引率10％）')


FIG['zaimu.tv'] = _tv()


def _annuity():
    # 毎年100を3年間受け取る場合の現在価値（年ごとに色を合わせる）
    w, h = 360, 222
    yb = 172
    xs = [62, 170, 245, 320]
    cols = ['b', 'c', 'a']
    pv = [90.91, 82.64, 75.13]
    o = [L(10, yb, 350, yb, col='main', sw=1.3)]
    for i, x in enumerate(xs[1:]):
        o.append(R(x - 18, yb - 100, 36, 100, fill=cols[i], stroke=cols[i], op=0.25))
        o.append(T(x, yb - 106, '100', 'middle', size=11, bold=True))
        o.append(T(x, yb + 16, '%d年後' % (i + 1), 'middle', size=11))
        o.append(T(x, yb - 40, '÷1.1' + ['', '²', '³'][i], 'middle', size=10.5))
    y = yb
    for i, v in enumerate(pv):
        hh = v * 0.55
        y -= hh
        o.append(R(xs[0] - 22, y, 44, hh, fill=cols[i], stroke=cols[i], op=0.3))
        o.append(T(xs[0], y + hh / 2 + 4, '%.1f' % v, 'middle', size=10.5, bold=True))
    o.append(T(xs[0], y - 6, '合計248.7', 'middle', size=11.5, bold=True))
    o.append(T(xs[0], yb + 16, '今日（現在価値）', 'middle', size=11))
    o.append(ARROW([(xs[1] - 24, yb - 60), (xs[0] + 28, yb - 60)], col='main', sw=1.2, head=5, dash='4 3'))
    o.append(T((xs[0] + xs[1]) / 2 + 2, yb - 66, '割り引く', 'middle', size=10))
    return _svg(w, h, o, '年金の現在価値（割引率10％）')


FIG['zaimu.annuity'] = _annuity()
FIG['zaimu.pv_formulas'] = grid(['受け取り方', '現在価値'],
                                [['n年後に1回だけCを受け取る', 'C÷（1＋r）^n（＝C×複利現価係数）'], ['n年間、毎年Cを受け取る', 'C×年金現価係数'],
                                 ['永久に毎年Cを受け取る', 'C÷r'], ['1年後のCから毎年g％ずつ成長して永久に続く', 'C÷（r－g）（r＞gのとき）']],
                                [170, 190], align=['l', 'l'], title='現在価値の求め方（r：割引率）', size=10.5)
FIG['zaimu.taxcf'] = waterfall([('売上による収入', 500, 'start'), ('現金支出の費用', -300, 'delta'), ('法人税\n（500－300－100）×30％', -30, 'delta'),
                                ('税引後CF', None, 'total')], title='税引後キャッシュ・フロー', lw=150)
FIG['zaimu.taxcf2'] = grid(['求め方', '計算'],
                           [['税引後利益＋減価償却費', '（500－300－100）×0.7＋100＝70＋100＝170'],
                            ['現金収支×（1－税率）＋タックス・シールド', '（500－300）×0.7＋100×0.3＝140＋30＝170']],
                           [150, 210], align=['l', 'l'], title='2つの求め方（同じ結果）', size=10.5)
FIG['zaimu.cf_rules'] = grid(['項目', 'キャッシュ・フローでの扱い'],
                             [['埋没原価（すでに支出した調査費など）', '含めない'], ['機会原価（使う土地を売れば得られた収入など）', '含める（マイナス）'],
                              ['運転資本の増加', 'マイナス（終了時の回収はプラス）'], ['既存製品の売上の減少（カニバリゼーション）', '差し引く'],
                              ['設備の取替えで売る旧設備の売却収入', 'プラス'], ['支払利息', '含めない（割引率で考慮する）'],
                              ['減価償却費', '支出ではない（節税効果だけを考える）']],
                             [200, 160], align=['l', 'l'], title='投資のキャッシュ・フローに含めるもの', size=10.5,
                             tcol={'含めない': 'a', '含めない（割引率で考慮する）': 'a'})


def _bond_price(y):
    return 4 / (1 + y / 100) + 104 / (1 + y / 100) ** 2


FIG['zaimu.bond'] = chart([([(y / 2, _bond_price(y / 2)) for y in range(0, 17)], 'b', False), ([(0, 100), (8, 100)], 'sub', True)],
                          0, 8.4, 90, 110, xlab='利回り（％）', ylab='債券の価格',
                          labels=[(4.3, 102.7, '利回り＝表面利率4％', 'start'), (4.3, 101.2, '→ 価格は額面100', 'start'), (2.2, 105.3, '利回り2％：103.9', 'start', 'b')],
                          dots=[(4, 100, 'main'), (2, _bond_price(2), 'b')], xticks=[(0, '0'), (2, '2'), (4, '4'), (6, '6'), (8, '8')],
                          yticks=[(100, '100'), (95, '95'), (105, '105')], w=360, h=220, title='利付債の価格と利回り（表面利率4％、残り2年）', zero=False)

# ------------------------------------------------ 1.8.2 投資評価基準
FIG['zaimu.npv_wf'] = waterfall([('投資額', -1000, 'start'), ('1年後400の現在価値', 363.64, 'delta'), ('2年後400の現在価値', 330.58, 'delta'),
                                 ('3年後400の現在価値', 300.53, 'delta'), ('NPV', None, 'total')], title='NPVの計算（割引率10％）', lw=140)


def _npv(r):
    return 400 * (1 - (1 + r) ** -3) / r - 1000 if r else 200.0


FIG['zaimu.npv_prof'] = chart([([(x / 2, _npv(x / 200)) for x in range(0, 41)], 'a', False), ([(0, 0), (20, 0)], 'sub', False)],
                              0, 20, -200, 220, xlab='割引率（％）', ylab='NPV',
                              labels=[(9.3, -40, 'IRR 約9.7％', 'end', 'a'), (10.4, 160, '資本コスト10％', 'start'), (3.0, 60, 'NPV＞0', 'start', 'b'), (13, -165, 'NPV＜0', 'start', 'a')],
                              vlines=[(10, '')], dots=[(9.7, 0, 'a'), (10, _npv(0.10), 'main')], xticks=[(0, '0'), (5, '5'), (10, '10'), (15, '15'), (20, '20')],
                              yticks=[(200, '200'), (-200, '－200')], w=360, h=230, title='割引率とNPV（NPVプロファイル）')
FIG['zaimu.irr_af'] = grid(['割引率', '3年の年金現価係数'],
                           [['8％', '2.577'], ['9％', '2.531'], ['（IRR）', '2.500'], ['10％', '2.487'], ['11％', '2.444']],
                           [180, 180], align=['c', 'c'], title='係数表からIRRの範囲を読む', size=11, hl_rows=(2,))
FIG['zaimu.methods'] = grid(['方法', '採用の基準', '時間価値'],
                            [['回収期間法', '回収期間が短い案', '考えない'], ['会計的投資利益率法', '利益率が高い案', '考えない'], ['正味現在価値法（NPV）', 'NPV＞0（排他的な案はNPVが大きい案）', '考える'],
                             ['内部収益率法（IRR）', 'IRR＞資本コスト', '考える'], ['収益性指数法（PI）', 'PI＞1', '考える']],
                            [126, 158, 76], align=['l', 'l', 'c'], title='投資評価の方法', size=10.5, tcol={'考えない': 'a', '考える': 'b'})
FIG['zaimu.mutual'] = chart([([(x, 1200 / (1 + x / 100) - 1000) for x in range(0, 36)], 'a', False), ([(x, 130 / (1 + x / 100) - 100) for x in range(0, 36)], 'b', False),
                             ([(0, 0), (35, 0)], 'sub', False)],
                            0, 35, -150, 220, xlab='割引率（％）', ylab='NPV',
                            labels=[(11.5, 120, 'A案（投資1,000）', 'start', 'a'), (21, 40, 'B案（投資100）', 'start', 'b'), (19.5, -30, 'IRR 20％', 'end', 'a'),
                                    (30, -30, 'IRR 30％', 'middle', 'b'), (11, -110, '資本コスト10％', 'start')],
                            vlines=[(10, '')], dots=[(20, 0, 'a'), (30, 0, 'b'), (10, 1200 / 1.1 - 1000, 'a'), (10, 130 / 1.1 - 100, 'b')],
                            xticks=[(0, '0'), (10, '10'), (20, '20'), (30, '30')], yticks=[(100, '100'), (200, '200')], w=360, h=240,
                            title='排他的な2案のNPVとIRR')

# ------------------------------------------------ 1.8.3 不確実性下の投資決定


def _dectree():
    # 投資するかのデシジョン・ツリー
    w, h = 360, 176
    o = []
    o.append(R(6, 72, 22, 22, fill='sheet', stroke='main', sw=1.4))
    o.append(T(17, 112, '決定', 'middle', size=10))
    o.append(L(28, 83, 110, 40, col='main', sw=1.3))
    o.append(L(28, 83, 110, 140, col='main', sw=1.3))
    o.append(T(62, 50, '投資する', 'middle', size=11, bold=True))
    o.append(T(62, 132, '投資しない', 'middle', size=11, bold=True))
    o.append('<circle cx="122" cy="40" r="11" style="fill:var(--sheet);stroke:currentColor" stroke-width="1.4"/>')
    o.append(T(122, 64, '期待値180', 'middle', size=10.5, bold=True, col='b'))
    o.append(L(133, 40, 230, 14, col='main', sw=1.2))
    o.append(L(133, 40, 230, 72, col='main', sw=1.2))
    o.append(T(182, 18, '好況 60％', 'middle', size=10.5))
    o.append(T(182, 70, '不況 40％', 'middle', size=10.5))
    o.append(T(236, 18, 'NPV ＋500', size=11.5, bold=True, col='b'))
    o.append(T(236, 76, 'NPV －300', size=11.5, bold=True, col='a'))
    o.append(T(118, 144, 'NPV 0', size=11.5, bold=True))
    o.append(T(6, 170, '期待値：500×0.6＋（－300）×0.4＝180＞0 → 投資する', size=10.5, bold=True))
    return _svg(w, h, o, 'デシジョン・ツリー')


FIG['zaimu.dectree'] = _dectree()
FIG['zaimu.risk_methods'] = grid(['方法', 'リスクの扱い方'],
                                 [['リスク調整割引率法', 'リスクの高い投資ほど、高い割引率で割り引く（分母で調整）'],
                                  ['確実性等価法', '不確実なCFを、同じ価値の確実な額に直し（分子で調整）、無リスク利子率で割り引く'],
                                  ['感度分析', '前提を1つずつ変えて、NPVの変化を調べる'], ['シナリオ分析', '楽観・標準・悲観など、複数の前提をまとめて変える'],
                                  ['シミュレーション', '前提の値を確率分布から多数回取り出し、NPVの分布を求める（モンテカルロ法）'],
                                  ['デシジョン・ツリー', '将来の意思決定（撤退・拡張など）と不確実な事象を枝分かれで表し、後ろの時点から順に、期待値で最適な選択を決める']],
                                 [112, 248], align=['l', 'l'], title='リスクを考える方法', size=10.5, hl_rows=(0, 1))
FIG['zaimu.realopt'] = grid(['状況', '撤退できない場合', '撤退できる場合'],
                            [['好況（50％）', '180', '180'], ['不況（50％）', '40', '70（設備を売って撤退）'], ['期待値', '110', '125'],
                             ['NPV（投資額100）', '10', '25']],
                            [104, 112, 144], align=['l', 'r', 'r'], title='撤退のオプションの価値（金額は現在価値）', size=10.5, hl_rows=(3,))

# ------------------------------------------------ 1.9.1 ポートフォリオ理論


def _sd(wa, rho):
    return math.sqrt(400 * wa * wa + 100 * (1 - wa) ** 2 + 2 * wa * (1 - wa) * rho * 200)


FIG['zaimu.port_tbl'] = grid(['相関係数', 'A・Bに半分ずつのときの標準偏差'],
                             [['＋1', '15％（加重平均と同じ。分散投資の効果なし）'], ['0', '約11.2％（分散＝0.25×400＋0.25×100＝125）'], ['－1', '5％（組み合わせ方によってはゼロにできる）']],
                             [80, 280], align=['c', 'l'], title='相関係数と分散投資の効果（期待収益率はどれも7％）', size=10.5)
FIG['zaimu.port_curve'] = chart([([(10, 4), (20, 10)], 'sub', True),
                                 ([(_sd(k / 40, 0), 4 + 6 * k / 40) for k in range(0, 41)], 'b', False),
                                 ([(10, 4), (0, 6), (20, 10)], 'a', False)],
                                0, 22, 3, 11, xlab='標準偏差（％）', ylab='期待収益率（％）',
                                labels=[(20.3, 10, 'A', 'start'), (10.3, 3.6, 'B', 'start'), (16.5, 7.3, 'ρ＝＋1', 'start', 'sub'), (9.2, 6.7, 'ρ＝0', 'end', 'b'),
                                        (1.2, 7.4, 'ρ＝－1', 'start', 'a')],
                                dots=[(20, 10, 'main'), (10, 4, 'main'), (0, 6, 'a')],
                                xticks=[(0, '0'), (10, '10'), (20, '20')], yticks=[(4, '4'), (6, '6'), (10, '10')], w=360, h=230,
                                title='2資産の組合せ（A：10％・20％、B：4％・10％）', zero=False)


def _frontier():
    pts = [(_sd(k / 50, 0), 4 + 6 * k / 50) for k in range(-10, 61)]
    mv = min(pts, key=lambda p: p[0])
    best = max(pts, key=lambda p: (p[1] - 2) / p[0])
    up = [p for p in pts if p[1] >= mv[1]]
    lo = [p for p in pts if p[1] <= mv[1]]
    slope = (best[1] - 2) / best[0]
    return chart([(lo, 'sub', True), (up, 'b', False), ([(0, 2), (24, 2 + slope * 24)], 'a', False)],
                 0, 25, 1, 13, xlab='標準偏差（リスク）', ylab='期待収益率',
                 labels=[(mv[0] - 0.5, mv[1] - 0.2, '最小分散', 'end'), (best[0] + 0.6, best[1] - 0.9, '接点（市場ポートフォリオ）', 'start', 'a'),
                         (14, 12.2, '資本市場線', 'end', 'a'), (24.5, 7.2, '効率的フロンティア', 'end', 'b'), (0.5, 2.6, '無リスク利子率', 'start')],
                 dots=[(mv[0], mv[1], 'main'), (best[0], best[1], 'a'), (0, 2, 'main')], w=360, h=250,
                 title='効率的フロンティアと資本市場線', zero=False)


FIG['zaimu.frontier'] = _frontier()


def _attitude():
    # 効用関数の形
    w, h = 360, 150
    o = []
    specs = [('リスク回避的', '上に凸', lambda x: math.sqrt(x)), ('リスク中立的', '直線', lambda x: x), ('リスク愛好的', '下に凸', lambda x: x * x)]
    for k, (nm, sh, f) in enumerate(specs):
        ox = 6 + k * 120
        x0, y0, ww, hh = ox + 10, 112, 92, 84
        o.append(L(x0, y0, x0 + ww, y0, col='main', sw=1.2))
        o.append(L(x0, y0, x0, y0 - hh, col='main', sw=1.2))
        d = 'M' + ' L'.join('%s %s' % (round(x0 + i / 20 * ww, 1), round(y0 - f(i / 20) * hh * 0.92, 1)) for i in range(21))
        o.append('<path d="%s" fill="none" style="stroke:%s" stroke-width="2.2"/>' % (d, _c(['b', 'sub', 'a'][k])))
        o.append(T(x0 + ww / 2, 128, nm, 'middle', size=11, bold=True))
        o.append(T(x0 + ww / 2, 143, '効用関数が' + sh, 'middle', size=10))
        o.append(T(x0 + 3, y0 - hh + 4, '効用', size=9.5))
        o.append(T(x0 + ww, y0 - 4, '富', 'end', size=9.5))
    return _svg(w, h, o, 'リスクに対する態度')


FIG['zaimu.attitude'] = _attitude()
FIG['zaimu.diversify'] = chart([([(n, math.sqrt(100 + 400 / n)) for n in range(1, 31)], 'a', False), ([(1, 10), (30, 10)], 'sub', True)],
                               0, 31, 0, 24, xlab='銘柄の数', ylab='ポートフォリオのリスク',
                               labels=[(12, 15.5, '個別リスク（分散で消せる）', 'start', 'a'), (12, 6, '市場リスク（分散で消せない）', 'start', 'sub')],
                               xticks=[(1, '1'), (10, '10'), (20, '20'), (30, '30')], w=360, h=210, title='分散投資と2つのリスク', zero=False)

# ------------------------------------------------ 1.9.2 資本市場理論
FIG['zaimu.cml_sml'] = grid(['', '資本市場線（CML）', '証券市場線（SML）'],
                            [['横軸', '標準偏差（総リスク）', 'β（市場リスク）'], ['対象', '効率的なポートフォリオだけ', '個別の証券を含むすべての資産'],
                             ['表すもの', '無リスク資産と市場ポートフォリオの組合せ', 'CAPM（βと期待収益率の関係）']],
                            [64, 148, 148], align=['l', 'l', 'l'], title='資本市場線と証券市場線', size=10.5)
FIG['zaimu.sml2'] = fig(lines=[([(0, 1), (1.7, 9.5)], 'b')], guides=[(0.8, 5, 0.8, 0), (0.8, 5, 0, 5), (1, 6, 1, 0), (1, 6, 0, 6)],
                        dots=[(0, 1, 'main'), (0.8, 5, 'a'), (1, 6, 'main')],
                        labels=[(-0.03, 1, '1％', 'end'), (-0.03, 5, '5％', 'end'), (-0.03, 6, '6％', 'end'), (0.8, -0.9, '0.8', 'middle'), (1, -0.9, '1', 'middle'),
                                (1.04, 5.6, '市場ポートフォリオ', 'start'), (0.85, 4.1, 'β＝0.8の株式', 'start', 'a'), (1.25, 8.9, '証券市場線（SML）', 'end', 'b')],
                        xlab='β', ylab='期待収益率', xmax=1.9, ymax=10, h=230, title='CAPMの計算例')


def _beta_pts():
    import random
    rnd = random.Random(7)
    pts = []
    for i in range(26):
        x = -8 + 16 * i / 25 + rnd.uniform(-0.6, 0.6)
        pts.append((x + 10, 1.3 * x + 10 + 0.5 + rnd.uniform(-2.6, 2.6)))
    return pts


FIG['zaimu.beta'] = fig(lines=[([(1, 10 + 0.5 - 1.3 * 9), (19, 10 + 0.5 + 1.3 * 9)], 'a')], dots=[(x, y, 'sub') for x, y in _beta_pts()],
                        labels=[(19.5, 4, '回帰直線の傾き＝β（1.3）', 'end', 'a')],
                        xlab='市場の収益率', ylab='個別の株式の収益率', xmax=20, ymax=22, h=230, title='市場モデルとβ')


def _emh():
    # 効率的市場仮説：情報の範囲の入れ子
    w, h = 360, 200
    o = []
    boxes_ = [(4, 4, 352, 192, 'a', 'ストロング型：内部情報を含むすべての情報', 'インサイダー情報でも超過収益は得られない'),
              (20, 50, 320, 140, 'c', 'セミストロング型：公開されているすべての情報', 'ファンダメンタル分析でも得られない'),
              (36, 96, 288, 88, 'b', 'ウィーク型：過去の価格の情報', 'テクニカル分析では得られない')]
    for x, y, ww, hh, col, t1, t2 in boxes_:
        o.append(R(x, y, ww, hh, fill=col, stroke=col, op=0.1, rx=8, sw=1.3))
        o.append(T(x + 10, y + 18, t1, size=11, bold=True))
        o.append(T(x + 10, y + 34, t2, size=10.5))
    return _svg(w, h, o, '効率的市場仮説の3つの型')


FIG['zaimu.emh'] = _emh()
