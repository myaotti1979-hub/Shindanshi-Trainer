# 経済学・経済政策の演習（qbank/q_keizai_z.py：範囲の穴埋め）の図表
# 名前はすべて keizai.qx.*（問題文の図は末尾が _q）
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import grid
from ekit import G, panels, txt, eq

FIG = {}


# ------------------------------------------------ keizai-201 等費用線（1.6.4）
def _q_isocost():
    g = G(xmax=50, ymax=40, h=220, xlab='労働 L', ylab='資本 K', pr=30, pl=34)
    g.line([(0, 30), (40, 0)], 'a', sw=2.4)
    g.yt(30, '30', 'a', True).xt(40, '40', 'a', True)
    g.text(17, 22, '等費用線\n30L＋40K＝1,200', 'start', 'a', True, 11)
    return g.svg('問題の図：等費用線（賃金30、資本のレンタル価格40、総費用1,200）')


FIG['keizai.qx.isocost_q'] = _q_isocost()


def _x_isocost():
    caps = [('賃金30→20', '横軸の切片だけが右へ'), ('レンタル価格40→60', '縦軸の切片だけが下へ')]
    gs = []
    for i in range(2):
        g = G(xmax=66, ymax=36, w=176, h=214, ox=i * 184, pl=24, pr=10, pt=40, pb=40, xlab='L', ylab='K', origin='')
        g.raw(txt(i * 184 + 88, 14, caps[i][0], 'middle', 'main', True, 11))
        g.raw(txt(i * 184 + 88, 30, caps[i][1], 'middle', 'a', True, 10.5))
        g.line([(0, 30), (40, 0)], 'main', sw=1.8)
        gs.append(g)
    gs[0].line([(0, 30), (60, 0)], 'a', dash=True, sw=2)
    gs[0].yt(30, '30').xt(40, '40').xt(60, '60', 'a', True)
    gs[1].line([(0, 20), (40, 0)], 'a', dash=True, sw=2)
    gs[1].yt(30, '30').yt(20, '20', 'a', True).xt(40, '40')
    ex = [txt(88, 206, '傾き 30÷40＝0.75→20÷40＝0.5', 'middle', 'a', True, 10),
          txt(272, 206, '傾き 30÷40＝0.75→30÷60＝0.5', 'middle', 'a', True, 10)]
    return panels(gs, '等費用線の傾きと切片の変化', h=214, extra=ex)


FIG['keizai.qx.isocost'] = _x_isocost()

FIG['keizai.qx.isocost2'] = grid(['変化', '横軸の切片\nC÷w\n労働の量', '縦軸の切片\nC÷r\n資本の量', '傾き\nw÷r', '等費用線の動き'],
                                 [['当初（w30、r40、C1,200）', '40', '30', '0.75', '―'],
                                  ['賃金だけが20に下がる', '60', '30', '0.5', '横軸の切片が右へ。緩やかになる'],
                                  ['レンタル価格だけが60に上がる', '40', '20', '0.5', '縦軸の切片が下へ。緩やかになる'],
                                  ['総費用だけが1,800に増える', '60', '45', '0.75', '外側へ平行に移動'],
                                  ['wとrがともに1.5倍（Cは1,200のまま）', '約26.7', '20', '0.75', '内側へ平行に移動']],
                                 [104, 54, 54, 42, 106], align=['l', 'r', 'r', 'r', 'l'],
                                 title='等費用線w×L＋r×K＝Cの切片と傾き（切片は費用ではなく投入量）', size=10.5, hl_rows=(1,))


# ------------------------------------------------ keizai-202 所得分配の公正の基準（1.8.1）
FIG['keizai.qx.fair3'] = grid(['考え方', '何に応じて分配するか', '例', '弱いところ'],
                              [['貢献に応じた分配', '生産への貢献（生産性）', '市場で決まる賃金（熟練した労働者の所得が高い）', '働くことが難しい人を救いにくい'],
                               ['必要に応じた分配', '家族の人数・健康の状態などの必要の大きさ', '生活保護（困窮の程度に応じた給付）', '貢献と所得の結びつきが弱まり、働く意欲を弱めることがある'],
                               ['平等な分配', '全員に同じだけ', '全員に同じ額の給付', '貢献や必要の違いを反映しない'],
                               ['（別の基準）功利主義（ベンサム）', '効用の合計が最大になるように', '―', '分配の平等さは問わない']],
                              [82, 88, 98, 92], align=['l', 'l', 'l', 'l'], title='所得分配の公正さの基準', size=10.5, hl_rows=(0, 1, 2))


# ------------------------------------------------ keizai-203 費用逓減産業の二部料金（1.5.5）
_AC = lambda q: 20 + 1200.0 / q


def _q_twopart():
    g = G(xmax=110, ymax=110, h=262, xlab='数量 Q', ylab='価格・費用', pr=30, pl=36, pb=40, xlpos='low')
    g.line([(0, 100), (100, 0)], 'a', label='D', at=(92, 14), dx=4)
    g.hl(20, 'b', x0=0, x1=106, label='MC', at=(106, 20), dx=2, dy=-2)
    g.fn(_AC, 13.5, 106, 'c', label='AC', at=(106, _AC(106)), dx=2, dy=-2)
    g.yt(100, '100').yt(20, '20').xt(100, '100')
    g.text(46, 92, 'D：P＝100－Q\nMC＝20（一定）\n固定費用1,200\nAC＝20＋1,200÷Q', 'start', 'main', True, 10.5)
    return g.svg('問題の図：需要曲線D、限界費用MC、平均費用AC')


FIG['keizai.qx.twopart_q'] = _q_twopart()


def _x_twopart():
    g1 = G(xmax=110, ymax=110, w=360, h=244, oy=0, pl=36, pr=30, pt=26, pb=40, xlpos='low', xlab='数量 Q', ylab='', cap='二部料金（従量料金20＝MC）', ccol='b')
    g1.rect(0, 20, 80, 35, col='a', op=0.32, label='損失1,200＝基本料金の総額', at=(36, 27.5), lcol='a', size=10.5)
    g1.text(46, 101, '消費者余剰（Dと価格20の間）\n＝3,200（基本料金の前）', 'start', 'b', True, 10)
    g1.arrow(45, 96, 14, 60, 'b', sw=1.2, head=5)
    g1.line([(0, 100), (100, 0)], 'a', sw=1.8, label='D', at=(92, 14), dx=4)
    g1.hl(20, 'b', x0=0, x1=106, sw=1.8, label='MC', at=(106, 20), dx=2, dy=-2)
    g1.fn(_AC, 13.5, 106, 'c', sw=1.8, label='AC', at=(106, _AC(106)), dx=2, dy=-2)
    g1.dot(80, 20, 'b')
    g1.seg(80, 35, 80, 0, 'main')
    g1.yt(35, '35', 'a', True).yt(20, '20').xt(80, '80', 'b', True)
    g2 = G(xmax=110, ymax=110, w=360, h=244, oy=250, pl=36, pr=30, pt=26, pb=40, xlpos='low', xlab='数量 Q', ylab='', cap='比べる：平均費用価格形成（価格40）', ccol='c')
    g2.area([(60, 40), (80, 20), (60, 20)], 'c', op=0.4)
    g2.text(3, 30, '死荷重＝（40－20）\n×（80－60）÷2＝200', 'start', 'c', True, 10)
    g2.arrow(45, 30, 64, 26, 'c', sw=1.2, head=5)
    g2.line([(0, 100), (100, 0)], 'a', sw=1.8, label='D', at=(92, 14), dx=4)
    g2.hl(20, 'b', x0=0, x1=106, sw=1.8, label='MC', at=(106, 20), dx=2, dy=-2)
    g2.fn(_AC, 13.5, 106, 'c', sw=1.8)
    g2.dot(60, 40, 'c', label='P＝AC', pos='ne')
    g2.guide(60, 40, xt='60', yt='40')
    g2.xt(80, '80')
    return panels([g1, g2], '二部料金と平均費用価格形成（D：P＝100－Q、MC＝20、固定費用1,200）', h=494)


FIG['keizai.qx.twopart'] = _x_twopart()

FIG['keizai.qx.twopart2'] = eq([[('平均費用\n（Q＝80）', 'c'), '＝', '限界費用\n20', '＋', '固定費用÷生産量\n1,200÷80＝15', '＝', ('35', 'c')],
                                [('基本料金の総額', 'a'), '＝', '（平均費用－従量料金）\n35－20＝15', '×', '生産量\n80', '＝', ('1,200\n＝固定費用', 'a')],
                                [('消費者余剰', 'b'), '＝', '（100－20）×80÷2\n＝3,200', '＞', '基本料金の総額\n1,200', '→', ('家計は\n加入する', 'b')]],
                               '二部料金の計算（従量料金＝限界費用20）', size=10.5, opw=14)


# ------------------------------------------------ keizai-204 世界の名目GDPに占める主要国の割合（1.1.9）
# IMF DataMapper（NGDPD、World Economic Outlook（2026年10月）、10億米ドル）から計算した割合（％）。計算は gap_keizai/calc/imf_share.py
_YS = [2000, 2005, 2010, 2015, 2020, 2025]
_SH = {'米国': [29.85, 27.09, 22.41, 24.11, 24.82, 26.05],
       '中国': [3.56, 4.82, 9.22, 14.86, 17.42, 16.56],
       '日本': [14.68, 10.13, 8.65, 5.98, 6.03, 3.76],
       'ドイツ': [5.73, 6.01, 5.17, 4.52, 4.61, 4.32],
       'インド': [1.36, 1.70, 2.49, 2.75, 3.04, 3.30]}


def _q_gdpshare():
    g = G(xmin=1998, xmax=2027, ymin=0, ymax=32, h=270, pl=34, pr=14, pb=40, xlab='（年）', ylab='（％）', xlpos='low', origin='')
    for y in (5, 10, 15, 20, 25, 30):
        g.seg(1998, y, 2027, y, 'sub', dash='2 4', op=0.5)
        g.yt(y, '%d' % y)
    g.yt(0, '0')
    for yr in _YS:
        g.xt(yr, '%d' % yr, size=10)
    sty = [('米国', 'main', '米国', (2010, 24.6), 'middle'), ('中国', 'a', 'a', (2020, 19.4), 'middle'),
           ('日本', 'b', 'b', (2005.6, 12.0), 'start'), ('ドイツ', 'sub', 'ドイツ', (2004.2, 7.6), 'middle'),
           ('インド', 'c', 'c', (2010, 0.9), 'middle')]
    for k, col, lab, at, an in sty:
        pts = list(zip(_YS, _SH[k]))
        g.line(pts, col, sw=2.2 if col != 'sub' else 1.8, dash=(col == 'sub'))
        for x, y in pts:
            g.dot(x, y, col if col != 'sub' else 'main', r=2.6)
        g.text(at[0], at[1], lab, an, col if col != 'sub' else 'main', True, 12)
    return g.svg('問題の図：世界全体の名目GDP（米ドル換算）に占める割合（％）')


FIG['keizai.qx.gdpshare_q'] = _q_gdpshare()

FIG['keizai.qx.gdpshare'] = grid(['国', '2000年', '2010年', '2025年', '見分け方'],
                                 [['米国', '29.9', '22.4', '26.0', 'どの年も最も大きい（4分の1前後）'],
                                  ['a 中国', '3.6', '9.2', '16.6', '急速に上がり、2010年には日本を上回る'],
                                  ['ドイツ', '5.7', '5.2', '4.3', '2023年に日本を上回る'],
                                  ['b 日本', '14.7', '8.7', '3.8', '2000年は米国に次ぐが、大きく下がる。2025年は4位'],
                                  ['c インド', '1.4', '2.5', '3.3', '1％台から3％台に上がる']],
                                 [62, 50, 50, 50, 148], align=['l', 'r', 'r', 'r', 'l'],
                                 title='世界全体の名目GDP（米ドル換算）に占める割合（％）', size=10.5, hl_rows=(1, 3, 4))


# ------------------------------------------------ keizai-205 労働生産性の国際比較（1.1.9）
# 日本生産性本部「労働生産性の国際比較2025」（2025年12月22日公表）サマリーの順位表（2024年、購買力平価換算、米ドル）
_LP = {'日本': (98344, 29, 60.1, 28), '米国': (180993, 4, 116.5, 4), '韓国': (106338, 27, 57.5, 31), 'OECD平均': (129635, None, 79.4, None)}


def _q_lprod():
    from vis import R, T, L, _svg
    order = [('a', '日本'), ('b', '米国'), ('c', '韓国'), ('OECD平均', 'OECD平均')]
    blocks = [('就業者1人当たり労働生産性（ドル）', 0, 200000, lambda v: '{:,}'.format(v)),
              ('時間当たり労働生産性（ドル）', 2, 130, lambda v: '%.1f' % v)]
    w, lw, vw = 360, 76, 64
    x0, x1 = lw, w - vw
    o = []
    y = 2
    for ttl, k, vmax, fmt in blocks:
        o.append(T(4, y + 14, ttl, 'start', 'main', True, 11.5))
        y += 22
        top = y
        for lab, key in order:
            v = _LP[key][k]
            bw = (x1 - x0) * v / vmax
            avg = (lab == 'OECD平均')
            o.append(R(x0, y + 3, bw, 16, fill='sub' if avg else 'b', stroke='main' if avg else 'b', op=0.18 if avg else 0.3, sw=1))
            o.append(T(lw - 8, y + 16, lab, 'end', 'main', True, 12 if not avg else 10.5))
            o.append(T(x0 + bw + 5, y + 16, fmt(v), 'start', 'main', True, 11))
            y += 22
        o.append(L(x0, top, x0, y, col='main', sw=1.1))
        y += 10
    return _svg(w, y, o, '問題の図：労働生産性（2024年、購買力平価換算）')


FIG['keizai.qx.lprod_q'] = _q_lprod()

FIG['keizai.qx.lprod'] = grid(['国', '1人当たり\n（ドル）', '順位', '時間当たり\n（ドル）', '順位', '見分け方'],
                              [['b 米国', '180,993', '4位', '116.5', '4位', 'どちらも最も高い'],
                               ['OECD平均', '129,635', '―', '79.4', '―', ''],
                               ['c 韓国', '106,338', '27位', '57.5', '31位', '1人当たりは日本より上、時間当たりは日本より下'],
                               ['a 日本', '98,344', '29位', '60.1', '28位', 'どちらもG7で最も低い']],
                              [58, 62, 38, 62, 38, 102], align=['l', 'r', 'r', 'r', 'r', 'l'],
                              title='労働生産性の国際比較（2024年、OECD加盟38か国中の順位）', size=10.5, hl_rows=(2, 3))

FIG['keizai.qx.lprod2'] = eq([[('時間当たり\n労働生産性', 'b'), '＝', '1人当たり\n労働生産性', '÷', '就業者1人当たりの\n労働時間']],
                             '時間当たりと1人当たりの関係（労働時間が長いと、時間当たりの順位が下がる）', size=10.5, opw=14)


# ------------------------------------------------ keizai-206 水平な需要曲線と直線の需要曲線の価格弾力性（1.5.2）
def _elast2(expl):
    g = G(xmax=14, ymax=14, h=250, xlab='数量 Q', ylab='価格 P', pr=40, pl=30)
    g.line([(0, 12), (12, 0)], 'a', label='D1（P＝12－Q）', at=(2.3, 9.7), dx=6, lsize=10.5)
    g.hl(6, 'b', x0=0, x1=13, label='D2', at=(13, 6), dx=2, dy=-2)
    for x, y, lab, pos in ((0, 12, 'E', 'e'), (3, 6, 'F', 'n'), (6, 6, 'G', 'ne'), (9, 3, 'H', 'ne')):
        g.dot(x, y, 'main', label=lab, pos=pos)
    g.yt(12, '12').yt(6, '6').yt(3, '3')
    for x in (3, 6, 9, 12):
        g.xt(x, '%d' % x)
    g.seg(9, 3, 9, 0, 'main').seg(9, 3, 0, 3, 'main').seg(3, 6, 3, 0, 'main').seg(6, 6, 6, 0, 'main')
    if expl:
        g.text(1.0, 12.9, '弾力性 ∞（数量ゼロ）', 'start', 'a', True, 10)
        g.text(6.3, 8.3, 'D1は1、D2は∞', 'start', 'main', True, 10)
        g.text(9.4, 4.4, '1/3', 'start', 'a', True, 10.5)
        g.text(10.2, 7.3, 'D2はどの点でも∞', 'middle', 'b', True, 10)
        return g.svg('需要曲線の点ごとの価格弾力性（絶対値）')
    return g.svg('問題の図：財1の需要曲線D1と財2の需要曲線D2')


FIG['keizai.qx.elast2_q'] = _elast2(False)
FIG['keizai.qx.elast2'] = _elast2(True)


# ------------------------------------------------ keizai-208 技術的限界代替率（1.6.4）
def _isoq2(expl):
    g = G(xmax=6.2, ymax=6.2, h=262, xlab='労働 L', ylab='資本 K', pr=34, pl=30)
    g.fn(lambda L: 4.0 / L, 0.7, 6.0, 'b', label='Q0（産出量2）', at=(6.0, 4.0 / 6.0), dx=-60, dy=-12, lsize=10.5)
    g.fn(lambda L: 16.0 / L, 2.62, 6.0, 'a', label='Q1（産出量4）', at=(6.0, 16.0 / 6.0), dx=-62, dy=-10, lsize=10.5)
    g.line([(0, 0), (5.9, 5.9)], 'main', dash='5 4', sw=1.3)
    pts = [(1, 4, 'A', 'e', '4'), (2, 2, 'C', 'e' if expl else 'se', '1'), (4, 1, 'B', 'n', '0.25'), (4, 4, 'D', 'e', '1')]
    for x, y, lab, pos, m in pts:
        g.dot(x, y, 'main', label=(lab + '（MRTS ' + m + '）') if expl else lab, pos=pos, size=10.5 if expl else None)
    for v in (1, 2, 4):
        g.xt(v, '%d' % v)
        g.yt(v, '%d' % v)
    if expl:
        g.text(3.0, 5.9, 'MRTS＝K÷L', 'start', 'main', True, 10.5)
    return g.svg('等産出量曲線と技術的限界代替率' if expl else '問題の図：等産出量曲線Q0・Q1と原点を通る直線')


FIG['keizai.qx.isoq2_q'] = _isoq2(False)
FIG['keizai.qx.isoq2'] = _isoq2(True)
