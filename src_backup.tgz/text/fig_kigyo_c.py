# 企業経営理論の図表（2.1 組織構造の基礎、2.2 組織の形態、2.3 組織文化、2.4 組織行動）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, boxes, flow, chart, htree, quad, timeline, barchart, gantt, cycle, pyramid, waterfall, matrix2, decomp, dtree,
                 ARROW, R, T, L, _svg, _c, wrap, tw)

FIG = {}


from kit import _lines, _dashrect, _box, _lists, _flow, _poly, _pline, _dot


# ------------------------------------------------ 2.1.1 組織目標
def _barnard():
    o = []
    _box(o, 6, 10, 140, 50, '共通目的\nメンバーが共有する目的', col='b', c0='b')
    _box(o, 214, 10, 140, 50, '貢献意欲（協働意欲）\n目的のために力を出す意思', col='c', c0='c')
    _box(o, 100, 112, 160, 50, 'コミュニケーション\n共通目的と貢献意欲を結びつける', col='a', c0='a')
    for a, b in (((140, 110), (88, 64)), ((220, 110), (272, 64))):
        o.append(ARROW([a, b], sw=1.4, head=6))
        o.append(ARROW([b, a], sw=1.4, head=6))
    o.append(T(180, 78, '3つの要素がそろうと', 'middle', size=11, bold=True))
    o.append(T(180, 94, '組織が成立する', 'middle', size=11, bold=True))
    o.append(T(180, 186, '公式組織＝2人以上の人々の、意識的に調整された活動や諸力の体系', 'middle', size=10.5))
    return _svg(360, 194, o, 'バーナードの組織の3要素')


def _balance():
    o = [T(180, 22, '誘因 ≧ 貢献', 'middle', size=15, bold=True, col='a'),
         T(180, 42, 'のとき、メンバーは組織に参加し続け、組織は存続する', 'middle', size=10.5)]
    xl, yl, xr, yr = 60, 150, 300, 120
    o.append('<path d="M180 135L164 176L196 176Z" style="fill:%s;stroke:none"/>' % _c('sub'))
    o.append(R(150, 176, 60, 6, fill='sub', stroke=None))
    o.append(L(xl, yl, xr, yr, col='main', sw=3))
    o.append(L(xl, yl, xl, yl + 10, col='main', sw=1.2))
    o.append(L(xr, yr, xr, yr + 10, col='main', sw=1.2))
    _box(o, xl - 52, yl + 10, 104, 58, '誘因\n給与、やりがい、地位など', col='b', c0='b')
    _box(o, xr - 52, yr + 10, 104, 58, '貢献\n労働、時間、努力', col='c', c0='c')
    o.append(T(180, 240, '誘因＜貢献になると、メンバーは組織を離れる', 'middle', size=10.5))
    return _svg(360, 248, o, '組織均衡（誘因と貢献）')


def _pillars():
    o = ['<path d="M20 64L180 14L340 64Z" style="fill:%s;fill-opacity:0.18;stroke:%s" stroke-width="1.3"/>' % (_c('a'), _c('a')),
         T(180, 52, '組織の存続', 'middle', size=13, bold=True, col='a')]
    _box(o, 50, 70, 110, 102, '有効性\n組織の共通目的を達成できている度合い', col='b', c0='b')
    _box(o, 200, 70, 110, 102, '能率\nメンバー個人の動機を満たし、貢献を引き出せている度合い', col='c', c0='c')
    o.append(R(20, 174, 320, 10, fill='sub', stroke=None, op=0.5))
    o.append(T(180, 204, 'どちらが欠けても、組織は存続できない', 'middle', size=11, bold=True))
    return _svg(360, 212, o, '組織の存続（有効性と能率）')


def _slack():
    o = []
    base = 196
    o.append(T(90, 16, '好況期（業績がよい）', 'middle', size=11, bold=True))
    o.append(R(34, base - 150, 50, 150, fill='b', stroke='b', op=0.22))
    o.append(R(96, base - 100, 50, 100, fill='c', stroke='c', op=0.22))
    o.append(_dashrect(96, base - 150, 50, 50, col='a', rx=0))
    o.append(T(121, base - 121, 'スラック', 'middle', size=10.5, bold=True, col='a'))
    o.append(T(121, base - 107, 'がたまる', 'middle', size=10, col='a'))
    o.append(T(270, 16, '不況期（業績が悪い）', 'middle', size=11, bold=True))
    o.append(R(214, base - 80, 50, 80, fill='b', stroke='b', op=0.22))
    o.append(_dashrect(214, base - 100, 50, 20, col='a', rx=0))
    o.append(T(239, base - 86, '取り崩す', 'middle', size=10, bold=True, col='a'))
    o.append(R(276, base - 100, 50, 100, fill='c', stroke='c', op=0.22))
    for x in (59, 239):
        o.append(T(x, base + 15, '実際に持つ', 'middle', size=10))
        o.append(T(x, base + 28, '資源', 'middle', size=10))
    for x in (121, 301):
        o.append(T(x, base + 15, '必要な支払い', 'middle', size=10))
        o.append(T(x, base + 28, '（誘因）', 'middle', size=10))
    o.append(L(24, base, 156, base, col='main', sw=1.2))
    o.append(L(204, base, 336, base, col='main', sw=1.2))
    o.append(L(180, 6, 180, base, dash='3 3', sw=0.8))
    o.append(T(180, base + 50, '業績がよいときにたまった余裕を、業績が悪いときに使う', 'middle', size=10.5, bold=True))
    return _svg(360, base + 56, o, '組織スラック')


FIG['kigyo.barnard3'] = _barnard()
FIG['kigyo.balance'] = _balance()
FIG['kigyo.pillars'] = _pillars()
FIG['kigyo.slack'] = _slack()
FIG['kigyo.formal'] = grid(['', '公式組織', '非公式組織'],
                           [['でき方', '目的に向けて、意識的に調整された組織', '職場の人間関係などから、自然に生まれる集団'],
                            ['働き', '共通目的の達成に向けて、活動を調整する', '公式組織に活力を与える一方、その目的と対立することもある']],
                           [64, 148, 148], align=['l', 'l', 'l'], title='公式組織と非公式組織', size=10.5)
FIG['kigyo.meansend'] = htree(('全社の目標', 'a', [('部門の目標', 'c', [('課・個人の目標', 'b', []), ('課・個人の目標', 'b', [])]),
                                                ('部門の目標', 'c', [('課・個人の目標', 'b', []), ('課・個人の目標', 'b', [])])]),
                              title='目的と手段の連鎖', colw=(96, 110, 130), size=10.5)


# ------------------------------------------------ 2.1.2 階層
def _katz():
    x0, y0, pw, ph = 62, 22, 292, 150
    X = lambda f: x0 + pw * f
    Y = lambda f: y0 + ph * f
    o = []
    _poly(o, [(X(0), Y(0)), (X(0.12), Y(0)), (X(0.55), Y(1)), (X(0), Y(1))], 'b')
    _poly(o, [(X(0.12), Y(0)), (X(0.45), Y(0)), (X(0.88), Y(1)), (X(0.55), Y(1))], 'c')
    _poly(o, [(X(0.45), Y(0)), (X(1), Y(0)), (X(1), Y(1)), (X(0.88), Y(1))], 'a')
    for f in (1 / 3, 2 / 3):
        o.append(L(6, Y(f), X(1), Y(f), dash='3 3', sw=0.8))
    for i, s in enumerate(['トップ', 'ミドル', 'ロワー']):
        o.append(T(x0 - 8, Y((i + 0.5) / 3) + 4, s, 'end', size=11, bold=True))
    o.append(T(x0 - 8, 14, '階層', 'end', size=10))
    o.append(T(X(0.03), Y(0.86) + 4, 'テクニカル・スキル', size=11, bold=True, col='b'))
    o.append(T(X(0.5), Y(0.5) - 3, 'ヒューマン', 'middle', size=11, bold=True, col='c'))
    o.append(T(X(0.5), Y(0.5) + 11, 'スキル', 'middle', size=11, bold=True, col='c'))
    o.append(T((X(0.51) + X(1)) / 2, Y(0.14) + 4, 'コンセプチュアル・スキル', 'middle', size=11, bold=True, col='a'))
    o.append(T(180, Y(1) + 20, '上の階層ほどコンセプチュアル、下の階層ほどテクニカルの比重が大きい', 'middle', size=10))
    return _svg(360, 200, o, 'カッツの3つのスキルと階層')


def _span():
    o = []

    def node(x, y, mgr=True):
        if mgr:
            _dot(o, x, y, 'a', r=5.5)
        else:
            _dot(o, x, y, 'main', r=5, fill='sheet')
    leaves = [14 + i * 21 for i in range(8)]
    lv3 = [(leaves[2 * i] + leaves[2 * i + 1]) / 2 for i in range(4)]
    lv2 = [(lv3[0] + lv3[1]) / 2, (lv3[2] + lv3[3]) / 2]
    levels = [[(lv2[0] + lv2[1]) / 2], lv2, lv3, leaves]
    ys = [50, 82, 114, 146]
    for d in range(3):
        for i, x in enumerate(levels[d + 1]):
            o.append(L(levels[d][i // 2], ys[d] + 5, x, ys[d + 1] - 5, sw=1))
    for d, lv in enumerate(levels):
        for x in lv:
            node(x, ys[d], mgr=(d < 3))
    leaves2 = [198 + i * 21 for i in range(8)]
    root2 = sum(leaves2) / 8
    for x in leaves2:
        o.append(L(root2, 55, x, 77, sw=1))
    node(root2, 50)
    for x in leaves2:
        node(x, 82, mgr=False)
    o.append(L(180, 6, 180, 160, dash='3 3', sw=0.8))
    o.append(T(88, 16, '統制の範囲が狭い（2人）', 'middle', size=11, bold=True))
    o.append(T(88, 32, '→ 4階層', 'middle', size=10.5))
    o.append(T(272, 16, '統制の範囲が広い（8人）', 'middle', size=11, bold=True))
    o.append(T(272, 32, '→ 2階層', 'middle', size=10.5))
    o.append(T(88, 172, 'トール（縦長）の組織', 'middle', size=11, bold=True, col='a'))
    o.append(T(272, 114, 'フラット（横長）の組織', 'middle', size=11, bold=True, col='b'))
    o.append(T(180, 194, '作業者が同じ8人の例。色つきの丸＝管理者、白い丸＝作業者', 'middle', size=10))
    return _svg(360, 200, o, '統制の範囲と組織の形')


FIG['kigyo.katz'] = _katz()
FIG['kigyo.span'] = _span()
FIG['kigyo.spanwide'] = _lists([('統制の範囲を広くできる条件', 'b', ['仕事が定型的で、例外的な事態が少ない', '作業の手順が標準化されている', '部下の能力（スキル）が高い',
                                                                   '管理者自身の管理能力が高い', '部下に権限が委譲され、部下が自ら判断できる']),
                                ('広げにくい', 'a', ['部下の裁量を抑えて、判断を上司に集める（上司が扱う判断が増える）'])],
                               '統制の範囲を広くできる条件', ws=[220, 132])
FIG['kigyo.flat'] = quad([''], ['', ''], [[('メリット', '意思決定が速くなる。情報が伝わる途中のゆがみが減る', 'b'),
                                           ('デメリット', '1人の管理者の負担が増える。昇進の機会が減る', 'a')]], title='フラット化', size=10.5)
FIG['kigyo.bureau'] = htree(('官僚制（ウェーバー）\n合理的・合法的な支配の組織', 'c',
                             [('規則による職務の遂行', 'b', []), ('権限の階層', 'b', []), ('文書による事務処理', 'b', []),
                              ('専門化された職務', 'b', []), ('資格による任用', 'b', [])]),
                            title='官僚制の特徴', colw=(160, 186), size=10.5)
FIG['kigyo.dysf'] = grid(['官僚制の逆機能', '内容'],
                         [['目的の置換（マートン）', '規則を守ること自体が目的になってしまう'],
                          ['訓練された無能（マートン）', '状況が変わっても、決められた手順を繰り返す'],
                          ['形式主義', '規則を絶対視し、融通のきかない画一的な対応になる'],
                          ['繁文縟礼（レッドテープ）', '膨大な手続きや書類の作成に追われる'],
                          ['セクショナリズム', '組織全体より、自部門の利益を優先する']],
                         [124, 236], align=['l', 'l'], title='官僚制の逆機能', size=10.5)


# ------------------------------------------------ 2.1.3 分業と調整
def _bungyo():
    o = [T(88, 16, '水平的分業', 'middle', size=11.5, bold=True, col='b'),
         T(88, 32, '機能や工程で分ける', 'middle', size=10.5)]
    for i, s in enumerate(['購買', '製造', '販売']):
        x = 4 + i * 60
        _box(o, x, 56, 46, 34, s, size=11)
        if i < 2:
            o.append(ARROW([(x + 47, 73), (x + 59, 73)], sw=1.2, head=5))
    o.append(L(180, 6, 180, 112, dash='3 3', sw=0.8))
    o.append(T(272, 16, '垂直的分業', 'middle', size=11.5, bold=True, col='c'))
    o.append(T(272, 32, '計画・判断と実行に分ける', 'middle', size=10.5))
    _box(o, 202, 42, 140, 26, '計画・判断（管理）', col='c', size=10.5)
    o.append(ARROW([(272, 69), (272, 84)], sw=1.2, head=5))
    _box(o, 202, 86, 140, 26, '実行（作業）', size=10.5)
    o.append(T(180, 138, '分業で熟練や効率が高まる一方、分けた仕事をつなぐ調整が必要になる', 'middle', size=10.5, bold=True))
    return _svg(360, 146, o, '水平的分業と垂直的分業')


def _thompson():
    o = []
    pw = 116
    heads = [('共有された', '（プールされた）', 'b'), ('連続的', '（逐次的）', 'c'), ('相互的', '（互恵的）', 'a')]
    descs = ['各部門が独立して仕事をし、共通の資源を使う', 'ある部門の産出が、次の部門の投入になる', '部門同士が、互いに産出と投入をやり取りする']
    adj = ['標準化\n共通の規則・手続き', '計画\nスケジュール', '相互調整\n当事者同士の調整']
    for i in range(3):
        x = i * (pw + 6)
        cx = x + pw / 2
        col = heads[i][2]
        o.append(R(x + 1, 1, pw - 2, 216, fill=col, stroke=col, op=0.07, rx=6))
        o.append(T(cx, 18, heads[i][0], 'middle', size=11.5, bold=True, col=col))
        o.append(T(cx, 32, heads[i][1], 'middle', size=10))
        for j, ln in enumerate(wrap(descs[i], pw - 12, 10)):
            o.append(T(cx, 128 + j * 13, ln, 'middle', size=10))
        o.append(T(cx, 172, '適する調整', 'middle', size=9.5))
        _box(o, x + 8, 178, pw - 16, 34, adj[i], col=col, size=10, c0=col)
    # 共有された
    _box(o, 10, 46, 40, 22, 'A', size=10.5)
    _box(o, 66, 46, 40, 22, 'B', size=10.5)
    _box(o, 18, 90, 80, 22, '共通の資源', col='b', size=10)
    o.append(L(30, 68, 44, 90, col='main', sw=1.2))
    o.append(L(86, 68, 72, 90, col='main', sw=1.2))
    # 連続的
    for k, s in enumerate('ABC'):
        x = 122 + 6 + k * 40
        _box(o, x, 66, 24, 22, s, size=10.5)
        if k < 2:
            o.append(ARROW([(x + 25, 77), (x + 39, 77)], sw=1.3, head=5))
    # 相互的
    _box(o, 252, 62, 32, 30, 'A', size=10.5)
    _box(o, 320, 62, 32, 30, 'B', size=10.5)
    o.append(ARROW([(286, 70), (318, 70)], sw=1.3, head=5))
    o.append(ARROW([(318, 84), (286, 84)], sw=1.3, head=5))
    o.append(ARROW([(10, 232), (350, 232)], col='sub', sw=1.6, head=7))
    o.append(T(180, 250, '右ほど依存が複雑で、調整の負担が大きい', 'middle', size=10.5, bold=True))
    return _svg(360, 256, o, '相互依存関係と調整（トンプソン）')


def _richness():
    o = []
    base = 166
    names = ['対面', '電話', '手紙やメモ', '定型の文書', '数値データ']
    hs = [120, 96, 72, 48, 24]
    ops = [0.5, 0.4, 0.3, 0.2, 0.12]
    for i, (s, hh) in enumerate(zip(names, hs)):
        x = 20 + i * 68
        o.append(R(x, base - hh, 56, hh, fill='c', stroke='c', op=ops[i], sw=1))
        o.append(T(x + 28, base + 15, s, 'middle', size=10.5, bold=True))
    o.append(L(12, base, 352, base, col='main', sw=1.2))
    o.append(T(20, 24, '豊かなメディア', size=11, bold=True, col='a'))
    o.append(T(20, 38, '多義性を減らすのに適する', size=10))
    o.append(T(348, 82, '乏しいメディア', 'end', size=11, bold=True, col='b'))
    o.append(T(348, 96, '不確実性を減らすのに適する', 'end', size=10))
    return _svg(360, 188, o, 'メディア・リッチネス（豊かさの順）')


def _control3():
    o = []
    _box(o, 6, 70, 80, 36, '投入\n原材料・設備など', size=10)
    _box(o, 126, 70, 100, 36, '活動', size=11)
    _box(o, 266, 70, 88, 36, 'アウトプット\n（結果）', size=10)
    o.append(ARROW([(88, 88), (124, 88)], sw=1.4, head=6))
    o.append(ARROW([(228, 88), (264, 88)], sw=1.4, head=6))
    o.append(T(46, 18, 'フィードフォワード', 'middle', size=10.5, bold=True, col='b'))
    o.append(T(46, 33, '投入を事前に検査する', 'middle', size=9.5))
    o.append(ARROW([(46, 40), (46, 67)], col='b', sw=1.4, head=6))
    o.append(T(176, 18, 'オープンループ', 'middle', size=10.5, bold=True, col='c'))
    o.append(T(176, 33, 'あらかじめ定めたプログラムで制御', 'middle', size=9.5))
    o.append(ARROW([(176, 40), (176, 67)], col='c', sw=1.4, head=6))
    o.append(ARROW([(310, 108), (310, 128), (190, 128), (190, 109)], col='a', sw=1.4, head=6))
    o.append(T(250, 146, 'フィードバック：結果の情報で活動を修正', 'middle', size=10.5, bold=True, col='a'))
    o.append(T(250, 161, '（結果が出てから修正するため、遅れが生じる）', 'middle', size=9.5))
    return _svg(360, 168, o, 'コントロール・システムの3つの形')


FIG['kigyo.bungyo'] = _bungyo()
FIG['kigyo.design6'] = grid(['基本要素', '内容'],
                            [['職務の専門化', '仕事を細かな作業に分け、1人が一部の作業を担当する'],
                             ['部門化', '仕事をまとめて部門をつくる。分け方には、機能別、製品別、地域別、\n工程（プロセス）別、顧客別などがある'],
                             ['指揮命令系統', 'トップから末端までの権限の系統。誰が誰に報告するかを決める'],
                             ['統制の範囲', '1人の管理者が直接管理する部下の数'],
                             ['集権化と分権化', '意思決定の権限が上位に集まっている程度。分権化すると、現場に近い階層で速く判断でき、環境の変化に対応しやすい'],
                             ['公式化', '手順や規則が標準化され、文書で定められている程度。公式化が進むほど、仕事の進め方についての個人の裁量は小さくなる']],
                            [96, 264], align=['l', 'l'], title='組織設計の基本要素', size=10.5)
FIG['kigyo.mintz6'] = grid(['', '調整のメカニズム', '何で調整するか'],
                           [['①', '相互調整', '当事者同士の非公式なやり取り'],
                            ['②', '直接監督', '上司が指示する'],
                            ['③', '作業プロセスの標準化', '作業の内容や手順を、あらかじめ決めておく'],
                            ['④', 'アウトプット（成果）の標準化', '達成すべき成果を決めておく'],
                            ['⑤', 'スキル（技能）の標準化', '仕事に必要な技能や知識（訓練）をそろえる'],
                            ['⑥', '規範の標準化', '価値観や信念をメンバーで共有する']],
                           [26, 150, 184], align=['c', 'l', 'l'], title='調整のメカニズム（ミンツバーグ）', size=10.5)
FIG['kigyo.mintz_size'] = _flow([('小さく単純な組織\n相互調整・直接監督', 'b'), ('規模が大きくなる\n標準化が中心', 'c'), ('きわめて複雑な仕事\n再び相互調整', 'a')],
                                '組織の規模・複雑さと調整の中心')
FIG['kigyo.thompson'] = _thompson()
FIG['kigyo.galbraith'] = htree(('仕事の不確実性が高い\n規則・階層・目標設定では処理しきれない', 'sheet',
                                [('情報処理の必要量を減らす', 'b', [('スラック資源を持つ（余裕のある在庫や納期）', 'b', []),
                                                                ('自己完結的な組織単位をつくる（製品別の事業部など）', 'b', [])]),
                                 ('情報処理の能力を高める', 'a', [('垂直的な情報システムに投資する', 'a', []),
                                                               ('水平的な関係をつくる（直接の接触、連絡役、タスクフォース、チーム、統合担当者、マトリックス組織）', 'a', [])])]),
                               title='組織の情報処理モデル（ガルブレイス）', colw=(96, 92, 148), size=10)
FIG['kigyo.uncert'] = grid(['', '不確実性', '多義性'],
                           [['状態', '判断に必要な情報が足りない', '情報の意味があいまいで、複数の解釈ができる'],
                            ['減らし方', '情報の量を増やす（定型の報告、データベースなど）', '情報を増やしても減らない。対話を通じて、解釈をすり合わせる'],
                            ['適する\nメディア', '多くの情報を効率よく処理できる、乏しいメディア', '豊かなメディア（対面など）']],
                           [64, 148, 148], align=['l', 'l', 'l'], title='不確実性と多義性（ダフト＆レンゲル）', size=10.5)
FIG['kigyo.richness'] = _richness()
FIG['kigyo.control3'] = _control3()


# ------------------------------------------------ 2.1.4 権限と責任
def _juyo():
    o = [T(88, 16, '権限法定説（公式権限説）', 'middle', size=11, bold=True)]
    _box(o, 44, 28, 88, 28, '上司（職位）', size=10.5)
    o.append(ARROW([(88, 58), (88, 102)], sw=1.8))
    o.append(T(96, 84, '権限を与える', size=10))
    _box(o, 44, 104, 88, 28, '部下', size=10.5)
    o.append(T(88, 152, '権限は職位に基づいて、', 'middle', size=10))
    o.append(T(88, 166, '上から下へ与えられる', 'middle', size=10))
    o.append(L(180, 6, 180, 170, dash='3 3', sw=0.8))
    o.append(T(272, 16, '権限受容説（バーナード）', 'middle', size=11, bold=True, col='a'))
    _box(o, 216, 28, 88, 28, '上司', size=10.5)
    o.append(ARROW([(240, 58), (240, 102)], sw=1.8))
    o.append(T(234, 84, '命令', 'end', size=10))
    o.append(ARROW([(282, 102), (282, 58)], col='a', sw=1.8, dash='4 3'))
    o.append(T(290, 76, '受け入れる', size=10, bold=True, col='a'))
    o.append(T(290, 90, '＝権威が成立', size=10, col='a'))
    _box(o, 216, 104, 88, 28, '部下（受け手）', col='a', size=10.5)
    o.append(T(272, 152, '権限があるかは、受ける側が', 'middle', size=10))
    o.append(T(272, 166, '受け入れるかどうかで決まる', 'middle', size=10))
    return _svg(360, 174, o, '権限法定説と権限受容説')


def _indiff():
    o = ['<ellipse cx="180" cy="86" rx="168" ry="76" style="fill:%s;fill-opacity:0.07;stroke:%s" stroke-width="1.2"/>' % (_c('sub'), _c('sub')),
         '<ellipse cx="180" cy="100" rx="92" ry="44" style="fill:%s;fill-opacity:0.18;stroke:%s" stroke-width="1.4"/>' % (_c('b'), _c('b')),
         T(180, 36, '受け入れるかどうかを吟味する命令', 'middle', size=10.5)]
    o.append(T(180, 96, '無関心圏', 'middle', size=13, bold=True, col='b'))
    o.append(T(180, 113, '権威の有無を意識的に問わずに', 'middle', size=10))
    o.append(T(180, 127, '受け入れる命令の範囲', 'middle', size=10))
    o.append(ARROW([(276, 100), (322, 100)], col='b', sw=1.6, dash='4 3'))
    o.append(ARROW([(84, 100), (38, 100)], col='b', sw=1.6, dash='4 3'))
    o.append(T(180, 184, '誘因が、受け手の負担や犠牲を上回る程度が大きいほど広い', 'middle', size=10.5, bold=True))
    return _svg(360, 192, o, '無関心圏（バーナード）')


def _lineorg():
    o = []
    pw = 116

    def nd(x, y, col='main', ww=22, hh=13, fill='sheet'):
        o.append(R(x - ww / 2, y - hh / 2, ww, hh, fill=fill, stroke=col, sw=1.1, rx=2))
    titles = [('ライン組織', '（直系組織）'), ('ファンクショナル組織', '（職能的組織）'), ('ライン・アンド・', 'スタッフ組織')]
    descs = ['トップから末端まで、1本の命令の系統でつながる', '作業者が、機能ごとの複数の専門の管理者から指示を受ける',
             'ラインが命令の系統を担い、スタッフが専門知識で助言・支援する']
    for i in range(3):
        cx = i * (pw + 6) + pw / 2
        o.append(T(cx, 15, titles[i][0], 'middle', size=10.5, bold=True))
        o.append(T(cx, 29, titles[i][1], 'middle', size=10.5 if i == 2 else 9.5, bold=(i == 2)))
        for j, s in enumerate(wrap(descs[i], pw - 10, 9.5)):
            o.append(T(cx, 150 + j * 13, s, 'middle', size=9.5))
    for x in (119, 241):
        o.append(L(x, 6, x, 136, dash='3 3', sw=0.8))
    # ライン組織
    for a in (30, 86):
        o.append(L(58, 50, a, 84, sw=1))
        for b in (a - 16, a + 16):
            o.append(L(a, 84, b, 118, sw=1))
    nd(58, 50, col='a')
    for a in (30, 86):
        nd(a, 84)
    for b in (14, 46, 70, 102):
        nd(b, 118)
    # ファンクショナル組織
    fx = [146, 180, 214]
    for a in fx:
        o.append(L(180, 48, a, 80, sw=1))
        for b in fx:
            o.append(L(a, 80, b, 118, col='a', sw=1))
    nd(180, 48)
    for a in fx:
        nd(a, 80, col='c')
    for b in fx:
        nd(b, 118)
    # ライン・アンド・スタッフ組織
    for a in (266, 312):
        o.append(L(288, 50, a, 84, sw=1))
        for b in (a - 12, a + 12):
            o.append(L(a, 84, b, 118, sw=1))
    o.append(L(299, 50, 336, 50, col='b', sw=1.2, dash='3 2'))
    o.append(L(336, 50, 336, 56, col='b', sw=1.2, dash='3 2'))
    nd(288, 50, col='a')
    o.append(R(316, 56, 40, 16, fill='b', stroke='b', op=0.2, rx=3))
    o.append(T(336, 68, 'スタッフ', 'middle', size=9))
    for a in (266, 312):
        nd(a, 84, ww=18)
    for b in (254, 278, 300, 324):
        nd(b, 118, ww=18)
    return _svg(360, 190, o, 'ライン組織・ファンクショナル組織・ライン・アンド・スタッフ組織')


FIG['kigyo.kanri5'] = grid(['管理原則', '内容'],
                           [['専門化の原則', '仕事を分けて専門化する'],
                            ['命令統一の原則', '部下は1人の上司だけから命令を受ける'],
                            ['統制の範囲の原則', '1人の上司が管理できる部下の数には限りがある'],
                            ['権限と責任一致の原則', '職務の権限と責任は、同じ大きさでなければならない'],
                            ['例外の原則', '定型的な判断は部下に任せ、上司は例外的な事項の判断に集中する']],
                           [132, 228], align=['l', 'l'], title='組織設計の原則（管理原則）', size=10.5)
FIG['kigyo.juyo'] = _juyo()
FIG['kigyo.juyo4'] = grid(['', '受け入れる4つの条件（同時にそろうこと）'],
                          [['①', '伝達の内容を理解でき、実際に理解している'],
                           ['②', '意思決定の時点で、伝達が組織の目的と矛盾しないと信じている'],
                           ['③', '意思決定の時点で、伝達が自分の個人的な利害と両立すると信じている'],
                           ['④', '伝達に従う精神的・肉体的な能力がある']],
                          [26, 334], align=['c', 'l'], title='伝達を権威あるものとして受け入れる条件', size=10.5)
FIG['kigyo.indiff'] = _indiff()
FIG['kigyo.lineorg'] = _lineorg()
FIG['kigyo.line_cmp'] = grid(['組織の形', '長所', '短所'],
                             [['ライン組織', '命令の一元化が徹底され、各管理者が担当範囲の責任と権限を包括的に持つ', '規模が大きくなると上位者の負担が重くなり、専門的な知識を活かしにくい'],
                              ['ファンクショナル\n組織', '専門性を活かせる', '命令の一元性が崩れ、指示が食い違いやすい'],
                              ['ライン・アンド・\nスタッフ組織', 'ライン組織の命令の一元性を保ちながら、スタッフの専門性を活かせる', 'ラインとスタッフの対立が起きやすい']],
                             [104, 128, 128], align=['l', 'l', 'l'], title='3つの組織の形の比較', size=10.5)


# ------------------------------------------------ 2.1.5 横断的関係
def _yokodan():
    o = []
    for x, s in ((8, '開発部門'), (136, '製造部門'), (264, '販売部門')):
        o.append(R(x, 32, 88, 226, fill='sub', stroke=None, op=0.1))
        _box(o, x, 6, 88, 24, s, size=10.5)
    bands = [(40, 'プロジェクト・チーム', '特定の課題のため複数の部門から集めた一時的な組織。達成すると解散', 'b', 344),
             (84, 'タスクフォース', '緊急の課題に取り組む、短期の特別チーム', 'b', 344),
             (128, '委員会', '部門の代表が集まって、審議・調整する', 'c', 344),
             (172, '統合担当者（プロダクト・マネジャーなど）', '複数の部門にまたがる仕事の統合に責任を持つ', 'c', 344),
             (216, '連絡役（リエゾン）', '部門間の調整を受け持つ担当者', 'a', 216)]
    for y, t1, t2, col, ww in bands:
        _box(o, 8, y, ww, 36, t1 + '\n' + t2, col=col, size=10, c0=col, op=0.18)
    return _svg(360, 260, o, '部門をまたぐ横断的な仕組み')


def _linkpin():
    o = []
    _poly(o, [(180, 6), (96, 80), (264, 80)], 'b', op=0.1)
    _poly(o, [(110, 62), (48, 136), (172, 136)], 'b', op=0.1)
    _poly(o, [(250, 62), (188, 136), (312, 136)], 'b', op=0.1)
    _poly(o, [(60, 118), (18, 192), (102, 192)], 'b', op=0.1)
    _dot(o, 180, 18, 'main', r=6)
    for x, y in ((180, 72), (60 + 50, 128), (160, 128), (200, 128), (250, 128), (300, 128), (30, 184), (60, 184), (90, 184)):
        _dot(o, x, y, 'main', r=5, fill='sheet')
    for x, y in ((110, 72), (250, 72), (60, 128)):
        _dot(o, x, y, 'a', r=7)
    o.append(T(140, 168, '● 連結ピン（管理者）', size=11, bold=True, col='a'))
    o.append(T(140, 184, '上の集団ではメンバー、', size=10.5))
    o.append(T(140, 199, '下の集団では長として上下をつなぐ', size=10.5))
    return _svg(360, 206, o, '連結ピン（リッカート）')


FIG['kigyo.yokodan'] = _yokodan()
FIG['kigyo.linkpin'] = _linkpin()
FIG['kigyo.lawlor'] = _flow(['環境\n部門ごとに、向き合う環境が異なる', ('分化\n目標、時間の見方、対人関係の志向、公式化の程度に違いが生まれる', 'c'),
                             '対立\n分化が進むほど、部門間の対立が起きやすい', ('統合\n統合担当者や統合部門を置き、対立を正面から話し合う（対決）', 'b')],
                            '分化と統合（ローレンス＆ローシュ）', per_row=1, gapy=18)


# ------------------------------------------------ 2.2.1 事業部制組織
def _divorg():
    o = []
    _box(o, 100, 6, 160, 40, '本社\n全社戦略・業績評価・資源配分', col='c', size=10, c0='c')
    o.append(L(180, 46, 180, 58, col='main', sw=1.1))
    o.append(L(89, 58, 271, 58, col='main', sw=1.1))
    for x, s in ((14, 'A事業部'), (196, 'B事業部')):
        o.append(_dashrect(x, 64, 150, 86, col='a'))
        o.append(L(x + 75, 58, x + 75, 70, col='main', sw=1.1))
        _box(o, x + 25, 70, 100, 24, s, size=10.5)
        o.append(L(x + 75, 94, x + 75, 106, col='main', sw=1.1))
        o.append(L(x + 25, 106, x + 125, 106, col='main', sw=1.1))
        for k, f in enumerate(['開発', '生産', '販売']):
            fx = x + 3 + k * 50
            o.append(L(fx + 22, 106, fx + 22, 118, col='main', sw=1.1))
            _box(o, fx, 118, 44, 24, f, size=10)
        o.append(T(x + 75, 166, 'プロフィット・センター', 'middle', size=10, bold=True, col='a'))
    return _svg(360, 174, o, '事業部制組織')


FIG['kigyo.divorg'] = _divorg()
FIG['kigyo.div_pm'] = _lists([('メリット', 'b', ['事業部の中で意思決定が完結するため、市場の変化に速く対応できる', '利益責任が明確になり、業績を評価しやすい',
                                               '事業部長として事業全体を見る経験を積めるため、次の経営者が育つ', 'トップが日常の業務から解放され、全社戦略に集中できる']),
                              ('デメリット', 'a', ['各事業部が同じ機能を持つため、資源が重複し、規模の経済が働きにくい', '事業部ごとの利益を優先し、短期志向やセクショナリズムに陥りやすい',
                                                 '事業部間で技術や顧客の情報が共有されにくく、全社的なシナジーが生まれにくい'])],
                             '事業部制組織のメリットとデメリット')
FIG['kigyo.center3'] = _flow([('事業部制\n利益に責任を持つ（プロフィット・センター）', 'b'),
                              ('社内カンパニー制\n独立性をさらに高め、投資や資産の効率にまで責任を持つ（インベストメント・センター）。\n社内の組織であり、独立した法人格は持たない', 'c'),
                              ('分社化\n事業を別の会社（別の法人）として切り離す', 'a')], '事業部制・社内カンパニー制・分社化', per_row=1)
FIG['kigyo.chandler'] = flow(['多角化の戦略をとる\n（デュポン、GMなど）', '職能別組織から\n事業部制組織に移る'], per_row=2, title='組織は戦略に従う（チャンドラー）')


# ------------------------------------------------ 2.2.2 職能部門組織
def _funcorg():
    o = []
    _box(o, 130, 6, 100, 28, 'トップ', col='c', size=11, c0='c')
    o.append(T(236, 24, '← 部門間の調整が集中', size=10, bold=True, col='a'))
    o.append(L(180, 34, 180, 50, col='main', sw=1.1))
    xs = [4 + i * 59 for i in range(6)]
    o.append(L(xs[0] + 27, 50, xs[-1] + 27, 50, col='main', sw=1.1))
    for x, s in zip(xs, ['購買', '製造', '販売', '研究開発', '人事', '経理']):
        o.append(L(x + 27, 50, x + 27, 66, col='main', sw=1.1))
        _box(o, x, 66, 54, 28, s, size=10.5)
    o.append(T(180, 118, '同じ専門の人材が集まり、専門性と規模の経済を得やすい', 'middle', size=10.5, bold=True, col='b'))
    return _svg(360, 126, o, '職能別組織')


FIG['kigyo.funcorg'] = _funcorg()
FIG['kigyo.func_div'] = grid(['観点', '職能別組織', '事業部制組織'],
                             [['部門の分け方', '購買、製造、販売など機能（職能）ごと', '製品、地域、顧客などの単位。各事業部が開発・生産・販売の機能を持つ'],
                              ['適する企業', '単一の事業や、製品の種類が少ない企業', '多角化した企業（チャンドラー）'],
                              ['専門性・規模の経済', '専門性が高まり、知識や技能が蓄積される。規模の経済が働き、重複が少ない', '資源が重複し、規模の経済が働きにくい'],
                              ['市場への対応', '製品や市場が増えると、意思決定が遅れる', '事業部の中で意思決定が完結し、速く対応できる'],
                              ['利益責任', 'あいまいになりやすい', '明確（プロフィット・センター）'],
                              ['トップの負担', '部門間の調整がトップに集中し、重い', '日常の業務から解放され、全社戦略に集中できる'],
                              ['経営者の育成', '事業全体を見る経験を積みにくい', '事業部長として事業全体を見る経験を積める'],
                              ['陥りやすい問題', '各部門が自分の機能を優先し、全社的な視野を持ちにくい', '短期志向やセクショナリズム。事業部間のシナジーが生まれにくい']],
                             [76, 142, 142], align=['l', 'l', 'l'], title='職能別組織と事業部制組織の比較', size=10.5)


# ------------------------------------------------ 2.2.3 マトリックス組織
def _matrix_org():
    o = [T(8, 22, '事業の軸 →', size=10.5, bold=True, col='b'), T(8, 40, '職能の軸 ↓', size=10.5, bold=True, col='c')]
    cx = [142, 226, 310]
    ry = [76, 120, 164]
    for i, x in enumerate(cx):
        o.append(L(x, 48, x, 180, col='b', sw=1, dash='3 3'))
    for j, y in enumerate(ry):
        o.append(L(92, y, 352, y, col='c', sw=1, dash='3 3'))
    o.append(L(226, 48, 226, 113, col='a', sw=2.4))
    o.append(L(92, 120, 219, 120, col='a', sw=2.4))
    for i, x in enumerate(cx):
        _box(o, x - 38, 8, 76, 40, '製品%s\nマネジャー' % 'ABC'[i], col='b', size=10, c0='b')
    for j, y in enumerate(ry):
        _box(o, 8, y - 15, 84, 30, ['開発部長', '製造部長', '販売部長'][j], col='c', size=10.5, c0='c')
    for i, x in enumerate(cx):
        for j, y in enumerate(ry):
            if i == 1 and j == 1:
                _dot(o, x, y, 'a', r=8)
            else:
                _dot(o, x, y, 'main', r=6, fill='sheet')
    o.append(T(180, 200, '交点のメンバーは、2人の上司から命令を受ける（ツーボス）', 'middle', size=10.5, bold=True, col='a'))
    return _svg(360, 208, o, 'マトリックス組織')


FIG['kigyo.matrix_org'] = _matrix_org()
FIG['kigyo.matrix_pm'] = _lists([('メリット', 'b', ['職能の専門性と、事業や製品への対応を同時に追求できる', '人材などの資源を、事業をまたいで柔軟に共有できる',
                                                  '情報処理の能力が高く、複雑で不確実な環境に対応しやすい']),
                                 ('デメリット', 'a', ['2人の上司の指示が食い違うと、メンバーが混乱する', '権限と責任があいまいになり、対立（コンフリクト）が起きやすい',
                                                    '調整に時間がかかり、意思決定が遅くなることがある'])],
                                'マトリックス組織のメリットとデメリット')


# ------------------------------------------------ 2.2.4 ネットワーク組織
def _network():
    o = []
    # 階層
    for a in (34, 82):
        o.append(L(58, 30, a, 60, sw=1))
        for b in (a - 12, a + 12):
            o.append(L(a, 60, b, 90, sw=1))
    _dot(o, 58, 30, 'sub', r=6)
    for a in (34, 82):
        _dot(o, a, 60, 'sub', r=5)
    for b in (22, 46, 70, 94):
        _dot(o, b, 90, 'sub', r=5)
    # ネットワーク
    pts = [(180 + 44 * math.cos(math.pi / 2 + k * math.pi / 3), 60 - 32 * math.sin(math.pi / 2 + k * math.pi / 3)) for k in range(6)]
    for k in range(6):
        o.append(L(pts[k][0], pts[k][1], pts[(k + 1) % 6][0], pts[(k + 1) % 6][1], col='b', sw=1.2))
    for a, b in ((0, 3), (1, 4), (2, 5)):
        o.append(L(pts[a][0], pts[a][1], pts[b][0], pts[b][1], col='b', sw=0.9, dash='3 3'))
    for (x, y) in pts:
        _dot(o, x, y, 'b', r=6)
    # 市場
    for y in (40, 84):
        o.append(L(274, y, 330, y, col='sub', sw=1.2, dash='4 3'))
        _dot(o, 268, y, 'sub', r=6)
        _dot(o, 336, y, 'sub', r=6)
        o.append(T(302, y - 6, '価格', 'middle', size=9.5))
    o.append(ARROW([(180, 124), (16, 124)], col='main', sw=1.2, head=6))
    o.append(ARROW([(180, 124), (344, 124)], col='main', sw=1.2, head=6))
    for x, t1, t2, col in ((58, '階層', '組織内の命令', 'sub'), (180, 'ネットワーク組織', '対等な関係・信頼', 'b'), (302, '市場', '価格による取引', 'sub')):
        _dot(o, x, 124, col, r=5)
        o.append(T(x, 144, t1, 'middle', size=11, bold=True, col=('b' if col == 'b' else 'main')))
        o.append(T(x, 159, t2, 'middle', size=10))
    return _svg(360, 166, o, '階層・ネットワーク・市場')


FIG['kigyo.network'] = _network()


# ------------------------------------------------ 2.2.5 持株会社
def _hd():
    o = []
    for x, t, top, col, d1, d2 in ((0, '純粋持株会社', '持株会社\n自らは事業を行わない', 'c', '株式の保有と、グループ全体の', '戦略・管理に専念する'),
                                   (184, '事業持株会社', '親会社\n自らも事業を行う', 'b', '自ら事業を行いながら、', '子会社を支配する')):
        cx = x + 88
        o.append(T(cx, 16, t, 'middle', size=11.5, bold=True, col=col))
        _box(o, cx - 60, 26, 120, 40, top, col=col, size=10.5, c0=col)
        xs = [cx - 58, cx, cx + 58]
        o.append(L(cx, 66, cx, 80, col='main', sw=1.1))
        o.append(L(xs[0], 80, xs[-1], 80, col='main', sw=1.1))
        for i, sx in enumerate(xs):
            o.append(ARROW([(sx, 80), (sx, 98)], sw=1.2, head=5))
            _box(o, sx - 25, 100, 50, 26, '子会社' + 'ABC'[i], size=10)
        o.append(T(cx, 148, d1, 'middle', size=10))
        o.append(T(cx, 162, d2, 'middle', size=10))
    o.append(L(180, 6, 180, 164, dash='3 3', sw=0.8))
    return _svg(360, 170, o, '純粋持株会社と事業持株会社')


def _hd_make():
    o = []
    pw = 116
    titles = ['株式移転', '株式交換', '会社分割']
    descs = ['既存の会社が完全子会社となり、完全親会社（持株会社）を新しく設立する', '既存の会社を完全子会社とし、その株主に親会社の株式を渡す',
             '事業の一部を切り出して、別の会社に承継させる']
    for i in range(3):
        x = i * (pw + 6)
        cx = x + pw / 2
        o.append(R(x + 1, 1, pw - 2, 200, fill='sub', stroke='sub', op=0.06, rx=6))
        o.append(T(cx, 18, titles[i], 'middle', size=11.5, bold=True, col='a'))
        for j, s in enumerate(wrap(descs[i], pw - 12, 10)):
            o.append(T(cx, 138 + j * 13, s, 'middle', size=10))
    _box(o, 10, 30, 96, 32, '持株会社\n（新しく設立）', col='a', size=9.5, dash=True, c0='a')
    o.append(ARROW([(58, 64), (58, 92)], sw=1.4, head=6))
    o.append(T(64, 82, '100％', size=9.5))
    _box(o, 10, 94, 96, 26, '既存の会社', size=10)
    _box(o, 132, 30, 96, 32, '親会社\n（既存の会社）', col='b', size=9.5, c0='b')
    o.append(ARROW([(180, 64), (180, 92)], sw=1.4, head=6))
    o.append(T(186, 82, '100％', size=9.5))
    _box(o, 132, 94, 96, 26, '既存の会社', size=10)
    o.append(R(250, 30, 104, 46, fill='sheet', stroke='main', sw=1.2, rx=6))
    o.append(T(302, 43, '会社', 'middle', size=10, bold=True))
    _box(o, 256, 48, 44, 22, '事業X', size=9.5)
    _box(o, 304, 48, 44, 22, '事業Y', col='a', size=9.5)
    o.append(ARROW([(326, 72), (326, 92)], col='a', sw=1.4, head=6))
    o.append(T(320, 86, '承継', 'end', size=9.5, col='a', bold=True))
    _box(o, 290, 94, 62, 26, '別の会社', size=9.5)
    return _svg(360, 204, o, '持株会社をつくる手法')


FIG['kigyo.hd'] = _hd()
FIG['kigyo.hd_make'] = _hd_make()
FIG['kigyo.hd_pm'] = _lists([('メリット', 'b', ['グループ全体の戦略（事業の選択と資源配分）と、各事業の執行を分けられる',
                                              '事業ごとに会社が分かれ、責任と権限が明確になる。事業の実情に合った人事・賃金制度をとれる',
                                              'M&Aで買収した企業を取り込みやすく、事業の売却や撤退もしやすい']),
                             ('デメリット', 'a', ['子会社の独立性が高まり、グループとしての一体感やシナジーが失われやすい',
                                                '管理部門の重複や、グループ内の調整のコストが生じる'])],
                            '持株会社のメリットとデメリット')


# ------------------------------------------------ 2.2.6 機械的・有機的管理システム
def _woodward():
    o = []
    xs = [128, 220, 312]
    for x, s in zip(xs, ['単品・小バッチ', '大量生産', '装置生産']):
        _box(o, x - 44, 6, 88, 26, s, size=10.5)
    o.append(ARROW([(84, 44), (356, 44)], col='sub', sw=1.4, head=6))
    o.append(T(80, 48, '技術の複雑性', 'end', size=10))
    o.append(T(80, 78, '高業績の組織', 'end', size=10.5, bold=True))
    for x, s, col in zip(xs, ['有機的', '機械的', '有機的'], ['b', 'a', 'b']):
        _box(o, x - 40, 60, 80, 26, s, col=col, size=11, c0=col)
    o.append(T(80, 150, '傾向', 'end', size=10.5, bold=True))
    o.append(R(84, 98, 272, 104, fill='none', stroke='line', sw=0.8))
    for pts, col, dash in (([(xs[0], 186), (xs[1], 150), (xs[2], 114)], 'a', False),
                           ([(xs[0], 114), (xs[1], 150), (xs[2], 186)], 'b', True),
                           ([(xs[0], 174), (xs[1], 110), (xs[2], 182)], 'c', False)):
        _pline(o, pts, col, dash)
        for (a, b) in pts:
            _dot(o, a, b, col, r=3.2)
    o.append(T(8, 222, '━ 階層の数、管理者・監督者の比率、間接部門の労働者の比率', size=10, bold=True, col='a'))
    o.append(T(8, 237, '┅ 総費用に占める労務費の比率', size=10, bold=True, col='b'))
    o.append(T(8, 252, '━ 第一線の監督者の統制の範囲（大量生産で最も広い）', size=10, bold=True, col='c'))
    return _svg(360, 258, o, '技術の複雑性と組織（ウッドワード）')


FIG['kigyo.burns'] = grid(['観点', '機械的管理システム', '有機的管理システム'],
                          [['職務', '細かく専門化される', '柔軟に見直される'],
                           ['権限', '明確な権限の階層', '専門知識に基づく'],
                           ['伝達・調整', '上下の命令と報告。\n規則・手続きを重視', '横の（水平的な）コミュニケーション。\n命令ではなく、助言や情報の交換'],
                           ['仕事の\nとらえ方', '組織全体の目的から\n切り離された、\n抽象的なもの', '組織全体の状況と\n結びつけてとらえる'],
                           ['知識の\nありか', '階層の上位に集まる', 'ネットワークの\nどこにでもありうる'],
                           ['重視される\nこと', '上司への忠誠と服従。\n組織の中でしか\n通用しない知識や経験', '組織の課題や優れた仕事への\n献身（コミットメント）。\n組織の外でも通用する専門性'],
                           ['適する環境', '安定した環境', '変化が激しく、不確実な環境']],
                          [76, 128, 156], align=['l', 'l', 'l'], title='機械的管理システムと有機的管理システム（バーンズ＆ストーカー）', size=10.5,
                          hl_rows=(6,))
FIG['kigyo.contingency'] = grid(['研究者', '注目した条件', '主張'],
                                [['バーンズ＆ストーカー', '環境', '安定した環境では機械的、変化が激しく不確実な環境では有機的な管理システムが適する'],
                                 ['ウッドワード', '生産技術', '単品・小バッチ生産と装置生産では有機的、大量生産では機械的な組織が高い業績を上げていた'],
                                 ['ローレンス＆ローシュ', '環境の不確実性', '環境の不確実性に応じて、分化と統合の適切な水準が異なる'],
                                 ['トンプソン', '技術の中核', '組織は、技術の中核（テクニカル・コア）を環境の変動から守ろうとする（緩衝化）']],
                                [96, 88, 176], align=['l', 'l', 'l'], title='コンティンジェンシー理論の主な研究', size=10.5)
FIG['kigyo.woodward'] = _woodward()
FIG['kigyo.mintz5'] = grid(['組織の類型', '主な調整', '例・特徴'],
                           [['単純構造', '直接監督', 'トップが直接監督する小さな組織'],
                            ['機械的官僚制', '作業プロセスの標準化', '大量生産の工場'],
                            ['専門職的官僚制', 'スキルの標準化', '病院、大学'],
                            ['事業部制', 'アウトプットの標準化', '本社が事業部の成果（業績）を管理する'],
                            ['アドホクラシー', '相互調整', '専門家のプロジェクト・チーム型の組織']],
                           [104, 112, 144], align=['l', 'l', 'l'], title='ミンツバーグの組織の類型', size=10.5)


# ------------------------------------------------ 2.3.1 組織文化のレベル
def _schein():
    o = []
    cx = 110
    lv = [(14, 84, 40, 116, 'b', '人工物', '', '目に見える表層。建物やオフィスのつくり、服装、ロゴ、儀式、言葉づかい、物語など'),
          (84, 150, 116, 180, 'c', '標榜された価値観', '（信奉された価値観）', '戦略、目標、理念など、組織が公に掲げる価値観。実際の行動と一致しないこともある'),
          (150, 222, 180, 204, 'a', '背後に潜む基本的仮定', '（文化の本質）', '当然のこととして、無意識に受け入れられている信念や前提。最も変えにくい')]
    for (y1, y2, w1, w2, col, t1, t2, note) in lv:
        _poly(o, [(cx - w1 / 2, y1), (cx + w1 / 2, y1), (cx + w2 / 2, y2), (cx - w2 / 2, y2)], col, op=0.2)
        ym = (y1 + y2) / 2
        if t2:
            o.append(T(cx, ym - 2, t1, 'middle', size=11.5, bold=True))
            o.append(T(cx, ym + 13, t2, 'middle', size=10))
        else:
            o.append(T(cx, ym + 14, t1, 'middle', size=11.5, bold=True))
        ls = wrap(note, 126, 10)
        for j, ln in enumerate(ls):
            o.append(T(230, ym + 4 + (j - (len(ls) - 1) / 2) * 13, ln, size=10, col=('a' if col == 'a' else 'main'), bold=(col == 'a')))
    o.append(L(0, 84, 360, 84, col='b', sw=1.2, dash='6 4'))
    o.append(T(4, 79, '目に見える', size=9.5, col='b'))
    o.append(T(4, 98, '見えにくい', size=9.5, col='b'))
    o.append(T(180, 242, '下の（深い）レベルほど意識されにくく、変えにくい', 'middle', size=10.5, bold=True))
    return _svg(360, 248, o, '組織文化の3つのレベル（シャイン）')


def _schein_form():
    o = []
    _box(o, 4, 8, 160, 54, '外部環境への適応\n使命、戦略、目標、手段についての合意', col='b', size=10, c0='b')
    _box(o, 4, 74, 160, 72, '内部の統合\n共通の言葉、集団の境界、権力や地位の配分、報酬と罰の基準についての合意', col='c', size=10, c0='c')
    _box(o, 196, 26, 160, 62, '組織文化\n集団が問題の解決の中で学んだ、共有された基本的仮定のパターン', col='a', size=10, c0='a')
    o.append(ARROW([(166, 35), (194, 50)], sw=1.4, head=6))
    o.append(ARROW([(166, 110), (194, 70)], sw=1.4, head=6))
    o.append(ARROW([(276, 90), (276, 108)], sw=1.4, head=6))
    _box(o, 196, 110, 160, 60, 'うまく機能し、妥当とみなされる\n新しいメンバーに「正しい方法」として教えられる', size=10)
    return _svg(360, 176, o, '組織文化が形づくられる過程（シャイン）')


FIG['kigyo.schein3'] = _schein()
FIG['kigyo.schein_form'] = _schein_form()
FIG['kigyo.strong'] = quad([''], ['', ''], [[('プラス', '価値観が広く共有され、強く信じられている。行動の一貫性が高まり、調整の負担が減る', 'b'),
                                             ('マイナス（逆機能）', '環境が変わったときに、変化を妨げることがある', 'a')]], title='強い文化の功罪', size=10.5)


# ------------------------------------------------ 2.3.2 組織文化と経営戦略
def _identity():
    o = []
    _box(o, 100, 8, 160, 30, '外部のイメージ（評判）', col='sub', size=10.5)
    _box(o, 100, 82, 160, 30, '組織アイデンティティ', col='a', size=11, c0='a')
    _box(o, 100, 156, 160, 30, '組織文化（内部）', col='c', size=10.5)
    for y1, y2 in ((38, 82), (112, 156)):
        o.append(ARROW([(160, y1 + 1), (160, y2 - 1)], sw=1.4, head=6))
        o.append(ARROW([(200, y2 - 1), (200, y1 + 1)], sw=1.4, head=6))
    o.append(T(152, 64, '外部の見方を映し出す', 'end', size=10.5))
    o.append(T(208, 64, '自らのイメージを印象づける', size=10.5))
    o.append(T(152, 138, '文化に埋め込まれる', 'end', size=10.5))
    o.append(T(208, 138, '文化についての理解を表す', size=10.5))
    return _svg(360, 192, o, '組織アイデンティティ（ハッチ＆シュルツ）')


FIG['kigyo.strongcult'] = flow(['強い共有価値が優れた業績を生む\n（ピーターズ＆ウォーターマン、ディール＆ケネディ）',
                                '強い文化の弱点\n環境が変わると、成功体験への固執が変化を妨げる',
                                '適応的な文化（コッター＆ヘスケット）\n業績に結びつくのは、単に強い文化ではなく、環境の変化に適応できる文化'],
                               per_row=1, title='強い文化と業績')
FIG['kigyo.cvf'] = quad(['柔軟性', '安定・統制'], ['内部志向', '外部志向'],
                        [[('クラン（家族型）', '協力と一体感を重視。リーダーは世話役、助言者（メンター）、親のような存在', 'b'),
                          ('アドホクラシー（革新型）', '創造と挑戦を重視。リーダーはリスクをとる企業家、革新者、先見性のある人', 'c')],
                         [('ヒエラルキー（官僚型）', '規則と効率を重視。リーダーは規則や手続きに沿って調整し、監視する管理者', 'sub'),
                          ('マーケット（市場型）', '競争と成果を重視。リーダーは結果を厳しく求める推進者、競争者', 'a')]],
                        title='競合価値観フレームワーク（キャメロン＆クイン）', lw=56, size=10.5)
FIG['kigyo.identity'] = _identity()
FIG['kigyo.socialize'] = timeline([(0, '予期的社会化', '組織に入る前に\n学び、期待を持つ', 'sub'), (0.36, '採用・入社', 'RJPで\n衝撃を和らげる', 'b'),
                                   (0.7, '組織社会化', '価値観や規範を\n学ぶ', 'c'), (1, '組織再社会化', '転職先で\nあらためて適応', 'a')],
                                  title='組織社会化の流れ', spans=[(0.36, 0.7, '社会化エージェント（上司・メンター・同僚）が助ける', 'c')])


# ------------------------------------------------ 2.3.3 組織文化の変革
def _anxiety():
    o = []
    o.append(R(60, 50, 70, 80, fill='c', stroke='c', op=0.3))
    o.append(R(230, 80, 70, 50, fill='a', stroke='a', op=0.3))
    o.append(L(40, 130, 320, 130, col='main', sw=1.2))
    o.append(T(180, 108, '＞', 'middle', size=28, bold=True))
    o.append(ARROW([(95, 46), (95, 18)], col='sub', sw=1.4, head=6, dash='4 3'))
    o.append(T(104, 30, '危機感を強める', size=10, col='sub'))
    o.append(T(265, 32, '訓練や支援で', 'middle', size=10.5, bold=True, col='b'))
    o.append(T(265, 46, '心理的安全性を整え、下げる', 'middle', size=10, col='b'))
    o.append(ARROW([(265, 54), (265, 88)], col='b', sw=2, head=7))
    o.append(T(95, 148, '生存の不安', 'middle', size=11, bold=True, col='c'))
    o.append(T(95, 162, '変わらなければ、という不安', 'middle', size=10))
    o.append(T(265, 148, '学習の不安', 'middle', size=11, bold=True, col='a'))
    o.append(T(265, 162, '新しく学ぶことへの不安', 'middle', size=10))
    return _svg(360, 168, o, '変革の条件：生存の不安＞学習の不安')


FIG['kigyo.embed'] = _lists([('一次的な仕組み', 'a', ['リーダーが何に注目し、何を測り、何を管理するか', '重大な出来事や危機への対応', '資源の配分の仕方',
                                                    'リーダー自身の行動による手本や指導', '報酬や地位の配分の基準', '採用、昇進、退職の基準']),
                             ('二次的な仕組み（一次的な仕組みと一致するときに働く）', 'c', ['組織の構造', '制度や手続き', '儀式', '建物などの物理的な空間',
                                                                              '物語や伝説', '理念や憲章などの公式な表明'])],
                            'リーダーが文化を埋め込む仕組み（シャイン）')
FIG['kigyo.stage3'] = grid(['段階', '文化の働き', '文化を変える仕組み'],
                           [['創業期・初期の成長期', '創業者がつくる。組織の独自の強みとアイデンティティの源泉になり、組織をまとめる',
                             '自然な進化。文化の中で育ちつつ新しい考え方を持つ人材（混成型の人材）の登用'],
                            ['中年期', '部門ごとに下位文化が育ち、文化の統合が弱まる',
                             '組織開発（OD）などの計画的変革、新しい技術の導入、不祥事（スキャンダル）や神話の崩壊による変化、段階的な変化'],
                            ['成熟期・衰退期', '革新を妨げ、過去の栄光を守るものになりやすい',
                             '深いレベルの変革には、強制的な説得、企業再生（ターンアラウンド）、経営陣の大幅な交代や組織の再編成による破壊と再生']],
                           [76, 132, 152], align=['l', 'l', 'l'], title='成長段階と文化の変革（シャイン）', size=10.5)
FIG['kigyo.lewin3'] = _flow([('解凍\n今のやり方では問題があるという情報で、生存の不安が学習の不安を上回る', 'c'),
                             ('学習\nロールモデルを見習い同一視する。または、自ら環境を探索し、試行錯誤で学ぶ', 'b'),
                             ('再凍結\n新しい行動が成果を生み、自己像と矛盾せず、周囲の重要な人々に認められると定着する', 'a')],
                            '文化変革の進め方（レヴィンの3段階モデル）', per_row=1)
FIG['kigyo.anxiety'] = _anxiety()


# ------------------------------------------------ 2.4.1 意思決定
def _garbage():
    o = [T(180, 16, '組織化された無秩序', 'middle', size=12, bold=True, col='a'),
         T(180, 33, '目的があいまい／手段（技術）が不明確／参加者が流動的', 'middle', size=10.5)]
    o.append(R(132, 46, 96, 7, fill='sub', stroke='main', sw=1, rx=2))
    o.append('<path d="M138 55L222 55L212 146L148 146Z" style="fill:%s;fill-opacity:0.12;stroke:%s" stroke-width="1.3"/>' % (_c('sub'), _c('main')))
    o.append(T(180, 96, '別々に', 'middle', size=10.5))
    o.append(T(180, 111, '流れ込む', 'middle', size=10.5))
    for (y, s, side) in ((76, '問題', 'L'), (118, '解（解決策）', 'L'), (76, '参加者', 'R'), (118, '選択の機会', 'R')):
        if side == 'L':
            o.append(T(100, y + 4, s, 'end', size=11, bold=True))
            o.append(ARROW([(104, y), (139 + (y - 55) / 91 * 10, y)], col='c', sw=1.6, head=6))
        else:
            o.append(T(260, y + 4, s, size=11, bold=True))
            o.append(ARROW([(256, y), (221 - (y - 55) / 91 * 10, y)], col='c', sw=1.6, head=6))
    o.append(ARROW([(180, 148), (180, 166)], sw=1.4, head=6))
    _box(o, 60, 168, 240, 26, '偶然に結びついて、意思決定がなされる', col='a', size=11)
    return _svg(360, 198, o, 'ゴミ箱モデル（コーエン、マーチ、オルセン）')


def _prospect():
    o = []
    cx, cy, sx, sy = 180, 112, 16, 9
    o.append(ARROW([(14, cy), (348, cy)], sw=1.2, head=6))
    o.append(ARROW([(cx, 228), (cx, 14)], sw=1.2, head=6))
    gain = [(cx + x * sx, cy - 6 * (x / 10) ** 0.6 * sy) for x in [i / 4 for i in range(0, 41)]]
    loss = [(cx - x * sx, cy + 12 * (x / 10) ** 0.6 * sy) for x in [i / 4 for i in range(0, 33)]]
    _pline(o, gain, 'b')
    _pline(o, loss, 'a')
    g5, l5 = cy - 6 * 0.5 ** 0.6 * sy, cy + 12 * 0.5 ** 0.6 * sy
    o.append(L(cx + 80, cy, cx + 80, g5, col='b', dash='3 3', sw=1.2))
    o.append(L(cx - 80, cy, cx - 80, l5, col='a', dash='3 3', sw=1.2))
    o.append(T(cx + 86, cy - 14, '利益の価値', size=9.5, col='b'))
    o.append(T(cx - 86, cy + 36, '損失の価値', 'end', size=9.5, col='a'))
    o.append(T(cx - 86, cy + 49, '（より大きい）', 'end', size=9.5, col='a'))
    o.append(T(352, 40, '利益の場面：リスクを避ける', 'end', size=10.5, bold=True, col='b'))
    o.append(T(190, 218, '損失の場面：リスクをとる', size=10.5, bold=True, col='a'))
    o.append(T(346, cy + 16, '利益', 'end', size=11, bold=True))
    o.append(T(16, cy + 16, '損失', size=11, bold=True))
    o.append(T(186, 22, '価値（感じ方）', size=10.5, bold=True))
    o.append(T(186, cy + 14, '参照点', size=9.5))
    o.append(T(180, 242, '同じ額でも、利益より損失を大きく感じる（損失回避）', 'middle', size=10.5, bold=True))
    return _svg(360, 248, o, 'プロスペクト理論の価値関数（模式図）')


def _satisfice():
    o = []
    base, k = 150, 1.2
    vals = [42, 58, 74, 90, 66]
    cols = ['sub', 'sub', 'b', 'a', 'sub']
    for i, (v, col) in enumerate(zip(vals, cols)):
        x = 44 + i * 62
        o.append(R(x, base - v * k, 44, v * k, fill=col, stroke=(col if col != 'sub' else 'main'), op=(0.3 if col != 'sub' else 0.15), sw=1))
        o.append(T(x + 22, base + 15, '案%d' % (i + 1), 'middle', size=10.5))
    o.append(L(34, base, 350, base, col='main', sw=1.2))
    o.append(L(34, base, 34, 14, col='main', sw=1.2))
    o.append(T(40, 14, '案のよさ', size=10))
    o.append(L(34, base - 65 * k, 350, base - 65 * k, col='c', sw=1.4, dash='5 3'))
    o.append(T(350, base - 65 * k - 5, '満足の基準', 'end', size=10.5, bold=True, col='c'))
    o.append(ARROW([(44, base + 26), (298, base + 26)], col='sub', sw=1.2, head=6))
    o.append(T(304, base + 30, '検討の順番', size=9.5, col='sub'))
    o.append(T(4, base + 50, '満足化（経営人）：基準を満たす案3が見つかった時点で選ぶ', size=10.5, bold=True, col='b'))
    o.append(T(4, base + 67, '最適化（経済人）：すべての案を比べて、最善の案4を選ぶ', size=10.5, bold=True, col='a'))
    return _svg(360, base + 74, o, '最適化と満足化（模式図）')


FIG['kigyo.satisfice'] = _satisfice()
FIG['kigyo.premise'] = grid(['', '事実前提', '価値前提'],
                            [['何についての前提か', '手段や因果関係', '目的や規範'],
                             ['確かめられるか', '観察や経験によって、正しいかどうかを確かめられる', '事実によって、正しいかどうかを確かめることはできない'],
                             ['例', '「値下げすれば、販売数量が増える」', '「短期の利益より、顧客の信頼を優先する」']],
                            [96, 132, 132], align=['l', 'l', 'l'], title='事実前提と価値前提（サイモン）', size=10.5)
FIG['kigyo.influence'] = grid(['仕組み', '意思決定の前提への影響'],
                              [['権限', '上司が示す前提を、部下が自分で一つひとつ吟味せずに受け入れる'],
                               ['コミュニケーション', '助言や情報を伝える'],
                               ['訓練', '判断に必要な知識や考え方の枠組み（前提）を、あらかじめ身につけさせる'],
                               ['能率の基準', '限られた資源で成果を最大にする案を選ぶよう求める'],
                               ['組織への一体化（忠誠心）', '組織の目的を自分の価値前提として受け入れる。進むと、組織の目的と個人の目的のずれが小さくなる']],
                              [112, 248], align=['l', 'l'], title='組織がメンバーの意思決定に影響を与える仕組み', size=10.5)
FIG['kigyo.program'] = grid(['', '定型的（プログラム化された）', '非定型的'],
                            [['問題', '繰り返し起こる問題', '新しい問題や、構造があいまいな問題'],
                             ['進め方', 'あらかじめ決めた手順（プログラム）に従う。組織は行動プログラムのレパートリーを用意し、代替案の集合として使う',
                              'その都度、探索と判断を行う。主に上位の管理者が担う']],
                            [56, 160, 144], align=['l', 'l', 'l'], title='定型的意思決定と非定型的意思決定（サイモン）', size=10.5)
FIG['kigyo.gresham'] = _flow([('原因\n管理者が、日常の定型業務に追われる', 'c'), ('結果\n長期の計画や革新の検討が、おろそかになる', 'a'),
                              ('対策\n計画を専門に担う部門や担当者を置き、定型業務から切り離す', 'b')],
                             '計画のグレシャムの法則（マーチ＆サイモン）')
FIG['kigyo.garbage'] = _garbage()
FIG['kigyo.bias'] = grid(['名称', '内容'],
                         [['代表性ヒューリスティック', '典型例に似ているかどうかで、確率を判断する'],
                          ['利用可能性ヒューリスティック', '思い出しやすい事例ほど、起こりやすいと判断する'],
                          ['アンカリング', '最初に示された数値に、判断が引きずられる'],
                          ['確証バイアス', '自分の考えを支持する情報ばかりを集める'],
                          ['サンクコスト効果', '回収できない過去の投資にとらわれて、続ける判断をする'],
                          ['フレーミング効果', '同じ内容でも、示し方（利益の面か、損失の面か）で選択が変わる'],
                          ['後知恵バイアス', '結果が分かった後で、その結果は初めから予測できたと思い込む'],
                          ['感情ヒューリスティック', 'そのときの気分や、対象への好き嫌いの感情に頼って判断する']],
                         [128, 232], align=['l', 'l'], title='ヒューリスティクスと認知バイアス', size=10.5)
FIG['kigyo.prospect'] = _prospect()
FIG['kigyo.yerkes'] = chart([([(x / 10, 100 * math.exp(-((x / 10 - 5) / 2.2) ** 2)) for x in range(0, 101)], 'a', False)],
                            0, 10, 0, 112, xlab='緊張（覚醒）の程度', ylab='成果',
                            labels=[(0.3, 20, '低すぎる', 'start', 'main'), (9.7, 20, '高すぎる', 'end', 'main'), (5.4, 98, '成果が最も高い', 'start', 'a')],
                            vlines=[(5, '適度')], w=360, h=200, title='ヤーキーズ＝ドッドソンの法則（逆U字）', zero=False)
FIG['kigyo.karasek'] = quad(['要求度が高い', '要求度が低い'], ['裁量が小さい', '裁量が大きい'],
                            [[('高ストレイン', 'ストレスが最も高まる', 'a'), ('能動的（アクティブ）', '要求は高いが、裁量で対処できる', 'b')],
                             [('受動的（パッシブ）', '要求も裁量も小さい', 'sub'), ('低ストレイン', '要求が低く、裁量が大きい', 'b')]],
                            title='仕事の要求度－コントロール（裁量）モデル（カラセック）', lw=64, size=10.5)


# ------------------------------------------------ 2.4.2 モチベーション
def _maslow():
    o = []
    pw, x0, top, lh = 216, 4, 26, 36
    cx = x0 + pw / 2
    o.append(T(cx, 15, '欲求段階説（マズロー）', 'middle', size=10.5, bold=True))
    o.append(T(296, 15, 'ERG理論（アルダファー）', 'middle', size=10.5, bold=True))
    names = ['自己実現の欲求', '承認（尊重）の欲求', '社会的欲求（所属と愛）', '安全の欲求', '生理的欲求']
    for i, s in enumerate(names):
        wt, wb = pw * (0.30 + 0.70 * i / 5), pw * (0.30 + 0.70 * (i + 1) / 5)
        y = top + i * lh
        _poly(o, [(cx - wt / 2, y), (cx + wt / 2, y), (cx + wb / 2, y + lh - 2), (cx - wb / 2, y + lh - 2)], 'sub', op=0.14)
        o.append(T(cx, y + lh / 2 + 3, s, 'middle', size=10.5, bold=True))
    erg = [(top, top + 1.5 * lh, '成長（G）', '自己の尊重、自己実現', 'a'),
           (top + 1.5 * lh, top + 3.5 * lh, '関係（R）', '他者からの承認、\n所属と愛、\n対人関係での安全', 'c'),
           (top + 3.5 * lh, top + 5 * lh, '生存（E）', '生理的欲求、\n物質的な安全', 'b')]
    for (y1, y2, t1, t2, col) in erg:
        _box(o, 236, y1 + 2, 120, y2 - y1 - 4, t1 + '\n' + t2, col=col, size=10, c0=col)
    for yy in (top + 1.5 * lh, top + 3.5 * lh):
        f = (yy - top) / (5 * lh)
        wx = pw * (0.30 + 0.70 * f)
        o.append(L(cx + wx / 2 + 2, yy, 234, yy, col='sub', dash='3 3', sw=1))
    o.append(T(cx, top + 5 * lh + 16, '↑ 低次がある程度満たされると高次が現れる', 'middle', size=9.5))
    o.append(T(296, top + 5 * lh + 16, '同時に働く・退行もある', 'middle', size=9.5))
    return _svg(360, top + 5 * lh + 22, o, '欲求段階説とERG理論')


def _herzberg():
    o = [T(8, 18, '衛生要因（不満足を防ぐ）', size=11.5, bold=True, col='c'),
         T(8, 34, '給与、作業条件、会社の方針と管理、監督、対人関係など', size=10)]
    o.append(ARROW([(20, 50), (340, 50)], col='c', sw=3, head=8))
    o.append(T(20, 67, '不満足', size=10.5, bold=True))
    o.append(T(340, 67, '不満足がない（満足ではない）', 'end', size=10.5, bold=True))
    o.append(T(8, 96, '動機づけ要因（満足をもたらす）', size=11.5, bold=True, col='b'))
    o.append(T(8, 112, '達成、承認、仕事そのもの、責任、昇進、成長', size=10))
    o.append(ARROW([(20, 128), (340, 128)], col='b', sw=3, head=8))
    o.append(T(20, 145, '満足がない', size=10.5, bold=True))
    o.append(T(340, 145, '満足（意欲が高まる）', 'end', size=10.5, bold=True))
    o.append(T(180, 172, '衛生要因を改善しても不満が減るだけで、意欲は高まらない', 'middle', size=10.5, bold=True, col='a'))
    return _svg(360, 180, o, '二要因理論（ハーズバーグ）')


def _expect():
    o = []
    _box(o, 4, 44, 80, 30, '努力', size=11.5)
    _box(o, 140, 44, 80, 30, '成果', size=11.5)
    _box(o, 276, 40, 80, 38, '報酬\n誘意性＝魅力', col='b', size=10.5, c0='b')
    o.append(ARROW([(86, 59), (138, 59)], col='a', sw=1.8, head=7))
    o.append(ARROW([(222, 59), (274, 59)], col='c', sw=1.8, head=7))
    o.append(T(112, 34, '期待', 'middle', size=11.5, bold=True, col='a'))
    o.append(T(248, 34, '道具性', 'middle', size=11.5, bold=True, col='c'))
    o.append(T(112, 94, '努力すれば成果が', 'middle', size=10))
    o.append(T(112, 107, '上がる見込み', 'middle', size=10))
    o.append(T(248, 94, '成果が報酬に', 'middle', size=10))
    o.append(T(248, 107, 'つながる見込み', 'middle', size=10))
    o.append(R(30, 122, 300, 48, fill='a', stroke='a', op=0.1, rx=6))
    o.append(T(180, 143, '動機づけの強さ ＝ 期待 × 誘意性', 'middle', size=13, bold=True))
    o.append(T(180, 161, 'どちらかがゼロなら、動機づけは生まれない', 'middle', size=10.5))
    return _svg(360, 176, o, '期待理論（ブルーム）')


def _equity():
    o = []
    for cx, who in ((90, '自分'), (270, '他人（比較の相手）')):
        o.append(T(cx, 15, who, 'middle', size=11, bold=True))
        o.append(T(cx, 36, '結果（報酬など）', 'middle', size=10.5))
        o.append(L(cx - 62, 44, cx + 62, 44, col='main', sw=1.3))
        o.append(T(cx, 61, '投入（努力など）', 'middle', size=10.5))
    o.append(ARROW([(158, 44), (202, 44)], col='a', sw=1.4, head=5))
    o.append(ARROW([(202, 44), (158, 44)], col='a', sw=1.4, head=5))
    o.append(T(180, 36, '比べる', 'middle', size=10, bold=True, col='a'))
    for x, t, col in ((4, '比率が等しい\n公平', 'b'), (124, '自分の比率が低い\n不公平（報われていない）', 'a'), (244, '自分の比率が高い\n不公平（報われすぎ）', 'c')):
        _box(o, x, 78, 112, 52, t, col=col, size=10.5, c0=col)
    o.append(T(180, 154, '不公平と感じると、それを解消する行動をとる', 'middle', size=10.5, bold=True))
    o.append(T(180, 170, '（努力を減らす、比較の相手を変えるなど）', 'middle', size=10))
    return _svg(360, 176, o, '公平理論（アダムス）')


def _jobdesign():
    o = []
    o.append(ARROW([(14, 174), (14, 22)], col='sub', sw=1.2, head=6))
    o.append(T(20, 16, '権限と責任（垂直）', size=9.5, col='sub'))
    o.append(ARROW([(14, 174), (218, 174)], col='sub', sw=1.2, head=6))
    o.append(T(218, 190, '仕事の種類（水平）', 'end', size=9.5, col='sub'))
    _box(o, 24, 106, 84, 40, '今の職務', size=11)
    _box(o, 128, 106, 84, 40, '同じレベルの\n仕事を加える', col='c', size=10, dash=True, bold0=False)
    o.append(ARROW([(108, 126), (126, 126)], col='c', sw=1.6, head=6))
    o.append(T(170, 162, '職務拡大', 'middle', size=11, bold=True, col='c'))
    _box(o, 24, 34, 84, 40, '計画や評価の\n権限と責任', col='b', size=10, dash=True, bold0=False)
    o.append(ARROW([(66, 104), (66, 76)], col='b', sw=1.6, head=6))
    o.append(T(116, 50, '職務充実', size=11, bold=True, col='b'))
    o.append(T(116, 65, '（動機づけ要因', size=9.5))
    o.append(T(116, 78, '　に基づく）', size=9.5))
    o.append(L(226, 8, 226, 196, dash='3 3', sw=0.8))
    o.append(T(293, 40, 'ジョブ・', 'middle', size=11, bold=True, col='a'))
    o.append(T(293, 55, 'ローテーション', 'middle', size=11, bold=True, col='a'))
    for k, s in enumerate('ABC'):
        _box(o, 234 + k * 42, 106, 36, 40, '職務\n' + s, size=10, bold0=False)
    o.append(ARROW([(250, 148), (250, 160), (292, 160), (292, 149)], col='a', sw=1.3, head=5))
    o.append(ARROW([(298, 148), (298, 166), (336, 166), (336, 149)], col='a', sw=1.3, head=5))
    o.append(T(293, 182, '同じレベルの職務の間で', 'middle', size=9.5))
    o.append(T(293, 195, '定期的に配置を換える', 'middle', size=9.5))
    return _svg(360, 200, o, '職務拡大・職務充実・ジョブ・ローテーション')


def _jcm():
    o = [T(73, 14, '中核的な職務特性', 'middle', size=10.5, bold=True), T(216, 14, '重要な心理状態', 'middle', size=10.5, bold=True),
         T(322, 14, '成果', 'middle', size=10.5, bold=True)]
    left = [(24, '技能の多様性'), (56, 'タスク・アイデンティティ'), (88, 'タスクの重要性'), (128, '自律性'), (168, 'フィードバック')]
    for y, s in left:
        _box(o, 4, y, 138, 26, s, col='c', size=10, op=0.14)
    mid = [(56, '仕事の有意味感'), (128, '結果への責任感'), (168, '結果についての知識')]
    for y, s in mid:
        _box(o, 166, y, 100, 26, s, col='b', size=10, op=0.14)
    _box(o, 288, 70, 68, 102, '内発的\n動機づけ\n仕事の質\n満足\nが高まる', col='a', size=10, bold0=False)
    for y in (37, 69, 101):
        o.append(ARROW([(143, y), (164, 69 + (y - 69) * 0.25)], sw=1.2, head=5))
    o.append(ARROW([(143, 141), (164, 141)], sw=1.2, head=5))
    o.append(ARROW([(143, 181), (164, 181)], sw=1.2, head=5))
    for y, ty in ((69, 96), (141, 124), (181, 150)):
        o.append(ARROW([(267, y), (286, ty)], sw=1.2, head=5))
    o.append(T(180, 214, '成長欲求の強い人ほど、効果が大きい', 'middle', size=10.5, bold=True))
    o.append(T(180, 232, 'MPS＝（多様性＋アイデンティティ＋重要性）÷3×自律性×フィードバック', 'middle', size=9.5))
    return _svg(360, 238, o, '職務特性モデル（ハックマン＆オールダム）')


FIG['kigyo.motiv_map'] = htree(('動機づけの理論', 'sheet',
                                [('内容理論\n何が人を動機づけるか', 'b', [('欲求段階説（マズロー）', 'b', []), ('ERG理論（アルダファー）', 'b', []),
                                                                     ('二要因理論（ハーズバーグ）', 'b', []), ('X理論・Y理論（マグレガー）', 'b', []),
                                                                     ('達成動機理論（マクレランド）', 'b', [])]),
                                 ('過程理論\nどのように動機づけられるか', 'c', [('期待理論（ブルーム）', 'c', []), ('ポーター＆ローラーのモデル', 'c', []),
                                                                         ('公平理論（アダムス）', 'c', []), ('目標設定理論（ロック＆レイサム）', 'c', [])]),
                                 ('内発的動機づけ', 'a', [('アンダーマイニング効果（デシ）', 'a', []), ('自己決定理論（デシ＆ライアン）', 'a', [])])]),
                               title='動機づけの理論の全体像', colw=(80, 96, 160), size=10)
FIG['kigyo.maslow'] = _maslow()
FIG['kigyo.herzberg'] = _herzberg()
FIG['kigyo.xy'] = quad([''], ['', ''], [[('X理論', '人は本来仕事が嫌いで、命令と統制が必要', 'a'),
                                         ('Y理論', '人は条件しだいで、自ら目標に向かって働き、責任をとる。マグレガーは、Y理論に立つ管理（目標による管理など）を勧めた', 'b')]],
                       title='X理論とY理論（マグレガー）', size=10.5)
FIG['kigyo.mcclelland'] = grid(['欲求', '内容'],
                               [['達成欲求', '高い人は、適度に難しい目標と、結果のフィードバックを好む'],
                                ['権力欲求', '他者に影響を与え、支配したい'],
                                ['親和欲求', '他者と友好的な関係を築きたい']],
                               [90, 270], align=['l', 'l'], title='達成動機理論（マクレランド）の3つの欲求', size=10.5)
FIG['kigyo.expect'] = _expect()
FIG['kigyo.porter'] = _flow(['努力', '業績\n（成果）', '報酬\n公平と\n感じられる', ('満足', 'b')], 'ポーター＆ローラーのモデル', per_row=4)
FIG['kigyo.equity'] = _equity()
FIG['kigyo.goal'] = chart([([(x / 10, 25 + 65 * (x / 75)) for x in range(0, 76)] + [(7.5 + x / 10, 90 - 55 * (x / 30)) for x in range(1, 31)], 'b', False)],
                          0, 10.8, 0, 112, xlab='目標の難しさ', ylab='成果',
                          labels=[(0.6, 100, '具体的で難しい目標ほど成果が高い', 'start', 'b'), (0.3, 12, '易しい目標', 'start', 'main'),
                                  (7.65, 22, '難しすぎる目標は', 'start', 'a'), (7.65, 10, '受け入れられない', 'start', 'a')],
                          vlines=[(7.5, '受け入れられる限界')], w=360, h=210, title='目標設定理論（模式図）', zero=False)
FIG['kigyo.underm'] = htree(('外的な報酬', 'sheet',
                             [('統制的な側面として受け取る\n（行動を操ろうとしている）', 'a', [('自己決定の感覚が損なわれ、\n内発的動機づけが下がる\n（アンダーマイニング効果）', 'a', [])]),
                              ('情報的な側面として受け取る\n（有能さを伝えている）', 'b', [('自己決定を損なわず、\n内発的動機づけが高まりうる\n（褒め言葉など：\nエンハンシング効果）', 'b', [])])]),
                            title='外的な報酬と内発的動機づけ（認知的評価理論）', colw=(56, 144, 136), size=10)
FIG['kigyo.jobdesign'] = _jobdesign()
FIG['kigyo.jcm'] = _jcm()


# ------------------------------------------------ 2.4.3 組織コミットメント
FIG['kigyo.allen3'] = grid(['種類', '心の声', '生まれ方・特徴'],
                           [['情緒的', '「とどまりたい」', '組織への愛着や一体感から生まれる。業績や協力的な行動と最も強く結びつく。ストレスと負の関係'],
                            ['継続的\n（存続的）', '「とどまる\n必要がある」', '辞めると失うもの（給与、退職金、人間関係、これまでの投資）が大きい。年功的な賃金や、その組織でしか評価されない技能で強まる。ストレスと正の関係'],
                            ['規範的', '「とどまる\nべきだ」', '恩義や義務感から生まれる。1つの組織にとどまるのが正しいという、家族や社会の規範を身につけることでも強まる']],
                           [66, 108, 186], align=['l', 'l', 'l'], title='組織コミットメントの3次元モデル（アレン＆メイヤー）', size=10.5)
FIG['kigyo.engage'] = quad([''], ['', ''], [[('ワーク・エンゲイジメント', '活力（仕事から活力を得る）、熱意（誇りとやりがい）、没頭（熱心に取り組む）', 'b'),
                                             ('バーンアウト（対極）', '情緒的消耗感、脱人格化、個人的達成感の低下', 'a')]],
                           title='ワーク・エンゲイジメントとバーンアウト', size=10.5)
FIG['kigyo.ocb'] = grid(['次元', '例'],
                        [['利他主義', '困っている同僚を手助けする'],
                         ['誠実さ', '上司が見ていなくても規則を守り、勤務時間を仕事に使う'],
                         ['スポーツマン精神', '多少の不便や不満に、苦情を言わずに耐える'],
                         ['丁重さ', '関係者に前もって報告や相談をし、問題が起きないよう配慮する'],
                         ['市民道徳', '会議への出席や情報の収集など、組織の運営に責任を持って参加する']],
                        [96, 264], align=['l', 'l'], title='組織市民行動（OCB）の5つの次元（オーガン）', size=10.5)
FIG['kigyo.psycon'] = quad([''], ['', ''], [[('取引的契約', '短期の経済的な交換が中心', 'c'), ('関係的契約', '長期の信頼に基づく', 'b')]],
                           title='心理的契約（ルソー）の2つの型', size=10.5)
