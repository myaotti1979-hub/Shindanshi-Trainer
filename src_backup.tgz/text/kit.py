# 図表の共通部品（箱、箇条書きの列、流れ図など）。fig_*.py から読み込んで使う
import math
from vis import ARROW, R, T, L, _svg, _c, wrap, tw


def _lines(text, w, size):
    """\\n で分けた段落ごとに折り返し、(行, 段落の番号) を返す"""
    out = []
    for i, p in enumerate(str(text).split('\n')):
        for ln in wrap(p, w, size):
            out.append((ln, i))
    return out


def _dashrect(x, y, w, h, col='main', rx=6, sw=1.3, dash='5 4'):
    return ('<rect x="%s" y="%s" width="%s" height="%s" rx="%s" style="fill:none;stroke:%s" stroke-width="%s" stroke-dasharray="%s"/>'
            % (round(x, 1), round(y, 1), round(w, 1), round(h, 1), rx, _c(col), sw, dash))


def _box(o, x, y, w, h, text, col=None, size=10.5, lh=None, op=0.16, dash=False, bold0=True, c0=None):
    """文字入りの箱。1段落目を太字にする。col があれば薄く色をつける"""
    lh = lh or round(size * 1.34, 1)
    if dash:
        o.append(R(x, y, w, h, fill='sheet', stroke=None, rx=6))
        if col:
            o.append(R(x, y, w, h, fill=col, stroke=None, rx=6, op=op))
        o.append(_dashrect(x, y, w, h, col=col or 'main'))
    elif col is None:
        o.append(R(x, y, w, h, fill='sheet', stroke='main', sw=1.2, rx=6))
    else:
        o.append(R(x, y, w, h, fill='sheet', stroke=None, rx=6))
        o.append(R(x, y, w, h, fill=col, stroke=col, sw=1.2, rx=6, op=op))
    ls = _lines(text, w - 10, size)
    n = len(ls)
    for j, (ln, pi) in enumerate(ls):
        yy = y + h / 2 + size * 0.36 + (j - (n - 1) / 2) * lh
        o.append(T(x + w / 2, yy, ln, 'middle', size=size, bold=(bold0 and pi == 0), col=(c0 if (c0 and pi == 0) else 'main')))


def _lists(cols, title, w=360, size=10.5, gap=8, ws=None):
    """箇条書きの列を横に並べる。cols: [(見出し, 色, [項目])]"""
    n = len(cols)
    ws = ws or [(w - gap * (n - 1)) / n] * n
    lh = round(size * 1.36, 1)
    blocks = []
    H = 0
    for (hd, col, items), cw in zip(cols, ws):
        hl = wrap(hd, cw - 12, size + 0.5)
        its = [wrap(it, cw - 14 - size, size) for it in items]
        hh = 10 + len(hl) * lh + 6
        ih = sum(len(x) for x in its) * lh + 4 * (len(its) - 1) + 12
        blocks.append((col, hl, its, hh, cw))
        H = max(H, hh + ih)
    o = []
    x = 0
    for (col, hl, its, hh, cw) in blocks:
        o.append(R(x + 1, 1, cw - 2, H, fill=col, stroke=col, op=0.1, rx=6, sw=1.2))
        for j, ln in enumerate(hl):
            o.append(T(x + cw / 2, 1 + 10 + size + j * lh, ln, 'middle', bold=True, col=col, size=size + 0.5))
        o.append(L(x + 8, hh - 1, x + cw - 8, hh - 1, col=col, sw=0.8))
        yy = hh + size + 6
        for ls in its:
            o.append(T(x + 6, yy, '・', size=size))
            for k, ln in enumerate(ls):
                o.append(T(x + 6 + size, yy + k * lh, ln, size=size))
            yy += len(ls) * lh + 4
        x += cw + gap
    return _svg(w, H + 2, o, title)


def _flow(steps, title, per_row=3, size=10.5, bh=None, gapx=20, gapy=24, w=360, bold0=True):
    """流れ図。steps: 文字（または (文字, 色)）。1段落目を太字にする"""
    bw = (w - gapx * (per_row - 1) - 4) / per_row
    lh = round(size * 1.34, 1)
    txt = [s[0] if isinstance(s, tuple) else s for s in steps]
    nl = max(len(_lines(s, bw - 10, size)) for s in txt)
    bh = bh or max(40, nl * lh + 14)
    nrows = (len(steps) + per_row - 1) // per_row
    h = nrows * bh + (nrows - 1) * gapy + 4
    o = []
    pos = []
    for i, s in enumerate(steps):
        r, c = divmod(i, per_row)
        x, y = 2 + c * (bw + gapx), 2 + r * (bh + gapy)
        col = s[1] if isinstance(s, tuple) else None
        _box(o, x, y, bw, bh, txt[i], col=col, size=size, c0=col, bold0=bold0)
        pos.append((x, y))
    for i in range(len(steps) - 1):
        (x1, y1), (x2, y2) = pos[i], pos[i + 1]
        if y1 == y2:
            o.append(ARROW([(x1 + bw + 2, y1 + bh / 2), (x2 - 2, y2 + bh / 2)], sw=1.4, head=6))
        elif x1 == x2:
            o.append(ARROW([(x1 + bw / 2, y1 + bh + 1), (x2 + bw / 2, y2 - 2)], sw=1.4, head=6))
        else:
            o.append(ARROW([(x1 + bw / 2, y1 + bh + 1), (x1 + bw / 2, y1 + bh + gapy / 2), (x2 + bw / 2, y1 + bh + gapy / 2), (x2 + bw / 2, y2 - 2)],
                           sw=1.4, head=6))
    return _svg(w, h, o, title)


def _poly(o, pts, col, op=0.2, sw=1.2):
    o.append('<path d="M%s Z" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="%s"/>' % (
        ' L'.join('%s %s' % (round(a, 1), round(b, 1)) for a, b in pts), _c(col), op, _c(col), sw))


def _pline(o, pts, col, dash=False, sw=2.2):
    o.append('<path d="M%s" fill="none" style="stroke:%s" stroke-width="%s"%s stroke-linecap="round" stroke-linejoin="round"/>' % (
        ' L'.join('%s %s' % (round(a, 1), round(b, 1)) for a, b in pts), _c(col), sw, ' stroke-dasharray="6 4"' if dash else ''))


def _dot(o, x, y, col='main', r=5, fill=None):
    if fill is None:
        o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;stroke:none"/>' % (round(x, 1), round(y, 1), r, _c(col)))
    else:
        o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;stroke:%s" stroke-width="1.2"/>' % (round(x, 1), round(y, 1), r, _c(fill), _c(col)))


def _cycle(steps, title, w=360, h=230, bw=118, bh=42, center='', size=10.5, bold0=False, ccol='a'):
    """箱を時計回りに並べて矢印でつなぐ。steps: 文字（または (文字, 色)）"""
    n = len(steps)
    cx, cy = w / 2, h / 2
    rx, ry = w / 2 - bw / 2 - 4, h / 2 - bh / 2 - 4
    pos = [(cx + rx * math.cos(-math.pi / 2 + 2 * math.pi * i / n), cy + ry * math.sin(-math.pi / 2 + 2 * math.pi * i / n)) for i in range(n)]
    o = []

    def edge(p, q):
        dx, dy = q[0] - p[0], q[1] - p[1]
        k = min((bw / 2 + 3) / abs(dx) if dx else 1e9, (bh / 2 + 3) / abs(dy) if dy else 1e9)
        return (p[0] + dx * k, p[1] + dy * k)
    for i in range(n):
        p, q = pos[i], pos[(i + 1) % n]
        o.append(ARROW([edge(p, q), edge(q, p)], col=ccol, sw=1.6, head=6))
    if center:
        ls = center.split('\n')
        for j, ln in enumerate(ls):
            o.append(T(cx, cy + 4 + (j - (len(ls) - 1) / 2) * 15, ln, 'middle', size=12, bold=True, col=ccol))
    for i, (x, y) in enumerate(pos):
        s, col = steps[i] if isinstance(steps[i], tuple) else (steps[i], None)
        _box(o, x - bw / 2, y - bh / 2, bw, bh, s, col=col, size=size, bold0=bold0, c0=col)
    return _svg(w, h, o, title)


def _rowflow(rows, title, lw=64, size=10.5, w=360, gapx=16, gapy=10, bh=None, bold0=True):
    """行ごとの流れ図。rows: [(行の見出し, 色, [段階（文字 または (文字, 色)）], 矢印の有無（省略時は有）)]。行の間はつながない"""
    lh = round(size * 1.34, 1)
    o = []
    y = 2
    for row in rows:
        lab, col, steps = row[0], row[1], row[2]
        arrow = row[3] if len(row) > 3 else True
        n = len(steps)
        x0 = lw + 8 if lw else 2
        g = gapx if arrow else 6
        bw = (w - x0 - 2 - g * (n - 1)) / n
        txt = [s[0] if isinstance(s, tuple) else s for s in steps]
        nl = max([len(_lines(s, bw - 10, size)) for s in txt] + ([len(_lines(lab, lw - 8, size))] if lw else []))
        hh = bh or max(36, nl * lh + 12)
        if lw:
            _box(o, 2, y, lw, hh, lab, col=col, size=size, op=0.24, c0=col)
        for i, s in enumerate(steps):
            c = s[1] if isinstance(s, tuple) else None
            x = x0 + i * (bw + g)
            _box(o, x, y, bw, hh, txt[i], col=c, size=size, bold0=bold0, c0=c)
            if i and arrow:
                o.append(ARROW([(x - g + 2, y + hh / 2), (x - 2, y + hh / 2)], sw=1.4, head=6))
        y += hh + gapy
    return _svg(w, y - gapy + 2, o, title)


def _bands(secs, title, w=360, size=10.5, gapx=16, gap=8, bh=None, bold0=True):
    """見出しの下に箱を並べる段を、上から積む。secs: [(見出し, 色, [箱], 矢印の有無)]"""
    lh = round(size * 1.34, 1)
    o = []
    y = 2
    for sec in secs:
        lab, col, items = sec[0], sec[1], sec[2]
        arrow = sec[3] if len(sec) > 3 else False
        if lab:
            for j, ln in enumerate(wrap(lab, w - 8, size)):
                o.append(T(4, y + size + j * lh, ln, size=size, bold=True, col=col))
            y += len(wrap(lab, w - 8, size)) * lh + 5
        n = len(items)
        g = gapx if arrow else 6
        bw = (w - 4 - g * (n - 1)) / n
        txt = [s[0] if isinstance(s, tuple) else s for s in items]
        nl = max(len(_lines(s, bw - 10, size)) for s in txt)
        hh = bh or max(32, nl * lh + 12)
        for i, s in enumerate(items):
            c = s[1] if isinstance(s, tuple) else col
            x = 2 + i * (bw + g)
            _box(o, x, y, bw, hh, txt[i], col=c, size=size, bold0=bold0)
            if i and arrow:
                o.append(ARROW([(x - g + 2, y + hh / 2), (x - 2, y + hh / 2)], sw=1.4, head=6))
        y += hh + gap + 4
    return _svg(w, y - gap - 2, o, title)


def _hub(center, items, title, w=360, h=None, bw=104, size=10.5, ccol='a', cw=108, a0=-90, bold0=True):
    """中心の箱のまわりに箱を並べ、線で結ぶ。items: 文字 または (文字, 色)"""
    n = len(items)
    lh = round(size * 1.34, 1)
    txt = [s[0] if isinstance(s, tuple) else s for s in items]
    bh = max(32, max(len(_lines(s, bw - 10, size)) for s in txt) * lh + 12)
    ch = max(36, len(_lines(center, cw - 10, size + 0.5)) * lh + 14)
    h = h or {3: 196, 4: 206, 5: 220, 6: 246, 7: 262, 8: 280}.get(n, 280) + max(0, bh - 40) * 2
    cx, cy = w / 2, h / 2
    rx, ry = w / 2 - bw / 2 - 3, h / 2 - bh / 2 - 3
    pos = [(cx + rx * math.cos(math.radians(a0 + 360 * i / n)), cy + ry * math.sin(math.radians(a0 + 360 * i / n))) for i in range(n)]
    o = []

    def edge(p, q, hw, hh):
        dx, dy = q[0] - p[0], q[1] - p[1]
        k = min(hw / abs(dx) if dx else 1e9, hh / abs(dy) if dy else 1e9)
        return (p[0] + dx * k, p[1] + dy * k)
    for (x, y) in pos:
        a = edge((cx, cy), (x, y), cw / 2 + 1, ch / 2 + 1)
        b = edge((x, y), (cx, cy), bw / 2 + 1, bh / 2 + 1)
        o.append(L(a[0], a[1], b[0], b[1], col='line', sw=1.3))
    _box(o, cx - cw / 2, cy - ch / 2, cw, ch, center, col=ccol, size=size + 0.5, op=0.22, c0=ccol)
    for i, (x, y) in enumerate(pos):
        c = items[i][1] if isinstance(items[i], tuple) else None
        _box(o, x - bw / 2, y - bh / 2, bw, bh, txt[i], col=c, size=size, bold0=bold0, c0=c)
    return _svg(w, h, o, title)


def _nest(rings, title, w=360, size=10.5, inset=14, pad=8):
    """入れ子の枠。rings: 外側から順に [(文字, 色)]。最も内側の枠は中央に文字を置く。\\n の前の段落を太字にする"""
    lh = round(size * 1.34, 1)
    n = len(rings)
    geo = []
    y = 2
    for i, (s, col) in enumerate(rings):
        x = 2 + i * inset
        ww = w - 4 - 2 * i * inset
        ls = _lines(s, ww - 16, size)
        geo.append((x, y, ww, ls, col))
        if i < n - 1:
            y += len(ls) * lh + 10
    H = geo[-1][1] + len(geo[-1][3]) * lh + 18 + (n - 1) * pad + 2
    o = []
    for i, (x, y, ww, ls, col) in enumerate(geo):
        hh = H - 2 - y - i * pad
        o.append(R(x, y, ww, hh, fill='sheet', stroke=None, rx=8))
        o.append(R(x, y, ww, hh, fill=col, stroke=col, op=0.1 + 0.03 * i, rx=8, sw=1.2))
        if i < n - 1:
            for j, (ln, pi) in enumerate(ls):
                o.append(T(x + ww / 2, y + 4 + size + j * lh, ln, 'middle', size=size, bold=(pi == 0), col=col if pi == 0 else 'main'))
        else:
            for j, (ln, pi) in enumerate(ls):
                o.append(T(x + ww / 2, y + hh / 2 + size * 0.36 + (j - (len(ls) - 1) / 2) * lh, ln, 'middle', size=size, bold=(pi == 0),
                           col=col if pi == 0 else 'main'))
    return _svg(w, H, o, title)


def _ladder(steps, title, w=360, bw=220, size=10.5, gap=6, label='', lcol='a'):
    """下から上へ1段ずつ右に上がる階段。steps: 下から順に 文字 または (文字, 色)"""
    n = len(steps)
    lh = round(size * 1.34, 1)
    txt = [s[0] if isinstance(s, tuple) else s for s in steps]
    bh = max(30, max(len(_lines(s, bw - 10, size)) for s in txt) * lh + 10)
    dx = (w - 4 - bw) / max(1, n - 1)
    H = n * bh + (n - 1) * gap + 4
    o = []
    for i, s in enumerate(steps):
        c = s[1] if isinstance(s, tuple) else None
        x = 2 + i * dx
        y = 2 + (n - 1 - i) * (bh + gap)
        _box(o, x, y, bw, bh, txt[i], col=c, size=size, c0=c)
    if label:
        x1, y1 = 10, H - 6
        x2, y2 = 2 + (n - 1) * dx - 8, 2 + bh / 2
        o.append(ARROW([(x1, y1 - bh), (x2 - 6, y2 + 4)], col=lcol, sw=1.8, head=7))
        for j, ln in enumerate(label.split('\n')):
            o.append(T(6, 16 + j * lh, ln, size=size, bold=True, col=lcol))
    return _svg(w, H, o, title)


def _venn3(labels, center, title, w=360, h=250, r=78, size=10.5):
    """3つの円の重なり。labels: [(文字, 色)] を 左上・右上・下 の順に"""
    cx, cy = w / 2, h / 2 + 4
    d = r * 0.62
    cs = [(cx - d, cy - d * 0.58), (cx + d, cy - d * 0.58), (cx, cy + d * 0.62)]
    o = []
    for (x, y), (s, col) in zip(cs, labels):
        o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;fill-opacity:0.12;stroke:%s" stroke-width="1.4"/>' % (round(x, 1), round(y, 1), r, _c(col), _c(col)))
    offs = [(-r * 0.46, -r * 0.28), (r * 0.46, -r * 0.28), (0, r * 0.5)]
    lh = round(size * 1.34, 1)
    for (x, y), (s, col), (ox, oy) in zip(cs, labels, offs):
        ls = s.split('\n')
        for j, ln in enumerate(ls):
            o.append(T(x + ox, y + oy + 4 + (j - (len(ls) - 1) / 2) * lh, ln, 'middle', size=size, bold=(j == 0), col=col if j == 0 else 'main'))
    ls = center.split('\n')
    for j, ln in enumerate(ls):
        o.append(T(cx, cy - d * 0.12 + 4 + (j - (len(ls) - 1) / 2) * lh, ln, 'middle', size=size + 1, bold=True))
    return _svg(w, h, o, title)


def _pmap(points, xl, xr, yb, yt, title, w=360, h=250, size=10.5, empty=None):
    """知覚マップ（十字の軸）。points: [(x, y, 文字, 色)]、x と y は -1〜1。empty: (x, y, 半径, 文字) 点線の円"""
    x0, x1, y0, y1 = 14, w - 14, 22, h - 22
    X = lambda v: (x0 + x1) / 2 + v * (x1 - x0) / 2 * 0.86
    Y = lambda v: (y0 + y1) / 2 - v * (y1 - y0) / 2 * 0.86
    o = [ARROW([(x0, Y(0)), (x1, Y(0))], col='main', sw=1.3, head=6), ARROW([(X(0), y1), (X(0), y0)], col='main', sw=1.3, head=6)]
    o.append(T(x1, Y(0) + 16, xr, 'end', size=size, bold=True))
    o.append(T(x0, Y(0) + 16, xl, size=size, bold=True))
    o.append(T(X(0) + 6, y0 + 4, yt, size=size, bold=True))
    o.append(T(X(0) + 6, y1 + 2, yb, size=size, bold=True))
    if empty:
        ex, ey, er, es = empty
        o.append('<circle cx="%s" cy="%s" r="%s" style="fill:none;stroke:%s" stroke-width="1.3" stroke-dasharray="5 4"/>' % (round(X(ex), 1), round(Y(ey), 1), er, _c('a')))
        for j, ln in enumerate(es.split('\n')):
            o.append(T(X(ex), Y(ey) + 4 + (j - (len(es.split('\n')) - 1) / 2) * 13, ln, 'middle', size=size - 0.5, col='a', bold=(j == 0)))
    for (x, y, s, col) in points:
        o.append('<circle cx="%s" cy="%s" r="13" style="fill:%s;fill-opacity:0.25;stroke:%s" stroke-width="1.3"/>' % (round(X(x), 1), round(Y(y), 1), _c(col), _c(col)))
        o.append(T(X(x), Y(y) + 4, s, 'middle', size=size, bold=True))
    return _svg(w, h, o, title)
