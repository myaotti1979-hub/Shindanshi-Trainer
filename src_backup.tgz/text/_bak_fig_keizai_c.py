# 経済学・経済政策の図表（1.5 市場メカニズム、1.6 消費と生産の理論）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, flow, chart, htree, quad, timeline, pyramid, barchart, waterfall, decomp, dtree, ARROW, R, T, L, _svg, _c, wrap, tw)
from kit import (_lines, _dashrect, _box, _lists, _flow, _rowflow, _bands, _hub, _nest, _ladder)
from ekit import G, panels, payoff, txt, hbars, stackbar, eq

FIG = {}


def _below(g, lines, y0=40):
    """グラフの横軸の下に説明の行を置く。lines: [(文字, 色)]"""
    for k, (s, c) in enumerate(lines):
        g.raw(txt(6 + g.ox, g.Y(g.xaxis) + y0 + k * 18, s, size=10.5, bold=True, col=c))


# ------------------------------------------------ 1.5.1 市場均衡・不均衡


def _sdeq():
    g = G(xmax=100, ymax=100, h=282, xlab='数量 Q', ylab='価格 P', pr=24, pb=48)
    g.line([(0, 100), (95, 5)], 'a', label='D', at=(95, 5), dx=4)
    g.line([(0, 10), (90, 55)], 'b', label='S', at=(90, 55), dx=4)
    _below(g, [('需要 Q＝100－P（D）、供給 Q＝－20＋2P（S）', 'main')], 36)
    g.dot(60, 40, 'main', label='E', pos='n').guide(60, 40, xt='60', yt='40', bold=True)
    g.hl(60, 'c', x0=0, x1=96, sw=1.2, dash='4 3')
    g.yt(60, 'P1', 'c', True)
    g.hspan(60, 40, 100, '超過供給（売れ残り）', 'c', dy=-9)
    g.hl(25, 'c', x0=0, x1=96, sw=1.2, dash='4 3')
    g.yt(25, 'P2', 'c', True)
    g.hspan(25, 30, 75, '超過需要（品不足）', 'c', dy=10)
    return g.svg('市場の均衡（Q＝100－P、Q＝－20＋2P の例）')


FIG['keizai.sdeq'] = _sdeq()


def _shiftmove():
    g1 = G(xmax=10, ymax=10, w=176, h=200, ox=0, pl=22, pr=12, xlab='Q', ylab='P', cap='需要量の変化', ccol='b')
    g2 = G(xmax=10, ymax=10, w=176, h=200, ox=184, pl=22, pr=12, xlab='Q', ylab='P', cap='需要の変化（シフト）', ccol='a')
    for g in (g1, g2):
        g.line([(0.5, 9), (8.5, 1)], 'a', label='D', at=(8.5, 1), dx=2)
    g1.dot(3, 6.5, 'main', label='A', pos='ne').dot(6, 3.5, 'main', label='B', pos='ne')
    g1.arrow(3.3, 6.0, 5.7, 3.8, 'b', sw=1.8, head=6)
    g2.line([(2.5, 9), (10, 1.5)], 'a', dash=True, label='D′', at=(10, 1.5), dy=-10, anchor='end')
    g2.arrow(3.6, 5.2, 5.4, 5.2, 'a', sw=1.8, head=6)
    ex = [txt(4, 216, '価格の変化で曲線の上を動く', size=10.5, bold=True, col='b'), txt(188, 216, '所得などの変化で曲線が動く', size=10.5, bold=True, col='a')]
    return panels([g1, g2], '曲線上の移動と、曲線のシフト', h=222, extra=ex)


FIG['keizai.shiftmove'] = _shiftmove()

FIG['keizai.sdfactor'] = _lists([('需要曲線をシフトさせる要因', 'a', ['所得', '他の財（代替財・補完財）の価格', '嗜好', '将来の予想']),
                                 ('供給曲線をシフトさせる要因', 'b', ['生産要素の価格', '技術', '企業の数'])], 'シフトの要因')

FIG['keizai.both'] = grid(['需要', '供給', '価格', '取引量'],
                          [['右', '左', '必ず上がる', '決まらない'], ['右', '右', '決まらない', '必ず増える'], ['左', '右', '必ず下がる', '決まらない'], ['左', '左', '決まらない', '必ず減る']],
                          [70, 70, 110, 110], align=['c', 'c', 'c', 'c'], title='需要と供給が同時にシフトしたとき', size=11.5,
                          tcol={'決まらない': 'a'})


def _ceil():
    g1 = G(xmax=10, ymax=10, w=176, h=208, ox=0, pl=24, pr=12, xlab='Q', ylab='P', cap='上限価格の規制', ccol='a')
    g2 = G(xmax=10, ymax=10, w=176, h=208, ox=184, pl=24, pr=12, xlab='Q', ylab='P', cap='下限価格の規制', ccol='b')
    for g in (g1, g2):
        g.line([(0, 10), (10, 0)], 'a', label='D', at=(9.4, 0.6), dx=2)
        g.line([(0, 0), (10, 10)], 'b', label='S', at=(9.4, 9.4), dx=-14, dy=4)
        g.dot(5, 5, 'main', label='E', pos='e')
    g1.hl(3, 'a', x0=0, x1=9.6, sw=1.6)
    g1.yt(3, '上限', 'a', True)
    g1.hspan(3, 3, 7, '品不足', 'a', dy=10)
    g2.hl(7, 'b', x0=0, x1=9.6, sw=1.6)
    g2.yt(7, '下限', 'b', True)
    g2.hspan(7, 3, 7, '売れ残り', 'b', dy=-9)
    ex = [txt(4, 224, '均衡より低い上限 → 超過需要', size=10.5, bold=True, col='a'), txt(188, 224, '均衡より高い下限 → 超過供給', size=10.5, bold=True, col='b')]
    return panels([g1, g2], '価格の規制', h=230, extra=ex)


FIG['keizai.ceil'] = _ceil()


def _adjust():
    g1 = G(xmax=10, ymax=10, w=176, h=208, ox=0, pl=22, pr=12, xlab='Q', ylab='P', cap='ワルラス的調整（価格）', ccol='a')
    g2 = G(xmax=10, ymax=10, w=176, h=208, ox=184, pl=22, pr=12, xlab='Q', ylab='P', cap='マーシャル的調整（数量）', ccol='b')
    for g in (g1, g2):
        g.line([(0, 10), (10, 0)], 'a', label='D', at=(9.4, 0.6), dx=2)
        g.line([(0, 0), (10, 10)], 'b', label='S', at=(9.4, 9.4), dx=-14, dy=4)
        g.dot(5, 5, 'main')
    g1.hl(7.5, 'c', x0=2.5, x1=7.5, sw=1.4, dash='4 3')
    g1.arrow(5, 7.4, 5, 5.6, 'c', sw=1.8, head=6)
    g1.text(5.2, 8.4, '超過供給なら\n価格が下がる', 'middle', 'c', True, 10)
    g2.vl(2.5, 'c', y0=2.5, y1=7.5, sw=1.4, dash='4 3')
    g2.arrow(2.6, 5, 4.4, 5, 'c', sw=1.8, head=6)
    g2.text(2.6, 8.9, '需要価格＞供給価格\nなら数量が増える', 'start', 'c', True, 10)
    return panels([g1, g2], '市場の調整', h=208)


FIG['keizai.adjust'] = _adjust()

FIG['keizai.stab'] = grid(['ケース', 'ワルラス的', 'マーシャル的'],
                          [['需要が右下がり、供給が右上がり', '安定', '安定'], ['供給が右下がりで、需要より傾きが急', '安定', '不安定'],
                           ['供給が右下がりで、需要より傾きが緩やか', '不安定', '安定'], ['需要が右上がりで、供給より傾きが急', '安定', '不安定']],
                          [196, 82, 82], align=['l', 'c', 'c'], title='市場の安定性', size=10.5, tcol={'不安定': 'a'})


def _cobweb():
    g = G(xmax=8, ymax=10, h=262, xlab='数量 Q', ylab='価格 P', pr=24)
    D = lambda q: 10 - q
    S = lambda q: 1 + 1.5 * q
    g.line([(0.5, 9.5), (7.5, 2.5)], 'a', label='D', at=(7.5, 2.5), dx=2)
    g.line([(0, 1), (6, 10)], 'b', label='S（傾きが急）', at=(5.6, 9.6), anchor='end')
    p = 8.0
    pts = []
    g.dot(0, p, 'c')
    g.yt(p, '最初', 'c', True)
    for k in range(5):
        q = (p - 1) / 1.5
        pts += [(q, p)]
        p2 = D(q)
        pts += [(q, p2)]
        p = p2
    path = [(0, 8.0)] + pts
    for a, b in zip(path[:-1], path[1:]):
        g.arrow(a[0], a[1], b[0], b[1], 'c', sw=1.6, head=5)
    g.dot(3.6, 6.4, 'main', label='E', pos='e')
    g.text(5.0, 7.6, '前期の価格を見て\n今期の供給量を決める', 'start', 'c', True, 10.5)
    return g.svg('くもの巣理論（供給曲線の傾きが急なら安定）')


FIG['keizai.cobweb'] = _cobweb()

# ------------------------------------------------ 1.5.2 弾力性の概念


def _elast():
    g = G(xmax=12, ymax=11, h=262, xlab='需要量 Q', ylab='価格 P', pr=24)
    g.line([(0, 10), (10, 0)], 'a', label='Q＝10－P', at=(10, 0.4), dx=2)
    g.dot(2, 8, 'a', label='P＝8：弾力性4', pos='e').dot(5, 5, 'main', label='中点：弾力性1', pos='e').dot(8, 2, 'b', label='P＝2：0.25', pos='e')
    g.text(1.2, 3.6, '中点より上：\n1より大きい（弾力的）\n中点より下：\n1より小さい（非弾力的）', 'start', 'main', True, 10.5)
    g.text(6.6, 9.6, '弾力性＝b×P÷Q（Q＝a－bP）', 'middle', 'main', True, 10.5)
    return g.svg('直線の需要曲線上の弾力性')


FIG['keizai.elast'] = _elast()


def _revrect():
    g = G(xmax=10, ymax=10, h=232, xlab='Q', ylab='P', pr=24)
    g.rect(0, 0, 4, 6, col='b', op=0.22)
    g.rect(0, 0, 2, 8, col='a', op=0.22)
    g.line([(0, 10), (10, 0)], 'a', label='D', at=(10, 0.4), dx=2)
    g.dot(2, 8, 'a').guide(2, 8, xt='2', yt='8').dot(4, 6, 'b').guide(4, 6, xt='4', yt='6')
    g.text(5.0, 8.6, '価格8：売上 8×2＝16\n価格6：売上 6×4＝24', 'start', 'main', True, 10.5)
    g.text(5.6, 3.6, '弾力的な範囲では、\n値下げで売上が増える', 'start', 'b', True, 10.5)
    return g.svg('弾力性と売上（Q＝10－Pの上側）')


FIG['keizai.revrect'] = _revrect()

FIG['keizai.elastrev'] = grid(['需要の価格弾力性', '値下げすると', '値上げすると', '財の例'],
                              [['1より大きい（弾力的）', '売上が増える', '売上が減る', 'ぜいたく品、代替品の多い財'], ['1', '変わらない', '変わらない', ''],
                               ['1より小さい（非弾力的）', '売上が減る', '売上が増える', '必需品、代替品の少ない財']],
                              [104, 72, 72, 112], align=['l', 'c', 'c', 'l'], title='弾力性と売上（支出額）', size=10.5)


def _elext():
    caps = [('垂直', '弾力性ゼロ'), ('水平', '無限大'), ('同じ点で交わる', '緩やかな方が弾力的')]
    gs = []
    for i in range(3):
        g = G(xmax=10, ymax=10, w=118, h=150, ox=i * 121, pl=14, pr=8, pt=34, pb=16, xlab='Q', ylab='P', origin='')
        g.raw(txt(i * 121 + 59, 12, caps[i][0], 'middle', 'main', True, 10.5))
        g.raw(txt(i * 121 + 59, 27, caps[i][1], 'middle', 'a', True, 10.5))
        gs.append(g)
    gs[0].vl(5, 'a', y0=0.5, y1=9.5)
    gs[1].hl(5, 'a', x0=0.5, x1=9.5)
    gs[2].line([(2.5, 9.5), (7.5, 0.5)], 'a', label='急', at=(7.5, 0.6), anchor='end', dx=-4, lsize=10)
    gs[2].line([(0.5, 7.25), (9.5, 2.75)], 'b', label='緩やか', at=(9.6, 3.6), anchor='end', lsize=10)
    gs[2].dot(5, 5, 'main')
    return panels(gs, '需要曲線の形と弾力性', h=150)


FIG['keizai.elext'] = _elext()

FIG['keizai.incelast'] = htree(('財の分類', 'main', [
    ('所得弾力性\nがプラス', 'b', [('正常財\n（上級財）', 'b', [('奢侈品：1より大きい', None, []), ('必需品：0から1の間', None, [])])]),
    ('所得弾力性\nがマイナス', 'a', [('劣等財\n（下級財）', 'a', [('所得が増えると需要が減る', None, [])])])]),
    '所得弾力性による財の分類', colw=(54, 76, 72, 128), gapx=10)

FIG['keizai.cross'] = grid(['交差弾力性', '関係', '例'],
                           [['プラス', '代替財（粗代替財）', 'コーヒーと紅茶'], ['マイナス', '補完財（粗補完財）', 'コーヒーと砂糖']],
                           [84, 150, 126], align=['c', 'l', 'l'], title='交差弾力性（他の財の価格が1％変わったときの需要量の変化率）', size=11)

FIG['keizai.selast'] = grid(['供給曲線', '供給の価格弾力性', '例'],
                            [['垂直', 'ゼロ', '収穫後の農産物、座席数が決まったチケット'], ['水平', '無限大', '限界費用が一定']],
                            [70, 104, 186], align=['c', 'c', 'l'], title='供給の価格弾力性', size=11)

# ------------------------------------------------ 1.5.3 経済余剰の概念


def _surplus():
    g = G(xmax=10, ymax=10, h=240, xlab='数量 Q', ylab='価格 P', pr=24)
    g.area([(0, 10), (0, 5), (5, 5)], 'a', op=0.24, label='消費者余剰\n12.5', at=(1.7, 6.7), lcol='a')
    g.area([(0, 0), (0, 5), (5, 5)], 'b', op=0.24, label='生産者余剰\n12.5', at=(1.7, 3.3), lcol='b')
    g.line([(0, 10), (10, 0)], 'a', label='D：P＝10－Q', at=(10, 0.4), anchor='end', dy=-10)
    g.line([(0, 0), (10, 10)], 'b', label='S：P＝Q', at=(9.4, 9.4), dx=-14, dy=4, anchor='end')
    g.dot(5, 5, 'main', label='E', pos='e').guide(5, 5, xt='5', yt='5')
    g.text(6.2, 7.6, '総余剰＝25（最大）', 'start', 'main', True, 10.5)
    return g.svg('消費者余剰と生産者余剰')


FIG['keizai.surplus'] = _surplus()


def _psprofit():
    g = G(xmax=14, ymax=60, h=236, xlab='生産量 Q', ylab='価格・費用', pr=24)
    g.area([(0, 0), (10, 40), (0, 40)], 'b', op=0.26, label='生産者余剰\n200', at=(3.2, 29), lcol='b')
    g.area([(0, 0), (10, 0), (10, 40)], 'sub', op=0.22, label='可変費用\n200', at=(7.0, 12), lcol='main')
    g.line([(0, 0), (14, 56)], 'b', label='MC＝4Q', at=(14, 56), anchor='end', dy=-10)
    g.hl(40, 'a', x0=0, x1=14, label='価格40', at=(14, 40), anchor='end', dy=-8)
    g.guide(10, 40, xt='10')
    g.text(11.2, 22, '総収入400\n＝可変費用200\n＋生産者余剰200', 'start', 'main', True, 10)
    return g.svg('生産者余剰＝利潤100＋固定費用100（TC＝100＋2Q²）')


FIG['keizai.psprofit'] = _psprofit()


def _tax():
    g = G(xmax=10, ymax=10, h=300, xlab='数量 Q', ylab='価格 P', pr=24, pb=82)
    g.rect(0, 5, 4, 6, col='a', op=0.3, label='消費者の負担4', lcol='a', size=10)
    g.rect(0, 4, 4, 5, col='b', op=0.3, label='生産者の負担4', lcol='b', size=10)
    g.area([(4, 6), (5, 5), (4, 4)], 'sub', op=0.5)
    g.line([(0, 10), (10, 0)], 'a', label='D', at=(10, 0.4), dx=2)
    g.line([(0, 0), (10, 10)], 'b', label='S', at=(9.6, 9.6), dx=-14, dy=4)
    g.line([(0, 2), (8, 10)], 'b', dash=True, label='S＋税', at=(8, 10), anchor='end', dx=-6, dy=4)
    g.dot(5, 5, 'main', label='E', pos='e').dot(4, 6, 'a')
    g.guide(4, 6, xt='4', yt='6').guide(4, 4, yt='4', v=False).yt(5, '5')
    _below(g, [('1単位2の税：税収＝2×4＝8（長方形）', 'main'), ('灰色の三角形＝死荷重1', 'main'), ('弾力性が同じなので、消費者と生産者が半分ずつ負担', 'main')])
    return g.svg('従量税の効果（D：P＝10－Q、S：P＝Q、税2）')


FIG['keizai.tax'] = _tax()


def _incid():
    g1 = G(xmax=10, ymax=10, w=176, h=214, ox=0, pl=22, pr=12, xlab='Q', ylab='P', cap='需要が非弾力的', ccol='a')
    g2 = G(xmax=10, ymax=10, w=176, h=214, ox=184, pl=22, pr=12, xlab='Q', ylab='P', cap='供給が非弾力的', ccol='b')
    g1.line([(3.5, 10), (6.5, 0)], 'a', label='D', at=(6.5, 0.4), dx=2)
    g1.line([(0, 1), (10, 9)], 'b', label='S', at=(9.6, 9.0), anchor='end', dy=-10)
    g1.line([(0, 3), (10, 11)], 'b', dash=True)
    # 需要 P＝10－(10/3)(Q－3.5)、S＋税 P＝3＋0.8Q の交点
    qa = (10 + 35 / 3.0 - 3) / (10 / 3.0 + 0.8)
    pa = 3 + 0.8 * qa
    g1.rect(0, 5, qa, pa, col='a', op=0.35).rect(0, 1 + 0.8 * qa, qa, 5, col='b', op=0.35)
    g1.dot(5, 5, 'main').dot(qa, pa, 'a').seg(qa, pa, qa, 1 + 0.8 * qa, 'main', dash='2 2')
    g2.line([(0, 9), (10, 1)], 'a', label='D', at=(10, 1.4), anchor='end', dy=-10)
    g2.line([(3.5, 0), (6.5, 10)], 'b', label='S', at=(6.5, 9.6), dx=2)
    g2.line([(2.9, 0), (5.9, 10)], 'b', dash=True)
    # D P＝9－0.8Q、S＋税 P＝(10/3)(Q－2.9)
    qb = (9 + 29 / 3.0) / (10 / 3.0 + 0.8)
    pb = 9 - 0.8 * qb
    g2.rect(0, 5, qb, pb, col='a', op=0.35).rect(0, 10 / 3.0 * (qb - 3.5), qb, 5, col='b', op=0.35)
    g2.dot(5, 5, 'main').dot(qb, pb, 'a').seg(qb, pb, qb, 10 / 3.0 * (qb - 3.5), 'main', dash='2 2')
    ex = [txt(4, 230, '消費者の負担が大きい', size=10.5, bold=True, col='a'), txt(188, 230, '生産者の負担が大きい', size=10.5, bold=True, col='b'),
          txt(180, 248, '赤い帯＝消費者の負担、緑の帯＝生産者の負担（点線は税を加えた供給曲線）', 'middle', size=10, bold=False)]
    return panels([g1, g2], '税の帰着：弾力性の小さい側が多く負担する', h=254, extra=ex)


FIG['keizai.incid'] = _incid()


def _taxtype():
    g1 = G(xmax=10, ymax=10, w=176, h=196, ox=0, pl=22, pr=12, xlab='Q', ylab='P', cap='従量税', ccol='b')
    g2 = G(xmax=10, ymax=10, w=176, h=196, ox=184, pl=22, pr=12, xlab='Q', ylab='P', cap='従価税', ccol='c')
    for g in (g1, g2):
        g.line([(0, 1), (9, 7.3)], 'b', label='S', at=(9, 7.3), dx=2)
    g1.line([(0, 3), (9, 9.3)], 'b', dash=True, label='平行に上へ', at=(4.4, 8.6), anchor='middle', lsize=10)
    g2.line([(0, 1.4), (9, 10.2)], 'c', dash=True, label='価格が高いほど\n大きく上へ', at=(3.6, 8.6), anchor='middle', lsize=10)
    return panels([g1, g2], '従量税と従価税での供給曲線の移り方', h=196)


FIG['keizai.taxtype'] = _taxtype()


def _subdwl():
    g = G(xmax=10, ymax=10, h=290, xlab='数量 Q', ylab='価格 P', pr=24, pb=74)
    g.rect(0, 4, 6, 6, col='c', op=0.26)
    g.area([(5, 5), (6, 6), (6, 4)], 'sub', op=0.55)
    g.line([(0, 10), (10, 0)], 'a', label='D', at=(10, 0.4), dx=2)
    g.line([(0, 0), (10, 10)], 'b', label='S', at=(9.6, 9.6), dx=-14, dy=4)
    g.line([(2, 0), (10, 8)], 'b', dash=True, label='S－補助金', at=(10, 8), anchor='end', dy=14)
    g.dot(5, 5, 'main', label='E', pos='w').dot(6, 4, 'b')
    g.guide(6, 6, xt='6', yt='6').guide(6, 4, yt='4', v=False).yt(5, '5')
    _below(g, [('補助金の総額＝2×6＝12（長方形）', 'c'), ('消費者余剰＋5.5、生産者余剰＋5.5、合計11＜12', 'main'), ('差の1（灰色の三角形）が死荷重', 'main')], 38)
    return g.svg('補助金の効果（1単位2の補助金）')


FIG['keizai.subdwl'] = _subdwl()


def _ceildwl():
    g = G(xmax=10, ymax=10, h=300, xlab='数量 Q', ylab='価格 P', pr=24, pb=86)
    g.area([(0, 10), (0, 3), (3, 3), (3, 7)], 'a', op=0.24, label='消費者余剰\n16.5', at=(1.4, 5.6), lcol='a', size=10)
    g.area([(0, 0), (0, 3), (3, 3)], 'b', op=0.26)
    g.area([(3, 7), (5, 5), (3, 3)], 'sub', op=0.5)
    g.line([(0, 10), (10, 0)], 'a', label='D', at=(10, 0.4), dx=2)
    g.line([(0, 0), (10, 10)], 'b', label='S', at=(9.6, 9.6), dx=-14, dy=4)
    g.hl(3, 'a', x0=0, x1=9.4, sw=1.6, label='上限価格3', at=(9.4, 3), anchor='end', dy=-8)
    g.dot(5, 5, 'main', label='E', pos='e').guide(3, 7, xt='3', h=False)
    _below(g, [('取引量は上限価格での供給量3に減る', 'main'), ('生産者余剰4.5（緑）、死荷重4（灰色）', 'main'), ('総余剰は25から21に減る', 'a')], 38)
    return g.svg('上限価格の規制と死荷重（D：P＝10－Q、S：P＝Q）')


FIG['keizai.ceildwl'] = _ceildwl()

# ------------------------------------------------ 1.5.4 競争的市場の資源配分機能
FIG['keizai.pc4'] = _hub('完全競争\n市場', [('売り手・買い手が多数\n（価格受容者）', None), ('財が同質', None), ('情報が完全', None), ('参入・退出が自由', None)],
                         '完全競争市場の4つの条件', bw=132, ccol='b', cw=92)


def _pareto():
    g = G(xmax=10, ymax=10, h=240, xlab='Aの効用', ylab='Bの効用', pr=20)
    f = lambda x: 9 * math.sqrt(max(0, 1 - (x / 9.0) ** 2))
    g.fn(f, 0, 9, 'b', label='効用可能性フロンティア', at=(4.6, 9.3), anchor='middle')
    g.dot(4, 4, 'a', label='A：パレート最適でない\n（両方の効用を上げられる）', pos='sw')
    g.arrow(4.3, 4.3, 5.6, 5.6, 'a', sw=1.6, head=5)
    g.dot(8.5, f(8.5), 'b', label='B', pos='ne').dot(6.36, 6.36, 'b', label='C', pos='ne')
    g.text(4.8, 1.3, 'BもCもパレート最適（Bは不公平でも最適）', 'middle', 'b', True, 10.5)
    return g.svg('パレート最適と公平は別')


FIG['keizai.pareto'] = _pareto()


def _edge():
    g = G(xmax=10, ymax=10, w=360, h=300, pl=60, pr=60, pt=26, pb=34, xlab='', ylab='', origin='')
    g.axes = False
    g.rect(0, 0, 10, 10, col='sub', op=0.06)
    g.raw(R(g.X(0), g.Y(10), g.X(10) - g.X(0), g.Y(0) - g.Y(10), fill='none', stroke='main', sw=1.3))
    for k, c in ((9, 49), (25, 25), (49, 9)):
        g.fn(lambda x, k=k: k / x, k / 10.0, 10, 'a', n=60, sw=1.8)
        g.fn(lambda x, c=c: 10 - c / (10 - x), 0, 10 - c / 10.0, 'b', n=60, sw=1.8)
    g.line([(0, 0), (10, 10)], 'c', dash='5 4', sw=2, label='契約曲線', at=(8.6, 9.3), anchor='end')
    for p in (3, 5, 7):
        g.dot(p, p, 'main')
    g.raw(txt(g.X(0) - 4, g.Y(0) + 16, 'Aの原点', 'end', 'a', True, 10.5))
    g.raw(txt(g.X(10) + 4, g.Y(10) - 6, 'Bの原点', 'start', 'b', True, 10.5))
    g.raw(txt(g.X(0) - 6, g.Y(5), 'Aの\n無差別\n曲線（赤）', 'end', 'a', True, 10, vc=True))
    g.raw(txt(g.X(10) + 6, g.Y(5), 'Bの\n無差別\n曲線（緑）', 'start', 'b', True, 10, vc=True))
    g.raw(txt(180, 294, '接点（●）では2人の限界代替率が等しい＝パレート最適', 'middle', 'main', True, 10.5))
    return g.svg('エッジワース・ボックスと契約曲線')


FIG['keizai.edge'] = _edge()


def _ppc():
    g = G(xmax=10, ymax=10, h=250, xlab='財X', ylab='財Y', pr=20)
    f = lambda x: 8.5 * math.sqrt(max(0, 1 - (x / 8.5) ** 2))
    g.fn(f, 0, 8.5, 'b', label='生産可能性曲線', at=(1.0, 9.0))
    x0 = 8.5 / math.sqrt(2)
    y0 = f(x0)
    g.line([(x0 - 3.4, y0 + 3.4), (x0 + 3.4, y0 - 3.4)], 'a', dash='5 3', sw=1.6, label='等収入線', at=(7.8, 5.0), anchor='start')
    g.dot(x0, y0, 'a', label='収入最大\n限界変形率＝価格比', pos='sw')
    g.dot(3, 3, 'main', label='内側：非効率', pos='e')
    g.dot(8, 8, 'sub', label='外側：生産できない', pos='n')
    return g.svg('生産可能性曲線（外側にふくらむ）')

FIG['keizai.ppc'] = _ppc()

FIG['keizai.welfare'] = grid(['定理', '内容'],
                             [['第1定理', '完全競争市場の均衡は、パレート最適である'], ['第2定理', '適切な所得の再分配（一括の移転）を行えば、どのパレート最適な配分も、競争市場の均衡として実現できる']],
                             [70, 290], align=['l', 'l'], title='厚生経済学の基本定理', size=11)

FIG['keizai.effcond'] = grid(['効率性', '条件'],
                             [['交換（エッジワース・ボックス）', '2人の限界代替率が等しい（契約曲線上）'], ['生産（ボックス・ダイアグラム）', '2財の技術的限界代替率が等しい'],
                              ['生産と価格', '限界変形率＝価格比'], ['競争市場：消費', '各消費者の限界代替率＝価格比'], ['競争市場：生産', '各企業の価格＝限界費用（P＝MC）']],
                             [150, 210], align=['l', 'l'], title='資源配分の効率性の条件', size=10.5)

# ------------------------------------------------ 1.5.5 市場の失敗
FIG['keizai.mf4'] = _hub('市場の失敗', [('外部性', 'a'), ('公共財', 'b'), ('費用逓減産業\n（自然独占）', 'c'), ('情報の\n非対称性', None)], '市場の失敗の主な原因', bw=110, ccol='a', cw=96)


def _extneg():
    g = G(xmax=10, ymax=10, h=300, xlab='数量 Q', ylab='価格・費用', pr=24, pb=76)
    g.area([(4, 6), (5, 7), (5, 5)], 'sub', op=0.55)
    g.line([(0, 10), (10, 0)], 'a', label='D', at=(10, 0.4), dx=2)
    g.line([(0, 0), (10, 10)], 'b', label='PMC', at=(9.6, 9.6), dx=-24, dy=8)
    g.line([(0, 2), (8, 10)], 'c', label='SMC', at=(8, 10), dx=-30, dy=4)
    g.dot(5, 5, 'b', label='市場の均衡', pos='e').dot(4, 6, 'c', label='社会的な最適', pos='w')
    g.guide(5, 5, xt='5').guide(4, 6, xt='4')
    _below(g, [('SMC＝PMC＋外部費用（1単位2）', 'c'), ('市場の取引量5は、最適な4より多すぎる', 'b'), ('灰色の三角形（1）が死荷重', 'main')], 38)
    return g.svg('外部不経済（D：P＝10－Q、PMC：P＝Q、SMC：P＝Q＋2）')


FIG['keizai.extneg'] = _extneg()


def _pigou():
    g = G(xmax=10, ymax=10, h=304, xlab='数量 Q', ylab='価格・費用', pr=24, pb=86)
    g.rect(0, 4, 4, 6, col='c', op=0.3, label='税収8', lcol='c', size=11)
    g.line([(0, 10), (10, 0)], 'a', label='D', at=(10, 0.4), dx=2)
    g.line([(0, 0), (10, 10)], 'b', label='PMC', at=(9.6, 9.6), dx=-24, dy=8)
    g.line([(0, 2), (8, 10)], 'c', label='PMC＋ピグー税', at=(8, 10), dx=-80, dy=4)
    g.dot(4, 6, 'c').guide(4, 6, xt='4', yt='6').guide(4, 4, yt='4', v=False)
    _below(g, [('最適な量での限界外部費用2を、1単位ごとの税にする', 'main'), ('取引量は4になり、税収は2×4＝8', 'c'), ('（SMCとPMCの間の平行四辺形の面積とも等しい）', 'main')], 38)
    return g.svg('ピグー税')


FIG['keizai.pigou'] = _pigou()


def _extpos():
    g = G(xmax=10, ymax=12, h=236, xlab='数量 Q', ylab='価格・便益', pr=24)
    g.area([(5, 5), (6, 6), (5, 7)], 'sub', op=0.55)
    g.line([(0, 10), (10, 0)], 'a', label='D（私的な便益）', at=(10, 0.4), anchor='end', dy=-10)
    g.line([(0, 12), (10, 2)], 'c', label='社会的な便益', at=(10, 2.4), anchor='end', dy=-10)
    g.line([(0, 0), (10, 10)], 'b', label='S', at=(9.6, 9.6), dx=-14, dy=4)
    g.dot(5, 5, 'b', label='市場', pos='w').dot(6, 6, 'c', label='最適', pos='e')
    g.text(0.4, 11.2, '教育や予防接種：市場の取引量は最適より少ない', 'start', 'main', True, 10.5)
    return g.svg('外部経済（ピグー補助金で最適な量へ）')


FIG['keizai.extpos'] = _extpos()

FIG['keizai.coase'] = grid(['権利を持つ側', '交渉のしかた', '結果'],
                           [['被害を受ける側', '加害者が補償を払って、生産する', '効率的な量'], ['加害者', '被害者がお金を払って、生産を減らしてもらう', '効率的な量']],
                           [96, 182, 82], align=['l', 'l', 'c'], title='コースの定理（取引費用ゼロ）：効率は同じ、分配は違う', size=10.5, tcol={'効率的な量': 'b'})

FIG['keizai.goods4'] = quad(['競合する', '競合しない'], ['排除できる', '排除できない'],
                            [[('私的財', '食品、衣服など', 'sub'), ('コモンプール財', '公海の漁業資源、混雑した一般道路（共有地の悲劇）', 'c')],
                             [('クラブ財', '有料のテレビ放送、有料の動画配信、混雑していない有料道路', 'c'), ('純粋公共財', '国防、混雑していない一般道路', 'b')]],
                            '財の分類（競合性と排除性）', lw=62)


def _natmono():
    g = G(xmax=10, ymax=10, h=300, xlab='数量 Q', ylab='価格・費用', pr=24, pb=76)
    g.rect(0, 2, 8, 3, col='a', op=0.3, label='赤字8', lcol='a', size=10.5)
    g.line([(0, 10), (10, 0)], 'a', label='D', at=(10, 0.4), dx=2)
    g.fn(lambda q: 2 + 8 / q, 0.9, 10, 'c', label='AC', at=(10, 2.8), dx=2)
    g.hl(2, 'b', x0=0, x1=10, label='MC', at=(10, 2.0), dx=2)
    qa = 4 + math.sqrt(8)
    g.dot(qa, 10 - qa, 'c', label='P＝AC', pos='ne').dot(8, 2, 'b', label='P＝MC', pos='ne')
    g.guide(qa, 10 - qa, xt='6.8').guide(8, 3, xt='8', h=False)
    _below(g, [('P＝MC：効率的な量8。ACを下回り赤字（＝固定費8）', 'b'), ('P＝AC：赤字はないが、量6.8は効率的な量より少ない', 'c'),
               ('（例：D：P＝10－Q、MC＝2、固定費8）', 'main')], 38)
    return g.svg('費用逓減産業（自然独占）の価格規制')


FIG['keizai.natmono'] = _natmono()


def _twopart():
    g = G(xmax=15, ymax=750, h=236, xlab='利用回数', ylab='価格（円）', pr=24)
    g.area([(0, 700), (0, 400), (6, 400)], 'b', op=0.3, label='消費者余剰\n900円', at=(1.9, 520), lcol='b', size=10.5)
    g.rect(0, 0, 6, 400, col='sub', op=0.16, label='料金 400×6', lcol='main', size=10.5)
    g.line([(0, 700), (14, 0)], 'a', label='P＝700－50Q', at=(14, 40), anchor='end', dy=-10)
    g.hl(400, 'c', x0=0, x1=14, label='1回400円', at=(14, 400), anchor='end', dy=-8)
    g.guide(6, 400, xt='6')
    g.text(7.0, 620, '入場料（基本料金）が\n900円以下なら加入する', 'start', 'main', True, 10.5)
    return g.svg('二部料金制での加入の判断')


FIG['keizai.twopart'] = _twopart()

# ------------------------------------------------ 1.6.1 効用理論


def _mu():
    tu = [0, 10, 18, 24, 28, 30]
    g1 = G(xmax=5.5, ymax=34, w=176, h=196, ox=0, pl=26, pr=8, cap='総効用', ccol='b', origin='0')
    g2 = G(xmax=5.5, ymax=12, w=176, h=196, ox=184, pl=22, pr=8, cap='限界効用', ccol='a', origin='0')
    g1.line([(i, v) for i, v in enumerate(tu)], 'b')
    for i in range(1, 6):
        g1.dot(i, tu[i], 'b', label=str(tu[i]), pos='nw', size=10)
        g1.xt(i, str(i), size=10)
        m = tu[i] - tu[i - 1]
        g2.rect(i - 0.32, 0, i + 0.32, m, col='a', op=0.3, label=str(m), at=(i, m + 0.9), lcol='main', size=10)
        g2.xt(i, str(i), size=10)
    ex = [txt(180, 212, '消費量（個）を増やすほど、限界効用は小さくなる', 'middle', size=10.5, bold=True, col='a')]
    return panels([g1, g2], '限界効用逓減の法則（数値例）', h=218, extra=ex)


FIG['keizai.mu'] = _mu()

FIG['keizai.muequal'] = _rowflow([('', None, [('Xの1円当たりの\n限界効用が大きい', 'b'), 'Xを増やし、\nYを減らす', ('効用が増える', 'b')]),
                                  ('', None, [('等しくなる', 'c'), ('限界効用÷価格が\nどの財も同じ', 'c'), ('効用が最大', 'c')])], '限界効用均等の法則', lw=0, size=10.5)


def _indiff():
    g = G(xmax=10, ymax=10, h=250, xlab='X財', ylab='Y財', pr=30)
    for k, col, lab in ((6, 'sub', 'U1'), (12, 'b', 'U2'), (20, 'a', 'U3')):
        g.fn(lambda x, k=k: k / x, k / 10.0, 10, col, label=lab, at=(10, k / 10.0), dx=2)
    g.arrow(3.0, 3.0, 4.6, 4.6, 'main', sw=1.6, head=6)
    g.text(5.0, 6.4, '右上ほど効用が高い', 'start', 'main', True, 10.5)
    g.line([(1.0, 9.6), (2.4, 4.8)], 'c', dash='4 3', sw=1.4)
    g.dot(1.732, 6.93, 'c', label='A', pos='w')
    g.line([(4.6, 3.6), (9.2, 1.0)], 'c', dash='4 3', sw=1.4)
    g.dot(6.93, 1.732, 'c', label='B', pos='s')
    g.text(3.4, 9.5, 'A：接線の傾きが急（MRSが大きい）', 'start', 'c', True, 10.5)
    g.text(3.4, 8.6, 'B：緩やか（MRSが小さい）', 'start', 'c', True, 10.5)
    return g.svg('無差別曲線と限界代替率の逓減')

FIG['keizai.indiff'] = _indiff()


def _special():
    caps = [('完全代替財', '右下がりの直線'), ('完全補完財', 'L字型'), ('負の財（横軸）', '右上がり'), ('中立財（縦軸）', '垂直')]
    gs = []
    for i in range(4):
        r, c = divmod(i, 2)
        g = G(xmax=10, ymax=10, w=176, h=150, ox=c * 184, oy=r * 156, pl=16, pr=8, pt=34, pb=14, origin='')
        g.raw(txt(c * 184 + 92, r * 156 + 13, caps[i][0], 'middle', 'main', True, 11))
        g.raw(txt(c * 184 + 92, r * 156 + 28, caps[i][1], 'middle', 'a', True, 10.5))
        gs.append(g)
    for k in (4, 7, 10):
        gs[0].line([(0, k), (k, 0)], 'a', sw=1.8)
    for k in (3, 5, 7):
        gs[1].line([(k, 10), (k, k), (10, k)], 'a', sw=1.8)
    for k in (2, 4.5, 7):
        gs[2].line([(0.5, k), (9.5, k + 2.5)], 'a', sw=1.8)
    gs[2].arrow(6, 4, 3.6, 7, 'main', sw=1.4, head=5)
    gs[2].text(6.2, 3.0, '効用が高い', 'start', 'main', True, 9.5)
    for k in (3, 5.5, 8):
        gs[3].vl(k, 'a', y0=0.5, y1=9.5, sw=1.8)
    gs[3].arrow(4, 1.2, 7, 1.2, 'main', sw=1.4, head=5)
    return panels(gs, '特殊な無差別曲線', h=306)


FIG['keizai.special'] = _special()

# ------------------------------------------------ 1.6.2 予算制約と消費者行動


def _budget():
    g1 = G(xmax=16, ymax=13, w=176, h=196, ox=0, pl=22, pr=10, xlab='X', ylab='Y', cap='所得が増える', ccol='b')
    g2 = G(xmax=16, ymax=13, w=176, h=196, ox=184, pl=22, pr=10, xlab='X', ylab='Y', cap='X財の価格が下がる', ccol='a')
    g1.line([(0, 8), (8, 0)], 'main').line([(0, 12), (12, 0)], 'b', dash=True)
    g1.arrow(4, 4, 6, 6, 'b', sw=1.6, head=5)
    g1.text(9.0, 9.4, '平行に外へ', 'middle', 'b', True, 10)
    g2.line([(0, 8), (8, 0)], 'main').line([(0, 8), (16, 0)], 'a', dash=True)
    g2.arrow(8.6, 0.8, 13.4, 0.8, 'a', sw=1.6, head=5)
    g2.text(9.6, 9.4, 'Y軸の切片を中心に\n外へ回転', 'middle', 'a', True, 10)
    return panels([g1, g2], '予算線の動き（傾き＝－Px÷Py）', h=196)


FIG['keizai.budget'] = _budget()


def _optimum():
    g = G(xmax=10, ymax=10, h=250, xlab='X財', ylab='Y財', pr=30)
    g.line([(0, 8), (8, 0)], 'main', sw=2.2, label='予算線 X＋Y＝8', at=(8, 0.4), dx=2)
    for k, col, lab in ((9, 'sub', 'U1'), (16, 'b', 'U2'), (25, 'a', 'U3')):
        g.fn(lambda x, k=k: k / x, k / 10.0, 10, col, label=lab, at=(10, k / 10.0), dx=2)
    g.dot(4, 4, 'b', label='E（4, 4）', pos='ne').guide(4, 4)
    g.text(5.2, 8.9, '接点E：限界代替率＝価格比\nU3は予算で買えない\nU1は効用を上げる余地がある', 'start', 'main', True, 10.5)
    return g.svg('最適な消費（U＝XY、所得8、価格1と1）')


FIG['keizai.optimum'] = _optimum()


def _slutsky():
    g = G(xmax=16, ymax=9, h=332, xlab='X財', ylab='Y財', pr=44, pb=102)
    gx = 4 * math.sqrt(2)
    gy = gx / 2
    g.line([(0, 8), (8, 0)], 'main', sw=1.8)
    g.line([(0, 8), (16, 0)], 'a', sw=2)
    g.line([(0, gx), (2 * gx, 0)], 'c', dash='5 4', sw=1.6)
    g.fn(lambda x: 16 / x, 1.8, 16, 'b', label='U＝16', at=(16, 1.0), dx=2, lsize=10.5)
    g.fn(lambda x: 32 / x, 3.6, 16, 'b', dash='6 3', label='U＝32', at=(16, 2.0), dx=2, lsize=10.5)
    g.dot(4, 4, 'main', label='E', pos='nw').dot(gx, gy, 'c', label='G', pos='sw').dot(8, 4, 'a', label='F', pos='ne')
    for x, s2 in ((4, '4'), (gx, '5.66'), (8, '8')):
        g.seg(x, 0, x, 9, 'main', dash='2 3', op=0.4)
        g.xt(x, s2)
    _below(g, [('黒＝元の予算線、赤＝新しい予算線、点線＝補助線', 'main'), ('E→G：代替効果（Xは約1.66増える）', 'c'), ('G→F：所得効果（Xは約2.34増える）', 'a'),
               ('Yは代替効果で約1.17減り、所得効果で同じだけ増える', 'main')], 36)
    return g.svg('代替効果と所得効果（U＝XY、所得8、Xの価格1→0.5）')

FIG['keizai.slutsky'] = _slutsky()


def _engel():
    g = G(xmax=10, ymax=10, h=250, xlab='需要量', ylab='所得', pr=24)
    pts = [(0, 0), (2, 1.6), (4, 3.6), (5.4, 5.4), (5.9, 6.4), (6.0, 7.0), (5.6, 8.2), (4.6, 9.6)]
    g.line(pts, 'a', sw=2.4)
    g.text(1.6, 3.6, '正常財：右上がり', 'end', 'b', True, 10.5)
    g.text(6.4, 6.6, '所得弾力性ゼロ：垂直', 'start', 'main', True, 10.5)
    g.text(5.4, 9.3, '劣等財：左上へ', 'start', 'a', True, 10.5)
    return g.svg('エンゲル曲線（縦軸に所得）')


FIG['keizai.engel'] = _engel()


def _engel2():
    g1 = G(xmax=10, ymax=10, w=176, h=200, ox=0, pl=22, pr=10, xlab='需要量', ylab='所得', cap='奢侈品（弾力性＞1）', ccol='a')
    g2 = G(xmax=10, ymax=10, w=176, h=200, ox=184, pl=22, pr=10, xlab='需要量', ylab='所得', cap='必需品（0～1）', ccol='b')
    g1.fn(lambda x: 3.0 * math.sqrt(x), 0, 10, 'a', sw=2.2)
    g1.seg(0, 0, 4, 6.0, 'main', dash='4 3', op=0.8)
    g1.dot(4, 6.0, 'a')
    g1.text(6.6, 3.0, '曲線が原点から\nの直線より緩やか', 'middle', 'a', True, 9.5)
    g2.fn(lambda x: 0.12 * x * x + 0.5 * x, 0, 10, 'b', sw=2.2)
    g2.seg(0, 0, 7, 0.12 * 49 + 3.5, 'main', dash='4 3', op=0.8)
    g2.dot(7, 0.12 * 49 + 3.5, 'b')
    g2.text(6.4, 2.6, '曲線が原点から\nの直線より急', 'middle', 'b', True, 9.5)
    return panels([g1, g2], '奢侈品と必需品（縦軸に所得の場合）', h=200)


FIG['keizai.engel2'] = _engel2()

FIG['keizai.goodseff'] = grid(['財', '代替効果', '所得効果', '価格が下がると需要量は'],
                              [['正常財', '増える', '増える', '必ず増える'], ['劣等財（ギッフェン財以外）', '増える', '減る（代替効果より小さい）', '増える'],
                               ['ギッフェン財', '増える', '減る（代替効果より大きい）', '減る（需要曲線が右上がり）']],
                              [104, 56, 104, 96], align=['l', 'c', 'c', 'c'], title='価格が下がったときの代替効果と所得効果', size=10.5,
                              tcol={'減る（需要曲線が右上がり）': 'a'})


def _twoper():
    g = G(xmax=12, ymax=17, h=250, xlab='今期の消費 C1', ylab='来期の消費 C2', pl=64, pr=20, pb=40, xlpos='low')
    g.line([(0, 12), (10, 0)], 'b', label='利子率r', at=(1.6, 11.2), anchor='start', lsize=10.5)
    g.line([(0, 16), (10, 0)], 'a', dash=True, label='rが上がる', at=(1.6, 15.6), anchor='start', lsize=10.5)
    g.dot(10, 0, 'main').xt(10, 'Y', bold=True)
    g.yt(12, 'Y（1＋r）', 'b', True)
    g.text(5.4, 11.0, '傾き＝－（1＋r）\n今期の消費1の機会費用は\n来期の消費1＋r', 'start', 'main', True, 10.5)
    return g.svg('2期間の消費の選択（C2＝（Y－C1）×（1＋r））')

FIG['keizai.twoper'] = _twoper()

# ------------------------------------------------ 1.6.3 需要曲線


def _pcc():
    g1 = G(xmax=10, ymax=8, w=360, h=180, oy=0, pl=40, pr=30, pb=22, xlab='X財', ylab='Y財', origin='')
    g2 = G(xmax=10, ymax=2.6, w=360, h=170, oy=180, pl=40, pr=30, pt=12, xlab='X財', ylab='Xの価格', origin='')
    for px, col in ((2, 'sub'), (1, 'main'), (0.5, 'a')):
        g1.line([(0, 8), (min(10, 8 / px), 8 - px * min(10, 8 / px))], col, sw=1.6)
    for x, k in ((2, 8), (4, 16), (8, 32)):
        g1.fn(lambda xx, k=k: k / xx, k / 8.0, 10, 'b', sw=1.4)
        g1.dot(x, 4, 'b')
        g1.seg(x, 4, x, 0, 'main', dash='2 3', op=0.6)
    g1.line([(1, 4), (9.6, 4)], 'c', dash='5 3', sw=2, label='価格消費曲線', at=(9.6, 4.6), anchor='end')
    for x, p in ((2, 2), (4, 1), (8, 0.5)):
        g2.dot(x, p, 'a').seg(x, p, x, 2.6, 'main', dash='2 3', op=0.6)
        g2.yt(p, str(p))
    g2.fn(lambda x: 4.0 / x, 1.6, 10, 'a', label='需要曲線', at=(9.6, 0.62), anchor='end', dy=-10)
    return panels([g1, g2], '価格消費曲線から需要曲線を導く（U＝XY、所得8）', h=350)


FIG['keizai.pcc'] = _pcc()


def _hsum():
    caps = ['Aの需要', 'Bの需要', '市場の需要（水平和）']
    gs = []
    for i in range(3):
        g = G(xmax=16, ymax=11, w=118, h=176, ox=i * 121, pl=18, pr=6, pt=24, pb=22, origin='')
        g.raw(txt(i * 121 + 59, 13, caps[i], 'middle', 'main', True, 10.5))
        g.hl(4, 'c', sw=1, dash='3 3')
        gs.append(g)
    gs[0].line([(0, 10), (10, 0)], 'a').dot(6, 4, 'a').xt(6, '6')
    gs[1].line([(0, 6), (6, 0)], 'b').dot(2, 4, 'b').xt(2, '2')
    gs[2].line([(0, 10), (4, 6), (16, 0)], 'main', sw=2.2).dot(8, 4, 'main').xt(8, '8').dot(4, 6, 'c')
    gs[0].yt(4, '4')
    gs[2].text(5.4, 8.2, '価格6で折れる', 'start', 'c', True, 9.5)
    ex = [txt(180, 194, '価格4では、6＋2＝8（横に足す）', 'middle', size=10.5, bold=True)]
    return panels(gs, '市場の需要曲線＝個人の需要の水平和', h=200, extra=ex)


FIG['keizai.hsum'] = _hsum()

FIG['keizai.dshift'] = grid(['要因', '需要曲線'],
                            [['代替財の価格が上がる', '右へ'], ['補完財の価格が上がる', '左へ'], ['所得が増える（正常財）', '右へ'], ['所得が増える（劣等財）', '左へ']],
                            [230, 130], align=['l', 'c'], title='需要曲線のシフト', size=11.5, tcol={'右へ': 'b', '左へ': 'a'})

FIG['keizai.others'] = grid(['効果', '内容'],
                            [['バンドワゴン効果', '多くの人が買うほど、その財が欲しくなる'], ['スノッブ効果', '多くの人が買うほど、その財が欲しくなくなる'],
                             ['ヴェブレン効果', '価格が高いこと自体が見せびらかしの価値を生み、需要を増やす']],
                            [106, 254], align=['l', 'l'], title='他人の消費が影響する需要', size=11)


def _wtp():
    g = G(xmax=6, ymax=11, xmin=0, h=236, xlab='数量（個）', ylab='支払意思額', pr=16)
    vals = [10, 8, 6, 4, 2]
    for i, v in enumerate(vals):
        x0 = i + 0.08
        if v > 5:
            g.rect(x0, 5, i + 0.92, v, col='b', op=0.32)
            g.rect(x0, 0, i + 0.92, 5, col='sub', op=0.18)
        else:
            g.rect(x0, 0, i + 0.92, v, col='sub', op=0.1)
        g.text(i + 0.5, v + 0.5, str(v), 'middle', 'main', True, 10.5)
        g.xt(i + 0.5, '%d個目' % (i + 1), size=9.5)
    g.hl(5, 'a', x0=0, x1=6, label='価格5', at=(6, 5), anchor='end', dy=-8)
    g.text(3.5, 9.4, '3個買う。緑＝消費者余剰\n（5＋3＋1＝9）、灰色＝支払額15', 'start', 'main', True, 10.5)
    return g.svg('需要曲線の高さ＝限界的な支払意思額')


FIG['keizai.wtp'] = _wtp()

# ------------------------------------------------ 1.6.4 生産関数


def _tpapmp():
    TP = lambda L: 6 * L * L - 0.3 * L ** 3
    g1 = G(xmax=14, ymax=380, w=360, h=200, oy=0, pl=40, pr=16, pb=22, xlab='労働量', ylab='総生産物（TP）', origin='0')
    g2 = G(xmax=14, ymax=45, w=360, h=184, oy=200, pl=40, pr=16, pt=10, xlab='労働量', ylab='', origin='0')
    g1.fn(TP, 0, 13.6, 'main')
    g1.line([(0, 0), (12.4, 372)], 'c', dash='5 3', sw=1.4)
    g1.dot(10, 300, 'c', label='原点からの直線が接する：AP最大＝MP', pos='w')
    g1.dot(13.33, TP(13.33), 'main', label='MP＝0', pos='sw')
    g2.fn(lambda L: 12 * L - 0.9 * L * L, 0, 13.6, 'a', label='MP（限界生産物）', at=(4.6, 40), anchor='end')
    g2.fn(lambda L: 6 * L - 0.3 * L * L, 0, 14, 'b', label='AP（平均生産物）', at=(4.0, 14.0), anchor='start')
    g2.dot(10, 30, 'main', label='AP最大＝MP', pos='se')
    g2.seg(10, 30, 10, 0, 'main', dash='3 3')
    g1.seg(10, 300, 10, 0, 'main', dash='3 3')
    return panels([g1, g2], '総生産物・平均生産物・限界生産物', h=384)


FIG['keizai.tpapmp'] = _tpapmp()


def _isoq():
    g = G(xmax=10, ymax=10, h=252, xlab='労働 L', ylab='資本 K', pr=26)
    g.fn(lambda L: 16 / L, 1.6, 10, 'b', label='等量曲線', at=(10, 1.6), dx=2)
    g.line([(0, 8), (8, 0)], 'a', label='等費用線', at=(8, 0.4), dx=2)
    g.line([(0, 10), (10, 0)], 'a', dash=True, label='費用が増える', at=(6.8, 4.2), anchor='start', lsize=10.5)
    g.dot(4, 4, 'main', label='E：費用最小', pos='sw')
    g.dot(2, 8, 'c', label='A', pos='e')
    g.yt(8, 'C÷r', 'a', True).xt(8, 'C÷w', 'a', True)
    g.text(3.2, 9.4, '接点：MPL÷w＝MPK÷r\n（技術的限界代替率＝w÷r）', 'start', 'main', True, 10.5)
    return g.svg('費用最小化（等量曲線と等費用線の接点）')


FIG['keizai.isoq'] = _isoq()


def _isocost():
    caps = [('賃金が下がる', '横の切片が右へ'), ('資本の価格が上がる', '縦の切片が下へ'), ('費用が増える', '平行に外へ')]
    gs = []
    for i in range(3):
        g = G(xmax=10, ymax=10, w=118, h=160, ox=i * 121, pl=14, pr=8, pt=34, pb=18, xlab='L', ylab='K', origin='')
        g.raw(txt(i * 121 + 59, 12, caps[i][0], 'middle', 'main', True, 10.5))
        g.raw(txt(i * 121 + 59, 27, caps[i][1], 'middle', 'a', True, 10))
        g.line([(0, 7), (6, 0)], 'main', sw=1.8)
        gs.append(g)
    gs[0].line([(0, 7), (9.5, 0)], 'a', dash=True)
    gs[1].line([(0, 4), (6, 0)], 'a', dash=True)
    gs[2].line([(0, 9.5), (8.1, 0)], 'a', dash=True)
    return panels(gs, '等費用線の動き（w×L＋r×K＝C、傾き－w÷r）', h=160)


FIG['keizai.isocost'] = _isocost()

FIG['keizai.costmin'] = grid(['状態', 'どうすればよいか'],
                             [['労働の限界生産物÷賃金 ＞ 資本の限界生産物÷資本のレンタル価格', '労働を増やし、資本を減らす'],
                              ['労働の限界生産物÷賃金 ＜ 資本の限界生産物÷資本のレンタル価格', '資本を増やし、労働を減らす'], ['両方が等しい', '費用が最小（等量曲線と等費用線の接点）']],
                             [220, 140], align=['l', 'l'], title='1円当たりの限界生産物で考える', size=10.5)

FIG['keizai.rts'] = grid(['すべての投入を2倍にすると', '規模に関する収穫', 'Y＝AK^αL^β'],
                         [['生産量が2倍より多い', '収穫逓増', 'α＋β＞1'], ['生産量がちょうど2倍', '収穫一定（1次同次）', 'α＋β＝1'], ['生産量が2倍より少ない', '収穫逓減', 'α＋β＜1']],
                         [130, 130, 100], align=['l', 'c', 'c'], title='規模に関する収穫', size=11)

# ------------------------------------------------ 1.6.5 費用関数
MCf = lambda q: 6 - 2.4 * q + 0.3 * q * q
AVCf = lambda q: 6 - 1.2 * q + 0.1 * q * q
ACf = lambda q: AVCf(q) + 20.0 / q
TCf = lambda q: 20 + 6 * q - 1.2 * q * q + 0.1 * q ** 3


def _costc():
    g = G(xmax=10.5, ymax=10, h=270, xlab='生産量 q', ylab='費用', pr=24, pb=40, xlpos='low')
    g.fn(MCf, 0.4, 9.6, 'a', label='MC', at=(9.4, 9.4), anchor='end', dy=-4)
    g.fn(ACf, 2.8, 10.5, 'b', label='AC', at=(10.5, ACf(10.5)), dx=2)
    g.fn(AVCf, 0.4, 10.5, 'c', label='AVC', at=(10.5, AVCf(10.5)), dx=2)
    g.dot(7.69, ACf(7.69), 'b', label='損益分岐点', pos='e').guide(7.69, ACf(7.69), xt='7.7')
    g.dot(6, 2.4, 'c', label='操業停止点', pos='se').guide(6, 2.4, xt='6')
    g.dot(4, 1.2, 'a', label='MCの最小', pos='s').guide(4, 1.2, xt='4', h=False)
    g.text(4.4, 9.4, 'MCは、AVCとACの\nそれぞれの最低点を通る', 'start', 'main', True, 10.5)
    return g.svg('費用曲線（TC＝20＋6q－1.2q²＋0.1q³）')


FIG['keizai.costc'] = _costc()


def _tcc():
    g = G(xmax=10.5, ymax=64, h=272, xlab='生産量 q', ylab='総費用 TC', pr=20, pb=50, xlpos='low')
    g.fn(TCf, 0, 10.4, 'main', label='TC', at=(10.4, TCf(10.4)), dx=2)
    g.line([(0, 0), (10.5, 10.5 * ACf(7.69))], 'b', dash='5 3', sw=1.4)
    g.line([(0, 20), (10.5, 20 + 2.4 * 10.5)], 'c', dash='5 3', sw=1.4)
    g.dot(0, 20, 'main').yt(20, 'FC')
    g.dot(7.69, TCf(7.69), 'b').guide(7.69, TCf(7.69), h=False)
    g.dot(6, TCf(6), 'c').guide(6, TCf(6), h=False)
    g.dot(4, TCf(4), 'a').guide(4, TCf(4), h=False)
    g.xt(4, '4\n変曲点', 'a', True).xt(6, '6\nAVC最小', 'c', True).xt(7.69, '7.7\nAC最小', 'b', True)
    g.text(0.4, 58, '原点からの直線の傾き＝平均費用\nFCの点からの直線の傾き＝平均可変費用\n接線の傾き＝限界費用（変曲点で最小）', 'start', 'main', True, 10.5)
    return g.svg('総費用曲線の読み方')

FIG['keizai.tcc'] = _tcc()

FIG['keizai.pzone'] = grid(['価格', '利潤', '企業の行動（短期）'],
                           [['ACの最低点（損益分岐点）以上', 'ゼロ以上', '生産する'], ['AVCの最低点とACの最低点の間', '損失（固定費用より小さい）', '生産を続ける'],
                            ['AVCの最低点（操業停止点）', '損失＝固定費用', '生産しても停止しても同じ'], ['AVCの最低点より低い', '生産すると損失＞固定費用', '停止する（損失を固定費用に）']],
                           [134, 116, 110], align=['l', 'l', 'l'], title='価格と企業の行動', size=10.5)


def _lrac():
    g = G(xmax=12, ymax=10, h=232, xlab='生産量', ylab='平均費用', pr=26)
    LR = lambda q: 3 + 0.08 * (q - 7) ** 2
    dLR = lambda q: 0.16 * (q - 7)
    for c in (2.5, 5, 7.5, 10):
        g.fn(lambda q, c=c: LR(c) + dLR(c) * (q - c) + 0.32 * (q - c) ** 2, c - 2.2, c + 2.2, 'sub', sw=1.6)
    g.fn(LR, 0.6, 12, 'a', sw=2.6, label='長期平均費用（包絡線）', at=(11.8, LR(11.8) + 0.6), anchor='end')
    g.text(3.0, 1.4, '規模の経済', 'middle', 'b', True, 10.5)
    g.arrow(1.4, 2.0, 5.6, 2.0, 'b', sw=1.6, head=5)
    g.text(4.8, 9.2, '灰色＝短期平均費用', 'start', 'main', True, 10.5)
    return g.svg('長期平均費用曲線')


FIG['keizai.lrac'] = _lrac()

# ------------------------------------------------ 1.6.6 利潤最大化


def _profpc():
    g = G(xmax=16, ymax=64, h=250, xlab='生産量 Q', ylab='価格・費用', pr=24)
    g.rect(0, 30, 10, 40, col='b', op=0.3, label='利潤100', lcol='b', size=11)
    g.rect(0, 0, 10, 30, col='sub', op=0.14, label='総費用300', lcol='main', size=10.5)
    g.line([(0, 0), (15, 60)], 'a', label='MC＝4Q', at=(15, 60), anchor='end', dy=-10)
    g.fn(lambda q: 100.0 / q + 2 * q, 2.0, 16, 'c', label='AC', at=(16, 100 / 16.0 + 32), dx=-4, dy=14, anchor='end')
    g.hl(40, 'b', x0=0, x1=16, label='P＝MR＝40', at=(16, 40), anchor='end', dy=-8)
    g.dot(10, 40, 'main').guide(10, 40, xt='10')
    g.yt(30, '30')
    return g.svg('完全競争企業の利潤最大化（P＝MC、TC＝100＋2Q²）')


FIG['keizai.profpc'] = _profpc()


def _trtc():
    g = G(xmax=20, ymax=820, h=250, xlab='生産量 Q', ylab='金額', pr=26)
    g.line([(0, 0), (20, 800)], 'b', label='TR＝40Q', at=(20, 800), anchor='end', dy=-8)
    g.fn(lambda q: 100 + 2 * q * q, 0, 20, 'a', label='TC', at=(18.0, 640), anchor='start')
    g.line([(4, 92), (16, 572)], 'c', dash='5 3', sw=1.4)
    g.vspan(10, 300, 400, '利潤100（最大）', 'main', size=10.5)
    g.dot(10, 400, 'b').dot(10, 300, 'a')
    g.text(0.6, 700, 'TCの接線の傾き（MC）がTRの傾き（MR）に\n等しい生産量で、縦の差（利潤）が最大', 'start', 'main', True, 10.5)
    return g.svg('総収入曲線と総費用曲線')


FIG['keizai.trtc'] = _trtc()


def _mr():
    g = G(xmax=10.5, ymax=10.5, h=232, xlab='数量 Q', ylab='価格', pr=26, pb=40, xlpos='low')
    g.line([(0, 10), (10, 0)], 'a', label='需要 P＝10－Q', at=(3.0, 7.8), anchor='start')
    g.line([(0, 10), (5, 0)], 'a', dash=True, label='MR＝10－2Q', at=(5, 0), dx=4, dy=-12)
    g.xt(5, '5').xt(10, '10')
    g.text(5.4, 9.4, '限界収入の傾きは需要曲線の2倍\n（横軸の切片はちょうど半分）', 'start', 'main', True, 10.5)
    return g.svg('直線の需要曲線と限界収入')

FIG['keizai.mr'] = _mr()


def _isoprof():
    g = G(xmax=10, ymax=10, h=232, xlab='労働量 L', ylab='生産量 y', pr=24)
    g.fn(lambda L: 3.2 * math.sqrt(L), 0, 10, 'b', label='生産関数', at=(10, 10.0), anchor='end', dy=14)
    # 接点 L＝4（傾き 0.8）
    g.line([(0, 3.2), (10, 11.2)], 'a', dash='5 3', sw=1.6, label='等利潤線（傾き＝w÷p）', at=(5.6, 9.0), anchor='end')
    g.line([(0, 1.6), (10, 9.6)], 'sub', dash='5 3', sw=1.2)
    g.dot(4, 6.4, 'main', label='利潤最大：MPL＝w÷p', pos='se')
    g.yt(3.2, 'π÷p', 'a', True)
    return g.svg('生産関数と等利潤線')


FIG['keizai.isoprof'] = _isoprof()

# ------------------------------------------------ 1.6.7 供給曲線


def _supmc():
    g = G(xmax=10.5, ymax=10, h=252, xlab='生産量 q', ylab='価格・費用', pr=24)
    g.fn(MCf, 0.4, 9.6, 'sub', sw=1.4)
    g.fn(ACf, 2.8, 10.5, 'sub', sw=1.2, dash='4 3', label='AC', at=(10.5, ACf(10.5)), dx=2, lcol='main')
    g.fn(AVCf, 0.4, 10.5, 'c', sw=1.4, label='AVC', at=(10.5, AVCf(10.5)), dx=2)
    g.fn(MCf, 6, 9.6, 'b', sw=3.2, label='供給曲線（MCの一部）', at=(9.4, 9.6), anchor='end')
    g.line([(0, 0), (0, 2.4)], 'b', sw=3.2)
    g.dot(6, 2.4, 'c', label='操業停止点', pos='se')
    g.text(6.4, 0.75, '操業停止点より下の価格では\n生産しない（q＝0）', 'start', 'b', True, 10.5)
    return g.svg('完全競争企業の短期の供給曲線')


FIG['keizai.supmc'] = _supmc()

FIG['keizai.lreq'] = _rowflow([('', None, [('利潤が出ている', 'b'), '新しい企業が参入', '供給が増え、\n価格が下がる', ('利潤ゼロ', 'c')]),
                               ('', None, [('損失が出ている', 'a'), '企業が退出', '供給が減り、\n価格が上がる', ('利潤ゼロ', 'c')])],
                              '長期の均衡：価格＝長期平均費用の最低点', lw=0, size=10.5)

FIG['keizai.sshift'] = _lists([('右へシフト', 'b', ['技術の進歩', '企業の数の増加', '補助金']), ('左へシフト', 'a', ['原材料や賃金の上昇', '企業の数の減少', '課税'])],
                              '供給曲線のシフトの要因')
