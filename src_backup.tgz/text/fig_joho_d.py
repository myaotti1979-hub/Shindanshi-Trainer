# 経営情報システムの図表（2.1 経営戦略と情報システム）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, htree, timeline, ARROW, R, T, L, _svg, _c, wrap, tw)
from kit import (_lines, _dashrect, _box, _lists, _flow, _rowflow, _nest, _hub, _cycle, _ladder)
from ekit import G, txt, eq, panels
from jkit import stack, tiles, dtab, lab, pc, srv, cyl, cloud, person, rtr, brace, code, seq, r1, MONO

FIG = {}


def poly(o, pts, col='main', fill=None, op=0.16, sw=1.3, dash=None):
    d = 'M' + ' L'.join('%s %s' % (r1(a), r1(b)) for a, b in pts) + ' Z'
    ds = ' stroke-dasharray="%s"' % dash if dash else ''
    o.append('<path d="%s" style="fill:var(--sheet);stroke:none"/>' % d)
    o.append('<path d="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="%s"%s/>' % (d, _c(fill or 'sheet'), op if fill else 1, _c(col), sw, ds))


def circ(o, x, y, r, col='main', fill=None, op=0.16, sw=1.3):
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:var(--sheet);stroke:none"/>' % (r1(x), r1(y), r))
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="%s"/>' % (
        r1(x), r1(y), r, _c(fill or 'sheet'), op if fill else 1, _c(col), sw))


# ------------------------------------------------ 2.1.1 情報システム戦略
FIG['joho.ea'] = stack([('ビジネスアーキテクチャ\n業務の内容や流れ', 'b', '機能構成図、業務フロー'), ('データアーキテクチャ\n業務で扱う情報の構造', 'c', 'E-R図'),
                        ('アプリケーションアーキテクチャ\n業務を支える情報システムの構成', 'a', '情報システム関連図'),
                        ('テクノロジアーキテクチャ\nハードウェア、ソフトウェア、ネットワークなどの技術の基盤', 'sub', 'ネットワーク構成図')],
                       'EAの4つのアーキテクチャと成果物の例', bw=236, size=10)

FIG['joho.asis'] = _flow(['現状\n（As-Is）', ('差を埋める\n移行の計画', 'c'), ('あるべき姿\n（To-Be）', 'b')], '現状とあるべき姿', per_row=3, size=10.5)


def _soa():
    o = []
    svs = ['受注', '在庫の引当', '請求', '配送']
    for i, s in enumerate(svs):
        x = 4 + i * 89
        _box(o, x, 22, 82, 30, s, col='b', size=10.5, c0='b')
    o.append(T(4, 14, 'サービス（業務の機能を部品にしたもの）', size=10, bold=True, col='b'))
    sys_ = [('通信販売のシステム', [0, 1, 3], 40), ('法人向けのシステム', [0, 2], 220)]
    for nm, use, x in sys_:
        _box(o, x, 104, 136, 32, nm, col='c', size=10.5, c0='c')
        for u in use:
            sx = 4 + u * 89 + 41
            o.append(L(sx, 54, x + 68, 102, col='c', sw=1.2, dash='4 3'))
    o.append(T(4, 160, '決められたインタフェースで緩やかに結びつく（疎結合）', size=10.5))
    o.append(T(4, 176, '→ 業務の変化に合わせて組み替えやすい', size=10.5, bold=True, col='b'))
    return _svg(360, 182, o, 'SOA')


FIG['joho.soa'] = _soa()


def _anthony():
    o = []
    lv = [('戦略的計画', 'a', 'トップ：長期の方針の決定'), ('マネジメント\nコントロール', 'c', 'ミドル：資源の配分と管理'),
          ('オペレーショナル\nコントロール', 'b', '現場：業務の管理')]
    pw, lh = 190, 50
    for i, (s, col, note) in enumerate(lv):
        wt, wb = pw * (0.2 + 0.8 * i / 3), pw * (0.2 + 0.8 * (i + 1) / 3)
        cx, y = 2 + pw / 2, 4 + i * lh
        poly(o, [(cx - wt / 2, y), (cx + wt / 2, y), (cx + wb / 2, y + lh - 3), (cx - wb / 2, y + lh - 3)], col=col, fill=col, op=0.22, sw=1.2)
        ls = s.split('\n')
        for k, ln in enumerate(ls):
            o.append(T(cx, y + lh / 2 + 4 + (k - (len(ls) - 1) / 2) * 13, ln, 'middle', size=10, bold=True))
        o.append(T(200, y + lh / 2 + 4, note, size=10))
    return _svg(360, 158, o, 'アンソニーの3階層')


FIG['joho.anthony'] = _anthony()


def _bmc():
    o = []
    H, W = 150, 72
    cells = [(0, 0, W, H, 'パートナー', 'sub'), (W, 0, W, H / 2, '主要活動', 'c'), (W, H / 2, W, H / 2, 'リソース', 'c'),
             (2 * W, 0, W, H, '価値提案', 'a'), (3 * W, 0, W, H / 2, '顧客との\n関係', 'b'), (3 * W, H / 2, W, H / 2, 'チャネル', 'b'),
             (4 * W, 0, W, H, '顧客\nセグメント', 'b'), (0, H, 180, 40, 'コスト構造', 'sub'), (180, H, 180, 40, '収益の流れ', 'b')]
    for x, y, w, h, s, col in cells:
        o.append(R(x + 1, y + 1, w - 2, h - 2, fill=col, stroke=col if col != 'sub' else 'line', op=0.16 if col != 'sub' else 0.1, sw=1))
        ls = s.split('\n')
        for k, ln in enumerate(ls):
            o.append(T(x + w / 2, y + h / 2 + 4 + (k - (len(ls) - 1) / 2) * 13, ln, 'middle', size=10.5, bold=True))
    return _svg(360, 192, o, 'ビジネスモデルキャンバス')


FIG['joho.bmc'] = _bmc()

FIG['joho.rfx'] = _flow(['システム化構想の立案\n目的・範囲・効果', ('RFI（情報提供依頼書）\n技術や製品の情報を求める', 'c'), ('RFP（提案依頼書）\n要件や条件を示し、提案を求める', 'b'),
                         '提案（と見積もり）を評価し、ベンダーを選定', '契約'], '調達の流れ', per_row=3, size=10)

FIG['joho.poc'] = _flow([('PoC（概念実証）\n技術やアイデアが実現できるか', 'c'), ('PoV（価値実証）\n利用者や事業にとって価値があるか', 'b'),
                         ('PoB（ビジネス実証）\n事業として成り立つか（収益）', 'a')], '小さく試して確かめる', per_row=3, size=10)


def _fitgap():
    o = []
    o.append('<circle cx="128" cy="96" r="74" style="fill:%s;fill-opacity:0.14;stroke:%s" stroke-width="1.4"/>' % (_c('c'), _c('c')))
    o.append('<circle cx="232" cy="96" r="74" style="fill:%s;fill-opacity:0.14;stroke:%s" stroke-width="1.4"/>' % (_c('b'), _c('b')))
    o.append(T(80, 14, '自社の業務の要件', 'middle', size=10.5, bold=True, col='c'))
    o.append(T(280, 14, 'パッケージの機能', 'middle', size=10.5, bold=True, col='b'))
    o.append(T(180, 94, 'フィット', 'middle', size=11, bold=True))
    o.append(T(180, 109, '（合う）', 'middle', size=9.5))
    o.append(T(96, 94, 'ギャップ', 'middle', size=11, bold=True, col='a'))
    o.append(T(96, 109, '（合わない）', 'middle', size=9.5, col='a'))
    o.append(T(4, 192, 'ギャップへの対応：業務をパッケージに合わせる、または追加開発', size=10))
    o.append(T(4, 208, '過度なカスタマイズは、費用と保守の負担を増やす', size=10, col='a', bold=True))
    return _svg(360, 214, o, 'フィット＆ギャップ分析')


FIG['joho.fitgap'] = _fitgap()

FIG['joho.scratch'] = grid(['', 'スクラッチ開発', 'パッケージの導入'],
                           [['つくり方', '一から開発する', '既製のパッケージを導入する'], ['業務との関係', '自社の業務に合わせやすい', '業務をパッケージに合わせる必要がある'],
                            ['費用と期間', 'かかる', '早く安く導入できる']],
                           [90, 130, 140], align=['l', 'l', 'l'], title='スクラッチ開発とパッケージの導入', size=10.5, tcol={'かかる': 'a', '早く安く導入できる': 'b'})

# ------------------------------------------------ 2.1.2 経営革新と情報システム


def _bprbpm():
    g = G(xmax=10, ymax=10, h=200, xlab='時間', ylab='業務の成果', origin='', pb=28)
    g.line([(0, 2), (4, 2), (4.3, 8), (10, 8)], col='a', sw=2.4)
    pts = []
    v = 2
    for k in range(10):
        pts += [(k, v), (k + 1, v)]
        v += 0.42
    g.line(pts, col='b', sw=2.2)
    g.text(4.6, 8.9, 'BPR：根本から再設計し、劇的に改善', 'start', 'a', True, 10)
    g.text(5.6, 3.6, 'BPM：サイクルで継続的に改善', 'start', 'b', True, 10)
    return g.svg('BPRとBPM')


FIG['joho.bprbpm'] = _bprbpm()

FIG['joho.bpm'] = _cycle(['分析', '設計', '実行', '監視', '改善'], 'BPMのサイクル', h=200, bw=80, bh=34, center='BPM', ccol='b')

FIG['joho.notation'] = _lists([('作業の流れ（ワークフロー）に着目', 'b', ['BPMN：業務の流れを図で表す国際標準', 'EPC：イベントと機能を交互につなぐ', 'ペトリネット：状態と遷移で並行処理を表す']),
                               ('人と人のやり取り（調整）に着目', 'c', ['DEMO：依頼や約束などのやり取りで業務をモデル化する'])], '業務のプロセスの表記法', size=10.5)


def _rpa():
    o = []
    st = ['受注メールを\n開く', '内容を表計算\nソフトに転記', '基幹システム\nに入力']
    for i, s in enumerate(st):
        x = 4 + i * 120
        _box(o, x, 26, 104, 40, s, size=10, bold0=False)
        if i:
            o.append(ARROW([(x - 14, 46), (x - 2, 46)], sw=1.3, head=5))
    o.append(T(4, 16, 'パソコンで人が行う定型の操作を、ソフトウェアのロボットが自動で実行', size=10, bold=True, col='b'))
    o.append(R(4, 82, 172, 54, fill='b', stroke='b', op=0.1, rx=6))
    o.append(T(12, 100, '向く', size=10.5, bold=True, col='b'))
    o.append(T(12, 118, '手順の決まった繰り返しの作業', size=10))
    o.append(R(184, 82, 172, 54, fill='a', stroke='a', op=0.1, rx=6))
    o.append(T(192, 100, '向かない', size=10.5, bold=True, col='a'))
    o.append(T(192, 118, '判断の基準が決まっていない業務', size=10))
    o.append(T(4, 156, '工場の産業用ロボットではない', size=10.5, bold=True, col='a'))
    return _svg(360, 162, o, 'RPA')


FIG['joho.rpa'] = _rpa()


def _lowcode():
    o = []
    st = [('スクラッチ開発', 'コードを書いてつくる', 'sub'), ('ローコード開発', 'コードを少しだけ書く', 'c'), ('ノーコード開発', 'コードをほとんど書かない', 'b')]
    for i, (a, b, col) in enumerate(st):
        x = 4 + i * 120
        _box(o, x, 8, 112, 42, a + '\n' + b, col=col, size=10, c0=col if col != 'sub' else None)
    o.append(ARROW([(4, 62), (356, 62)], col='b', sw=1.4, head=6))
    o.append(T(356, 78, '業務部門の担当者でも開発できる（市民開発）', 'end', size=10, bold=True, col='b'))
    o.append(T(4, 104, '情報システム部門が把握していないところで、従業員が独自にITのサービスや', size=10))
    o.append(T(4, 119, '機器を使う＝シャドーIT（情報漏えいなどのリスク）', size=10, col='a', bold=True))
    return _svg(360, 126, o, 'ノーコード開発とローコード開発')


FIG['joho.lowcode'] = _lowcode()

FIG['joho.erp'] = _hub('ERP\nデータを一元化', ['販売', '購買', '生産', '在庫', '会計', '人事'], 'ERP（統合基幹業務システム）', bw=78, cw=120, ccol='b')


def _scm():
    o = []
    st = ['調達', '生産', '物流', '販売']
    for i, s in enumerate(st):
        x = 4 + i * 90
        _box(o, x, 10, 74, 32, s, col='c', size=11, c0='c')
        if i:
            o.append(ARROW([(x - 14, 26), (x - 2, 26)], sw=1.4, head=5))
        o.append(ARROW([(x + 37, 76), (x + 37, 46)], col='b', sw=1.2, head=5))
        o.append(ARROW([(x + 37, 46), (x + 37, 76)], col='b', sw=1.2, head=5))
    o.append(R(4, 78, 344, 30, fill='b', stroke='b', op=0.16, rx=5))
    o.append(T(176, 98, '供給の流れの全体で情報を共有する', 'middle', size=10.5, bold=True, col='b'))
    o.append(T(176, 128, '→ 在庫と期間を最適にする', 'middle', size=10.5, bold=True))
    return _svg(360, 136, o, 'SCM')


FIG['joho.scm'] = _scm()

FIG['joho.bizsys'] = grid(['システム', '対象', 'ねらい'],
                          [['ERP', '販売、購買、生産、在庫、会計、人事などの基幹業務', 'データを一元化し、経営資源の全体を把握する'],
                           ['SCM', '調達から販売までの供給の流れ', '在庫と期間を最適にする'], ['CRM', '顧客の情報や取引の履歴', '顧客との長期的な関係を築く'],
                           ['SFA', '営業の活動（訪問の記録、商談の進み具合など）', '営業の効率を高める']],
                          [50, 160, 150], align=['l', 'l', 'l'], title='業務のシステムの比較', size=10)

FIG['joho.edi'] = stack([('取引基本規約', 'sub', '取引の契約の基本'), ('業務運用規約', 'sub', '運用の方法やタイミング'),
                         ('情報表現規約', 'a', 'データの書き方の規則（シンタックスルール）やメッセージの形式'), ('情報伝達規約', 'b', '通信の方法（プロトコルなど）')],
                        'EDIの取り決め（規約）の4つの階層', bw=130, size=10.5)

def _dx():
    o = []
    items = [('2018年', 'DXレポート', 'レガシーシステムを放置すると、2025年以降に大きな経済損失（2025年の崖）', 'a'),
             ('2018年', 'DX推進ガイドライン', 'DXを進めるために経営者が押さえるべき事項', 'c'),
             ('2021年', 'DXレポート2.1', '既存の企業とベンダーが互いに依存する関係から脱する', 'b'),
             ('2022年', 'デジタルガバナンス・コード2.0', 'DX推進ガイドラインを統合', 'b'),
             ('2024年', 'デジタルガバナンス・コード3.0', '5つの柱に整理', 'b')]
    y = 6
    pts = []
    for yr, nm, d, col in items:
        ls = wrap(d, 270, 9.5)
        h = 20 + len(ls) * 13
        pts.append((y, col))
        o.append(T(4, y + 13, yr, size=10.5, bold=True, col=col))
        o.append(T(78, y + 13, nm, size=10.5, bold=True))
        for k, ln in enumerate(ls):
            o.append(T(78, y + 28 + k * 13, ln, size=9.5))
        y += h + 6
    o.insert(0, L(64, 10, 64, pts[-1][0] + 10, col='line', sw=1.4))
    for (yy, col) in pts:
        circ(o, 64, yy + 9, 4.5, col=col, fill=col, op=0.9)
    return _svg(360, y, o, 'DXの政策の流れ')


FIG['joho.dx'] = _dx()

FIG['joho.dxguide'] = grid(['', '○ 提言', '× 避けること'],
                           [['経営トップ', '自ら変革にコミットする', '現場の積み上げに任せる'],
                            ['事業部門', 'ITシステムのオーナーシップを持ち、企画と要件定義を自ら行う', '情報システム部門やベンダーに任せきりにする'],
                            ['PoC', '経営戦略を示したうえで行う', '技術から入る'],
                            ['刷新したシステムの評価', 'ビジネスの変化に素早く追従でき、うまくいくか', '短期間で完成したか'],
                            ['変革の範囲', '組織・人事の仕組み、企業文化・風土も', '仕事の仕方だけ']],
                           [84, 148, 128], align=['l', 'l', 'l'], title='DX推進ガイドラインの主な提言', size=10)

FIG['joho.dx21'] = tiles([('企業の変革を共に推進するパートナー', 'b'), ('DXに必要な技術を提供するパートナー', 'b'), ('共通のプラットフォームの提供主体', 'c'),
                          ('新しいビジネスやサービスの提供主体', 'c')], 'DXレポート2.1：デジタル産業を構成する企業の類型', cols=2, size=10.5)


def _mfgdx():
    o = []
    _box(o, 4, 30, 140, 70, 'スマートファクトリー\n製造のプロセスの最適化や効率化', col='c', size=10, c0='c')
    o.append(T(4, 18, '① まずここに取り組む', size=10, bold=True, col='c'))
    o.append(ARROW([(146, 65), (186, 42)], sw=1.5, head=6))
    o.append(ARROW([(146, 65), (186, 100)], sw=1.5, head=6))
    o.append(T(166, 18, '② 順調に進んだら強化', size=10, bold=True, col='b'))
    _box(o, 190, 24, 166, 40, 'スマートプロダクト\nデジタルの技術やデータで価値を高めた製品', col='b', size=9.5, c0='b')
    _box(o, 190, 72, 166, 60, 'スマートサービス\n製品の利用の場面をサービスに。製造のノウハウを他の製造業者に提供', col='b', size=9.5, c0='b')
    o.append(T(4, 152, '軸：OT（工場の設備や機械を制御・運用する技術）のデジタル化とITとの連携', size=10))
    o.append(T(4, 168, '収益に直結するスマートプロダクトから始めることを勧めているのではない', size=10, col='a', bold=True))
    return _svg(360, 174, o, '製造業のDX')


FIG['joho.mfgdx'] = _mfgdx()

FIG['joho.dxcheck'] = tiles(['競争優位性の確立', '業務プロセスの最適化', 'システムの構築・見直しの中長期計画', 'データの収集と可視化', 'データ活用・分析', 'データ連携',
                             'プライバシー・データセキュリティ', '外部資源の活用', '人材の育成・確保'], '製造分野DX度チェックの9つの項目', cols=3, size=10)

FIG['joho.dxlevel'] = _ladder([('レベル0\n取組ができていない', None), ('レベル1\n課題が明確になっている', None), ('レベル2\n取組を実行している', 'c'),
                               ('レベル3\n変化に対応できる仕組みが構築できている（DXの到達）', 'b')], '進展のレベル', bw=210, size=10)

# ------------------------------------------------ 2.1.3 ITガバナンス


def _edm():
    o = []
    o.append(R(2, 4, 356, 112, fill='a', stroke='a', op=0.08, rx=8, sw=1.2))
    o.append(T(10, 22, '取締役会等：ITガバナンス', size=11, bold=True, col='a'))
    items = [(70, 'E', '評価', '現状とあるべき姿を\n比べて判断'), (180, 'D', '指示', '責任と資源を\n割り当てる'), (290, 'M', 'モニタ', '達成の度合いや\n遵守の状況を確かめる')]
    for x, k, nm, d in items:
        circ(o, x, 52, 17, col='a', fill='a', op=0.25)
        o.append(T(x, 57, k, 'middle', size=13, bold=True))
        o.append(T(x + 22, 48, nm, size=10, bold=True))
        for j, ln in enumerate(d.split('\n')):
            o.append(T(x, 86 + j * 13, ln, 'middle', size=9.5))
    o.append(ARROW([(89, 52), (161, 52)], col='a', sw=1.2, head=5))
    o.append(ARROW([(199, 52), (271, 52)], col='a', sw=1.2, head=5))
    _box(o, 40, 150, 280, 40, '経営者（CEO、CIOなど）：ITマネジメント\n計画、実行、管理', col='b', size=10.5, c0='b')
    o.append(ARROW([(180, 118), (180, 148)], col='a', sw=1.8, head=6))
    o.append(T(186, 138, '指示', size=10, bold=True, col='a'))
    o.append(ARROW([(290, 148), (290, 118)], col='b', sw=1.8, head=6))
    o.append(T(296, 138, '報告', size=10, bold=True, col='b'))
    o.append(T(4, 210, 'ISO/IEC 38500（JIS Q 38500）にもとづく考え方', size=10))
    return _svg(360, 216, o, 'EDMモデル')


FIG['joho.edm'] = _edm()

FIG['joho.coso'] = tiles([('統制環境', 'b'), ('リスク評価', 'b'), ('統制活動', 'b'), ('情報と伝達', 'b'), ('モニタリング', 'b'), ('ITへの対応\n（日本の基準で追加）', 'a')],
                         'COSOの内部統制の構成要素', cols=3, size=10.5)

FIG['joho.itctrl'] = grid(['IT統制', '内容の例'],
                          [['IT全社的統制', '組織全体の、ITに関する統制'], ['IT全般統制', 'システムの開発、運用、アクセスの管理など'], ['IT業務処理統制', '入力のチェックなど、個々の業務の処理の統制']],
                          [120, 240], align=['l', 'l'], title='IT統制', size=10.5)

FIG['joho.audit'] = _flow(['監査計画の策定', '予備調査', '本調査\n監査証拠の入手と評価', '監査報告書の\n作成と報告', ('フォローアップ\n改善の状況の確認', 'b')], 'システム監査の流れ', per_row=3, size=10)

FIG['joho.auditor'] = _lists([('独立性', 'b', ['精神上の独立性', '外観上の独立性（監査の対象から独立）']), ('倫理', 'c', ['誠実性', '客観性', '能力と正当な注意', '秘密の保持']),
                              ('役割', 'a', ['保証を与える、または改善のための助言をする', '改善を自ら実施するのではない'])], 'システム監査人', size=10)


def _dgc():
    o = []
    rows = [('1', '経営ビジョン・ビジネスモデルの策定'), ('2', 'DX戦略の策定'), ('3', 'DX戦略の推進'), ('4', '成果指標の設定・DX戦略の見直し'), ('5', 'ステークホルダーとの対話')]
    y = 4
    for n, s in rows:
        h = 76 if n == '3' else 30
        o.append(R(4, y, 352, h, fill='b', stroke='b', op=0.1 if n != '3' else 0.14, rx=5, sw=1))
        circ(o, 22, y + 15, 10, col='b', fill='b', op=0.4)
        o.append(T(22, y + 19, n, 'middle', size=11, bold=True))
        o.append(T(40, y + 20, s, size=10.5, bold=True))
        if n == '3':
            for k, sub in enumerate(['3-1 組織づくり', '3-2 デジタル人材の\n育成・確保', '3-3 ITシステム・\nサイバーセキュリティ']):
                _box(o, 40 + k * 106, y + 32, 100, 38, sub, size=9.5, bold0=False)
        y += h + 6
    o.append(T(4, y + 12, '「企業文化に関する方策」「経営者の情報発信」という名の柱はない', size=10, col='a', bold=True))
    return _svg(360, y + 18, o, 'デジタルガバナンス・コード3.0の5つの柱')


FIG['joho.dgc'] = _dgc()

FIG['joho.dxcert'] = grid(['', 'DX認定の申請の項目（要旨）'],
                          [['(1)', '経営ビジョン・ビジネスモデル（方向性の決定）'], ['(2)', '戦略の決定（推進の体制、最新の技術を活用する環境整備の方策の提示を含む）'],
                           ['(3)', '戦略の達成状況に係る指標の決定'], ['(4)', '実務執行総括責任者による情報発信'],
                           ['(5)', '実務執行総括責任者が主導する、情報処理システムの課題の把握'], ['(6)', 'サイバーセキュリティに関する対策の策定と実施']],
                          [36, 324], align=['c', 'l'], title='DX認定の6つの項目', size=10)

# ------------------------------------------------ 2.1.4 情報化社会
def _society():
    o = []
    st = [('1.0', '狩猟社会'), ('2.0', '農耕社会'), ('3.0', '工業社会'), ('4.0', '情報社会')]
    for i, (n, s) in enumerate(st):
        x, y = 4 + i * 56, 132 - i * 26
        _box(o, x, y, 52, 40, 'Society\n' + n + '\n' + s, col='c' if i == 3 else None, size=9, c0='c' if i == 3 else None)
    _box(o, 232, 6, 124, 112, 'Society 5.0\nサイバー空間とフィジカル空間を高度に融合したシステムで、経済の発展と社会的な課題の解決を両立する人間中心の社会', col='b', size=9.5, c0='b')
    return _svg(360, 176, o, 'Society 5.0')


FIG['joho.society'] = _society()


def _cps():
    o = []
    o.append(R(2, 4, 160, 132, fill='c', stroke='c', op=0.08, rx=8, sw=1.2))
    o.append(T(82, 22, 'フィジカル空間（現実）', 'middle', bold=True, size=10.5, col='c'))
    o.append(R(198, 4, 160, 132, fill='b', stroke='b', op=0.08, rx=8, sw=1.2))
    o.append(T(278, 22, 'サイバー空間（仮想）', 'middle', bold=True, size=10.5, col='b'))
    o.append('<path d="M40 104 L40 74 L60 62 L60 74 L80 62 L80 74 L100 62 L100 104 Z" style="fill:%s;fill-opacity:0.3;stroke:%s" stroke-width="1.3"/>' % (_c('c'), _c('c')))
    o.append(T(70, 124, '現実の設備', 'middle', size=9.5))
    o.append('<path d="M262 104 L262 74 L282 62 L282 74 L302 62 L302 74 L322 62 L322 104 Z" style="fill:none;stroke:%s" stroke-width="1.3" stroke-dasharray="4 3"/>' % _c('b'))
    o.append(T(292, 124, '双子のように再現', 'middle', size=9.5))
    o.append(ARROW([(118, 54), (240, 54)], col='c', sw=1.8, head=6))
    o.append(T(180, 46, 'センサーでデータを集める', 'middle', size=9.5, bold=True))
    o.append(ARROW([(240, 92), (118, 92)], col='b', sw=1.8, head=6))
    o.append(T(180, 84, '分析の結果を返して役立てる', 'middle', size=9.5, bold=True))
    o.append(T(4, 156, 'CPS：現実のデータを集め、サイバー空間で分析し、現実に返して役立てる', size=10))
    o.append(T(4, 172, 'デジタルツイン：現実を仮想の空間に再現し、シミュレーションや予測に使う', size=10))
    return _svg(360, 178, o, 'CPSとデジタルツイン')


FIG['joho.cps'] = _cps()


def _bubble():
    o = []
    o.append(T(86, 14, 'フィルターバブル', 'middle', bold=True, size=11, col='c'))
    o.append(T(270, 14, 'エコーチェンバー', 'middle', bold=True, size=11, col='a'))
    pal = ['a', 'b', 'c']
    import random
    rnd = random.Random(3)
    for i in range(16):
        x, y = 14 + rnd.random() * 150, 26 + rnd.random() * 30
        circ(o, x, y, 4, col=pal[i % 3], fill=pal[i % 3], op=0.7)
    o.append(R(14, 64, 150, 8, fill='main', stroke=None, op=0.25, rx=2))
    o.append(T(86, 86, '好みに合う情報だけを選んで表示', 'middle', size=9.5))
    o.append('<circle cx="86" cy="128" r="30" style="fill:%s;fill-opacity:0.1;stroke:%s" stroke-width="1.4"/>' % (_c('c'), _c('c')))
    person(o, 86, 132, col='c')
    for (x, y) in [(66, 110), (106, 112), (72, 148), (102, 148)]:
        circ(o, x, y, 4, col='c', fill='c', op=0.8)
    o.append(T(86, 176, '自分と異なる情報から隔てられる', 'middle', size=9.5, bold=True))
    cx, cy = 270, 100
    o.append('<circle cx="%s" cy="%s" r="56" style="fill:%s;fill-opacity:0.08;stroke:%s" stroke-width="1.4"/>' % (cx, cy, _c('a'), _c('a')))
    for k in range(5):
        a = -math.pi / 2 + 2 * math.pi * k / 5
        person(o, cx + 32 * math.cos(a), cy + 32 * math.sin(a) + 4, col='a')
    o.append(T(cx, cy + 4, '同じ意見', 'middle', size=9.5, bold=True, col='a'))
    o.append(T(270, 176, '同じ考えの人どうしで意見が反響し増幅', 'middle', size=9.5, bold=True))
    return _svg(360, 184, o, 'フィルターバブルとエコーチェンバー')


FIG['joho.bubble'] = _bubble()

FIG['joho.jpki'] = grid(['', '署名用電子証明書', '利用者証明用電子証明書'],
                        [['使う場面', '電子文書に電子署名をする', 'Webサイトなどへのログイン（本人の証明）'], ['含む情報', '氏名、住所、生年月日、性別', '氏名などを含まない'],
                         ['住所や氏名が変わると', '失効する', '失効しない'], ['暗証番号', '6〜16文字の英数字', '4桁の数字']],
                        [100, 128, 132], align=['l', 'l', 'l'], title='公的個人認証の2つの電子証明書', size=10, tcol={'失効する': 'a', '失効しない': 'b'})

FIG['joho.denchoho'] = grid(['区分', '書類の例', '保存のポイント'],
                            [['電子取引', '電子メールやWebサイトで受け取った請求書など', '紙に印刷せず、電子データのまま保存する'],
                             ['スキャナ保存：重要書類', '契約書、納品書、請求書、領収書（資金や物の流れに直結）', '要件が厳しい'],
                             ['スキャナ保存：一般書類', '見積書、注文書、検収書（直結しない）', '要件が緩い。適時に入力すればよい']],
                            [100, 150, 110], align=['l', 'l', 'l'], title='電子帳簿保存法', size=10)

FIG['joho.bizpat'] = _lists([('特許の対象にならない', 'a', ['ビジネスの方法そのもの（人の取り決めや手順）']), ('特許の対象になりうる', 'b', ['ICT（コンピュータやネットワーク）を使ってビジネスの方法を実現する発明'])],
                            'ビジネス関連発明', size=10.5)

# ------------------------------------------------ 2.1.5 情報システムの適用領域


def _funnel():
    o = []
    lv = [('表示 10,000回', 1.0, 'sub'), ('クリック（訪問） 200', 0.68, 'c'), ('成果（購入） 6', 0.4, 'b')]
    W, cx = 180, 94
    for i, (s, k, col) in enumerate(lv):
        y = 6 + i * 44
        wt = W * k
        wb = W * (lv[i + 1][1] if i < 2 else 0.4)
        poly(o, [(cx - wt / 2, y), (cx + wt / 2, y), (cx + wb / 2, y + 40), (cx - wb / 2, y + 40)], col=col if col != 'sub' else 'line', fill=col, op=0.22, sw=1.1)
        o.append(T(cx, y + 25, s, 'middle', size=10.5, bold=True))
    o.append(T(196, 46, 'CTR（クリック率）', size=10.5, bold=True, col='c'))
    o.append(T(196, 62, '＝200÷10,000＝2％', size=10.5, bold=True, col='c'))
    o.append(T(196, 96, 'CVR（コンバージョン率）', size=10.5, bold=True, col='b'))
    o.append(T(196, 112, '＝6÷200＝3％', size=10.5, bold=True, col='b'))
    o.append(T(4, 156, '数値は例。クリックした人がそのまま訪問したとする', size=9.5))
    return _svg(360, 162, o, 'クリック率とコンバージョン率')


FIG['joho.funnel'] = _funnel()


def _bounce():
    o = []
    vis = [('訪問1', ['A', 'B', 'C']), ('訪問2', ['A']), ('訪問3', ['B', 'A']), ('訪問4', ['A', 'C'])]
    for i, (nm, pages) in enumerate(vis):
        y = 8 + i * 30
        o.append(T(4, y + 16, nm, size=10.5, bold=True))
        for j, p in enumerate(pages):
            x = 52 + j * 44
            isa = p == 'A'
            last = j == len(pages) - 1
            o.append(R(x, y, 30, 22, fill='c' if isa else 'sheet', stroke='c' if isa else 'line', op=0.25 if isa else None, rx=3, sw=1.1))
            o.append(T(x + 15, y + 16, p, 'middle', size=11, bold=True))
            if j:
                o.append(ARROW([(x - 13, y + 11), (x - 2, y + 11)], sw=1.1, head=4))
            if last:
                o.append(T(x + 35, y + 16, '去る', size=9.5, col='a'))
    o.append(T(206, 20, 'ページAについて', size=10.5, bold=True))
    o.append(T(206, 40, '直帰率', size=10.5, bold=True, col='c'))
    o.append(T(206, 55, 'Aから始まった訪問 3件', size=9.5))
    o.append(T(206, 69, 'Aだけで去った 1件（訪問2）', size=9.5))
    o.append(T(206, 84, '→ 1÷3≒33％', size=10.5, bold=True, col='c'))
    o.append(T(206, 106, '離脱率', size=10.5, bold=True, col='a'))
    o.append(T(206, 121, 'Aの閲覧 4回', size=9.5))
    o.append(T(206, 135, 'Aを最後に去った 2回（訪問2・3）', size=9.5))
    o.append(T(206, 150, '→ 2÷4＝50％', size=10.5, bold=True, col='a'))
    return _svg(360, 158, o, '直帰率と離脱率')


FIG['joho.bounce'] = _bounce()

FIG['joho.ltv'] = eq([[('平均継続期間', 'c'), '＝', '1', '÷', '月の解約率\n0.05', '＝', ('20か月', 'c')],
                      [('LTV', 'b'), '＝', '月の平均利益\n10,000円', '×', '20か月', '＝', ('200,000円', 'b')]], 'LTVの計算', size=10.5)

FIG['joho.pay'] = grid(['', '前払い', '即時払い', '後払い'],
                      [['いつ払うか', '購入の前（チャージ）', '購入と同時に口座から', '購入の後（後日に請求）'], ['例', '電子マネーなど', 'デビットカードなど', 'クレジットカードなど']],
                      [72, 96, 96, 96], align=['l', 'c', 'c', 'c'], title='キャッシュレス決済の支払いの時期', size=10)


def _qrpay():
    o = []

    def qr(x, y, s=22):
        o.append(R(x, y, s, s, fill='sheet', stroke='main', sw=1.1))
        for (i, j) in [(0, 0), (0, 2), (2, 0), (1, 1), (2, 2), (1, 2)]:
            o.append(R(x + 2 + j * 6, y + 2 + i * 6, 5, 5, fill='main', stroke=None, op=0.8))
    rows = [('店舗提示型（MPM）', '店舗が示したQRコードを', '利用者のスマートフォンで読み取る', 'shop'), ('利用者提示型（CPM）', '利用者がスマートフォンに表示したコードを', '店舗が読み取る', 'user')]
    for i, (ttl, a, b, kind) in enumerate(rows):
        y = 4 + i * 78
        o.append(T(4, y + 12, ttl, size=11, bold=True, col='b' if i == 0 else 'c'))
        o.append(R(14, y + 22, 58, 34, fill='c', stroke='c', op=0.18, rx=3))
        o.append(T(30, y + 43, '店舗', 'middle', size=9.5, bold=True))
        o.append(R(110, y + 20, 22, 38, fill='sheet', stroke='main', sw=1.3, rx=4))
        o.append(T(121, y + 72, '利用者', 'middle', size=9))
        if kind == 'shop':
            qr(48, y + 31, 16)
            o.append(ARROW([(108, y + 40), (76, y + 40)], col='b', sw=1.4, head=5, dash='3 2'))
        else:
            qr(113, y + 28, 16)
            o.append(ARROW([(74, y + 40), (106, y + 40)], col='c', sw=1.4, head=5, dash='3 2'))
        o.append(T(150, y + 34, a, size=10))
        o.append(T(150, y + 50, b, size=10, bold=True))
    return _svg(360, 160, o, 'QRコード決済の方式')


FIG['joho.qrpay'] = _qrpay()


def _3ds():
    o = []
    _box(o, 2, 40, 86, 40, '取引の情報', size=10.5)
    o.append(ARROW([(90, 60), (110, 60)], sw=1.4, head=5))
    _box(o, 112, 40, 86, 40, 'リスクを判定', col='c', size=10.5, c0='c')
    o.append(ARROW([(200, 52), (226, 26)], sw=1.4, head=5))
    o.append(ARROW([(200, 68), (226, 94)], sw=1.4, head=5))
    _box(o, 230, 6, 128, 40, '低い：追加の認証なし', col='b', size=10, c0='b')
    _box(o, 230, 74, 128, 46, '高い：追加の認証\n（ワンタイムパスワードなど）', col='a', size=10, c0='a')
    o.append(T(4, 140, 'EMV 3-Dセキュア：インターネットのカード決済で、カード会社が本人を確かめる', size=9.5))
    return _svg(360, 146, o, '3Dセキュア')


FIG['joho.3ds'] = _3ds()
