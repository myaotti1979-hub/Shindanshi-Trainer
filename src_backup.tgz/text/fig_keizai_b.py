# 経済学・経済政策の図表（1.2 マクロ経済理論と経済政策、1.3 国際経済と経済政策）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, flow, chart, htree, quad, timeline, pyramid, barchart, waterfall, decomp, dtree, ARROW, R, T, L, _svg, _c, wrap, tw)
from kit import (_lines, _dashrect, _box, _lists, _flow, _rowflow, _bands, _hub, _nest, _ladder)
from ekit import G, panels, payoff, txt, hbars, stackbar, eq

FIG = {}

# ------------------------------------------------ 1.2.1 生産物市場とGDP


def _cross45():
    g = G(xmax=10, ymax=10, w=360, h=300, pl=70, pr=74, pb=40, xlab='国民所得 Y', ylab='総需要・総供給', xlpos='low')
    g.line([(0, 0), (10, 10)], 'b', label='45度線', at=(10, 10), dx=4)
    g.line([(0, 3), (10, 9)], 'a', dash=True, label='C＋I＋G′', at=(10, 9), dx=4)
    g.line([(0, 2), (10, 8)], 'a', label='C＋I＋G\n（傾き＝c）', at=(10, 8), dx=4)
    g.yt(2, 'C0＋I＋G', 'a', True).yt(3, '', 'a')
    g.dot(5, 5, 'main', label='E', pos='n').guide(5, 5, xt='Y*', bold=True, h=False)
    g.dot(7.5, 7.5, 'main', label='E′', pos='n').guide(7.5, 7.5, xt='YF', bold=True, h=False)
    g.dot(7.5, 6.5, 'a')
    g.vspan(7.5, 6.5, 7.5, '', 'a')
    g.text(8.0, 4.3, 'デフレ・ギャップ\n（YFでの縦の差）', 'start', 'a', True, 10.5)
    g.arrow(8.2, 5.0, 7.65, 6.75, 'a', sw=1.2, head=5)
    g.arrow(1.5, 2.95, 1.5, 3.85, 'a', sw=1.8, head=5)
    g.text(1.7, 3.0, 'ΔG', 'start', 'a', True, 11)
    g.hspan(0.9, 5, 7.5, 'ΔY＝乗数×ΔG', 'main', dy=-9)
    return g.svg('45度線分析（デフレ・ギャップと乗数）')

FIG['keizai.cross45'] = _cross45()

FIG['keizai.multtbl'] = grid(['乗数', '式', 'c＝0.8の例'],
                             [['投資乗数・政府支出乗数', '1÷（1－c）', '5'], ['租税乗数（定額税）', '－c÷（1－c）', '－4'], ['均衡予算乗数', '1', '1'],
                              ['政府支出乗数（比例税 t）', '1÷（1－c（1－t））', 't＝0.25で2.5'], ['政府支出乗数（限界輸入性向 m）', '1÷（1－c＋m）', 'm＝0.2で2.5']],
                             [148, 118, 94], align=['l', 'c', 'c'], title='乗数の一覧', size=11)

FIG['keizai.multex'] = hbars([('政府支出を10増やす', 50, 'b'), ('10減税する', 40, 'c'), ('政府支出10を同額の増税でまかなう', 10, 'sub')],
                             '国民所得の増え方（C＝20＋0.8Y、I＝40、G＝40、Y＝500から）', lw=150, lo=0, hi=56, fmt=lambda v: '＋%d' % v,
                             note='減税10のうち2は貯蓄に回り、消費は8しか増えない。だから減税の効果は政府支出より小さい')

FIG['keizai.ftm'] = _rowflow([('', None, [('輸出\n＋10', 'b'), '国民所得\n＋25\n（×2.5）', '輸入\n＋5\n（0.2×25）', ('貿易収支\n＋5', 'b')])],
                             '外国貿易乗数（c＝0.8、m＝0.2）', lw=0, size=10.5, gapx=14)


def _savinv():
    g = G(xmax=14, ymax=6, ymin=-3, xaxis=0, h=240, xlab='国民所得 Y', ylab='貯蓄・投資', pr=26)
    g.line([(0, -2), (14, 3.6)], 'b', label='S', at=(14, 3.6), dx=2)
    g.hl(2, 'a', label='I', at=(14, 2), dx=6)
    g.dot(10, 2, 'main', label='E', pos='n').guide(10, 2, xt='Y*', bold=True, h=False)
    g.text(3.4, 4.4, 'S＜I（超過需要）\nYが増える', 'middle', 'a', True, 10.5)
    g.text(11.6, 4.8, 'S＞I（超過供給）\nYが減る', 'middle', 'b', True, 10.5)
    g.arrow(5.6, 2.9, 8.6, 2.9, 'a', sw=1.8).arrow(13.2, 0.9, 11.2, 0.9, 'b', sw=1.8)
    g.text(0.3, -2.4, '切片－C0', 'start', 'b', True, 10.5)
    g.text(7.0, -1.9, '傾き＝限界貯蓄性向（1－c）', 'start', 'b', True, 10.5)
    return g.svg('貯蓄・投資図')


FIG['keizai.savinv'] = _savinv()


def _thrift():
    g = G(xmax=14, ymax=6, ymin=-3, xaxis=0, h=236, xlab='国民所得 Y', ylab='貯蓄・投資', pr=26)
    g.line([(0, -2), (14, 3.6)], 'b', label='S', at=(14, 3.6), dx=2)
    g.line([(0, -1), (11.5, 3.6)], 'b', dash=True, label='S′', at=(11.5, 3.6), dx=2, dy=4)
    g.hl(2, 'a', label='I', at=(14, 2), dx=6)
    g.dot(10, 2, 'main', label='E', pos='se').guide(10, 2, xt='Y0', h=False)
    g.dot(7.5, 2, 'b', label='E′', pos='nw').guide(7.5, 2, xt='Y1', tcol='b', bold=True, h=False)
    g.arrow(9.6, 1.4, 7.9, 1.4, 'b', sw=1.8)
    g.text(0.4, 5.2, '貯蓄を増やそうとする（S→S′）と、国民所得が\nY0からY1に減り、貯蓄の総額はIのまま増えない', 'start', 'main', True, 10.5)
    return g.svg('節約のパラドックス')


FIG['keizai.thrift'] = _thrift()

# ------------------------------------------------ 1.2.2 貨幣市場と利子率
FIG['keizai.motive'] = grid(['動機', '何に応じて増えるか', '式'],
                            [['取引的動機', '所得が増えるほど増える', 'L1（Y）'], ['予備的動機', '所得が増えるほど増える', 'L1（Y）'],
                             ['投機的動機', '利子率が低いほど増える（債券価格が高く、値下がりを見込んで貨幣で持つ）', 'L2（r）']],
                            [86, 210, 64], align=['l', 'l', 'c'], title='貨幣需要の3つの動機（L＝L1（Y）＋L2（r））', size=11,
                            tcol={'L2（r）': 'a'})


def _mmarket():
    g = G(xmax=10, ymax=10, h=250, xlab='貨幣の量', ylab='利子率 r', pr=18)
    f = lambda x: 1 + 8 * math.exp(-0.55 * (x - 1))
    g.fn(f, 0.75, 10, 'a', label='貨幣需要 L', at=(2.2, 8.2), anchor='start')
    g.vl(3, 'b', label='M/P', at=(3, 9.6), anchor='middle', dy=-4)
    g.vl(4.5, 'b', dash=True, label='M′/P', at=(4.5, 9.6), anchor='middle', dy=-4)
    g.dot(3, f(3), 'main').guide(3, f(3), yt='r0', h=True, v=False)
    g.dot(4.5, f(4.5), 'b').guide(4.5, f(4.5), yt='r1', tcol='b', bold=True, v=False)
    g.arrow(3.15, 6.6, 4.35, 6.6, 'b', sw=1.6, head=5)
    g.vl(7.2, 'sub', dash='4 3', sw=1.3).vl(9.0, 'sub', dash='4 3', sw=1.3)
    g.arrow(7.35, 4.0, 8.85, 4.0, 'main', sw=1.6, head=5)
    g.text(8.1, 5.6, '流動性のわな\n供給を増やしても\n利子率は下がらない', 'middle', 'main', True, 10.5)
    g.text(5.6, 2.9, '供給を増やすと\n利子率が下がる', 'start', 'b', True, 10.5)
    return g.svg('貨幣市場の均衡と流動性のわな')


FIG['keizai.mmarket'] = _mmarket()

FIG['keizai.bondp'] = grid(['市場の利子率', '1年後に105円を受け取れる債券の価格'],
                           [['2％', '105÷1.02≒102.9円（高い）'], ['5％', '105÷1.05＝100円'], ['10％', '105÷1.10≒95.5円（安い）']],
                           [110, 250], align=['c', 'l'], title='債券価格と利子率は逆に動く', size=11.5,
                           tcol={'105÷1.10≒95.5円（安い）': 'a', '105÷1.02≒102.9円（高い）': 'b'})

# ------------------------------------------------ 1.2.3 IS-LM曲線


def _islm():
    g = G(xmax=10, ymax=10, h=262, xlab='国民所得 Y', ylab='利子率 r', pr=30, pb=40, xlpos='low')
    g.line([(1, 8), (9, 0)], 'a', label='IS', at=(9, 0.5), dx=2)
    g.line([(2.5, 9), (10, 1.5)], 'a', dash=True, label='IS′', at=(10, 1.6), dx=2)
    g.line([(0, 1), (10, 7)], 'b', label='LM', at=(10, 7), dx=2)
    y1 = 10.5 / 1.6
    g.dot(5, 4, 'main', label='E', pos='w').guide(5, 4, xt='Y0', yt='r0')
    g.dot(y1, 1 + 0.6 * y1, 'a', label='E′', pos='nw').guide(y1, 1 + 0.6 * y1, xt='Y1', yt='r1', tcol='a', bold=True)
    g.raw('<circle cx="%s" cy="%s" r="3.4" style="fill:none;stroke:%s" stroke-width="1.4"/>' % (round(g.X(7.5), 1), round(g.Y(4), 1), _c('a')))
    g.seg(5, 4, 7.5, 4, 'a', dash='3 3', op=0.9).seg(7.5, 4, 7.5, 0, 'a', dash='3 3', op=0.6)
    g.xt(7.5, 'Y2')
    g.hspan(1.0, y1, 7.5, '', 'c')
    g.text(6.4, 1.0, 'クラウディング・アウト', 'end', 'c', True, 10.5)
    return g.svg('財政政策とクラウディング・アウト')


FIG['keizai.islm'] = _islm()


def _islm2():
    g1 = G(xmax=10, ymax=10, w=176, h=206, ox=0, pl=22, pr=18, xlab='Y', ylab='r', cap='拡張的な財政政策', ccol='a')
    g2 = G(xmax=10, ymax=10, w=176, h=206, ox=184, pl=22, pr=18, xlab='Y', ylab='r', cap='拡張的な金融政策', ccol='b')
    for g in (g1, g2):
        g.line([(1, 8), (9, 0)], 'a', label='IS', at=(9, 0.6), dx=1)
        g.line([(0, 1), (10, 7)], 'b', label='LM', at=(9.2, 7.6), anchor='end')
        g.dot(5, 4, 'main').guide(5, 4)
    y1 = 10.5 / 1.6
    g1.line([(2.5, 9), (10, 1.5)], 'a', dash=True, label='IS′', at=(10, 1.6), dx=0, dy=-10, anchor='end')
    g1.dot(y1, 1 + 0.6 * y1, 'a').guide(y1, 1 + 0.6 * y1)
    g1.arrow(6.0, 3.0, 7.2, 3.0, 'a', sw=1.6, head=5)
    g2.line([(2, 1), (10, 5.8)], 'b', dash=True, label='LM′', at=(10, 5.8), dx=0, dy=14, anchor='end')
    g2.dot(5.75, 3.25, 'b').guide(5.75, 3.25)
    g2.arrow(6.6, 5.6, 7.4, 4.8, 'b', sw=1.6, head=5)
    ex = [txt(4, 222, 'Y↑ r↑（投資が減る）', size=10.5, bold=True, col='a'), txt(188, 222, 'Y↑ r↓', size=10.5, bold=True, col='b')]
    return panels([g1, g2], '財政政策と金融政策の効果', h=228, extra=ex)


FIG['keizai.islm2'] = _islm2()


def _islmext():
    gs = []
    caps = [('流動性のわな', 'LMが水平'), ('古典派', 'LMが垂直'), ('投資が利子率に', '反応しない（IS垂直）')]
    for i in range(3):
        g = G(xmax=10, ymax=10, w=118, h=214, ox=i * 121, pl=14, pr=8, pt=34, pb=58, xlab='Y', ylab='r', origin='')
        g.raw(txt(i * 121 + 59, 12, caps[i][0], 'middle', 'main', True, 11))
        g.raw(txt(i * 121 + 59, 27, caps[i][1], 'middle', 'main', False, 10))
        gs.append(g)
    a, b, c = gs
    a.line([(0, 2), (7.5, 2), (10, 6)], 'b', label='LM', at=(9.0, 5.6), anchor='end', lsize=10)
    a.line([(1, 5.5), (6.5, 0)], 'a', label='IS', at=(6.5, 0.6), lsize=10)
    a.line([(3, 5.5), (8.5, 0)], 'a', dash=True)
    a.dot(3.5, 2, 'main').dot(5.5, 2, 'a').arrow(3.9, 2.9, 5.1, 2.9, 'a', sw=1.4, head=4)
    b.vl(5, 'b', label='LM', at=(5.3, 9.2), lsize=10)
    b.line([(1, 7), (8, 0)], 'a', label='IS', at=(8, 0.6), lsize=10, anchor='end')
    b.line([(2.5, 9.5), (9.5, 2.5)], 'a', dash=True)
    b.dot(5, 3, 'main').dot(5, 5, 'a').arrow(6.0, 3.2, 6.0, 4.8, 'a', sw=1.4, head=4)
    c.vl(5, 'a', label='IS', at=(5.3, 9.2), lsize=10)
    c.line([(0, 1), (9, 6.4)], 'b', label='LM', at=(9.4, 6.9), anchor='end', lsize=10)
    c.line([(1.5, 0), (10, 5.1)], 'b', dash=True)
    c.dot(5, 4, 'main').dot(5, 2.4, 'b').arrow(3.8, 3.9, 3.8, 2.6, 'b', sw=1.4, head=4)
    ex = []
    res = [('財政：完全に有効', '金融：無効'), ('財政：無効', '金融：有効'), ('財政：完全に有効', '金融：無効')]
    for i, (f, m) in enumerate(res):
        ex.append(txt(i * 121 + 59, 184, f, 'middle', 'b' if '有効' in f and '無効' not in f else 'a', True, 10))
        ex.append(txt(i * 121 + 59, 200, m, 'middle', 'b' if '無効' not in m else 'a', True, 10))
    return panels(gs, 'IS-LMの極端なケース（点線は政策で移った後の曲線）', h=208, extra=ex)


FIG['keizai.islmext'] = _islmext()

FIG['keizai.islmslope'] = grid(['曲線', '傾きが緩やか（水平に近い）', '傾きが急（垂直に近い）'],
                               [['IS', '投資の利子弾力性が大きい、限界消費性向が大きい（乗数が大きい）', '投資の利子弾力性が小さい（ゼロで垂直）'],
                                ['LM', '貨幣需要の利子弾力性が大きい（流動性のわなで水平）', '貨幣需要の利子弾力性が小さい（古典派で垂直）、貨幣需要の所得弾力性が大きい']],
                               [44, 158, 158], align=['c', 'l', 'l'], title='IS曲線とLM曲線の傾き', size=10.5, tcol={'IS': 'a', 'LM': 'b'})

FIG['keizai.islmshift'] = grid(['要因', '動く曲線', '向き'],
                               [['政府支出の増加、減税', 'IS', '右'], ['輸出の増加（訪日外国人の消費の増加を含む）、投資意欲の高まり', 'IS', '右'],
                                ['貯蓄意欲の高まり（消費の減少）', 'IS', '左'], ['貨幣供給の増加', 'LM', '右（下）'], ['物価の上昇（実質貨幣供給の減少）', 'LM', '左']],
                               [236, 64, 60], align=['l', 'c', 'c'], title='IS曲線とLM曲線のシフト', size=10.5, tcol={'IS': 'a', 'LM': 'b'})


def _islmarea():
    g = G(xmax=10, ymax=10, h=250, xlab='国民所得 Y', ylab='利子率 r', pr=24)
    g.line([(0, 9), (9, 0)], 'a', label='IS', at=(9, 0.5), dx=2)
    g.line([(0, 1), (10, 7)], 'b', label='LM', at=(10, 7), dx=-14, dy=-12)
    g.dot(5, 4, 'main', label='E', pos='e')
    g.text(5, 8.4, '財：超過供給\n貨幣：超過供給', 'middle', 'main', True, 10.5)
    g.text(8.3, 3.5, '財：超過供給\n貨幣：超過需要', 'middle', 'main', True, 10.5)
    g.text(5, 1.3, '財：超過需要\n貨幣：超過需要', 'middle', 'main', True, 10.5)
    g.text(1.6, 4.7, '財：超過需要\n貨幣：超過供給', 'middle', 'main', True, 10.5)
    return g.svg('不均衡の領域（ISの右上は財の超過供給、LMの右下は貨幣の超過需要）')


FIG['keizai.islmarea'] = _islmarea()

FIG['keizai.islmtbl'] = grid(['ケース', '財政政策', '金融政策'],
                             [['通常（ISは右下がり、LMは右上がり）', '有効（クラウディング・アウトで一部減る）', '有効'],
                              ['流動性のわな（LMが水平）', '完全に有効', '無効'], ['古典派（LMが垂直）', '無効（完全なクラウディング・アウト）', '有効'],
                              ['投資の利子弾力性がゼロ（ISが垂直）', '完全に有効', '無効']],
                             [134, 152, 74], align=['l', 'l', 'c'], title='財政政策と金融政策の効果のまとめ', size=10.5,
                             tcol={'無効': 'a', '無効（完全なクラウディング・アウト）': 'a', '完全に有効': 'b'})

# ------------------------------------------------ 1.2.4 政府支出
FIG['keizai.crowd'] = _flow(['政府支出が\n増える', '国民所得が\n増える', '貨幣の取引需要\nが増える', ('利子率が\n上がる', 'a'), ('民間投資が\n減る', 'a'), '所得の増加が\n乗数より小さい'],
                            'クラウディング・アウトのしくみ', per_row=3, size=10.5)

FIG['keizai.ricardo'] = _rowflow([('増税で\nまかなう', 'c', ['いま増税', '可処分所得が減る', ('消費が減る', 'a')]),
                                  ('公債で\nまかなう', 'b', ['いま公債を発行', '将来の増税を見越して貯蓄を増やす', ('消費が減る', 'a')])],
                                 'リカードの等価定理：どちらでも消費への効果は同じ', lw=62, size=10.5)


def _bondw():
    g = G(xmax=10, ymax=10, h=236, xlab='国民所得 Y', ylab='利子率 r', pr=30)
    g.line([(1, 8), (9, 0)], 'a', label='IS', at=(9, 0.5), dx=2)
    g.line([(3, 8), (10, 1)], 'a', dash=True, label='IS′', at=(10, 1.2), dx=2)
    g.line([(0, 1), (10, 7)], 'b', label='LM', at=(10, 7), dx=2)
    g.line([(0, 2.2), (10, 8.2)], 'b', dash=True, label='LM′', at=(9.4, 8.6), anchor='end')
    g.dot(5, 4, 'main', label='E', pos='w').guide(5, 4, yt='r0')
    g.dot(5.5, 5.5, 'c', label='E′', pos='n').guide(5.5, 5.5, yt='r1', tcol='c', bold=True)
    return g.svg('公債の資産効果')


FIG['keizai.bondw'] = _bondw()


def _taxsmooth():
    g = G(xmax=8, ymax=10, h=206, xlab='年', ylab='税率', origin='', pr=10)
    g.line([(0, 3), (2.6, 3), (3, 8), (4, 8), (4.4, 3), (8, 3)], 'a', label='支出に合わせて税率を変える', at=(4.6, 8.2), lsize=10.5)
    g.line([(0, 3.8), (8, 3.8)], 'b', label='税率をならし、一時的な支出は公債で', at=(8, 4.4), anchor='end', lsize=10.5)
    g.text(3.5, 1.6, '災害などで支出が一時的に増える', 'middle', 'main', False, 10.5)
    g.text(4.0, 9.4, '税率を大きく変えるほど、超過負担（死荷重）が大きくなる', 'middle', 'main', True, 10.5)
    return g.svg('課税平準化の理論（イメージ）')


FIG['keizai.taxsmooth'] = _taxsmooth()


def _pb():
    w, h = 360, 240
    o = []
    x1, x2, bw, top, H = 60, 196, 96, 30, 150
    k = H / 100.0
    rev = [('税収など', 62, 'b'), ('公債金', 38, 'a')]
    exp = [('政策的経費\n（社会保障など）', 75, 'c'), ('国債費\n（元利払い）', 25, 'sub')]
    for x, segs, nm in ((x1, rev, '歳入'), (x2, exp, '歳出')):
        y = top
        o.append(T(x + bw / 2, top - 8, nm, 'middle', bold=True, size=12))
        for s2, v, col in segs:
            o.append(R(x, y, bw, v * k, fill=col, stroke=col if col != 'sub' else 'main', op=0.28 if col != 'sub' else 0.14))
            ls = s2.split('\n')
            for j, ln in enumerate(ls):
                o.append(T(x + bw / 2, y + (v * k / 2 if col != 'c' else 26) + 4 + (j - (len(ls) - 1) / 2) * 14, ln, 'middle', size=10.5, bold=(j == 0)))
            y += v * k
    y62, y75 = top + 62 * k, top + 75 * k
    o.append(R(x2, y62, bw, y75 - y62, fill='a', stroke=None, op=0.45))
    o.append(L(x1 + bw, y62, x2 + bw, y62, col='a', dash='4 3', sw=1.3))
    o.append(T(x2 + bw / 2, (y62 + y75) / 2 + 4, 'PBの赤字', 'middle', size=10.5, bold=True, col='a'))
    o.append(T(x2 + bw + 6, (y62 + y75) / 2 - 4, '税収などで', size=10, bold=True, col='a'))
    o.append(T(x2 + bw + 6, (y62 + y75) / 2 + 10, '足りない分', size=10, bold=True, col='a'))
    o.append(T(4, top + H + 24, 'プライマリー・バランス（PB）＝税収など－政策的経費', size=11, bold=True))
    o.append(T(4, top + H + 42, '（公債金と国債費を除いて比べる。大きさはイメージ）', size=10.5))
    return _svg(w, h, o, 'プライマリー・バランス（基礎的財政収支）')

FIG['keizai.pb'] = _pb()

# ------------------------------------------------ 1.2.5 租税と財政政策
FIG['keizai.fis3'] = _bands([('', 'main', [('資源配分\n公共財などを供給する', 'b'), ('所得再分配\n累進的な税や社会保障で格差を縮める', 'c'),
                                                          ('経済安定化\n景気の変動をならす', 'a')])], '財政の3つの機能（マスグレイブ）', size=10.5)

FIG['keizai.bis'] = _rowflow([('好況', 'b', ['所得が増える', '累進課税で税収が\n大きく増える', ('需要を抑える', 'b')]),
                              ('不況', 'a', ['所得が減る', '税収が減り、\n失業給付が増える', ('需要を支える', 'a')])],
                             'ビルトイン・スタビライザー（自動安定化装置）', lw=44, size=10.5)

FIG['keizai.bisstr'] = _lists([('働きが強い', 'b', ['累進性の高い所得税（最高税率の引上げなど）', '手厚い失業給付や生活保護', '一定額まで非課税とする所得税', '利益に累進的にかかる法人税']),
                               ('働きが弱い', 'a', ['所得に関係なく同じ額をとる定額税', '景気で支出が変わりにくい生活必需品への消費税'])],
                              '自動安定化の働きの強さ（税や給付が所得の変動に敏感なほど強い）')


def _progtax():
    g = G(xmax=10, ymax=10, h=212, xlab='所得', ylab='税の負担率（所得に対する割合）', origin='', pr=64)
    g.line([(0.5, 1.5), (9.5, 8.5)], 'a', label='累進税', at=(9.5, 8.5), dx=2)
    g.hl(4.5, 'c', x0=0.5, x1=9.5, label='比例税', at=(9.5, 4.5), dx=2)
    g.line([(0.5, 7.5), (9.5, 2.0)], 'b', label='逆進税', at=(9.5, 2.0), dx=2)
    g.text(4.2, 0.8, '消費税は所得に対して逆進的とされる', 'middle', 'b', True, 10.5)
    return g.svg('累進税・比例税・逆進税')


FIG['keizai.progtax'] = _progtax()

FIG['keizai.taxcls'] = grid(['分類', '内容'],
                            [['直接税', '納税者と負担者が同じ（所得税、法人税など）'], ['間接税', '納税者と負担者が異なる（消費税など）'],
                             ['水平的公平', '同じ所得なら同じ負担'], ['垂直的公平', '所得の高い人ほど多く負担'], ['中立', '経済活動をゆがめない'], ['簡素', 'わかりやすく、手間が少ない']],
                            [96, 264], align=['l', 'l'], title='租税の分類と課税の原則', size=11, hl_rows=(2, 3, 4, 5))

FIG['keizai.bbm'] = _rowflow([('', None, [('政府支出\n＋10', 'b'), '国民所得\n＋50（×5）']), ('', None, [('増税\n10', 'a'), '国民所得\n－40（×4）']),
                              ('', None, [('合計', 'c'), ('国民所得＋10\n＝政府支出の増加額\n（均衡予算乗数1）', 'c')])], '均衡予算乗数（c＝0.8）', lw=0, size=10.5)

# ------------------------------------------------ 1.2.6 貨幣理論と金融政策
FIG['keizai.moneyfn'] = _bands([('', 'main', [('価値尺度\n値段をつける物差し（計算の単位）', 'b'), ('交換手段\n支払いに使う', 'c'), ('価値貯蔵\n価値を将来に持ち越す', 'a')])],
                               '貨幣の3つの機能', size=10.5)


def _credit():
    g = G(xmax=8.6, ymax=110, xmin=-0.6, h=232, ylab='預金（万円）', origin='', pr=10, pb=40)
    d = 100.0
    for i in range(8):
        g.rect(i - 0.36, 0, i + 0.36, d, col='b' if i == 0 else 'c', op=0.3)
        g.rect(i - 0.36, d * 0.9, i + 0.36, d, col='sub', op=0.45)
        g.text(i, d + 5, '%g' % round(d, 1), 'middle', 'main', True, 10)
        g.xt(i, '銀行%d' % (i + 1) if i < 3 else ('…' if i == 7 else ''))
        d *= 0.9
    g.text(3.3, 100, '灰色の部分＝準備（10％）\n残りを貸し出し、次の銀行の預金になる', 'start', 'main', True, 10.5)
    g.raw(txt(4, 226, '預金の総額＝100＋90＋81＋…＝100÷0.1＝1,000万円', size=11, bold=True, col='b'))
    return g.svg('信用創造（最初の預金100万円、預金準備率10％）')


FIG['keizai.credit'] = _credit()

FIG['keizai.mpolicy'] = grid(['手段', '金融緩和（景気を支える）', '金融引締め'],
                             [['公開市場操作', '買いオペ（資金を供給）', '売りオペ（資金を吸収）'], ['預金準備率操作', '準備率を下げる', '準備率を上げる'],
                              ['政策金利（無担保コール翌日物金利の誘導目標）', '引き下げる', '引き上げる']],
                             [128, 122, 110], align=['l', 'c', 'c'], title='金融政策の手段', size=10.5)

FIG['keizai.bojtl'] = grid(['時期', '日本銀行の主な政策'],
                           [['1999年', 'ゼロ金利政策'], ['2001年', '量的緩和政策'], ['2013年', '「物価安定の目標」2％、量的・質的金融緩和'],
                            ['2016年1月', 'マイナス金利政策'], ['2016年9月', '長短金利操作（イールドカーブ・コントロール）'],
                            ['2024年3月', 'マイナス金利政策と長短金利操作を終える（誘導目標0～0.1％程度）']],
                           [82, 278], align=['l', 'l'], title='日本の金融政策の流れ', size=11, hl_rows=(5,))


def _rate():
    g = G(xmax=33, ymax=1.5, h=212, ylab='無担保コール翌日物金利の誘導目標（％）', pr=14, pl=40, pb=36)
    steps = [(0, 0.05, '0～0.1'), (4, 0.25, '0.25'), (10, 0.5, '0.5'), (21, 0.75, '0.75'), (27, 1.0, '1.0'), (30, 1.25, '1.25')]
    pts = []
    for i, (m, v, s) in enumerate(steps):
        nx = steps[i + 1][0] if i + 1 < len(steps) else 32
        pts += [(m, v), (nx, v)]
        g.dot(m, v, 'a', label=s, pos='nw' if i else 'n', size=10.5)
    g.line(pts, 'a', sw=2.4)
    for m, s in ((0, '2024年3月'), (10, '2025年1月'), (21, '2025年12月'), (30, '2026年9月')):
        g.xt(m, s, size=9.5)
    g.yt(0.5, '0.5').yt(1.0, '1.0')
    return g.svg('2024年以降の利上げ（2026年10月末時点）')


FIG['keizai.rate'] = _rate()

FIG['keizai.trans'] = _rowflow([('', None, [('金利の低下', 'b'), '投資・消費が増える', ('景気と物価に\n影響する', 'c')]),
                                ('', None, [('金利の低下', 'b'), '株式などの資産価格が上がる', ('景気と物価に\n影響する', 'c')]),
                                ('', None, [('金利の低下', 'b'), '円安（輸出が増える）', ('景気と物価に\n影響する', 'c')])], '金融政策の波及の経路', lw=0, size=10.5)

FIG['keizai.fisher'] = grid(['', '名目利子率', '予想インフレ率', '実質利子率'],
                            [['例1', '2％', '0％', '2％'], ['例2（予想インフレ率が上がる）', '2％', '3％', '－1％'], ['例3（デフレ）', '0％', '－2％', '2％（高い）']],
                            [134, 72, 82, 72], align=['l', 'c', 'c', 'c'], title='フィッシャー方程式（実質利子率＝名目利子率－予想インフレ率）', size=11,
                            tcol={'－1％': 'b', '2％（高い）': 'a'})

# ------------------------------------------------ 1.2.7 雇用と物価水準


def _adas2():
    g1 = G(xmax=10, ymax=10, w=176, h=208, ox=0, pl=22, pr=18, xlab='Y', ylab='P', cap='ケインズ派（ASが右上がり）', ccol='a')
    g2 = G(xmax=10, ymax=10, w=176, h=208, ox=184, pl=22, pr=18, xlab='Y', ylab='P', cap='古典派（ASが垂直）', ccol='b')
    g1.line([(0.5, 1.4), (9.5, 8.6)], 'b', label='AS', at=(9.2, 9.3), anchor='end')
    g2.vl(5, 'b', label='AS', at=(5.3, 9.4))
    for g in (g1, g2):
        g.line([(0.5, 8.6), (9.5, 1.4)], 'a', label='AD', at=(9.6, 1.6), anchor='end', dy=-10)
        g.line([(2.5, 8.6), (9.8, 2.76)], 'a', dash=True, label='AD′', at=(9.8, 2.9), anchor='end', dy=-10)
        g.dot(5, 5, 'main').guide(5, 5)
    g1.dot(6, 5.8, 'a').guide(6, 5.8)
    g2.dot(5, 6.6, 'a').guide(5, 6.6)
    ex = [txt(4, 224, 'P↑ Y↑', size=10.5, bold=True, col='a'), txt(188, 224, 'P↑ だけ（Yは変わらない）', size=10.5, bold=True, col='b')]
    return panels([g1, g2], '総需要（AD）の増加の効果', h=230, extra=ex)


FIG['keizai.adas2'] = _adas2()

FIG['keizai.adwhy'] = _rowflow([('ケインズ\n効果', 'b', ['物価が下がる', '実質貨幣供給が増え、\n利子率が下がる', ('投資が増える', 'b')]),
                                ('ピグー\n効果', 'c', ['物価が下がる', '資産の実質価値が\n上がる', ('消費が増える', 'c')])],
                               'AD曲線が右下がりになる理由', lw=56, size=10.5)

FIG['keizai.adasshift'] = grid(['要因', '動く曲線', '向き'],
                               [['技術進歩、生産性の上昇、労働人口の増加', 'AS', '右（下）'], ['原材料価格（原油など）や名目賃金の上昇', 'AS', '左（上）'],
                                ['政府支出の増加、減税、貨幣供給の増加（買いオペ）', 'AD', '右'], ['政府支出の削減、銀行の貸出の縮小', 'AD', '左']],
                               [236, 64, 60], align=['l', 'c', 'c'], title='AD曲線とAS曲線のシフト', size=10.5, tcol={'AS': 'b', 'AD': 'a'})

FIG['keizai.longrun'] = grid(['長期の効果', '国民所得', '物価', '利子率'],
                             [['政府支出の増加', '変わらない', '上がる', '上がる'], ['貨幣供給の増加', '変わらない', '上がる（名目賃金も同じ率）', '変わらない']],
                             [100, 72, 116, 72], align=['l', 'c', 'c', 'c'], title='長期（完全雇用の水準に戻る）の効果', size=10.5)

FIG['keizai.unemp3'] = grid(['失業の種類', '内容'],
                            [['摩擦的失業', '転職などで、職を探している間の一時的な失業'], ['構造的失業', '求人と求職の条件（技能、地域、年齢など）が合わない'],
                             ['需要不足による失業\n（非自発的失業、循環的失業）', '景気の悪化で総需要が不足して生じる']],
                            [128, 232], align=['l', 'l'], title='失業の種類（摩擦的＋構造的だけの状態の失業率＝自然失業率）', size=10.5, hl_rows=(0, 1))

FIG['keizai.rigid'] = _lists([('メニュー・コスト', 'c', ['価格を変えるときにかかる費用（値札や価格表の書き換え、顧客への通知など）', '費用が小さくても、価格を変えない方が得になることがある']),
                              ('効率賃金仮説', 'b', ['均衡より高い賃金を払うと、意欲が高まり、離職が減って生産性が上がる', '失業があっても賃金が下がりにくい'])],
                             '価格や賃金が硬直的になる理由')

FIG['keizai.rigid2'] = grid(['理論', '賃金が下がりにくい理由'],
                            [['効率賃金仮説', '賃金を下げると意欲や定着率が下がり、\n生産性が落ちるので、企業が自ら下げない'],
                             ['インサイダー・\nアウトサイダー理論', '雇われている労働者（インサイダー）は、\n入れ替えの費用（採用・訓練・解雇）を背景に、\n高い賃金を保てる。失業者（アウトサイダー）は\n低い賃金でも雇われにくい'],
                             ['暗黙の契約理論', 'リスク回避的な労働者に、企業が景気によらない\n安定した賃金を約束する（保険の役割）。\n景気への調整は、雇用や労働時間で行う']],
                            [112, 248], align=['l', 'l'], title='賃金が硬直的になる理由（労働市場の理論）', size=10.5, hl_rows=(1, 2))


def _gap():
    g = G(xmax=10, ymax=10, h=232, xlab='時間', ylab='GDP', origin='', pl=16, pr=12)
    pot = lambda x: 2.4 + 0.55 * x
    act = lambda x: pot(x) + 1.3 * math.sin(2 * math.pi * (x - 0.5) / 6)
    xs = [i / 40.0 for i in range(401)]
    seg = []
    for i, x in enumerate(xs):
        s = act(x) >= pot(x)
        if seg and seg[-1][0] == s:
            seg[-1][1].append(x)
        else:
            seg.append((s, [x]))
    for s, pts in seg:
        poly = [(x, act(x)) for x in pts] + [(x, pot(x)) for x in reversed(pts)]
        g.area(poly, 'b' if s else 'a', op=0.22)
    g.fn(pot, 0, 10, 'main', dash='6 4', label='潜在GDP（点線）', at=(9.9, 6.4), anchor='end')
    g.fn(act, 0, 10, 'a', label='実際のGDP', at=(0.3, 5.4))
    g.text(2.0, 7.8, 'プラス：需要超過\n人手不足、物価の上昇圧力', 'middle', 'b', True, 10.5)
    g.text(6.6, 2.2, 'マイナス：需要不足\n失業の増加、物価の下落圧力', 'middle', 'a', True, 10.5)
    return g.svg('GDPギャップ（需給ギャップ）')


FIG['keizai.gap'] = _gap()

# ------------------------------------------------ 1.2.8 景気変動と景気循環
FIG['keizai.waves'] = grid(['波', '周期', '原因'],
                           [['キチンの波', '約40か月', '在庫投資の変動（在庫循環）'], ['ジュグラーの波', '約10年', '設備投資の変動'], ['クズネッツの波', '約20年', '建設投資の変動'],
                            ['コンドラチェフの波', '約50年', '技術革新など']],
                           [120, 80, 160], align=['l', 'c', 'l'], title='景気循環の4つの波', size=11.5, tcol={'約40か月': 'a', '約10年': 'a', '約20年': 'a', '約50年': 'a'})


def _accel():
    prod = [100, 110, 125, 135, 140]
    g1 = G(xmax=4.5, xmin=-0.5, ymax=150, ymin=90, w=176, h=208, ox=0, pl=30, pr=6, cap='生産', ccol='b', origin='')
    g2 = G(xmax=4.5, xmin=-0.5, ymax=36, w=176, h=208, ox=184, pl=26, pr=6, cap='投資＝2×生産の増加', ccol='a', origin='')
    g1.line([(i, v) for i, v in enumerate(prod)], 'b')
    for i, v in enumerate(prod):
        g1.dot(i, v, 'b', label=str(v), pos='nw' if i else 'e', size=10)
        g1.xt(i, '%d期' % i, size=9.5)
    for i in range(1, 5):
        inv = 2 * (prod[i] - prod[i - 1])
        g2.rect(i - 0.3, 0, i + 0.3, inv, col='a', op=0.3, label=str(inv), at=(i, inv + 2.2), lcol='main', size=10)
        g2.xt(i, '%d期' % i, size=9.5)
    ex = [txt(180, 222, '生産の増加 ＋10→＋15→＋10→＋5', 'middle', size=10.5, bold=True, col='b'),
          txt(180, 240, '生産が増え続けても、増え方が鈍ると投資は減る', 'middle', size=10.5, bold=True, col='a')]
    return panels([g1, g2], '加速度原理（資本係数v＝2の例）', h=248, extra=ex)


FIG['keizai.accel'] = _accel()


def _invcycle():
    g = G(xmax=5, xmin=-5, ymax=5, ymin=-5, xaxis=0, h=290, origin='', pl=18, pr=18, pt=14, pb=20)
    o = []
    X0 = g.X(0)
    g.raw(ARROW([(X0, g.Y(-5)), (X0, g.Y(5) - 4)], col='main', sw=1.3, head=6), 'bg')
    g.axes = False
    g.raw(ARROW([(g.X(-5), g.Y(0)), (g.X(5) + 6, g.Y(0))], col='main', sw=1.3, head=6), 'bg')
    g.text(0.3, 4.75, '在庫の前年比', 'start', 'main', False, 10.5)
    g.text(5.0, -0.55, '出荷の前年比', 'end', 'main', False, 10.5)
    pts = [(3.4 * math.cos(t / 60.0 * 2 * math.pi - math.pi / 2), 3.0 * math.sin(t / 60.0 * 2 * math.pi - math.pi / 2)) for t in range(61)]
    g.line(pts, 'c', sw=2)
    for t in (7, 22, 37, 52):
        a = t / 60.0 * 2 * math.pi - math.pi / 2
        b = (t + 1.2) / 60.0 * 2 * math.pi - math.pi / 2
        g.arrow(3.4 * math.cos(a), 3.0 * math.sin(a), 3.4 * math.cos(b), 3.0 * math.sin(b), 'c', sw=2, head=8)
    g.text(3.0, -4.2, '① 意図せざる在庫減\n（回復の初め）', 'middle', 'b', True, 10.5)
    g.text(3.0, 4.2, '② 在庫の積み増し', 'middle', 'b', True, 10.5)
    g.text(-3.0, 4.2, '③ 意図せざる在庫増\n（後退の初め）', 'middle', 'a', True, 10.5)
    g.text(-3.0, -4.2, '④ 在庫の調整', 'middle', 'a', True, 10.5)
    g.text(0, 0.9, '反時計回り', 'middle', 'c', True, 10.5)
    return g.svg('在庫循環図')


FIG['keizai.invcycle'] = _invcycle()


def _phase():
    g = G(xmax=10, ymax=10, h=208, xlab='時間', ylab='景気', origin='', pl=16, pb=44, xlpos='low')
    f = lambda x: 5 - 3.4 * math.cos(2 * math.pi * (x - 1) / 8)
    g.fn(f, 0, 10, 'a')
    g.rect(1, 0, 5, 10, col='b', op=0.08).rect(5, 0, 9, 10, col='a', op=0.07)
    g.dot(1, f(1), 'a', label='谷', pos='s').dot(5, f(5), 'a', label='山', pos='n').dot(9, f(9), 'a', label='谷', pos='s')
    g.text(3, 9.3, '拡張期（好況）', 'middle', 'b', True, 11).text(7, 9.3, '後退期（不況）', 'middle', 'a', True, 11)
    g.hspan(-0.9, 1, 9, '', 'main')
    g.raw(txt(g.X(5), g.Y(0) + 32, '景気循環の1周期（谷から次の谷まで）', 'middle', 'main', True, 10.5))
    return g.svg('景気の局面')


FIG['keizai.phase'] = _phase()

# ------------------------------------------------ 1.3.1 比較生産費と貿易理論
FIG['keizai.compadv'] = grid(['', '財X 1単位', '財Y 1単位', 'Xの機会費用', 'Yの機会費用'],
                             [['A国', '2人', '4人', '2÷4＝0.5', '4÷2＝2'], ['B国', '6人', '8人', '6÷8＝0.75', '8÷6≒1.33']],
                             [52, 68, 68, 86, 86], align=['l', 'c', 'c', 'c', 'c'], title='比較優位の判定（必要な労働者の数）', size=11,
                             tcol={'2÷4＝0.5': 'b', '8÷6≒1.33': 'b'})


def _ppf():
    g = G(xmax=12, ymax=22, h=256, xlab='財X（個/日）', ylab='財Y（個/日）', pr=20, pb=40, xlpos='low')
    g.line([(0, 20), (10, 0)], 'a', label='A国', at=(5.2, 10.6))
    g.line([(0, 6), (6, 0)], 'b', label='B国', at=(3.1, 3.6))
    g.yt(20, '20').yt(6, '6').xt(10, '10').xt(6, '6')
    g.text(5.4, 19.0, 'A国：Xの機会費用＝Y2個', 'start', 'a', True, 10.5)
    g.text(5.4, 16.6, 'B国：Xの機会費用＝Y1個', 'start', 'b', True, 10.5)
    g.text(5.4, 13.6, 'B国はXに、A国はYに比較優位\n（A国は両方の財で絶対優位）', 'start', 'main', True, 10.5)
    return g.svg('1日に生産できる量と機会費用（線の傾き＝Xの機会費用）')

FIG['keizai.ppf'] = _ppf()

FIG['keizai.ho'] = _rowflow([('', None, [('資本が豊富な国', 'c'), '資本集約的な財を輸出']), ('', None, [('労働が豊富な国', 'b'), '労働集約的な財を輸出'])],
                            'ヘクシャー＝オリーンの定理', lw=0, size=11)


def _capmove():
    g = G(xmax=10, ymax=10, h=262, xlab='', ylab='資本の報酬', pr=40, pb=46)
    ra = lambda x: 8 - 0.6 * x
    rb = lambda x: 3.5 + 0.6 * x
    g.raw(ARROW([(g.X(10), g.Y(0)), (g.X(10), g.Y(10) - 6)], col='main', sw=1.3, head=6))
    g.area([(3.75, 5.75), (7, ra(7)), (7, rb(7))], 'c', op=0.35)
    g.line([(0, 8), (10, 2)], 'a', label='A国の限界生産物', at=(0.3, 8.6))
    g.line([(0, 3.5), (10, 9.5)], 'b', label='B国の限界生産物', at=(9.7, 9.9), anchor='end')
    g.vl(7, 'main', dash='4 3', sw=1.2).vl(3.75, 'main', dash='4 3', sw=1.2)
    g.dot(3.75, 5.75, 'main')
    g.xt(7, '最初の配分').xt(3.75, '移動後')
    g.arrow(6.8, 1.0, 4.0, 1.0, 'c', sw=2)
    g.text(5.4, 1.7, '資本がA国からB国へ', 'middle', 'c', True, 10.5)
    g.text(8.1, 5.75, '世界の生産\nの増加', 'start', 'c', True, 10.5)
    g.arrow(8.0, 5.75, 6.6, 5.75, 'c', sw=1.2, head=5)
    g.raw(txt(g.X(0), g.Y(0) + 30, 'A国の資本 →', 'start', 'a', True, 10.5))
    g.raw(txt(g.X(10), g.Y(0) + 30, '← B国の資本', 'end', 'b', True, 10.5))
    return g.svg('資本の国際移動（横幅＝世界の資本の総量）')


FIG['keizai.capmove'] = _capmove()

FIG['keizai.capwho'] = grid(['', '資本が流出する国（A国）', '資本が流入する国（B国）'],
                            [['国内の生産', '減る（国民所得は増える）', '増える'], ['資本の所有者', '報酬が上がり、所得が増える', '報酬が下がり、所得が減る'],
                             ['労働者', '賃金所得が減る', '賃金所得が増える']],
                            [80, 140, 140], align=['l', 'c', 'c'], title='資本の移動で得をする人・損をする人', size=10.5)

# ------------------------------------------------ 1.3.2 貿易政策


def _sd(g, dlab=(9.6, 0.4), slab=(9.4, 9.4)):
    g.line([(0, 10), (10, 0)], 'a', label='D', at=dlab, dx=4)
    g.line([(0, 0), (10, 10)], 'b', label='S', at=slab, dx=4)


def _freetrade():
    g = G(xmax=10, ymax=10, h=262, xlab='数量', ylab='価格', pr=24, pb=34)
    g.area([(0, 2), (2, 2), (5, 5), (0, 5)], 'c', op=0.3, label='消費者へ移る\n10.5', at=(1.6, 3.6), lcol='c')
    g.area([(2, 2), (8, 2), (5, 5)], 'b', op=0.32, label='総余剰の\n増加 9', at=(5, 3.0), lcol='b')
    _sd(g)
    g.hl(2, 'main', sw=1.6, label='国際価格2', at=(10, 2.0), anchor='end', dy=-8, lcol='main')
    g.dot(5, 5, 'main', label='閉鎖経済の均衡', pos='e')
    g.guide(5, 5, yt='5', v=False)
    g.guide(2, 2, xt='2', h=False).guide(8, 2, xt='8', h=False)
    g.hspan(0.9, 2, 8, '輸入6', 'a', dy=-8)
    g.yt(2, '2')
    return g.svg('自由貿易の利益（輸入する小国の例）')


FIG['keizai.freetrade'] = _freetrade()


def _tariff():
    g = G(xmax=10, ymax=10, h=338, xlab='数量', ylab='価格', pr=24, pb=104)
    g.area([(0, 2), (2, 2), (4, 4), (0, 4)], 'b', op=0.28, label='a', at=(1.6, 3.0), lcol='b', size=12)
    g.area([(2, 2), (4, 4), (4, 2)], 'sub', op=0.45, label='b', at=(3.4, 2.65), lcol='main', size=12)
    g.rect(4, 2, 6, 4, col='c', op=0.32, label='c', lcol='c', size=12)
    g.area([(6, 4), (8, 2), (6, 2)], 'sub', op=0.45, label='d', at=(6.6, 2.65), lcol='main', size=12)
    _sd(g)
    g.hl(2, 'main', sw=1.4, label='国際価格2', at=(10, 2.0), anchor='end', dy=-8, lcol='main')
    g.hl(4, 'a', sw=1.6, label='国内価格4', at=(10, 4.0), anchor='end', dy=-8)
    for x in (2, 4, 6, 8):
        g.seg(x, 2, x, 0, 'main')
        g.xt(x, str(x))
    g.yt(2, '2').yt(4, '4')
    for k, (s2, c2) in enumerate([('a：生産者余剰の増加 6（生産 2→4）', 'b'), ('c：関税収入 4（輸入 2×関税 2）', 'c'), ('b＋d：死荷重 2＋2', 'main'),
                                  ('消費者余剰の減少 14＝a＋b＋c＋d（消費 8→6）', 'a')]):
        g.raw(txt(6, g.Y(0) + 40 + k * 18, s2, size=10.5, bold=True, col=c2))
    return g.svg('関税の効果（小国、関税2の例）')


FIG['keizai.tariff'] = _tariff()


def _subsidy():
    g = G(xmax=10, ymax=10, h=318, xlab='数量', ylab='価格', pr=24, pb=90)
    g.area([(0, 2), (2, 2), (4, 4), (0, 4)], 'b', op=0.28, label='生産者余剰\nの増加', at=(1.7, 3.0), lcol='b', size=10)
    g.area([(2, 2), (4, 4), (4, 2)], 'sub', op=0.45, label='', lcol='main')
    _sd(g)
    g.line([(2, 0), (10, 8)], 'b', dash=True, label='S－補助金', at=(10, 8), anchor='end', dy=14)
    g.hl(2, 'main', sw=1.6, label='国際価格2（消費者が払う価格）', at=(10, 2.0), anchor='end', dy=-8, lcol='main')
    g.hl(4, 'b', sw=1.2, dash='4 3', x1=4)
    for x in (2, 4, 8):
        g.seg(x, 2, x, 0, 'main')
        g.xt(x, str(x))
    g.yt(4, '4').yt(2, '2')
    g.hspan(0.9, 4, 8, '輸入4', 'a', dy=-8)
    for k, s2 in enumerate(['生産者は、国際価格2＋補助金2＝4を受け取り、4まで生産', '消費は8のまま減らない（消費側の死荷重がない）', '死荷重は、生産側の灰色の三角形（2）だけ']):
        g.raw(txt(6, g.Y(0) + 40 + k * 18, s2, size=10.5, bold=True))
    return g.svg('生産補助金（関税と同じだけ国内生産を増やす場合）')


FIG['keizai.subsidy'] = _subsidy()

FIG['keizai.tqs'] = grid(['', '関税', '輸入数量制限', '生産補助金'],
                         [['消費者が払う価格', '上がる', '上がる', '変わらない'], ['輸入量', '減る', '減る', '減る（関税より多い）'],
                          ['四角形の部分', '関税収入（政府）', 'レント（輸入の権利を持つ者）', '補助金の支出（財政の負担）'], ['死荷重', '生産側＋消費側', '生産側＋消費側', '生産側だけ']],
                         [86, 82, 100, 92], align=['l', 'c', 'c', 'c'], title='関税・輸入数量制限・生産補助金の比較', size=10.5, tcol={'生産側だけ': 'b', '変わらない': 'b'})

FIG['keizai.bigtariff'] = _flow(['大国が関税を\nかける', '輸入が減り、\n国際価格が下がる', ('交易条件が\n改善する', 'b'), ('利益が死荷重を\n上回れば余剰が増える\n（最適関税）', 'c')],
                                '大国の関税', per_row=4, size=10, gapx=12)

FIG['keizai.wto'] = _lists([('最恵国待遇', 'b', ['ある国に与えた有利な待遇を、すべての加盟国に与える']), ('内国民待遇', 'c', ['輸入品を国内品と差別しない'])], 'WTOの基本の原則')


def _fta():
    g = G(xmax=10, ymax=10, h=322, xlab='数量', ylab='価格', pr=24, pb=90)
    g.area([(3, 3), (4, 4), (4, 3)], 'b', op=0.4, label='', lcol='b')
    g.area([(6, 4), (7, 3), (6, 3)], 'b', op=0.4, label='', lcol='b')
    g.rect(4, 2, 6, 3, col='a', op=0.32, label='転換\n2', lcol='a', size=10)
    _sd(g)
    g.hl(4, 'main', sw=1.4, label='FTA前：域外2＋関税2＝4', at=(10, 4.0), anchor='end', dy=-8, lcol='main')
    g.hl(3, 'b', sw=1.6, label='FTA後：域内国3', at=(10, 3.0), anchor='end', dy=-8)
    g.hl(2, 'sub', sw=1.2, dash='4 3', label='域外国の価格2', at=(10, 2.0), anchor='end', dy=12, lcol='main')
    for x in (3, 4, 6, 7):
        g.seg(x, 3, x, 0, 'main')
        g.xt(x, str(x))
    for k, (s2, c2) in enumerate([('緑の三角形：貿易創造効果 0.5＋0.5＝1', 'b'), ('赤の長方形：貿易転換効果（3－2）×2＝2', 'a'), ('総余剰は 1－2＝－1（減る）', 'main')]):
        g.raw(txt(6, g.Y(0) + 40 + k * 18, s2, size=10.5, bold=True, col=c2))
    return g.svg('FTAの貿易創造効果と貿易転換効果（数値例）')


FIG['keizai.fta'] = _fta()

FIG['keizai.epa'] = _nest([('EPA（経済連携協定）\n関税の撤廃などに加えて、投資、人の移動、知的財産なども含む', 'b'), ('FTA（自由貿易協定）\n関税の撤廃など', 'c')], 'FTAとEPA')

# ------------------------------------------------ 1.3.3 国際収支と為替レート
FIG['keizai.isbal'] = eq([[('（S－I）\n民間の貯蓄超過', 'b'), '＋', ('（T－G）\n財政収支', 'c'), '＝', ('X－M\n経常収支', 'a')],
                          [('（100－80）\n＝20', 'b'), '＋', ('（50－60）\n＝－10', 'c'), '＝', ('10の黒字', 'a')],
                          [('国内総生産', None), '－', ('国内需要\n（C＋I＋G）', None), '＝', ('経常収支\n（X－M）', 'a')]], 'ISバランスとアブソープション（2行目は数値例）', size=10.5)

FIG['keizai.ml'] = grid(['輸出と輸入の価格弾力性の合計', '円安（自国通貨の減価）の貿易収支への効果'],
                        [['1より大きい', '改善する（マーシャル＝ラーナー条件）'], ['1に等しい', '変わらない'], ['1より小さい', '悪化する（数量がまったく変わらなければ、輸入の支払いが増えるだけ）']],
                        [122, 238], align=['c', 'l'], title='マーシャル＝ラーナー条件（貿易収支が均衡している状態から）', size=10.5,
                        tcol={'改善する（マーシャル＝ラーナー条件）': 'b'})


def _jcurve():
    g = G(xmax=10, ymax=4.2, ymin=-2.5, xaxis=0, h=220, xlab='時間', ylab='経常収支', origin='', pl=16)
    J = lambda x: 0 if x < 2 else (-6 * (x - 2) * math.exp(-(x - 2) / 0.9) + 3 * (1 - math.exp(-(x - 2) / 3.0)))
    g.fn(J, 0, 10, 'a', n=200)
    g.vl(2, 'main', dash='4 3', sw=1.2, y0=-2.5, y1=3.9, label='円安', at=(2, 4.0), anchor='middle', lcol='main')
    g.text(3.6, -1.6, '数量がすぐには変わらず、一時的に悪化', 'start', 'a', True, 10.5)
    g.text(6.6, 3.3, '数量が調整されて改善', 'middle', 'b', True, 10.5)
    return g.svg('Jカーブ効果')


FIG['keizai.jcurve'] = _jcurve()

FIG['keizai.fxreg'] = grid(['制度', '為替レートの決まり方'],
                           [['固定相場制', '中央銀行が介入して、為替レートを一定に保つ'], ['変動相場制', '市場の需給で決まる']],
                           [96, 264], align=['l', 'l'], title='為替レート制度', size=11.5)

FIG['keizai.bopstage'] = grid(['発展の段階', '貿易・\nサービス\n収支', '第一次\n所得収支', '経常\n収支', '対外純資産'],
                              [['①未成熟の債務国', '赤字', '赤字', '赤字', '－\n（債務が増える）'],
                               ['②成熟した債務国', '黒字', '赤字', '赤字', '－\n（債務が増える）'],
                               ['③債務返済国', '黒字', '赤字', '黒字', '－\n（債務が減る）'],
                               ['④未成熟の債権国', '黒字', '黒字', '黒字', '＋\n（資産が増える）'],
                               ['⑤成熟した債権国', '赤字', '黒字', '黒字', '＋\n（資産が増える）'],
                               ['⑥債権取り崩し国', '赤字', '黒字', '赤字', '＋\n（資産が減る）']],
                              [100, 54, 56, 46, 104], align=['l', 'c', 'c', 'c', 'c'], title='国際収支の発展段階説（クローサー）', size=10.5,
                              tcol={'黒字': 'b', '赤字': 'a'}, hl_rows=(4,))

# ------------------------------------------------ 1.3.4 国際マクロ経済の理論と政策
FIG['keizai.mftbl'] = grid(['資本移動が完全な小国', '財政政策', '金融政策'],
                           [['変動相場制', '無効', '有効'], ['固定相場制', '有効', '無効']],
                           [140, 110, 110], align=['l', 'c', 'c'], title='マンデル＝フレミング・モデルの結論', size=12.5, tcol={'無効': 'a', '有効': 'b'})

FIG['keizai.mfflow'] = _rowflow([('変動\n財政', 'a', ['政府支出↑\n金利↑の圧力', '資本流入\n自国通貨高', '輸出↓ 輸入↑', ('所得は元に\n戻る（無効）', 'a')]),
                                 ('変動\n金融', 'b', ['貨幣供給↑\n金利↓の圧力', '資本流出\n自国通貨安', '純輸出↑', ('所得が増える\n（有効）', 'b')]),
                                 ('固定\n財政', 'b', ['政府支出↑\n金利↑の圧力', '通貨高を防ぐ\n自国通貨売り\nの介入', '貨幣供給↑', ('所得が大きく\n増える（有効）', 'b')]),
                                 ('固定\n金融', 'a', ['貨幣供給↑\n金利↓の圧力', '通貨安を防ぐ\n自国通貨買い\nの介入', '貨幣供給が\n元に戻る', ('効果なし\n（無効）', 'a')])],
                                '政策の効果が生まれる・消えるしくみ', lw=40, size=9.5, gapx=10)


def _mffloat():
    g1 = G(xmax=10, ymax=10, w=176, h=210, ox=0, pl=22, pr=18, xlab='Y', ylab='r', cap='変動相場制の財政政策', ccol='a')
    g2 = G(xmax=10, ymax=10, w=176, h=210, ox=184, pl=22, pr=18, xlab='Y', ylab='r', cap='変動相場制の金融政策', ccol='b')
    for g in (g1, g2):
        g.hl(4, 'c', sw=2, label='BP（r＝r*）', at=(0.2, 4.6), lsize=10)
        g.line([(1, 8), (9, 0)], 'a', label='IS', at=(9, 0.6), dx=1)
        g.line([(0, 1), (10, 7)], 'b', label='LM', at=(9.0, 7.6), anchor='end')
        g.dot(5, 4, 'main').guide(5, 4, h=False)
    g1.line([(2.5, 9), (10, 1.5)], 'a', dash=True, label='IS′', at=(10, 1.6), dy=-10, anchor='end')
    g1.arrow(7.0, 2.6, 6.0, 2.6, 'a', sw=1.6, head=5)
    g1.text(7.6, 9.4, '通貨高で\nISが戻る', 'middle', 'a', True, 10)
    g2.line([(2.5, 1), (10, 5.5)], 'b', dash=True, label='LM′', at=(10, 5.6), dy=14, anchor='end')
    g2.line([(3, 8), (10, 1)], 'a', dash=True, label='IS′', at=(10, 1.2), dy=-10, anchor='end')
    g2.dot(7, 4, 'b').guide(7, 4, h=False)
    g2.text(7.8, 9.4, '通貨安で\nISも右へ', 'middle', 'b', True, 10)
    ex = [txt(4, 226, 'Yは変わらない（無効）', size=10.5, bold=True, col='a'), txt(188, 226, 'Yが増える（有効）', size=10.5, bold=True, col='b')]
    return panels([g1, g2], 'マンデル＝フレミング・モデル（資本移動が完全）', h=232, extra=ex)


FIG['keizai.mffloat'] = _mffloat()


def _bp():
    caps = [('資本移動が不完全', '右上がり'), ('資本移動が完全', '水平'), ('資本移動がない', '垂直')]
    gs = []
    for i in range(3):
        g = G(xmax=10, ymax=10, w=118, h=160, ox=i * 121, pl=14, pr=8, pt=34, pb=20, xlab='Y', ylab='r', origin='')
        g.raw(txt(i * 121 + 59, 12, caps[i][0], 'middle', 'main', True, 10.5))
        g.raw(txt(i * 121 + 59, 27, caps[i][1], 'middle', 'c', True, 10.5))
        gs.append(g)
    gs[0].line([(1, 1.5), (9, 8.5)], 'c', label='BP', at=(9, 8.0), anchor='end', dy=10, lsize=10)
    gs[1].hl(5, 'c', label='BP', at=(9.6, 5.4), anchor='end', dy=-10, lsize=10)
    gs[2].vl(5, 'c', label='BP', at=(5.4, 9.0), lsize=10)
    return panels(gs, 'BP曲線の形（国際収支が均衡する所得と利子率）', h=160)


FIG['keizai.bp'] = _bp()


def _trilemma():
    w, h = 360, 268
    A, B, C = (180, 34), (52, 214), (308, 214)
    o = ['<path d="M%s %sL%s %sL%s %sZ" style="fill:%s;fill-opacity:0.08;stroke:%s" stroke-width="1.6"/>' % (A + B + C + (_c('c'), _c('c')))]
    for (x, y), s in ((A, '為替レートの安定'), (B, '自由な資本移動'), (C, '金融政策の独立性')):
        o.append('<circle cx="%s" cy="%s" r="6" style="fill:%s"/>' % (x, y, _c('c')))
    o.append(txt(A[0], A[1] - 12, '為替レートの安定（固定相場）', 'middle', 'main', True, 11.5))
    o.append(txt(B[0], B[1] + 22, '自由な資本移動', 'middle', 'main', True, 11.5))
    o.append(txt(C[0], C[1] + 22, '金融政策の独立性', 'middle', 'main', True, 11.5))
    o.append(txt((B[0] + C[0]) / 2, B[1] - 12, '変動相場制（日本、米国など）', 'middle', 'b', True, 10.5))
    o.append(txt((A[0] + B[0]) / 2 - 8, (A[1] + B[1]) / 2, '通貨同盟\n（ユーロ圏）', 'end', 'a', True, 10.5, vc=True))
    o.append(txt((A[0] + C[0]) / 2 + 8, (A[1] + C[1]) / 2, '固定相場制＋\n資本の規制', 'start', 'c', True, 10.5, vc=True))
    o.append(txt(180, 150, '3つのうち2つしか\n同時に実現できない', 'middle', 'main', True, 11, vc=True))
    o.append(txt(4, 262, '辺の上の文字：その両端の2つを選んだ組合せ', size=10))
    return _svg(w, h, o, '国際金融のトリレンマ')


FIG['keizai.trilemma'] = _trilemma()
