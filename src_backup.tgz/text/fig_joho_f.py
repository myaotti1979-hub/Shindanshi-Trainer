# 経営情報システムの図表（2.4 情報システムの評価、2.5 意思決定・データ分析・データサイエンス）
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vis import (grid, htree, barchart, timeline, quad, ARROW, R, T, L, _svg, _c, wrap, tw)
from kit import (_lines, _dashrect, _box, _lists, _flow, _rowflow, _nest, _hub, _cycle, _ladder)
from ekit import G, txt, eq, panels
from jkit import stack, tiles, dtab, lab, pc, srv, cyl, cloud, person, rtr, brace, code, seq, r1, MONO

FIG = {}


def poly(o, pts, col='main', fill=None, op=0.16, sw=1.3, dash=None):
    d = 'M' + ' L'.join('%s %s' % (r1(a), r1(b)) for a, b in pts) + ' Z'
    ds = ' stroke-dasharray="%s"' % dash if dash else ''
    o.append('<path d="%s" style="fill:var(--sheet);stroke:none"/>' % d)
    o.append('<path d="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="%s"%s/>' % (d, _c(fill or 'sheet'), op if fill else 1, _c(col), sw, ds))


def circ(o, x, y, r, col='main', fill=None, op=0.16, sw=1.3):
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:var(--sheet);stroke:none"/>' % (r1(x), r1(y), r))
    o.append('<circle cx="%s" cy="%s" r="%s" style="fill:%s;fill-opacity:%s;stroke:%s" stroke-width="%s"/>' % (
        r1(x), r1(y), r, _c(fill or 'sheet'), op if fill else 1, _c(col), sw))


# ------------------------------------------------ 2.4.1 品質評価
def _q25010():
    o = []
    left = ['機能適合性', '性能効率性', '互換性', '使用性', '信頼性', 'セキュリティ', '保守性', '移植性']
    right = ['機能適合性', '性能効率性', '互換性', 'インタラクション容易性', '信頼性', 'セキュリティ', '保守性', '柔軟性', '安全性']
    o.append(T(70, 14, 'JIS X 25010:2013（8つ）', 'middle', size=10, bold=True))
    o.append(T(288, 14, '2025年の改正（9つ）', 'middle', size=10, bold=True))
    for i, s in enumerate(left):
        y = 24 + i * 24
        ch = i in (3, 7)
        o.append(R(4, y, 132, 20, fill='c' if ch else 'sheet', stroke='c' if ch else 'line', op=0.2 if ch else None, rx=3, sw=1))
        o.append(T(70, y + 14, s, 'middle', size=10, bold=ch))
    for i, s in enumerate(right):
        y = 24 + i * 24
        ch = i in (3, 7)
        new = i == 8
        col = 'a' if new else ('c' if ch else None)
        o.append(R(214, y, 142, 20, fill=col or 'sheet', stroke=col or 'line', op=0.22 if col else None, rx=3, sw=1))
        o.append(T(285, y + 14, s, 'middle', size=10, bold=bool(col)))
        if i < 8:
            o.append(L(136, y + 10, 214, y + 10, col='c' if ch else 'line', sw=1.6 if ch else 0.8, dash=None if ch else '3 3'))
    o.append(T(176, 24 + 8 * 24 + 14, '新たに加わった', 'middle', size=9.5, col='a', bold=True))
    o.append(T(4, 250, '利用時の品質は、別の規格（JIS X 25019）に分けられた', size=10))
    return _svg(360, 256, o, '製品品質モデルの改正')


FIG['joho.q25010'] = _q25010()

FIG['joho.q9126'] = grid(['品質特性', '主な副特性'],
                         [['機能性', '合目的性、正確性、相互運用性、セキュリティ'], ['信頼性', '成熟性、障害許容性、回復性'], ['使用性', '理解性、習得性、運用性、魅力性'],
                          ['効率性', '時間効率性、資源効率性'], ['保守性', '解析性、変更性、安定性、試験性'], ['移植性', '環境適応性、設置性、共存性、置換性']],
                         [70, 290], align=['l', 'l'], title='旧規格JIS X 0129-1（ISO/IEC 9126）の6つの品質特性', size=10.5)


def _growth():
    f = lambda x: 9 / (1 + math.exp(-(x - 4) * 1.1))
    g = G(xmax=10, ymax=10, h=200, xlab='テストの時間（件数）', ylab='見つかった誤りの累積', origin='', pb=30, pl=24, pt=20)
    g.fn(f, 0, 10, col='b', sw=2.6)
    g.hl(9, col='line', x0=0, x1=10, sw=1, dash='3 3')
    g.text(7.4, 7.6, '横ばいになれば、残っている', 'middle', 'b', True, 9.5)
    g.text(7.4, 6.6, '誤りが少ないと判断できる', 'middle', 'b', True, 9.5)
    g.text(2.2, 5.2, 'S字の曲線', 'middle', 'main', True, 10)
    return g.svg('信頼度成長曲線')


FIG['joho.growth'] = _growth()

FIG['joho.seed'] = eq([[('見つかった50件', 'c'), '＝', ('埋め込んだ誤り\n40件', 'a'), '＋', ('もともとの誤り\n10件', 'b')],
                       [('総数の推定', 'b'), '＝', 'もともと\n10', '×', '埋め込んだ数\n100', '÷', '見つかった\n埋め込み 40', '＝', ('25件', 'b')],
                       [('残っている誤り', 'a'), '＝', '推定の総数\n25', '－', '見つかった\nもともと 10', '＝', ('15件', 'a')]], 'エラー埋め込み法の計算', size=10)

FIG['joho.reviewk'] = _lists([('ウォークスルー', 'c', ['作成者が説明しながら進める']), ('インスペクション', 'b', ['進行役（モデレータ）のもとで、決められた手順で行う公式のレビュー'])],
                             'レビューの種類', size=10.5)

FIG['joho.cmmi'] = _ladder([('レベル1　初期\n場当たり的', None), ('レベル2　管理された\nプロジェクトごとに管理', None), ('レベル3　定義された\n組織で標準のプロセスを定義', 'c'),
                            ('レベル4　定量的に管理された', 'c'), ('レベル5　最適化している\n継続的に改善', 'b')], 'CMMIの成熟度のレベル', bw=200, size=10)

# ------------------------------------------------ 2.4.2 価値評価
FIG['joho.evaltime'] = _flow([('企画\n評価の指標（KGI・KPI）を決めておく', 'c'), ('事前評価\n投資するかどうかを決める', 'b'), ('中間評価\n計画どおりに進んでいるか', 'b'),
                              ('事後評価\n期待した効果が出たか', 'b')], 'IT投資の評価の時期', per_row=4, size=9.5, gapx=12)

FIG['joho.kgikpi'] = htree(('KGI\n最終の目標の達成の度合い\n（例：売上高を前年の1.2倍）', 'b', [('KPI：新規の訪問の件数', 'c', []), ('KPI：成約率', 'c', []), ('KPI：1件あたりの単価', 'c', [])]),
                           'KGIとKPI（例）', colw=(170, 170), gapx=12, size=10.5)

FIG['joho.roi'] = eq([[('ROI', 'b'), '＝', '投資による利益\n300万円', '÷', '投資額\n1,000万円', '＝', ('30％', 'b')]], 'ROIの計算（数値は例）', size=10.5)


def _bsc():
    o = []
    rows = [('財務', '売上高を増やす', 'a'), ('顧客', '顧客の満足を高める', 'c'), ('業務プロセス', '受注の処理を速くする', 'b'), ('学習と成長', '社員のITの能力を高める', 'b')]
    for i, (a, b, col) in enumerate(rows):
        y = 4 + i * 48
        o.append(R(2, y, 356, 40, fill=col, stroke=None, op=0.07, rx=4))
        o.append(T(10, y + 25, a, size=11, bold=True, col=col))
        _box(o, 150, y + 6, 170, 28, b, size=10.5, col=col, c0=None, op=0.2)
        if i:
            o.append(ARROW([(235, y + 4), (235, y - 12)], sw=1.6, head=6))
    o.append(T(4, 210, '下の視点の目標が、上の視点の成果につながる（因果関係）', size=10))
    return _svg(360, 216, o, '戦略マップの例')


FIG['joho.bsc'] = _bsc()

FIG['joho.effect'] = _lists([('金額で測れる効果', 'b', ['人件費の削減など']), ('金額で測りにくい効果', 'c', ['顧客の満足', '意思決定の迅速化'])], '効果の種類', size=10.5)

# ------------------------------------------------ 2.5.1 問題分析・意思決定技法


def _payoff():
    o = []
    rows = [['A案', '10', '4', '－3', '－3', '10', '約3.7'], ['B案', '6', '5', '2', '2', '6', '約4.3'], ['C案', '4', '3', '3', '3', '4', '約3.3']]
    hl = {(2, 4): 'a', (0, 5): 'c', (1, 6): 'b'}
    dtab(o, 4, 4, ['', '拡大', '現状維持', '縮小', '最悪', '最良', '平均'], rows, [44, 50, 58, 50, 50, 50, 54], size=10.5, rh=24, hl=hl)
    o.append(T(4, 124, '単位：億円。色のついた値が、各基準で選ばれる案', size=9.5))
    o.append(T(4, 142, 'マキシミン：最悪の値が最大 → C案', size=10.5, bold=True, col='a'))
    o.append(T(4, 160, 'マキシマックス：最良の値が最大 → A案', size=10.5, bold=True, col='c'))
    o.append(T(4, 178, 'ラプラス：平均が最大 → B案', size=10.5, bold=True, col='b'))
    return _svg(360, 184, o, '利得表と意思決定の基準')


FIG['joho.payoff'] = _payoff()


def _regret():
    o = []
    rows = [['A案', '10－10＝0', '5－4＝1', '3－(－3)＝6', '6'], ['B案', '10－6＝4', '5－5＝0', '3－2＝1', '4'], ['C案', '10－4＝6', '5－3＝2', '3－3＝0', '6']]
    dtab(o, 4, 4, ['', '拡大（最大10）', '現状（最大5）', '縮小（最大3）', '最大'], rows, [40, 84, 80, 90, 58], size=10, rh=24, hl={(1, 4): 'b'})
    o.append(T(4, 124, 'リグレット＝その状況での最大の利得－その案の利得', size=10))
    o.append(T(4, 142, '各案の最大のリグレットが最も小さいB案を選ぶ', size=10.5, bold=True, col='b'))
    return _svg(360, 148, o, 'ミニマックス・リグレット原理')


FIG['joho.regret'] = _regret()

FIG['joho.criteria'] = grid(['基準', '比べる値（A、B、C）', '選ぶ案'],
                            [['マキシミン（悲観的）', '最悪の値（－3、2、3）', 'C'], ['マキシマックス（楽観的）', '最良の値（10、6、4）', 'A'],
                             ['ラプラス', '平均（約3.7、約4.3、約3.3）', 'B'], ['ミニマックス・リグレット', '最大のリグレット（6、4、6）が最小', 'B'],
                             ['ハーヴィッツ（α＝0.6の例）', '最良×0.6＋最悪×0.4（4.8、4.4、3.6）', 'A']],
                            [128, 192, 40], align=['l', 'l', 'c'], title='不確実性の下での意思決定の基準（まとめ）', size=10)


def _dtree():
    o = []
    o.append(R(4, 70, 22, 22, fill='c', stroke='c', op=0.4, sw=1.2))
    o.append(T(4, 108, '意思決定', size=9))
    o.append(L(26, 81, 60, 44, col='main', sw=1.3))
    o.append(L(26, 81, 60, 130, col='main', sw=1.3))
    o.append(T(64, 40, '新製品を出す', size=10.5, bold=True))
    o.append(T(64, 124, '出さない', size=10.5, bold=True))
    o.append(L(60, 44, 150, 44, col='main', sw=1.3))
    o.append(L(60, 130, 230, 130, col='main', sw=1.3))
    circ(o, 160, 44, 10, col='b', fill='b', op=0.4)
    o.append(T(160, 70, '確率', 'middle', size=9))
    o.append(L(170, 44, 230, 18, col='main', sw=1.3))
    o.append(L(170, 44, 230, 70, col='main', sw=1.3))
    o.append(T(196, 22, '成功 0.6', 'middle', size=9.5))
    o.append(T(196, 74, '失敗 0.4', 'middle', size=9.5))
    o.append(T(236, 22, '10億円', size=10.5, bold=True))
    o.append(T(236, 74, '－5億円', size=10.5, bold=True, col='a'))
    o.append(T(236, 135, '0億円', size=10.5, bold=True))
    o.append(T(4, 172, '出す場合の期待値＝0.6×10＋0.4×(－5)＝4億円', size=10.5, bold=True, col='b'))
    o.append(T(4, 190, '出さない場合の0億円より大きいので、新製品を出す（数値は例）', size=10))
    return _svg(360, 196, o, 'デシジョンツリー')


FIG['joho.dtree'] = _dtree()

FIG['joho.brain'] = tiles([('批判しない', 'b'), ('質より量', 'b'), ('自由に発言する', 'b'), ('他人の案の結合・改善を歓迎', 'b')], 'ブレーンストーミングのルール', cols=2, size=10.5)

FIG['joho.kj'] = _flow(['情報を\nカードに書く', '似たものを\nグループに', 'グループに\n名前をつける', ('関係を図にし\n構造を明らかに', 'b')], 'KJ法（親和図法）', per_row=4, size=9.5, gapx=12)


def _fishbone():
    o = []
    o.append(ARROW([(10, 100), (262, 100)], sw=2.6, head=8))
    _box(o, 266, 76, 90, 48, '不良品が\n増えた（特性）', col='a', size=10, c0='a')
    bones = [(60, '人', ['経験が浅い'], 'top'), (170, '機械', ['設備が古い'], 'top'), (60, '材料', ['品質のばらつき'], 'bot'), (170, '方法', ['手順があいまい'], 'bot')]
    for x, nm, subs, pos in bones:
        if pos == 'top':
            o.append(L(x, 30, x + 50, 100, col='main', sw=1.6))
            o.append(T(x - 4, 24, nm, 'middle', size=11, bold=True, col='c'))
            o.append(L(x + 18, 56, x + 54, 56, col='line', sw=1.1))
            o.append(T(x + 56, 60, subs[0], size=9.5))
        else:
            o.append(L(x, 170, x + 50, 100, col='main', sw=1.6))
            o.append(T(x - 4, 184, nm, 'middle', size=11, bold=True, col='c'))
            o.append(L(x + 18, 144, x + 54, 144, col='line', sw=1.1))
            o.append(T(x + 56, 148, subs[0], size=9.5))
    o.append(T(4, 204, '結果（特性）と、それに影響する要因を魚の骨の形で整理する（例）', size=9.5))
    return _svg(360, 210, o, '特性要因図')


FIG['joho.fishbone'] = _fishbone()

FIG['joho.pareto'] = barchart([45, 25, 15, 10, 5], ['配送の\n遅れ', '破損', '誤配送', '説明\n不足', 'その他'], 'パレート図とABC分析（苦情の件数の例）', h=230, cum=True,
                              zones=[(0, 1, 'A', 'a'), (2, 2, 'B', 'c'), (3, 4, 'C', 'b')], ylab='件数')

FIG['joho.logic'] = htree(('利益が減った', 'a', [('売上が減った', 'c', [('客数が減った', 'c', []), ('客単価が下がった', 'c', [])]),
                                             ('費用が増えた', 'b', [('原価が上がった', 'b', []), ('販売費が増えた', 'b', [])])]),
                          'ロジックツリー（原因の分解の例）', colw=(96, 104, 120), gapx=12, size=10.5)

FIG['joho.expsm'] = eq([[('次の期の予測値', 'b'), '＝', '前の期の予測値\n100', '＋', 'α\n0.2', '×', '（実績120－予測100）\n20', '＝', ('104', 'b')]], '指数平滑法の計算', size=10)


def _bass():
    p, q, M = 0.03, 0.38, 100

    def F(t):
        e = math.exp(-(p + q) * t)
        return (1 - e) / (1 + q / p * e)
    g = G(xmax=20, ymax=12, h=210, xlab='時間', ylab='新しく購入する人の数', origin='', pb=30, pl=24, pt=20)
    g.fn(lambda t: M * (p + q * F(t)) * (1 - F(t)), 0, 20, col='main', sw=2.4)
    g.fn(lambda t: M * p * (1 - F(t)), 0, 20, col='c', sw=2, dash=True)
    g.fn(lambda t: M * q * F(t) * (1 - F(t)), 0, 20, col='b', sw=2, dash=True)
    for k, (s_, col, dash) in enumerate([('合計', 'main', None), ('模倣者：購入者の数に影響される', 'b', '6 4'),
                                         ('革新者：外部の情報（広告など）', 'c', '6 4')]):
        yy = 11.2 - k * 1.25
        g.seg(10.6, yy, 11.8, yy, col=col, dash=dash, sw=2, op=1)
        g.text(12.1, yy, s_, 'start', col, True, 9)
    return g.svg('バスモデル')


FIG['joho.bass'] = _bass()

# ------------------------------------------------ 2.5.2 データ分析技術と活用
FIG['joho.scales'] = grid(['尺度', '例', '順序', '差', '比'],
                          [['名義尺度', '性別、血液型', '×', '×', '×'], ['順序尺度', '満足度の5段階', '○', '×', '×'], ['間隔尺度', '摂氏の気温、西暦', '○', '○', '×'],
                           ['比例尺度', '長さ、重さ、売上高', '○', '○', '○']],
                          [80, 160, 40, 40, 40], align=['l', 'l', 'c', 'c', 'c'], title='データの尺度（意味を持つもの）', size=10.5, tcol={'○': 'b', '×': 'a'})


def _summary():
    o = []
    X = lambda v: 24 + v * 32
    o.append(ARROW([(X(0) - 6, 110), (X(10.5), 110)], sw=1.2, head=5))
    for v in range(1, 11):
        o.append(L(X(v), 106, X(v), 114, col='main', sw=1))
        o.append(T(X(v), 128, str(v), 'middle', size=10))
    data = [2, 2, 4, 5, 5, 7, 8, 8, 9, 10]
    cnt = {}
    for d in data:
        cnt[d] = cnt.get(d, 0) + 1
        mode = d in (2, 5, 8)
        circ(o, X(d), 106 - cnt[d] * 16 + 4, 6.5, col='c' if mode else 'b', fill='c' if mode else 'b', op=0.5)
    o.append('<path d="M%s 136 L%s 146 L%s 146 Z" style="fill:%s"/>' % (X(6), X(6) - 6, X(6) + 6, _c('a')))
    o.append(T(X(6), 162, '平均値＝60÷10＝6　中央値＝（5＋7）÷2＝6', 'middle', size=10.5, bold=True, col='a'))
    o.append(T(4, 182, 'オレンジ：2回ずつ現れる2、5、8 → 最頻値は1つに決まらない', size=10, col='c', bold=True))
    return _svg(360, 188, o, '平均値・中央値・最頻値')


FIG['joho.summary'] = _summary()


def _var():
    o = []
    xs = [2, 2, 4, 5, 5, 7, 8, 8, 9, 10]
    dev = [x - 6 for x in xs]
    rows = [['得点'] + [str(x) for x in xs] + ['60'], ['偏差'] + [('%+d' % d).replace('+', '＋').replace('-', '－') for d in dev] + ['0'],
            ['偏差の2乗'] + [str(d * d) for d in dev] + ['72']]
    dtab(o, 4, 4, [''] + ['%d' % (i + 1) for i in range(10)] + ['合計'], rows, [64] + [24] * 10 + [48], size=9.5, rh=22, hl={(2, 11): 'b'})
    o.append(T(4, 110, '分散（偏差の2乗の平均）＝72÷10＝7.2', size=10.5))
    o.append(T(4, 128, '不偏分散（母分散の推定値）＝72÷（10－1）＝8', size=10.5, bold=True, col='b'))
    o.append(T(4, 146, '標準偏差は分散の正の平方根（元のデータと同じ単位）', size=10))
    return _svg(360, 152, o, '分散と不偏分散')


FIG['joho.var'] = _var()

FIG['joho.cv'] = eq([[('Aの変動係数', 'c'), '＝', '標準偏差 10', '÷', '平均 40', '＝', ('0.25', 'c')], [('Bの変動係数', 'b'), '＝', '標準偏差 20', '÷', '平均 100', '＝', ('0.2', 'b')]],
                    '変動係数（相対的なばらつきはAが大きい）', size=10.5)


def _boxplot():
    o = []
    o.append(T(80, 14, 'ヒストグラム', 'middle', size=10.5, bold=True))
    hs = [2, 4, 7, 5, 2]
    for i, h in enumerate(hs):
        o.append(R(14 + i * 28, 120 - h * 12, 26, h * 12, fill='b', stroke='b', op=0.35, sw=1))
    o.append(L(10, 120, 158, 120, col='main', sw=1.2))
    o.append(T(80, 138, '度数分布を表す棒グラフ', 'middle', size=9.5))
    o.append(T(270, 14, '箱ひげ図', 'middle', size=10.5, bold=True))
    y = 70
    xs = {'min': 196, 'q1': 228, 'med': 262, 'q3': 300, 'max': 346}
    o.append(L(xs['min'], y, xs['q1'], y, col='main', sw=1.3))
    o.append(L(xs['q3'], y, xs['max'], y, col='main', sw=1.3))
    o.append(L(xs['min'], y - 10, xs['min'], y + 10, col='main', sw=1.3))
    o.append(L(xs['max'], y - 10, xs['max'], y + 10, col='main', sw=1.3))
    o.append(R(xs['q1'], y - 16, xs['q3'] - xs['q1'], 32, fill='c', stroke='main', op=0.25, sw=1.3))
    o.append(L(xs['med'], y - 16, xs['med'], y + 16, col='a', sw=2.2))
    labs = [('min', '最小値', 100), ('q1', '第1四分位数', 34), ('med', '中央値', 104), ('q3', '第3四分位数', 34), ('max', '最大値', 100)]
    for k, s, yy in labs:
        o.append(T(xs[k], yy, s, 'middle', size=9, bold=(k == 'med'), col='a' if k == 'med' else 'main'))
    return _svg(360, 146, o, 'ヒストグラムと箱ひげ図')


FIG['joho.boxplot'] = _boxplot()


def _corr():
    import random
    rnd = random.Random(5)
    gs = []
    for k, (ttl, kind, col) in enumerate([('強い正の相関\n（1に近い）', 1, 'b'), ('ほぼ相関なし\n（0に近い）', 0, 'sub'), ('強い負の相関\n（－1に近い）', -1, 'a')]):
        g = G(xmax=10, ymax=10, w=116, h=136, ox=k * 122, pl=10, pr=6, pt=30, pb=14, origin='', size=10)
        for i in range(14):
            x = 0.6 + i * 0.65
            if kind == 1:
                y = 1 + x * 0.8 + rnd.uniform(-0.9, 0.9)
            elif kind == -1:
                y = 9 - x * 0.8 + rnd.uniform(-0.9, 0.9)
            else:
                y = rnd.uniform(1, 9)
            g.dot(x, y, col=col if col != 'sub' else 'main', r=2.8)
        for j, ln in enumerate(ttl.split('\n')):
            g.raw(txt(g.ox + 58, 12 + j * 13, ln, 'middle', col=col if col != 'sub' else 'main', bold=(j == 0), size=10, halo=False))
        gs.append(g)
    return panels(gs, '散布図と相関係数', h=140)


FIG['joho.corr'] = _corr()


def _spurious():
    o = []
    _box(o, 124, 6, 112, 34, '気温が高い', col='c', size=11, c0='c')
    _box(o, 4, 106, 120, 34, 'アイスの売上', size=10.5)
    _box(o, 236, 106, 120, 34, '水の事故', size=10.5)
    o.append(ARROW([(150, 42), (80, 104)], col='c', sw=1.8, head=6))
    o.append(ARROW([(210, 42), (280, 104)], col='c', sw=1.8, head=6))
    o.append(L(126, 123, 234, 123, col='a', sw=1.4, dash='5 3'))
    o.append(T(180, 117, '相関はある', 'middle', size=10, bold=True, col='a'))
    o.append(T(180, 156, '一方が他方の原因ではない（見せかけの相関）', 'middle', size=10, bold=True, col='a'))
    o.append(T(180, 172, '第3の要因（気温）が両方に影響している', 'middle', size=10))
    return _svg(360, 178, o, '相関と因果')


FIG['joho.spurious'] = _spurious()


def _reg():
    import random
    rnd = random.Random(11)
    g = G(xmax=10, ymax=10, h=210, xlab='販売促進費（説明変数）', ylab='売上高（目的変数）', origin='', pb=30, pl=24, pt=20)
    for i in range(16):
        x = 0.8 + i * 0.55
        g.dot(x, 1.5 + 0.75 * x + rnd.uniform(-1, 1), col='main', r=2.8)
    g.line([(0, 1.5), (10, 9)], col='b', sw=2.4)
    g.text(9.8, 9.6, '回帰の式', 'end', 'b', True, 10.5)
    g.text(9.8, 2.2, '決定係数：式が目的変数のばらつきを', 'end', 'main', False, 9.5)
    g.text(9.8, 1.3, 'どれだけ説明できるか（0〜1）', 'end', 'main', False, 9.5)
    return g.svg('単回帰分析')


FIG['joho.reg'] = _reg()

FIG['joho.errors'] = quad(('帰無仮説が\n正しい', '帰無仮説が\n誤り'), ('棄却する', '棄却しない'),
                          [[('第1種の過誤', '正しいのに棄却してしまう。起こる確率＝有意水準', 'a'), ('正しい判断', '', 'b')],
                           [('正しい判断', '正しく棄却できる確率＝検出力（1－第2種の過誤の確率）', 'b'), ('第2種の過誤', '誤っているのに棄却しない', 'a')]],
                          '仮説検定の2つの過誤', lw=72, size=10)


def _ztest():
    phi = lambda z: math.exp(-z * z / 2) / math.sqrt(2 * math.pi)
    g = G(xmin=-3.6, xmax=3.6, ymax=0.45, h=200, xlab='', ylab='', origin='', pb=34, pl=10, pt=14, axes=False)
    for a, b in ((-3.6, -1.96), (1.96, 3.6)):
        pts = [(a, 0)] + [(a + (b - a) * i / 40, phi(a + (b - a) * i / 40)) for i in range(41)] + [(b, 0)]
        g.area(pts, col='a', op=0.4)
    g.fn(phi, -3.6, 3.6, col='main', sw=2)
    g.seg(-3.6, 0, 3.6, 0, col='main', dash=None, sw=1.2, op=1)
    for z, s in [(-1.96, '－1.96'), (0, '0'), (1.96, '1.96')]:
        g.seg(z, 0, z, phi(z) if z else 0.42, col='main', dash='3 3', sw=1)
        g.text(z, -0.03, s, 'middle', 'main', True, 10)
    g.text(-2.7, 0.07, '2.5％', 'middle', 'a', True, 10)
    g.text(2.7, 0.07, '2.5％', 'middle', 'a', True, 10)
    g.text(0, 0.2, '95％', 'middle', 'b', True, 11)
    g.raw(txt(180, 194, '両側検定（有意水準5％）：z値の絶対値が1.96を超えれば棄却', 'middle', size=10, halo=False))
    return g.svg('z検定の棄却域')


FIG['joho.ztest'] = _ztest()

FIG['joho.tests'] = grid(['調べたいこと', '使う検定'],
                         [['2つの群の平均の差（分散が既知、または標本が大きい）', 'z検定'], ['2つの群の平均の差（分散が未知で、標本が小さい）', 't検定（等分散でなければウェルチ）'],
                          ['3つ以上の群の平均の差（分散分析）', 'F検定'], ['2つの群の分散が等しいか', 'F検定'], ['クロス集計表の2つの変数が独立か', 'カイ二乗検定'],
                          ['相関係数・偏回帰係数が0でないか', 't検定']],
                         [220, 140], align=['l', 'l'], title='検定の使い分け', size=10)

FIG['joho.anova'] = eq([[('群間の自由度', 'c'), '＝', '群の数 k', '－', '1', '＝', ('3－1＝2', 'c')], [('群内の自由度', 'b'), '＝', '全体の個数 N', '－', '群の数 k', '＝', ('30－3＝27', 'b')]],
                       '分散分析の自由度（3群・合計30件の例）', size=10.5)

FIG['joho.multivar'] = grid(['手法', 'すること'],
                            [['クラスター分析', '似たもの同士をグループに分ける（正解のグループを決めずに）'], ['判別分析', '既知のグループの特徴から、新しいデータの属するグループを判別'],
                             ['因子分析', '多くの変数の背後にある共通の要因（因子）を見つける'], ['主成分分析', '多くの変数を、少数の総合的な指標（主成分）にまとめる'],
                             ['コンジョイント分析', '属性の組み合わせへの好みから、属性ごとの重要度を推定'], ['アソシエーション分析', '同時に起こる事柄の関係を見つける（支持度、確信度、リフト値）'],
                             ['決定木', '条件による分岐を繰り返して分類・予測（木の形で解釈しやすい）']],
                            [112, 248], align=['l', 'l'], title='多変量解析とデータマイニングの手法', size=10)


def _assoc():
    o = []
    o.append(R(4, 6, 168, 116, fill='sheet', stroke='line', rx=6))
    o.append(T(10, 22, '全体の取引 1,000件', size=10, bold=True))
    o.append('<circle cx="66" cy="72" r="38" style="fill:%s;fill-opacity:0.2;stroke:%s" stroke-width="1.3"/>' % (_c('c'), _c('c')))
    o.append('<circle cx="116" cy="72" r="30" style="fill:%s;fill-opacity:0.2;stroke:%s" stroke-width="1.3"/>' % (_c('b'), _c('b')))
    o.append(T(48, 76, 'A 200', 'middle', size=10, bold=True, col='c'))
    o.append(T(130, 76, 'B 100', 'middle', size=10, bold=True, col='b'))
    o.append(T(94, 108, '両方 50', 'middle', size=9.5, bold=True))
    o.append(T(182, 22, '「Aを買う人はBも買う」', size=10, bold=True))
    o.append(T(182, 44, '支持度＝50÷1,000＝5％', size=10))
    o.append(T(182, 58, '（AとBを同時に含む割合）', size=9))
    o.append(T(182, 80, '確信度＝50÷200＝25％', size=10))
    o.append(T(182, 94, '（Aを含むもののうちBも含む）', size=9))
    o.append(T(182, 116, 'リフト値＝25％÷10％＝2.5', size=10, bold=True, col='b'))
    o.append(T(182, 130, '（Bの割合100÷1,000で割る）', size=9))
    o.append(T(4, 150, 'リフト値が1より大きいほど、Aと一緒にBが買われやすい（数値は例）', size=10))
    return _svg(360, 156, o, 'アソシエーション分析の指標')


FIG['joho.assoc'] = _assoc()


def _survey():
    o = []
    defs = [('横断的調査', 'ある一時点で、多くの対象者を調べる'), ('パネル調査', '同じ対象者に、時間をおいて繰り返し調べる'),
            ('コーホート分析', '同じ時期に同じ経験をした集団を、時間を追って分析')]
    for k, (nm, d) in enumerate(defs):
        x0 = 4 + k * 120
        o.append(T(x0 + 56, 14, nm, 'middle', size=10.5, bold=True))
        for i in range(5):
            for j in range(4):
                if k == 0:
                    on = j == 1
                elif k == 1:
                    on = i in (1, 3)
                else:
                    on = i == 2
                circ(o, x0 + 22 + j * 24, 32 + i * 18, 5.5, col='b' if on else 'line', fill='b' if on else None, op=0.55)
        o.append(T(x0 + 56, 132, '→ 時間', 'middle', size=9))
        for jj, ln in enumerate(wrap(d, 110, 9.5)):
            o.append(T(x0 + 56, 150 + jj * 13, ln, 'middle', size=9.5))
    o.append(T(4, 196, '縦＝対象者（人や集団）、横＝調べる時点。緑＝調べる対象', size=9.5))
    return _svg(360, 202, o, '調査の手法')


FIG['joho.survey'] = _survey()

# ------------------------------------------------ 2.5.3 データサイエンス


def _mltype():
    o = []
    for k, (t, col) in enumerate([('教師あり学習', 'b'), ('教師なし学習', 'c'), ('強化学習', 'a')]):
        o.append(T(60 + k * 120, 14, t, 'middle', bold=True, size=10.5, col=col))
    pts1 = [(20, 40, 'o'), (34, 56, 'o'), (26, 76, 'o'), (44, 36, 'o'), (80, 88, 'x'), (96, 70, 'x'), (90, 104, 'x'), (70, 110, 'x')]
    for x, y, s in pts1:
        if s == 'o':
            circ(o, x, y, 5, col='b', fill='b', op=0.6)
        else:
            o.append(T(x, y + 4, '×', 'middle', size=12, bold=True, col='a'))
    o.append(L(14, 104, 110, 30, col='main', sw=1.4, dash='4 3'))
    o.append(T(60, 132, '正解（ラベル）つきで学習', 'middle', size=9))
    o.append(T(60, 145, '分類・回帰', 'middle', size=9, bold=True))
    import random
    rnd = random.Random(2)
    for cx, cy in [(150, 50), (204, 60), (176, 100)]:
        for i in range(6):
            circ(o, cx + rnd.uniform(-12, 12), cy + rnd.uniform(-10, 10), 4, col='main', fill='main', op=0.45)
        o.append('<circle cx="%s" cy="%s" r="20" style="fill:none;stroke:%s" stroke-width="1.2" stroke-dasharray="4 3"/>' % (cx, cy, _c('c')))
    o.append(T(180, 132, '正解なしで構造を見つける', 'middle', size=9))
    o.append(T(180, 145, 'クラスタリングなど', 'middle', size=9, bold=True))
    _box(o, 254, 34, 50, 30, 'エージェント', size=8.5, col='a', c0='a', bold0=False)
    _box(o, 306, 84, 50, 30, '環境', size=9)
    o.append(ARROW([(304, 52), (330, 52), (330, 82)], col='a', sw=1.2, head=5))
    o.append(T(334, 66, '行動', size=8.5))
    o.append(ARROW([(306, 104), (279, 104), (279, 66)], col='b', sw=1.2, head=5))
    o.append(T(262, 118, '報酬', size=8.5, col='b', bold=True))
    o.append(T(300, 132, '試行錯誤で報酬が', 'middle', size=9))
    o.append(T(300, 145, '最大の行動を学ぶ', 'middle', size=9, bold=True))
    return _svg(360, 152, o, '機械学習の種類')


FIG['joho.mltype'] = _mltype()


def _nn():
    o = []
    layers = [(40, 3, '入力層'), (140, 4, '隠れ層（中間層）'), (240, 4, '隠れ層'), (330, 2, '出力層')]
    pos = []
    for x, n, nm in layers:
        ys = [90 + (i - (n - 1) / 2) * 34 for i in range(n)]
        pos.append([(x, y) for y in ys])
        o.append(T(x, 170, nm, 'middle', size=9.5, bold=True))
    for a in range(3):
        for (x1, y1) in pos[a]:
            for (x2, y2) in pos[a + 1]:
                o.append(L(x1, y1, x2, y2, col='line', sw=0.8))
    for k, ps in enumerate(pos):
        for (x, y) in ps:
            circ(o, x, y, 11, col='b' if k in (1, 2) else ('c' if k == 0 else 'a'), fill='b' if k in (1, 2) else ('c' if k == 0 else 'a'), op=0.3)
    o.append(T(90, 22, '線の結合の強さ＝重み', 'middle', size=9.5, col='b', bold=True))
    o.append(T(4, 192, '多くの隠れ層を持つものを使う機械学習＝深層学習（ディープラーニング）', size=9.5))
    return _svg(360, 198, o, 'ニューラルネットワーク')


FIG['joho.nn'] = _nn()


def _act():
    gs = []
    defs = [('シグモイド関数', lambda x: 1 / (1 + math.exp(-x)), 0, 1, '0から1'), ('tanh', lambda x: math.tanh(x), -1, 1, '－1から1'),
            ('ReLU', lambda x: max(0.0, x), -1, 4, '0以下は0、正はそのまま')]
    for k, (nm, f, lo, hi, d) in enumerate(defs):
        ymin = lo if lo < 0 else -0.2
        g = G(xmin=-4, xmax=4, ymin=ymin if nm != 'ReLU' else -0.6, ymax=hi * 1.15, w=116, h=130, ox=k * 122, pl=8, pr=6, pt=20, pb=26, origin='', axes=False,
              cap=nm, ccol='b', size=10)
        g.seg(-4, 0, 4, 0, col='line', dash=None, sw=1, op=1)
        g.seg(0, g.ymin, 0, g.ymax, col='line', dash=None, sw=1, op=1)
        g.fn(f, -4, 4, col='b', sw=2.2)
        g.raw(txt(g.ox + 58, 124, d, 'middle', size=9, halo=False))
        gs.append(g)
    return panels(gs, '活性化関数', h=130)


FIG['joho.act'] = _act()


def _overfit():
    g = G(xmax=10, ymax=10, h=200, xlab='学習を進める（モデルを複雑に）', ylab='誤差', origin='', pb=30, pl=24, pt=20)
    g.fn(lambda x: 8 * math.exp(-x / 2.6) + 0.5, 0, 10, col='b', sw=2.4)
    g.fn(lambda x: 8 * math.exp(-x / 2.6) + 0.5 + 0.09 * x * x, 0, 10, col='a', sw=2.4)
    g.text(9.6, 1.6, '学習用のデータ', 'end', 'b', True, 10)
    g.text(9.6, 8.6, '検証用（未知）のデータ', 'end', 'a', True, 10)
    g.vl(4.6, col='line', y0=0, y1=9.6, sw=1, dash='3 3')
    g.text(5.0, 6.2, '過学習', 'start', 'a', True, 10.5)
    return g.svg('過学習')


FIG['joho.overfit'] = _overfit()


def _confmat():
    o = []
    lw, cw, rh = 96, 132, 44
    o.append(R(4, 4, lw - 4, 28, fill='paper', stroke='line'))
    for j, s in enumerate(['予測：陽性', '予測：陰性']):
        o.append(R(lw + j * cw, 4, cw, 28, fill='paper', stroke='line'))
        o.append(T(lw + j * cw + cw / 2, 23, s, 'middle', size=10.5, bold=True))
    cells = [[('TP（真陽性）', '80', 'b'), ('FN（偽陰性）', '20', 'a')], [('FP（偽陽性）', '40', 'a'), ('TN（真陰性）', '860', 'b')]]
    for i, rname in enumerate(['実際：陽性', '実際：陰性']):
        y = 32 + i * rh
        o.append(R(4, y, lw - 4, rh, fill='paper', stroke='line'))
        o.append(T(lw / 2 + 2, y + rh / 2 + 4, rname, 'middle', size=10.5, bold=True))
        for j in range(2):
            a, v, col = cells[i][j]
            x = lw + j * cw
            o.append(R(x, y, cw, rh, fill=col, stroke='line', op=0.18))
            o.append(T(x + cw / 2, y + 19, a, 'middle', size=10.5, bold=True, col=col))
            o.append(T(x + cw / 2, y + 36, v + '件', 'middle', size=10.5))
    o.append(T(4, 140, '陽性100件、陰性900件の例（緑＝正しい分類、赤＝誤り）', size=10))
    return _svg(360, 146, o, '混同行列')


FIG['joho.confmat'] = _confmat()


def _prrc():
    o = []
    for k, (ttl, hl, f, col) in enumerate([('適合率', 'col', 'TP÷（TP＋FP）\n＝80÷120≒0.67', 'c'), ('再現率', 'row', 'TP÷（TP＋FN）\n＝80÷100＝0.8', 'b')]):
        x0 = 4 + k * 180
        o.append(T(x0 + 84, 14, ttl, 'middle', size=11, bold=True, col=col))
        lab_ = ['TP', 'FN', 'FP', 'TN']
        for i in range(2):
            for j in range(2):
                on = (hl == 'col' and j == 0) or (hl == 'row' and i == 0)
                x, y = x0 + 30 + j * 60, 36 + i * 34
                o.append(R(x, y, 58, 32, fill=col if on else 'sheet', stroke='line', op=0.3 if on else None))
                o.append(T(x + 29, y + 21, lab_[i * 2 + j], 'middle', size=11, bold=True))
        o.append(T(x0 + 24, 56, '陽', 'end', size=9.5))
        o.append(T(x0 + 24, 90, '陰', 'end', size=9.5))
        o.append(T(x0 + 59, 31, '予測陽', 'middle', size=9))
        o.append(T(x0 + 119, 31, '予測陰', 'middle', size=9))
        d = '陽性と予測したもののうち' if hl == 'col' else '実際に陽性のもののうち'
        o.append(T(x0 + 84, 122, d, 'middle', size=9.5))
        for j, ln in enumerate(f.split('\n')):
            o.append(T(x0 + 84, 140 + j * 15, ln, 'middle', size=10.5, bold=True, col=col))
    return _svg(360, 172, o, '適合率と再現率の分母')


FIG['joho.prrc'] = _prrc()

FIG['joho.metrics'] = eq([[('正解率', 'sub'), '＝', '（80＋860）', '÷', '1,000', '＝', '0.94'], [('F値', 'a'), '＝', '2×0.67×0.8', '÷', '（0.67＋0.8）', '≒', ('0.73', 'a')]],
                         '正解率とF値（調和平均）', size=10.5)

FIG['joho.regerr'] = grid(['指標', '計算（誤差 2、－2、3／実績 10、20、30）', '値'],
                          [['MAE', '（2＋2＋3）÷3', '≒2.33'], ['MSE', '（4＋4＋9）÷3', '≒5.67'], ['RMSE', 'MSEの平方根', '≒2.38'],
                           ['MAPE', '（2÷10＋2÷20＋3÷30）÷3', '≒13.3％'], ['WAPE', '（2＋2＋3）÷（10＋20＋30）', '≒11.7％']],
                          [56, 230, 74], align=['l', 'l', 'r'], title='回帰のモデルの評価指標', size=10)

FIG['joho.rag'] = _flow(['利用者の質問', '社内の文書などの外部の情報を検索', '見つけた内容＋質問を生成AIに渡す', ('内容にもとづいて回答', 'b')], 'RAG（検索拡張生成）', per_row=4, size=9.5,
                        gapx=12)

FIG['joho.agent'] = _cycle(['目的を受け取る', '計画を立てる', '外部のツールや\nシステムを使う', '結果を確かめる'], 'AIエージェント', h=200, bw=110, bh=40, center='自律的に\n作業を進める',
                           ccol='b')


def _aiguide():
    o = []
    for i, s in enumerate(['AI開発者', 'AI提供者', 'AI利用者']):
        _box(o, 4 + i * 120, 6, 112, 30, s, col='b', size=11, c0='b')
    o.append(T(4, 56, '共通の指針（主なもの）', size=10.5, bold=True))
    ps = ['人間中心', '安全性', '公平性', 'プライバシー保護', 'セキュリティ確保', '透明性', 'アカウンタビリティ']
    x, y = 4, 66
    for p in ps:
        w = tw(p, 10) + 18
        if x + w > 356:
            x, y = 4, y + 28
        o.append(R(x, y, w, 22, fill='c', stroke='c', op=0.18, rx=11))
        o.append(T(x + w / 2, y + 15, p, 'middle', size=10, bold=True))
        x += w + 6
    o.append(T(4, y + 44, '2026年3月の第1.2版で、AIエージェントなどへの対応が加わった', size=10))
    return _svg(360, y + 50, o, 'AI事業者ガイドライン')


FIG['joho.aiguide'] = _aiguide()


# ------------------------------------------------ 演習の解説用
def _qnorm():
    phi = lambda z: math.exp(-z * z / 2) / math.sqrt(2 * math.pi)
    g = G(xmin=-3.6, xmax=3.6, ymax=0.46, h=222, xlab='', ylab='', origin='', pb=76, pl=10, pt=10, axes=False)
    for a, col, op in ((3, 'sub', 0.12), (2, 'c', 0.18), (1, 'b', 0.3)):
        pts = [(-a, 0)] + [(-a + 2 * a * i / 60, phi(-a + 2 * a * i / 60)) for i in range(61)] + [(a, 0)]
        g.area(pts, col=col, op=op)
    g.fn(phi, -3.6, 3.6, col='main', sw=2)
    g.seg(-3.6, 0, 3.6, 0, col='main', dash=None, sw=1.2, op=1)
    for z in (-3, -2, -1, 0, 1, 2, 3):
        g.text(z, -0.03, ('%+dσ' % z if z else '平均').replace('+', '＋').replace('-', '－'), 'middle', 'main', True, 9.5)
    g.text(0, 0.17, '約68％', 'middle', 'b', True, 11)
    rows = [('平均±1標準偏差', '約68％', 'b'), ('平均±2標準偏差', '約95％', 'c'), ('平均±3標準偏差', '約99.7％', 'main')]
    for k, (a, b, col) in enumerate(rows):
        g.raw(txt(70, 182 + k * 15, a, 'start', col, True, 10, halo=False))
        g.raw(txt(220, 182 + k * 15, b, 'start', col, True, 10, halo=False))
    return g.svg('正規分布と標準偏差')


FIG['joho.qnorm'] = _qnorm()
