# 組み合わせの問題で、記述を判断しなくても選択肢の並びだけで正答が分かってしまう形を探す
#   値の組（a：正 b：誤 …、A：語句 B：語句 …、①：語句 ②：語句 …）：
#     ①記述（空欄）ごとの多数決が正答と一致 ②正答がほかのすべての肢と1か所だけ違う（星形）③正答だけがほかとの違いの合計が最小
#   記号の組（aとb …）：正答が「最も多く出てくる記号」の組と一致（ほかに同じ多さの組がない）
#   値の組（全角の空白で区切った短い項目が同じ数だけ並ぶ選択肢。会社ごとの数値、仕訳など）：値の組と同じ3つの基準
# 使い方: python3 combo_scan.py [ファイル（pwa/data/m_*.json）...]  省略時は全部。-v で検出した組の形も出す
import sys, json, glob, re, os
B = os.path.dirname(os.path.abspath(__file__))
KM = re.compile(r'(?:^|(?<=[\s　]))[（(]?([A-Ea-e①-⑤])[）)]?\s*[：:]\s*')
PR = re.compile(r'^\s*([a-e])(?:\s*(?:と|・|、)\s*([a-e]))+\s*$')


def tuples(ch):
    """「A：語句　B：語句」の形なら（記号の並び, 選択肢ごとの値の組）。値は次の記号までの文字（前後の空白を除く）"""
    vs = []
    for c in ch:
        ms = list(KM.finditer(c))
        if len(ms) < 2 or ms[0].start() != len(c) - len(c.lstrip()):
            return None
        d = {}
        for i, m in enumerate(ms):
            k = m.group(1)
            v = c[m.end():ms[i + 1].start() if i + 1 < len(ms) else len(c)].strip(' 　、，,')
            if k in d or not v:
                return None
            d[k] = v
        vs.append(d)
    keys = sorted(vs[0])
    if any(sorted(v) != keys for v in vs):
        return None
    return keys, [tuple(v[k] for k in keys) for v in vs]


def check_tuple(V, a):
    why = []
    ans = V[a]
    maj = []
    for i in range(len(ans)):
        col = [x[i] for x in V]
        cnt = {}
        for x in col:
            cnt[x] = cnt.get(x, 0) + 1
        top = max(cnt.values())
        tops = [x for x in cnt if cnt[x] == top]
        maj.append(tops[0] if len(tops) == 1 else None)
    if tuple(maj) == ans:
        why.append('多数決で当たる')
    d = lambda x, y: sum(p != q for p, q in zip(x, y))
    if all(d(ans, x) == 1 for k, x in enumerate(V) if k != a):
        why.append('星形')
    tot = [sum(d(x, y) for y in V) for x in V]
    if tot[a] == min(tot) and tot.count(min(tot)) == 1:
        why.append('違いの合計が最小')
    return why


def scan_item(it):
    """1問を調べる。組み合わせの問題でなければ None、そうなら（並びで当たる理由のリスト, 種類）"""
    ch, a = it['ch'], it['a']
    t = tuples(ch)
    if t:
        keys, V = t
        kind = '正誤の組' if all(set(v) <= {'正', '誤'} for v in V) else '語句の組'
        return check_tuple(V, a), kind
    ms = [re.findall(r'[a-e]', c) if PR.match(c) else None for c in ch]
    if not (all(ms) and all(len(m) == len(ms[0]) for m in ms)):
        # 値の組（「X社 1,200　Y社 800」「（借）売掛金 75　（貸）売上 75」など、全角の空白で区切った短い項目が同じ数だけ並ぶ選択肢）
        V = [tuple(x for x in re.split(r'　+', c.strip()) if x) for c in ch]
        if len(V[0]) >= 2 and all(len(v) == len(V[0]) for v in V) and all(len(x) <= 24 for v in V for x in v):
            if any(len(set(v[i] for v in V)) > 1 for i in range(len(V[0]))):
                return check_tuple(V, a), '値の組'
        return None
    cnt = {}
    for m in ms:
        for L in m:
            cnt[L] = cnt.get(L, 0) + 1
    k = len(ms[0])
    top = sorted(cnt, key=lambda L: -cnt[L])
    why = []
    if len(top) > k and cnt[top[k - 1]] > cnt[top[k]] and set(top[:k]) == set(ms[a]):
        why.append('最も多く出る記号の組')
    return why, '記号の組'


if __name__ == '__main__':
    args = [x for x in sys.argv[1:] if not x.startswith('-')]
    verbose = '-v' in sys.argv
    files = args or sorted(glob.glob(os.path.join(B, 'pwa', 'data', 'm_*_*.json')))
    hits = []
    for f in files:
        j = json.load(open(f, encoding='utf-8'))
        for it in j['items']:
            r = scan_item(it)
            if r and r[0]:
                hits.append((os.path.basename(f), it['no'], r[1], '・'.join(r[0])))
                if verbose:
                    print('  ', it['ch'], '正答', it['a'])
    for h in hits:
        print(*h)
    print('該当', len(hits))
