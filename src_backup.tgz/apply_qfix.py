# 本試験形式の演習の検証結果（review/qb_*.json）を qbank に当てる
# 使い方: python3 apply_qfix.py review/qb_keizai1.json [--dry] [--mark] [--skip id,id]
#   fix の old は、その問題の dict(...) の中で1か所だけに一致すること（一致しなければ止める）
#   --mark: ok と、直しを当てた fix の問題を qbank/verified.json に入れる（figfix がある問題は入れない）
import sys, os, json, glob, re
B = os.path.dirname(os.path.abspath(__file__))
args = sys.argv[1:]
dry, mark = '--dry' in args, '--mark' in args
skip = set()
if '--skip' in args:
    skip = set(args[args.index('--skip') + 1].split(','))
files = [a for a in args if a.endswith('.json')]
R = []
for f in files:
    R += json.load(open(f, encoding='utf-8'))
src = {}
for f in glob.glob(B + '/qbank/q_*.py'):
    src[f] = open(f, encoding='utf-8').read()


def block(qid):
    for f, s in src.items():
        i = s.find("dict(id='%s'" % qid)
        if i >= 0:
            j = s.find("\ndict(id='", i + 1)
            if j < 0:
                j = s.rfind(']')
            return f, i, j
    sys.exit('問題が見つからない: ' + qid)


ok, fixed, rej, fig = [], [], [], []
for r in R:
    qid, v = r['id'], r['verdict']
    if qid in skip:
        print('飛ばす', qid); continue
    if v == 'ok':
        ok.append(qid); continue
    if v == 'reject':
        rej.append((qid, r.get('problem', ''))); continue
    if r.get('figfix'):
        fig.append((qid, r['figfix']))
    for fx in r.get('fixes', []):
        if 'old' not in fx:
            if fx.get('figfix'):
                fig.append((qid, fx['figfix']))
            continue
        f, i, j = block(qid)
        s = src[f]
        part = s[i:j]
        n = part.count(fx['old'])
        if n != 1:
            sys.exit('%s: 置換前の文字列が %d か所に一致: %s' % (qid, n, fx['old'][:60]))
        part = part.replace(fx['old'], fx['new'])
        src[f] = s[:i] + part + s[j:]
    if not any(q == qid for q, _ in fig):
        fixed.append(qid)
print('ok', len(ok), 'fix', len(fixed), 'reject', len(rej), '図の直し', len(fig))
for q, p in rej:
    print('reject', q, p[:200])
for q, p in fig:
    print('図', q, p[:300])
if not dry:
    for f, s in src.items():
        if s != open(f, encoding='utf-8').read():
            open(f, 'w', encoding='utf-8').write(s)
            print('書いた', os.path.basename(f))
    if mark:
        p = B + '/qbank/verified.json'
        V = json.load(open(p)) if os.path.exists(p) else {}
        for q in ok + fixed:
            V[q] = os.path.basename(files[0])
        json.dump(V, open(p, 'w'), ensure_ascii=False, indent=0, sort_keys=True)
        print('verified.json', len(V))
