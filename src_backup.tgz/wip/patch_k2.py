#!/usr/bin/env python3
"""wip/pwa/index.html に過去問（2次）の画面を入れる。使い方：python3 wip/patch_k2.py <index.html>"""
import sys, os
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
B = os.path.dirname(os.path.abspath(__file__))
block = open(os.path.join(B, 'k2_block.js'), encoding='utf-8').read()

def rep(old, new, cnt=1):
    global s
    n = s.count(old)
    if n != cnt:
        sys.exit('一致が %d か所（%d のはず）：%s' % (n, cnt, old[:80]))
    s = s.replace(old, new)

# 1. タブと、広い画面で問題PDFを並べる所
rep('<button class="tab" type="button" data-act="tab2" data-tab="j4drill"><span class="tab-dot" aria-hidden="true"></span>事例Ⅳドリル</button>\n  </nav>',
    '<button class="tab" type="button" data-act="tab2" data-tab="j4drill"><span class="tab-dot" aria-hidden="true"></span>事例Ⅳドリル</button>\n'
    '    <button class="tab" type="button" data-act="tab2" data-tab="jkako"><span class="tab-dot" aria-hidden="true"></span>過去問</button>\n  </nav>')
rep('<section class="panel" id="sess" aria-label="演習" hidden></section>',
    '<aside id="k2side" aria-label="問題（保存したPDF）"></aside>\n<section class="panel" id="sess" aria-label="演習" hidden></section>')

# 2. 見た目
CSS = r'''
/* 2次の過去問：一覧、80分のタイマー、字数のマス目、自己採点、広い画面の2列（左に保存した問題PDF） */
.k2-years{display:flex;flex-direction:column;gap:18px}
.k2-yr{display:flex;flex-direction:column;gap:8px}
.k2-yr h3{margin:0;font-size:14px;font-weight:700}
.k2-cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
@media (min-width:600px){.k2-cards{grid-template-columns:repeat(4,minmax(0,1fr))}}
.k2-card{appearance:none;display:flex;flex-direction:column;gap:3px;min-width:0;text-align:left;background:var(--sheet);border:1.5px solid var(--guide);border-radius:var(--r);padding:10px 12px;font:inherit;color:var(--ink);cursor:pointer}
.k2-card b{font-size:14px}
.k2-th{font-size:12px;color:var(--ink-2);line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.k2-st{font-size:12px;font-weight:700;color:var(--ink-2);font-variant-numeric:tabular-nums}
.k2-st.run{color:var(--warn)}
.k2-st.done{color:var(--good)}
.k2-card.off{opacity:.5;cursor:default}
.k2-head{gap:10px}
.k2-links{display:flex;flex-wrap:wrap;gap:8px}
.k2-wide-hint{display:none}
@media (min-width:1100px){.k2-wide-hint{display:block}}
.k2-timer{position:sticky;top:-16px;z-index:5;display:flex;align-items:center;gap:8px 12px;flex-wrap:wrap;background:var(--paper);border-bottom:1.5px solid var(--guide);padding-block:10px}
.k2-clock{font-size:28px;font-weight:900;line-height:1;font-variant-numeric:tabular-nums;letter-spacing:-.01em}
.k2-clock.warn{color:var(--warn)}
.k2-clock.over{color:var(--bad)}
.k2-f{gap:6px}
.ex-ta{font-weight:400}
.ex-ta:disabled,.d4-row input:disabled,.d4-row select:disabled{opacity:1;color:var(--ink);-webkit-text-fill-color:var(--ink)}
.k2-grid{display:grid;grid-template-columns:repeat(20,minmax(0,1fr));width:100%;max-width:520px;border-top:1px solid var(--guide);border-left:1px solid var(--guide);background:var(--sheet)}
.k2-grid i{font-style:normal;aspect-ratio:1;display:flex;align-items:center;justify-content:center;border-right:1px solid var(--guide);border-bottom:1px solid var(--guide);font-size:clamp(9px,3vw,14px);line-height:1;font-weight:400;color:var(--ink);overflow:hidden}
.k2-grid i:nth-child(20n+11){border-left:1px solid var(--guide)}
.k2-grid i.ov{background:var(--bad-soft);color:var(--bad)}
.k2-memo summary{cursor:pointer;font-size:13px;font-weight:700;color:var(--ink-2);padding-block:4px}
.k2-memo textarea{margin-top:6px}
.k2-part{display:flex;flex-direction:column;gap:10px;padding-top:10px;border-top:1px dashed var(--guide)}
.k2-sum{display:flex;flex-wrap:wrap;align-items:baseline;gap:4px 10px;font-weight:700}
.k2-sum b{font-size:32px;font-weight:900;line-height:1.1;font-variant-numeric:tabular-nums}
.k2-ai-t{color:var(--good)}
.k2-us{font-size:13px;color:var(--good);font-weight:700;white-space:nowrap}
.k2-pt{display:flex;align-items:flex-start;gap:8px;font-size:14px;line-height:1.6;color:var(--ink);font-weight:400;cursor:pointer}
.k2-pt input{flex:none;width:18px;height:18px;margin-top:3px;accent-color:var(--good)}
.k2-pt em{font-style:normal;font-size:12.5px;color:var(--ink-2);white-space:nowrap}
.k2-pt small{display:block;font-size:12px;color:var(--ink-2)}
.k2-fl{color:var(--ink);font-size:13px}
.k2-sub{display:block;font-size:12px;color:var(--drop);letter-spacing:.06em;margin-top:6px}
.k2-ul{margin:4px 0 0;padding-left:1.2em;font-size:14px;line-height:1.7;display:flex;flex-direction:column;gap:2px}
.k2-p{margin:4px 0 0;font-size:14px;line-height:1.75}
.k2-why{display:flex;flex-direction:column;gap:2px;padding-top:8px;border-top:1px dashed var(--guide)}
.k2-e{border-bottom:0;padding-block:4px 0}
.k2-mx td{text-align:center;color:var(--drop);font-weight:700}
.k2-mx tbody th{white-space:normal;min-width:9em;font-size:12.5px}
.k2-confirm{display:flex;flex-direction:column;gap:8px;padding:12px;border-radius:10px;background:var(--warn-soft)}
#k2side{display:none}
@media (min-width:1100px){
  body.k2w #k2side{display:flex;flex-direction:column;position:fixed;top:0;bottom:0;left:0;width:50vw;border-right:1.5px solid var(--guide);background:var(--paper)}
  body.k2w #app{margin-left:50vw;margin-right:0;width:50vw;max-width:none}
}
.k2-if{flex:1;width:100%;border:0;background:var(--sheet)}
.k2-sbar{flex:none;display:flex;align-items:center;gap:12px;flex-wrap:wrap;padding:8px 16px;border-top:1px solid var(--guide)}
.k2-sbar .fine{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.k2-empty{margin:auto;max-width:440px;padding:24px;display:flex;flex-direction:column;gap:12px}
'''
rep('</style>', CSS + '</style>')

# 3. 記録の初期化
rep("if(!ST2.log)ST2.log={};", "if(!ST2.log)ST2.log={};\nif(!ST2.k2)ST2.k2={};  // 過去問：{[事例id]: {a:{欄:文字}, m:{設問:メモ}, t:{s,e}, done, sc:{観点:1}, ai:{設問:AI採点}, lid, at}}")

# 4. 過去問の関数（事例Ⅳドリルの関数のあと）
rep('function draftOf(st){', block + '\nfunction draftOf(st){')

# 5. 事例Ⅳの欄の描き方を、過去問でも使えるように（欄の印の名前を変えられる）
rep("function d4Field(p,f,v,chk){\n  var k=f.k,id=' data-d4=\"'+esc(p.id)+'\" data-k=\"',h='<div class=\"field d4-f\">';",
    "function d4Field(p,f,v,chk,att){\n  var A=att||'d4',k=f.k,id=' data-'+A+'=\"'+esc(p.id)+'\" data-k=\"',h='<div class=\"field d4-f\">';")
rep("'<button class=\"d4-pm\" type=\"button\" data-act=\"d4-pm\" data-d4p=\"'+esc(p.id)+'\" data-k=\"'+esc(k)+'\"",
    "'<button class=\"d4-pm\" type=\"button\" data-act=\"d4-pm\" data-d4p=\"'+esc(p.id)+'\" data-att=\"'+A+'\" data-k=\"'+esc(k)+'\"")
rep("var pin=document.querySelector('[data-d4=\"'+b.dataset.d4p+'\"][data-k=\"'+b.dataset.k+'\"]');",
    "var pin=document.querySelector('[data-'+(b.dataset.att||'d4')+'=\"'+b.dataset.d4p+'\"][data-k=\"'+b.dataset.k+'\"]');")

# 6. 描画：過去問のタブと、広い画面の左の PDF
rep("function render(){\n  renderHeader();renderNote();renderStage();",
    "function render(){\n  renderHeader();renderNote();renderStage();k2Side();")
rep("""    } else {
      v.innerHTML=DATA2.j4?viewJ4():'<p class="fine">読み込んでいます…</p>';
      if(!DATA2.j4)loadJ4().then(function(){render();});
    }""",
    """    } else if(UI.tab2==='jkako'){
      v.innerHTML=DATA2.k2?viewK2():'<p class="fine">読み込んでいます…</p>';
      if(!DATA2.k2)loadK2().then(function(){render();},function(){v.innerHTML='<p class="err">過去問の一覧を読み込めませんでした。つながる所で開き直してください</p>';});
    } else {
      v.innerHTML=DATA2.j4?viewJ4():'<p class="fine">読み込んでいます…</p>';
      if(!DATA2.j4)loadJ4().then(function(){render();});
    }""")

# 7. テキストの本文：「【2次】<節のid>|<見出し>」は2次のテキストの節を開くボタン
rep("""    buf.push(l.replace(/^- /,'・'));""",
    """    var m2=l.trim().match(/^【2次】([a-z0-9_.]+)\\|(.+)$/);
    if(m2){flush();out.push(jtHas(m2[1])?'<button class="tx-link" type="button" data-act="k2-jt" data-sec="'+esc(m2[1])+'">2次テキスト：'+esc(m2[2])+'</button>':'<p class="fine">2次テキスト：'+esc(m2[2])+'</p>');return;}
    buf.push(l.replace(/^- /,'・'));""")
rep("function viewJText(){",
    "function jtHas(id){var f=false;J_TEXT_FILES.forEach(function(k){var d=DATA2.text[k];if(d)d.chapters.forEach(function(c){c.sections.forEach(function(x){if(x.id===id)f=true;});});});return f;}\nfunction viewJText(){")
rep("""      h+='<section class="sec"><div class="sec-h"><span>'+esc(found.ch.title)+'</span></div>';
      h+='<div class="sheet"><div class="tx-sec">""",
    """      h+='<section class="sec"><div class="sec-h"><span>'+esc(found.ch.title)+'</span></div>';
      if(UI.jtFrom)h+='<button class="linkbtn back" type="button" data-act="jt-ret">← 過去問に戻る</button>';
      h+='<div class="sheet"><div class="tx-sec">""")

# 8. 操作
rep("case 'tab2':UI.tab2=b.dataset.tab;UI.jtSec=null;$('#main').scrollTop=0;render();break;",
    "case 'tab2':UI.tab2=b.dataset.tab;UI.jtSec=null;UI.jtFrom=null;$('#main').scrollTop=0;render();break;")
rep("""    case 'jt-1ji':openText(b.dataset.s,null,b.dataset.sec,2);break;   // 2次のテキストから、1次のテキストの節を開く""",
    """    case 'jt-1ji':openText(b.dataset.s,null,b.dataset.sec,2);break;   // 2次のテキストから、1次のテキストの節を開く
    case 'k2-jt':if(UI.tab2==='jkako')UI.jtFrom={tab:'jkako',top:$('#main').scrollTop};UI.tab2='jtext';UI.jtSec=b.dataset.sec;$('#main').scrollTop=0;render();break;   // 解説から2次のテキストの節を開く
    case 'jt-ret':{var jf=UI.jtFrom;UI.jtFrom=null;UI.jtSec=null;UI.tab2=(jf&&jf.tab)||'jtext';render();$('#main').scrollTop=(jf&&jf.top)||0;break;}
    /* 過去問 */
    case 'k2-open':k2Open(b.dataset.id);break;
    case 'k2-back':UI.k2Id=null;UI.k2Confirm=false;$('#main').scrollTop=0;render();break;
    case 'k2-start':{var kr=k2Rec(UI.k2Id);if(!kr.t.s){kr.t.s=Date.now();kr.at=Date.now();save2();}render();break;}
    case 'k2-pause':{var kr=k2Rec(UI.k2Id);k2Stop(kr);kr.at=Date.now();save2();render();break;}
    case 'k2-done':{
      var km=DATA2.k2&&DATA2.k2.by[UI.k2Id];if(!km)break;
      var kr=k2Rec(km.id),kn=Date.now();k2Stop(kr);kr.done=kn;kr.at=kn;
      var klid=kr.lid&&ST2.log[kr.lid]?kr.lid:uid('k2');   // 直してからもう一度「解き終えた」なら、同じ回の記録を書き換える
      ST2.log[klid]=Object.assign(ST2.log[klid]||{},{k:'k2',p:km.id,at:kn,sec:Math.round(k2Ms(kr)/1000)});kr.lid=klid;k2Log(km.id);
      save2();$('#main').scrollTop=0;render();break;
    }
    case 'k2-redo':{var kr=k2Rec(UI.k2Id);kr.done=0;kr.at=Date.now();UI.k2Confirm=false;save2();$('#main').scrollTop=0;render();break;}
    case 'k2-new':UI.k2Confirm=true;render();break;
    case 'k2-new-no':UI.k2Confirm=false;render();break;
    case 'k2-new-yes':{   // 今の答えは記録（ST2.log）に残し、白紙から解き直す
      var kid=UI.k2Id,kr=k2Rec(kid);
      if(kr.lid&&ST2.log[kr.lid])ST2.log[kr.lid].a=JSON.parse(JSON.stringify(kr.a));
      ST2.k2[kid]={a:{},m:{},t:{s:0,e:0},done:0,sc:{},ai:{},at:Date.now()};UI.k2Confirm=false;
      save2();$('#main').scrollTop=0;render();break;
    }
    case 'k2-sc':{var kr=k2Rec(b.dataset.id);if(b.checked)kr.sc[b.dataset.key]=1;else delete kr.sc[b.dataset.key];kr.at=Date.now();k2Log(b.dataset.id);save2();schedRender();break;}
    case 'k2-ai':{
      var am=DATA2.k2&&DATA2.k2.by[UI.k2Id],ac=am&&DATA2.k2c&&DATA2.k2c[am.id];if(!ac||!AI_KEY||am.j>3)break;
      var ar=k2Rec(am.id),AU=k2Units(am,ac).filter(function(u){return !ar.ai[u.k]&&!UI.k2Grading[am.id+'/'+u.k]&&u.f.some(function(f){return ar.a[f.key];});});
      if(!AU.length){toast('採点する答えがありません（採点済みか、まだ書いていない）');break;}
      AU.forEach(function(u){UI.k2Grading[am.id+'/'+u.k]=true;});
      // 1問ずつ順に送る（同時に送ると、利用の上限に当たりやすい）
      AU.reduce(function(pr,u){return pr.then(function(){
        var gk=am.id+'/'+u.k,rr=k2Rec(am.id);
        return aiMessage(k2AiPrompt(am,ac,u,rr)).then(function(txt){var g=k2ParseAi(txt,u,rr);rr.ai[u.k]=g;rr.at=Date.now();k2Log(am.id);save2();})
          .catch(function(e){toast('採点できませんでした：'+((e&&e.message)||e));})
          .then(function(){delete UI.k2Grading[gk];schedRender();});
      });},Promise.resolve());
      render();break;
    }
    case 'k2-pdf-del':{var pid=UI.k2Id;if(pid){k2PdfDel(pid);k2PdfShow(pid,null);}break;}""")
rep("""  if(t.id==='importFile'){if(t.files&&t.files[0])onImportFile(t.files[0]);t.value='';return;}""",
    """  if(t.id==='importFile'){if(t.files&&t.files[0])onImportFile(t.files[0]);t.value='';return;}
  if(t.classList&&t.classList.contains('k2pdf')){   // 過去問：保存した問題PDFを左に並べる（この端末の中だけ）
    var kf=t.files&&t.files[0],kfid=UI.k2Id;t.value='';
    if(kf&&kfid){if(!/pdf$/i.test(kf.type||'')&&!/\\.pdf$/i.test(kf.name||'')){toast('PDFのファイルを選んでください');return;}k2PdfPut(kfid,kf).catch(function(){});k2PdfShow(kfid,{name:kf.name,blob:kf});}
    return;
  }""")
rep("""  // 事例Ⅳドリル（本番形式）の入力の保存。""",
    """  // 過去問の答えとメモの保存。記述の欄は改行を入れず、字数とマス目をその場で直す。答えを書き直したら、その設問のAI採点は消す
  if(t.dataset&&t.dataset.k2){
    var kid2=t.dataset.k2,kk=t.dataset.k,kr2=k2Rec(kid2);
    if(t.dataset.memo){kr2.m[kk]=t.value;kr2.at=Date.now();save2();return;}
    var kv=t.value;
    if(t.dataset.grid&&/[\\r\\n]/.test(kv)){var kpos=(t.selectionStart||0),kbef=kv.slice(0,kpos).replace(/[\\r\\n]/g,'');kv=kv.replace(/[\\r\\n]/g,'');t.value=kv;try{t.setSelectionRange(kbef.length,kbef.length);}catch(e){}}
    kr2.a[kk]=kv;kr2.at=Date.now();
    if(t.dataset.u&&kr2.ai[t.dataset.u])delete kr2.ai[t.dataset.u];
    save2();
    if(t.dataset.grid){var kl=+t.dataset.grid,kb=t.parentElement,kn2=k2Len(kv),kc=kb&&kb.querySelector('.ex-count'),kg=kb&&kb.querySelector('.k2-grid');if(kc){kc.textContent=kn2+' / '+kl+'字';kc.classList.toggle('over',kn2>kl);}if(kg)kg.outerHTML=k2Grid(kv,kl);}
    if(t.tagName==='SELECT'&&/_n$/.test(kk)){var kdu=t.parentElement&&t.parentElement.querySelector('.d4-u');if(kdu)kdu.textContent=t.value?d4Unit(t.value):'';}
    return;
  }
  // 事例Ⅳドリル（本番形式）の入力の保存。""")
rep("""  if(UI.d4t0&&!UI.d4chk){var dck=document.getElementById('d4clock');if(dck)dck.textContent=fmtClock(Date.now()-UI.d4t0);}""",
    """  if(UI.d4t0&&!UI.d4chk){var dck=document.getElementById('d4clock');if(dck)dck.textContent=fmtClock(Date.now()-UI.d4t0);}
  if(UI.k2Id&&UI.stage==='s2'&&UI.tab2==='jkako'){var kck=document.getElementById('k2clock'),kcr=ST2.k2[UI.k2Id];if(kck&&kcr){var kms=k2Ms(kcr);kck.textContent=k2Clock(kcr);kck.classList.toggle('over',kms>K2MIN*60000);kck.classList.toggle('warn',kms<=K2MIN*60000&&kms>(K2MIN-10)*60000);
    UI.k2Alert=UI.k2Alert||{};if(kcr.t.s&&kms>=K2MIN*60000&&!UI.k2Alert[UI.k2Id]){UI.k2Alert[UI.k2Id]=1;toast('80分が経ちました（本試験ならここで終わり）');}}}""")

# 9. 同期：過去問の記録も合わせる（事例ごとに新しいほう）
rep("function sync2Part(S){S=S||{};return JSON.parse(JSON.stringify({ex:S.ex||{},dr:S.dr||{},log:S.log||{},j4:S.j4||{}}));}",
    "function sync2Part(S){S=S||{};return JSON.parse(JSON.stringify({ex:S.ex||{},dr:S.dr||{},log:S.log||{},j4:S.j4||{},k2:S.k2||{}}));}")
rep("  var o={ex:{},dr:{},log:{},j4:{}};",
    "  var o={ex:{},dr:{},log:{},j4:{},k2:{}};\n  Object.keys(L.k2).concat(Object.keys(R.k2)).forEach(function(c){o.k2[c]=newer(L.k2[c],R.k2[c]);});")
rep("function put2(mg){ST2.ex=mg.ex||{};ST2.dr=mg.dr||{};ST2.log=mg.log||{};ST2.j4=mg.j4||{};}",
    "function put2(mg){ST2.ex=mg.ex||{};ST2.dr=mg.dr||{};ST2.log=mg.log||{};ST2.j4=mg.j4||{};ST2.k2=mg.k2||{};}")

# 10. UI の初期値
rep("jtSec:null,exId:null,", "jtSec:null,jtFrom:null,k2Id:null,k2Pdf:null,k2Grading:{},k2Confirm:false,exId:null,")

open(p, 'w', encoding='utf-8').write(s)
print('当てた：', p)
