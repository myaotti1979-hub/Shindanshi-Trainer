// 2次の過去問の画面を確かめる（一覧、解く画面、見直し、AI採点〔偽の API〕、事例Ⅳ、広い画面の2列、明暗、はみ出し、記録の残り方、同期の合わせ方）
// 使い方：node t_k2.js <pwa のフォルダ> [撮った画面の置き場所]   （DRAFT=1 でビルドした写しの pwa を渡す。k2-r06-1 と k2-r06-4 の中身が要る）
const http = require('http'), fs = require('fs'), path = require('path'), assert = require('assert');
const [, , PWA, OUTD] = process.argv;
const ROOT = path.resolve(PWA), OUT = path.resolve(OUTD || path.join(ROOT, '..', 'shots_k2'));
fs.mkdirSync(OUT, { recursive: true });
const srv = http.createServer((q, r) => {
  const u = decodeURIComponent(q.url.split('?')[0]), f = path.join(ROOT, u === '/' ? 'index.html' : u);
  if (!f.startsWith(ROOT)) { r.writeHead(403); return r.end(); }
  try { const d = fs.readFileSync(f); const t = f.endsWith('.json') ? 'application/json' : f.endsWith('.js') ? 'text/javascript' : f.endsWith('.png') ? 'image/png' : f.endsWith('.pdf') ? 'application/pdf' : 'text/html'; r.writeHead(200, { 'Content-Type': t + '; charset=utf-8' }); r.end(d); }
  catch (e) { r.writeHead(404); r.end('nf'); }
});
// 小さな PDF（1ページ。広い画面の左に並べる確かめ用）
const PDF = '%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 300 200]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n';
const PDFF = path.join(OUT, 'test.pdf'); fs.writeFileSync(PDFF, PDF);
const AI = { pts: [{ i: 1, got: 5, why: '強みの要素1あり' }, { i: 2, got: 3, why: '一部' }, { i: 3, got: 0, why: 'なし' }, { i: 4, got: 5, why: 'あり' }], feedback: '強みは書けている。弱みは与件の根拠を足す。' };
const out = { checks: [], errors: [] };
function ok(name, cond, info) { out.checks.push({ name, ok: !!cond, info }); }

srv.listen(0, '127.0.0.1', async () => {
  const URL0 = 'http://127.0.0.1:' + srv.address().port + '/';
  const { chromium } = require('playwright');
  const b = await chromium.launch();
  async function open(o) {
    const ctx = await b.newContext({ viewport: o.vp || { width: 390, height: 844 }, colorScheme: o.dark ? 'dark' : 'light', serviceWorkers: 'block' });
    await ctx.addInitScript((k) => { try { localStorage.setItem('shindan1-stage', 's2'); if (k) localStorage.setItem('shindan2-aikey', 'sk-ant-test'); } catch (e) {} }, !!o.key);
    const p = await ctx.newPage();
    p.on('pageerror', e => out.errors.push((o.name || '') + ': ' + e.message));
    p.__ai = [];
    await p.route('https://api.anthropic.com/**', async (route) => {
      const req = route.request(), body = req.postData() ? JSON.parse(req.postData()) : null;
      p.__ai.push(body);
      await route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify({ content: [{ type: 'thinking', thinking: '', signature: 's' }, { type: 'text', text: JSON.stringify(AI) }], stop_reason: 'end_turn' }) });
    });
    await p.goto(URL0); await p.waitForTimeout(900);
    await p.click('[data-tab="jkako"]'); await p.waitForTimeout(500);
    return { p, ctx };
  }
  const over = (p) => p.evaluate(() => Math.max(document.documentElement.scrollWidth, document.getElementById('main').scrollWidth) > window.innerWidth + 1);
  async function shot(p, name) {
    const h = await p.evaluate(() => document.getElementById('main').scrollHeight + 260);
    const vp = p.viewportSize();
    await p.setViewportSize({ width: vp.width, height: Math.min(h, 12000) }); await p.waitForTimeout(150);
    await p.screenshot({ path: path.join(OUT, name + '.png') });
    await p.setViewportSize(vp);
  }

  // 1. 一覧（明暗）
  for (const dark of [false, true]) {
    const { p, ctx } = await open({ dark, name: 'list' + (dark ? '-dark' : '') });
    const n = await p.locator('.k2-card').count();
    ok('一覧に24事例', n === 24, n);
    ok('事例Ⅳの中身のない事例は押せない', await p.locator('.k2-card.off').count() === 5, await p.locator('.k2-card.off').count());
    ok('一覧ではみ出さない' + (dark ? '（暗）' : ''), !(await over(p)));
    await shot(p, 'list' + (dark ? '_dark' : ''));
    await ctx.close();
  }

  // 2. 事例Ⅰ：解く → 見直し → 自己採点 → AI採点 → 2次のテキストへ行って戻る → 読み込み直しても残る
  {
    const { p, ctx } = await open({ key: true, name: 'r06-1' });
    await p.click('[data-act="k2-open"][data-id="k2-r06-1"]'); await p.waitForTimeout(600);
    ok('解く画面：欄が6つ', await p.locator('textarea[data-grid]').count() === 6, await p.locator('textarea[data-grid]').count());
    ok('解く画面：出題の趣旨のリンクはまだ出さない', await p.locator('a[href*="shushi"]').count() === 0);
    ok('タイマーは80:00', (await p.textContent('#k2clock')).trim() === '80:00', await p.textContent('#k2clock'));
    await p.click('[data-act="k2-start"]'); await p.waitForTimeout(1300);
    const c1 = (await p.textContent('#k2clock')).trim();
    ok('タイマーが進む', c1 !== '80:00', c1);
    const ta = p.locator('textarea[data-grid]');
    await ta.nth(0).fill('高い技術力と地域の顧客との長い取引関係がある。');
    await ta.nth(1).fill('権限が社長に集中し、若手が育たず、意思決定が遅れがちである。さらに長く書いて字数を超える。');
    await ta.nth(2).fill('改行を\n入れても\n消える');
    const v2 = await ta.nth(2).inputValue();
    ok('記述の欄に改行が入らない', !/\n/.test(v2), v2);
    const cnt = await p.locator('.k2-f').nth(1).locator('.ex-count').textContent();
    ok('字数を超えると赤（数え）', /over/.test(await p.locator('.k2-f').nth(1).locator('.ex-count').getAttribute('class')), cnt);
    ok('マス目：超えた分が赤', await p.locator('.k2-f').nth(1).locator('.k2-grid i.ov').count() > 0);
    ok('マス目：30字の欄は30マス＋超過', await p.locator('.k2-f').nth(0).locator('.k2-grid i').count() === 30, await p.locator('.k2-f').nth(0).locator('.k2-grid i').count());
    await p.click('.k2-memo >> nth=0 >> summary');
    await p.fill('textarea[data-memo]:visible >> nth=0', '骨子：強み＝技術、関係。弱み＝権限集中');
    ok('解く画面ではみ出さない', !(await over(p)));
    await shot(p, 'r06-1_solve');
    // 読み込み直しても、答えと時間が残る
    await p.reload(); await p.waitForTimeout(900);
    await p.click('[data-tab="jkako"]'); await p.waitForTimeout(300);
    const st = await p.textContent('[data-id="k2-r06-1"] .k2-st');
    ok('一覧の状態が「解答中」', /解答中/.test(st), st);
    await p.click('[data-act="k2-open"][data-id="k2-r06-1"]'); await p.waitForTimeout(600);
    ok('読み込み直しても答えが残る', (await p.locator('textarea[data-grid]').nth(0).inputValue()).startsWith('高い技術力'));
    await p.click('[data-act="k2-done"]'); await p.waitForTimeout(400);
    ok('見直し：出題の趣旨のリンクが出る', await p.locator('a[href*="shushi"]').count() === 1);
    ok('見直し：解答例', await p.locator('.ex-model').count() >= 5, await p.locator('.ex-model').count());
    ok('見直し：対応表', await p.locator('.k2-mx tbody tr').count() === 7);
    // 観点をチェック → 点（字数を超えた弱みの欄の観点は数えない）
    await p.locator('#k2u-q1 input[type=checkbox]').nth(0).check(); await p.waitForTimeout(150);
    await p.locator('#k2u-q1 input[type=checkbox]').nth(2).check(); await p.waitForTimeout(150);
    const us = await p.textContent('#k2u-q1 .k2-us');
    ok('自己採点：字数を超えた欄の観点は数えない（5点）', /自己採点 5点/.test(us), us);
    const tot = await p.textContent('.k2-sum b');
    ok('合計の自己採点', tot.trim() === '5', tot);
    // AI採点（偽の API）
    await p.click('[data-act="k2-ai"]'); await p.waitForTimeout(1500);
    ok('AI採点：設問ごとに1回ずつ API を呼ぶ（答えのある設問だけ＝2問）', p.__ai.length === 2, p.__ai.length);
    const pr = p.__ai[0] && p.__ai[0].messages[0].content;
    ok('AI採点：観点・解答例・受験者の解答・字数超過を渡す', pr && /採点の観点/.test(pr) && /解答例/.test(pr) && /字数超過/.test(pr), (pr || '').slice(0, 80));
    const ai = await p.textContent('#k2u-q1 .ex-ai');
    ok('AI採点：字数を超えた欄の観点は0点（5+3+0+0＝8）', /AI採点 8 \/ 20点/.test(ai), ai.slice(0, 40));
    await shot(p, 'r06-1_review');
    // 2次のテキストへ → 過去問に戻る
    const lk = p.locator('#k2u-q1 [data-act="k2-jt"]');
    ok('解説から2次のテキストへのボタン', await lk.count() === 1);
    await lk.click(); await p.waitForTimeout(400);
    ok('2次のテキストの節が開く', await p.locator('[data-act="jt-ret"]').count() === 1);
    await p.click('[data-act="jt-ret"]'); await p.waitForTimeout(400);
    ok('過去問の見直しに戻る', await p.locator('#k2u-q1').count() === 1);
    // 直してからもう一度「解き終えた」：同じ回の記録を書き換える（記録は増えない）
    await p.click('[data-act="k2-redo"]'); await p.waitForTimeout(300);
    ok('答えを直す：解く画面に戻り、答えが残る', (await p.locator('textarea[data-grid]').nth(0).inputValue()).startsWith('高い技術力'));
    await p.click('[data-act="k2-done"]'); await p.waitForTimeout(300);
    ok('もう一度「解き終えた」でも記録は1つ', (await p.evaluate(() => Object.values(JSON.parse(localStorage.getItem('shindan2')).log).filter(l => l.k === 'k2').length)) === 1);
    // 白紙から解き直す（確かめを挟む）
    await p.click('[data-act="k2-new"]'); await p.waitForTimeout(200);
    ok('白紙の前に確かめる', await p.locator('[data-act="k2-new-yes"]').count() === 1);
    await p.click('[data-act="k2-new-yes"]'); await p.waitForTimeout(300);
    ok('白紙になる', (await p.locator('textarea[data-grid]').nth(0).inputValue()) === '');
    const logs = await p.evaluate(() => Object.values(JSON.parse(localStorage.getItem('shindan2')).log).filter(l => l.k === 'k2'));
    ok('記録に前の答えと点が残る', logs.length === 1 && logs[0].self === 5 && logs[0].ai === undefined && logs[0].a && logs[0].a['1-0'], JSON.stringify(logs[0]).slice(0, 120));
    await ctx.close();
  }

  // 3. 事例Ⅳ：数値・指標・選択・記述
  for (const dark of [false, true]) {
    const { p, ctx } = await open({ dark, name: 'r06-4' });
    await p.click('[data-act="k2-open"][data-id="k2-r06-4"]'); await p.waitForTimeout(700);
    await p.selectOption('select[data-k2="k2-r06-4"][data-k="i1_n"]', '有形固定資産回転率');
    await p.fill('input[data-k2="k2-r06-4"][data-k="i1_v"]', '1.85');
    await p.selectOption('select[data-k2="k2-r06-4"][data-k="i2_n"]', '売上高経常利益率');
    await p.fill('input[data-k2="k2-r06-4"][data-k="i2_v"]', '2.10');
    await p.selectOption('select[data-k2="k2-r06-4"][data-k="i3_n"]', '自己資本比率');
    await p.fill('input[data-k2="k2-r06-4"][data-k="i3_v"]', '45.2');
    await p.fill('input[data-k2="k2-r06-4"][data-k="n1"]', '960');
    await p.fill('input[data-k2="k2-r06-4"][data-k="n2"]', '1234');
    await p.click('[data-act="d4-pm"][data-k="n2"]');
    ok('± で符号が付く（過去問の欄でも）', (await p.inputValue('input[data-k2="k2-r06-4"][data-k="n2"]')) === '-1234');
    await p.selectOption('select[data-k2="k2-r06-4"][data-k="c1"]', '投資しない');
    await p.fill('textarea[data-k2="k2-r06-4"][data-k="t1"]', '収益性は低いが、安全性は高い。');
    ok('事例Ⅳの解く画面ではみ出さない' + (dark ? '（暗）' : ''), !(await over(p)));
    if (!dark) await shot(p, 'r06-4_solve');
    await p.click('[data-act="k2-done"]'); await p.waitForTimeout(400);
    const ng = await p.locator('.d4-mk.ng').count(), okk = await p.locator('.d4-mk.ok').count();
    ok('事例Ⅳの答え合わせ：6欄すべて正解（指標は順を問わない）', okk === 6 && ng === 0, okk + ' / ' + ng);
    await p.locator('#k2u-q1 input[type=checkbox]').nth(0).check(); await p.waitForTimeout(150);
    const us = await p.textContent('#k2u-q1 .k2-us');
    ok('事例Ⅳの自己採点：設問1 15点＋設問2 10×1/3≒3 → 18点', /自己採点 18点/.test(us), us);
    ok('事例Ⅳの見直しではみ出さない' + (dark ? '（暗）' : ''), !(await over(p)));
    await shot(p, 'r06-4_review' + (dark ? '_dark' : ''));
    await ctx.close();
  }

  // 4. 広い画面：左に保存した PDF を並べる
  {
    const { p, ctx } = await open({ vp: { width: 1280, height: 860 }, name: 'wide' });
    await p.click('[data-act="k2-open"][data-id="k2-r06-1"]'); await p.waitForTimeout(600);
    ok('広い画面：左の欄が出る', await p.evaluate(() => document.body.classList.contains('k2w') && getComputedStyle(document.getElementById('k2side')).display !== 'none'));
    await p.setInputFiles('#k2side input.k2pdf', PDFF); await p.waitForTimeout(800);
    ok('広い画面：PDF を選ぶと左に出る', await p.locator('#k2side iframe').count() === 1);
    await p.locator('textarea[data-grid]').nth(0).fill('左にPDFを置いたまま書く');
    await p.click('[data-act="k2-start"]'); await p.waitForTimeout(300);
    const src1 = await p.getAttribute('#k2side iframe', 'src');
    await p.click('[data-act="k2-pause"]'); await p.waitForTimeout(300);
    ok('描き直しても左の PDF は読み込み直さない', (await p.getAttribute('#k2side iframe', 'src')) === src1 && await p.evaluate(() => !!document.querySelector('#k2side iframe')));
    await p.screenshot({ path: path.join(OUT, 'wide.png') });
    // 一覧に戻ると左の欄は消える。もう一度開くと、覚えた PDF が出る
    await p.click('[data-act="k2-back"]'); await p.waitForTimeout(300);
    ok('一覧に戻ると左の欄は消える', !(await p.evaluate(() => document.body.classList.contains('k2w'))));
    await p.click('[data-act="k2-open"][data-id="k2-r06-1"]'); await p.waitForTimeout(800);
    ok('もう一度開くと、覚えた PDF が出る', await p.locator('#k2side iframe').count() === 1);
    await ctx.close();
  }

  // 5. 同期の合わせ方：事例ごとに新しいほう（index.html から sync2Part と merge2 を取り出して確かめる）
  {
    const h = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
    const f1 = h.match(/function sync2Part\(S\)\{[^\n]*\n/)[0], f2 = h.match(/function merge2\(L,R\)\{[\s\S]*?\n\}\n/)[0];
    const merge2 = new Function(f1 + f2 + 'return merge2;')();
    const L = { k2: { a: { a: { '1-0': '古い' }, at: 1 }, b: { a: { '1-0': 'L' }, at: 5 } } }, R = { k2: { a: { a: { '1-0': '新しい' }, at: 2 }, c: { a: {}, at: 3 } } };
    const m = merge2(L, R), r = [m.k2.a.a['1-0'], m.k2.b.a['1-0'], !!m.k2.c];
    ok('同期：事例ごとに新しいほうを残す', r[0] === '新しい' && r[1] === 'L' && r[2], r);
  }
  await b.close(); srv.close();
  const bad = out.checks.filter(c => !c.ok);
  console.log(JSON.stringify({ out: OUT, n: out.checks.length, bad, errors: out.errors }, null, 1));
  process.exit(bad.length || out.errors.length ? 1 : 0);
});
