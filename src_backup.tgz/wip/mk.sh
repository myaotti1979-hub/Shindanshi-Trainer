#!/bin/sh
# 作業中の過去問の画面を、本物の pwa・niji・text の写しに当てて作る
#   mk.sh        → wip（作る担当・検証の担当が写しの元に使う。本物の niji/src/kako の事例を入れる）
#   mk.sh test   → wip/t（画面の試験用。testcases の偽の事例を入れる。node t_k2.js wip/t/pwa で確かめる）
set -e
S=/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad
W=$S/wip
D=$W; [ "$1" = "test" ] && D=$W/t
mkdir -p "$D"
for d in pwa niji text; do rm -rf "$D/$d"; cp -r "$S/$d" "$D/$d"; done
# 本物の pwa に過去問の画面が入ったあと（v64〜）は、当てずにそのまま使う
grep -q "function viewK2" "$D/pwa/index.html" || python3 "$W/patch_k2.py" "$D/pwa/index.html"
grep -q "'data/k2.json'" "$D/pwa/sw.js" || sed -i "s#'data/j_exercise.json'\$#'data/j_exercise.json', 'data/k2.json'#" "$D/pwa/sw.js"
grep -q "'data/k2.json'" "$D/pwa/sw.js" || { echo 'sw.js に k2.json を入れられない'; exit 1; }
if [ "$1" = "test" ]; then rm -f "$D/niji/src/kako/"k2_*.py; cp "$W/testcases/"k2_r06_*.py "$D/niji/src/kako/"; fi
cd "$D" && DRAFT=1 python3 niji/build.py | grep -E "過去問|書き出し先" || true
