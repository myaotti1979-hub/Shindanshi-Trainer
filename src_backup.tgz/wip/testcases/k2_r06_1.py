# 画面の確かめ用（公開しない。wip の中だけ）
A30 = '試験用の解答例の文で、三十字に近い長さにした文章です。'
A100 = ('画面の確かめのための解答例である。与件の根拠を使い、因果で書く形を想定し、'
        '字数の八割から十割に収まるように長さを合わせた。マス目に収まるかを確かめる。')
C = dict(
  id='k2-r06-1', y=6, j=1, theme='テスト用の事例（画面の確かめ）',
  gist=['創業と沿革', '主力の製品と顧客', '組織の体制', '事業承継', '新しい事業', '人材の採用と育成', '今後の方針'],
  lesson=['設問の条件を落とさない', '時制（過去・現在・今後）を分ける'],
  qs=[
    dict(k='q1', h='第1問', dai=1, pts=20, ask='テスト：強みと弱みを、それぞれ30字以内で',
         fields=[dict(k='a', label='強み', limit=30), dict(k='b', label='弱み', limit=30)],
         model=dict(a=A30, b=A30),
         points=[dict(f='a', t='強みの要素1', w=5), dict(f='a', t='強みの要素2', w=5), dict(f='b', t='弱みの要素1', w=5), dict(f='b', t='弱みの要素2', w=5)],
         basis=[[1, '創業期の技術'], [3, '組織の偏り']], shushi='テスト：趣旨の要約', e='\n'.join(['**題意**', '・テストの解説。', '【ひっかけ注意】テスト', '【2次】j1.over.pattern|設問の型と頻度', '【1次】kigyo.1.2.1|テスト'])),
    dict(k='q2', h='第2問', dai=2, pts=20, ask='テスト：第2問の要約', fields=[dict(k='a', label='解答', limit=100)],
         model=dict(a=A100), points=[dict(f='a', t='要素1', w=10), dict(f='a', t='要素2', w=10)], basis=[[2, '要点']], shushi='趣旨', e='解説'),
    dict(k='q3', h='第3問', dai=3, pts=20, ask='テスト：第3問の要約', fields=[dict(k='a', label='解答', limit=100)],
         model=dict(a=A100), points=[dict(f='a', t='要素1', w=10), dict(f='a', t='要素2', w=10)], basis=[[4, '要点'], [5, '要点']], shushi='趣旨', e='解説'),
    dict(k='q4a', h='第4問（設問1）', dai=4, pts=20, ask='テスト：設問1の要約', fields=[dict(k='a', label='解答', limit=80)],
         model=dict(a=A100[:78]), points=[dict(f='a', t='要素1', w=20)], basis=[[6, '要点']], shushi='趣旨', e='解説'),
    dict(k='q4b', h='第4問（設問2）', dai=4, pts=20, ask='テスト：設問2の要約', fields=[dict(k='a', label='解答', limit=100)],
         model=dict(a=A100), points=[dict(f='a', t='要素1', w=10), dict(f='a', t='要素2', w=10)], basis=[[7, '要点']], shushi='趣旨', e='解説'),
  ],
)
