# 画面の確かめ用（公開しない。wip の中だけ）
T80 = '試験用の記述の解答例。財務の特徴を、収益性と効率性と安全性の観点から書いた形にして、字数の八割を超える長さにした文章である。'
C = dict(
  id='k2-r06-4', y=6, j=4, theme='テスト用の事例Ⅳ（画面の確かめ）',
  gist=['事業の概要', '財務諸表', '新しい投資', '事業部の評価'],
  lesson=['端数の処理を問題の指示どおりに'],
  qs=[
    dict(k='q1', h='第1問', dai=1, pts=25, ask='テスト：経営分析', basis=[[2, '財務諸表']], shushi='趣旨', e='解説\n【2次】j4.anal.mgmt|経営分析',
         parts=[
           dict(h='設問1', pts=15, q='テスト：課題2つと優れている1つ（小数第3位を四捨五入）',
                fields=[dict(k='i1', type='ind', label='課題①', grp='課題', dp=2, accept={'売上高営業利益率': dict(v=2.5, u='%'), '売上高経常利益率': dict(v=2.1, u='%')}),
                        dict(k='i2', type='ind', label='課題②', grp='課題', dp=2, accept={'有形固定資産回転率': dict(v=1.85, u='回')}),
                        dict(k='i3', type='ind', label='優れている指標', dp=2, accept={'自己資本比率': dict(v=45.2, u='%')})],
                steps=['テストの手順1', 'テストの手順2']),
           dict(h='設問2', pts=10, q='テスト：特徴を80字以内で', fields=[dict(k='t1', type='text', label='解答', limit=80, model=T80[:78], points=['収益性', '効率性', '安全性'])]),
         ]),
    dict(k='q2', h='第2問', dai=2, pts=20, ask='テスト：CVP', basis=[[2, '要点']], shushi='趣旨', e='解説',
         parts=[dict(h='設問1', q='テスト：損益分岐点売上高（百万円未満を四捨五入）',
                     fields=[dict(k='n1', type='num', label='損益分岐点売上高', unit='百万円', dp=0, ans=960), dict(k='p1', type='proc', label='計算過程')],
                     steps=['変動費率＝0.6', '960百万円'])],
         ce={'n1': 'よくある誤り：テスト'}),
    dict(k='q3', h='第3問', dai=3, pts=30, ask='テスト：投資', basis=[[3, '要点']], shushi='趣旨', e='解説',
         parts=[dict(h='設問1', q='テスト：NPV（千円未満を四捨五入）', fields=[dict(k='n2', type='num', label='NPV', unit='千円', dp=0, ans=-1234)], steps=['テスト']),
                dict(h='設問2', q='テスト：80字', fields=[dict(k='t2', type='text', label='解答', limit=80, model=T80[:76], points=['要素A', '要素B'])])]),
    dict(k='q4', h='第4問', dai=4, pts=25, ask='テスト：評価', basis=[[4, '要点']], shushi='趣旨', e='解説',
         parts=[dict(h='設問1', q='テスト：60字', fields=[dict(k='t3', type='text', label='解答', limit=60, model=T80[:55], points=['要素C', '要素D'])]),
                dict(h='設問2', q='テスト：選ぶ', fields=[dict(k='c1', type='choice', label='判断', opts=['投資する', '投資しない'], ans='投資しない')], steps=['テスト'])]),
  ],
)
