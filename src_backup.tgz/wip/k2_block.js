/* ---------- 2次の過去問（令和元〜6年度の24事例） ----------
   与件と設問は協会の問題PDFで読む（アプリには載せない）。アプリでは80分を計り、解答欄（字数のマス目）に書く。
   解き終えたら、解答例・解説・採点の観点（このアプリが作ったもの。検証済みの事例だけ）で見直し、自己採点か AI 採点で点の目安を出す。
   記録：ST2.k2[事例id] = {a:{欄:文字}, m:{設問:メモ}, t:{s:計り始めた時刻（0＝止めている）, e:それまでの経過ms}, done:解き終えた時刻（0＝途中）,
          sc:{観点:1}（自己採点のチェック）, ai:{設問:AI採点}, lid:記録（ST2.log）のid, at:書いた時刻}
   欄のキー：事例Ⅰ〜Ⅲは「大問-その大問の中の欄の番号」（例 '4-1'）。解答例のない事例でも同じキーで書け、あとで解答例が載っても答えが残る。事例Ⅳは欄の k */
var K2J={1:'事例Ⅰ',2:'事例Ⅱ',3:'事例Ⅲ',4:'事例Ⅳ'},K2JN={1:'組織・人事',2:'マーケティング・流通',3:'生産・技術',4:'財務・会計'},K2MIN=80;
function loadK2(){
  if(DATA2.k2)return Promise.resolve();
  return fetch('data/k2.json').then(function(r){return r.json();}).then(function(j){var by={};(j.cases||[]).forEach(function(c){by[c.id]=c;});DATA2.k2={cases:j.cases||[],by:by};});
}
function loadK2C(id){
  DATA2.k2c=DATA2.k2c||{};
  if(DATA2.k2c[id])return Promise.resolve(DATA2.k2c[id]);
  return fetch('data/'+id+'.json').then(function(r){if(!r.ok)throw new Error('nf');return r.json();}).then(function(j){DATA2.k2c[id]=j;return j;});
}
function k2Len(s){return Array.from(String(s||'')).length;}
function k2Rec(id){var r=ST2.k2[id];if(!r)r=ST2.k2[id]={a:{},m:{},t:{s:0,e:0},done:0,sc:{},ai:{},at:0};['a','m','sc','ai'].forEach(function(k){if(!r[k])r[k]={};});if(!r.t)r.t={s:0,e:0};return r;}
function k2Ms(r){return r&&r.t?(r.t.e||0)+(r.t.s?Math.max(0,Date.now()-r.t.s):0):0;}
function k2Fmt(ms){var s=Math.max(0,Math.floor(ms/1000));return Math.floor(s/60)+':'+pad(s%60);}   // 分:秒（80分を「80:00」と出す）
function k2Clock(r){var left=K2MIN*60000-k2Ms(r);return left>=0?k2Fmt(left):'+'+k2Fmt(-left);}
function k2Stop(r){if(r.t.s){r.t.e=(r.t.e||0)+Math.max(0,Date.now()-r.t.s);r.t.s=0;}}
/* 設問の単位（配点の付いた単位）。解答例があればそれを、なければ大問ごと（共通編の字数と配点）にする */
function k2Units(m,c){
  if(c&&c.qs){
    var cnt={},byDai={};c.qs.forEach(function(q){byDai[q.dai]=(byDai[q.dai]||0)+1;});
    var seen={};
    return c.qs.map(function(q){
      seen[q.dai]=(seen[q.dai]||0)+1;
      var u={k:q.k,h:q.h,dai:q.dai,pts:q.pts,q:q,col:String(q.dai)+(byDai[q.dai]>1?'-'+seen[q.dai]:'')};
      if(m.j<=3)u.f=(q.fields||[]).map(function(f){var n=cnt[q.dai]||0;cnt[q.dai]=n+1;return {key:q.dai+'-'+n,k:f.k,label:f.label,limit:f.limit};});
      return u;
    });
  }
  if(m.j>3)return [];
  return (m.dai||[]).map(function(d){return {k:'d'+d.no,h:'第'+d.no+'問',dai:d.no,pts:d.pts,q:null,col:String(d.no),f:d.lim.map(function(l,i){return {key:d.no+'-'+i,k:String(i),label:d.lim.length>1?'解答欄'+(i+1):'解答',limit:l};})};});
}
/* 字数のマス目（1行20マス。字数を超えた分は赤） */
function k2Grid(s,lim){
  var ch=Array.from(String(s||'')),n=Math.max(lim,ch.length),h='<div class="k2-grid" aria-hidden="true">';
  for(var i=0;i<n;i++)h+='<i'+(i>=lim?' class="ov"':'')+'>'+(ch[i]?esc(ch[i]):'')+'</i>';
  return h+'</div>';
}
function k2TextField(id,uk,key,label,lim,val,ro){
  var n=k2Len(val),h='<div class="field k2-f"><span>'+esc(label)+'（'+lim+'字以内）</span>';
  if(!ro)h+='<textarea class="ex-ta" rows="3" data-k2="'+esc(id)+'" data-k="'+esc(key)+'" data-u="'+esc(uk)+'" data-grid="'+lim+'" aria-label="'+esc(label)+'">'+esc(val)+'</textarea>';
  if(ro&&!n)return h+'<p class="fine">（書いていない）</p></div>';
  h+='<div class="ex-count'+(n>lim?' over':'')+'">'+n+' / '+lim+'字'+(ro&&n>lim?'（字数を超えている。本試験の解答用紙には書けない）':'')+'</div>'+k2Grid(val,lim);
  return h+'</div>';
}
/* 事例Ⅳの欄：数値・指標・選択・計算過程は事例Ⅳドリルの描き方を使う（欄の印は data-k2） */
function k2P4(m,u){return {id:m.id,parts:u.q.parts,ce:u.q.ce||{}};}
function k2Fld(u,f){for(var i=0;i<u.q.fields.length;i++)if(u.q.fields[i].k===f)return u.q.fields[i];return null;}
/* 自己採点（目安）：事例Ⅰ〜Ⅲは、チェックした観点の配分の合計。字数を超えた欄の観点は数えない */
function k2Self(m,u,r){
  if(!u.q)return null;
  if(m.j<=3){
    var over={};u.f.forEach(function(f){if(k2Len(r.a[f.key])>f.limit)over[f.k]=1;});
    var s=0;u.q.points.forEach(function(p,i){if(r.sc[u.k+'.'+i]&&!over[p.f])s+=p.w;});return Math.min(u.pts,s);
  }
  // 事例Ⅳ：設問ごとに、自動で採点する欄（数値・指標・選択）の正解と、記述の欄の観点のチェックの割合から（設問の配点がなければ均等に分ける）
  var res=d4Check({parts:u.q.parts},r.a),tot=0,np=u.q.parts.length;
  u.q.parts.forEach(function(pt){
    var pp=pt.pts!=null?pt.pts:u.pts/np,n=0,got=0;
    pt.fields.forEach(function(f){
      if(f.type==='num'||f.type==='ind'||f.type==='choice'){n++;if(res[f.k])got++;}
      else if(f.type==='text'){n++;var P=f.points||[];if(P.length&&k2Len(r.a[f.k])<=f.limit){var c=0;P.forEach(function(x,i){if(r.sc[u.k+'.'+f.k+'.'+i])c++;});got+=c/P.length;}}
    });
    if(n)tot+=pp*got/n;
  });
  return Math.round(tot);
}
function k2Total(m,c,r,ai){
  var U=k2Units(m,c),t=0;if(!c||!U.length)return null;
  for(var i=0;i<U.length;i++){
    if(ai){var g=r.ai[U[i].k];if(!g)return null;t+=g.score;}
    else t+=k2Self(m,U[i],r)||0;
  }
  return t;
}
function k2Log(id){var r=ST2.k2[id];if(!r||!r.lid||!ST2.log[r.lid])return;var m=DATA2.k2&&DATA2.k2.by[id],c=DATA2.k2c&&DATA2.k2c[id];if(!m||!c)return;var L=ST2.log[r.lid];L.self=k2Total(m,c,r,false);var a=k2Total(m,c,r,true);if(a!=null)L.ai=a;}
function k2Status(m,r){
  if(!r||(!r.done&&!k2Ms(r)&&!Object.keys(r.a||{}).some(function(k){return r.a[k];})))return {t:'未着手',c:''};
  if(!r.done)return {t:'解答中 ・ 残り '+k2Clock(r),c:'run'};
  var L=r.lid&&ST2.log[r.lid],s=L&&L.self!=null?L.self:null;   // 自己採点は、チェックしたときに記録へ書いた値
  return {t:'解き終えた'+(s!=null?' ・ 自己採点 '+s+'点':''),c:'done'};
}
function viewK2(){
  var d=DATA2.k2;if(!d)return '';
  var m=UI.k2Id&&d.by[UI.k2Id];
  if(m)return k2Case(m);
  var h='<section class="sec"><div class="sec-h"><span>過去問（令和元〜6年度）</span></div><div class="sheet">'
    +'<p class="lead">協会の問題PDFで与件と設問を読み、80分を計って、解答欄（字数のマス目）に書きます。解き終えたら、解答例・解説・採点の観点で見直します。</p>'
    +'<p class="fine">解答例と採点の観点はこのアプリが作ったものです（協会は模範解答も採点基準も公表していません）。解答例ができた事例から順に載せます。令和7・8年度は、仕上げに初見で解くために残しています。</p></div></section>';
  h+='<section class="sec"><div class="sec-h"><span>年度と事例を選ぶ</span></div><div class="k2-years">';
  for(var y=6;y>=1;y--){
    h+='<div class="k2-yr"><h3>令和'+(y===1?'元':y)+'年度（'+(2018+y)+'）</h3><div class="k2-cards">';
    d.cases.filter(function(c){return c.y===y;}).forEach(function(c){
      var off=c.j>3&&!c.has,st=k2Status(c,ST2.k2[c.id]);
      h+='<button class="k2-card'+(off?' off':'')+'" type="button" data-act="k2-open" data-id="'+esc(c.id)+'"'+(off?' disabled':'')+'><b>'+K2J[c.j]+'</b>'
        +'<span class="k2-th">'+esc(c.has?c.theme:(off?'準備中':K2JN[c.j]+'（解答例は準備中）'))+'</span>'
        +(off?'':'<span class="k2-st '+st.c+'">'+esc(st.t)+'</span>')+'</button>';
    });
    h+='</div></div>';
  }
  return h+'</div></section>';
}
function k2Case(m){
  var c=DATA2.k2c&&DATA2.k2c[m.id],r=k2Rec(m.id),U=k2Units(m,c),rev=!!r.done,yn='令和'+(m.y===1?'元':m.y)+'年度';
  var h='<section class="sec"><div class="sec-h"><span>'+yn+' '+K2J[m.j]+'</span></div>'
    +'<button class="linkbtn back" type="button" data-act="k2-back">← 過去問の一覧に戻る</button>'
    +'<div class="sheet k2-head"><p class="lead">'+esc(c?c.theme:K2JN[m.j])+'</p>'
    +'<div class="k2-links"><a class="btn ghost small" href="'+esc(m.pdf)+'" target="_blank" rel="noopener">問題（協会のPDF）</a>'
    +(rev?'<a class="btn ghost small" href="'+esc(m.shushi)+'" target="_blank" rel="noopener">出題の趣旨（協会のPDF）</a>':'')+'</div>'
    +(c?'':'<p class="fine">この事例の解答例・解説は準備中です。解いた答えは残るので、載ったら見直せます。</p>')
    +'<p class="fine k2-wide-hint">パソコンの広い画面では、保存した問題PDFを左に並べて表示できます。</p></div></section>';
  if(!rev){
    var run=!!r.t.s,ms=k2Ms(r);
    h+='<div class="k2-timer"><span class="k2-clock'+(ms>K2MIN*60000?' over':ms>(K2MIN-10)*60000?' warn':'')+'" id="k2clock">'+k2Clock(r)+'</span>'
      +'<span class="fine">'+(run?'計っています':ms?'止めています':'80分')+'</span>'
      +'<button class="btn small'+(run?'':' primary')+'" type="button" data-act="'+(run?'k2-pause':'k2-start')+'">'+(run?'一時停止':ms?'再開':'開始')+'</button></div>';
    U.forEach(function(u){
      h+='<section class="sec"><div class="ex-qbox"><h4>'+esc(u.h)+'（配点'+u.pts+'点）</h4>'+(u.q?'<p>'+esc(u.q.ask)+'</p>':'<p class="fine">設問は問題PDFで読む。</p>');
      if(m.j<=3)u.f.forEach(function(f){h+=k2TextField(m.id,u.k,f.key,f.label,f.limit,r.a[f.key]||'',false);});
      else h+=k2Parts4(m,u,r,null);
      var memo=r.m[u.k]||'';
      h+='<details class="k2-memo"'+(memo?' open':'')+'><summary>メモ（骨子）</summary><textarea class="ex-ta" rows="3" data-k2="'+esc(m.id)+'" data-k="'+esc(u.k)+'" data-memo="1" aria-label="'+esc(u.h)+'のメモ">'+esc(memo)+'</textarea></details>';
      h+='</div></section>';
    });
    h+='<section class="sec"><button class="btn primary wide" type="button" data-act="k2-done">解き終えた（見直しへ）</button>'
      +'<p class="fine">解き終えると時間を止め、'+(c?'解答例・解説・採点の観点':'出題の趣旨へのリンク')+'を出します。</p></section>';
    return h;
  }
  return h+k2Review(m,c,r,U);
}
/* 事例Ⅳの大問の中身：設問（parts）ごとに、欄と（見直しのとき）答え合わせ */
function k2Parts4(m,u,r,chk){
  var p=k2P4(m,u),h='';
  u.q.parts.forEach(function(pt){
    h+='<div class="k2-part">'+(pt.h?'<h5 class="d4-h">'+esc(pt.h)+(pt.pts!=null?'（'+pt.pts+'点）':'')+'</h5>':'')+'<div class="d4-q">'+d4Paras(pt.q)+'</div>';
    pt.fields.forEach(function(f){
      if(f.type==='text'){
        h+=k2TextField(m.id,u.k,f.k,f.label,f.limit,r.a[f.k]||'',!!chk);
        if(chk){h+='<div class="ex-model"><b>解答例</b><p>'+esc(f.model)+'</p><b>採点の観点（自分の答えに入っていればチェック）</b>';
          (f.points||[]).forEach(function(x,i){var key=u.k+'.'+f.k+'.'+i;h+='<label class="k2-pt"><input type="checkbox" data-act="k2-sc" data-id="'+esc(m.id)+'" data-key="'+esc(key)+'"'+(r.sc[key]?' checked':'')+'><span>'+esc(x)+'</span></label>';});
          h+='</div>';}
      } else {var fh=d4Field(p,f,r.a,chk,'k2');h+=chk?fh.replace(/<(input|select|textarea)\b/g,'<$1 disabled').replace(/<button class="d4-pm"/g,'<button disabled class="d4-pm"'):fh;}   // 見直しでは書き換えない（直すときは「答えを直す」）
    });
    if(chk&&pt.steps&&pt.steps.length)h+='<div class="d4-steps"><b>計算の手順</b><ol>'+pt.steps.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ol></div>';
    h+='</div>';
  });
  return h;
}
function k2Review(m,c,r,U){
  var h='',sec=Math.round(k2Ms(r)/1000);
  var self=c?k2Total(m,c,r,false):null,ai=c?k2Total(m,c,r,true):null;
  h+='<section class="sec"><div class="sec-h"><span>見直し</span></div><div class="sheet"><div class="k2-sum">'
    +(c?'<span>自己採点（目安）</span><b>'+self+'</b><span>/ 100点</span>'+(ai!=null?'<span class="k2-ai-t">AI採点 '+ai+'点</span>':''):'<span>解答例は準備中</span>')
    +'</div><p class="fine">かかった時間 '+k2Fmt(sec*1000)+(sec>K2MIN*60?'（80分を超えた）':'')+'。'+(c?'各設問の観点のうち、自分の答えに入っているものにチェックを付けると点になります。点と配分はこのアプリの目安です。':'出題の趣旨（協会のPDF）で、問われたことに答えられたかを確かめてください。')+'</p>';
  if(c&&AI_KEY&&m.j<=3)h+='<button class="btn primary wide" type="button" data-act="k2-ai">AI採点する（観点ごと）</button>';
  else if(c&&m.j<=3)h+='<p class="fine">AI採点は、Anthropic のAPIキーを「演習」の画面で設定すると使えます（キーはこの端末にだけ保存）。</p>';
  h+=UI.k2Confirm?'<div class="k2-confirm"><p class="fine">今の答えと点は記録に残し、白紙から80分で解き直します。</p><div class="d4-nav"><button class="btn primary small" type="button" data-act="k2-new-yes">白紙にする</button><button class="btn ghost small" type="button" data-act="k2-new-no">やめる</button></div></div>'
    :'<div class="d4-nav"><button class="btn ghost small" type="button" data-act="k2-redo">答えを直す</button><button class="btn ghost small" type="button" data-act="k2-new">もう一度、白紙から解く</button></div>';
  h+='</div></section>';
  if(c){
    // 与件の流れと設問の対応（basis から描く）
    var mx='<div class="d4-tw"><table class="d4-tbl k2-mx"><caption>与件の流れと設問の対応（●＝根拠に使う所）</caption><thead><tr><th scope="col">与件の流れ</th>'+U.map(function(u){return '<th scope="col">'+esc(u.col)+'</th>';}).join('')+'</tr></thead><tbody>';
    c.gist.forEach(function(g,gi){mx+='<tr><th scope="row">'+(gi+1)+'. '+esc(g)+'</th>'+U.map(function(u){return '<td>'+((u.q.basis||[]).some(function(b){return b[0]===gi+1;})?'●':'')+'</td>';}).join('')+'</tr>';});
    mx+='</tbody></table></div>';
    h+='<section class="sec"><div class="sec-h"><span>この事例の要点</span></div><div class="sheet">'+mx
      +'<div><b class="k2-sub">この事例で身につけること</b><ul class="k2-ul">'+c.lesson.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ul></div></div></section>';
  }
  U.forEach(function(u){
    var q=u.q,sc=c?k2Self(m,u,r):null,g=r.ai[u.k];
    h+='<section class="sec" id="k2u-'+esc(u.k)+'"><div class="ex-qbox"><h4>'+esc(u.h)+'（配点'+u.pts+'点）'+(sc!=null?' <span class="k2-us">自己採点 '+sc+'点'+(g?' ・ AI '+g.score+'点':'')+'</span>':'')+'</h4>'+(q?'<p>'+esc(q.ask)+'</p>':'');
    if(m.j<=3){
      u.f.forEach(function(f){h+=k2TextField(m.id,u.k,f.key,'あなたの答え：'+f.label,f.limit,r.a[f.key]||'',true);});
      if(q){
        h+='<div class="ex-model"><b>解答例</b>'+q.fields.map(function(f){return '<p>'+(q.fields.length>1?'<b class="k2-fl">'+esc(f.label)+'：</b>':'')+esc(q.model[f.k])+'</p>';}).join('');
        h+='<b>採点の観点（自分の答えに入っていればチェック）</b>';
        q.points.forEach(function(p,i){var key=u.k+'.'+i,fl=k2Fld(u,p.f),aiG=g&&g.got?g.got[i]:null;
          h+='<label class="k2-pt"><input type="checkbox" data-act="k2-sc" data-id="'+esc(m.id)+'" data-key="'+esc(key)+'"'+(r.sc[key]?' checked':'')+'><span>'+(q.fields.length>1&&fl?'['+esc(fl.label)+'] ':'')+esc(p.t)+' <em>'+p.w+'点'+(aiG!=null?' ・ AI '+aiG+'点':'')+'</em>'+(g&&g.why&&g.why[i]?'<small>'+esc(g.why[i])+'</small>':'')+'</span></label>';});
        h+='</div>';
        if(UI.k2Grading&&UI.k2Grading[m.id+'/'+u.k])h+='<div class="ex-loading">AI採点中…</div>';
        else if(g)h+='<div class="ex-ai"><b>AI採点 '+g.score+' / '+u.pts+'点</b><div class="ex-fb">'+esc(g.feedback)+'</div></div>';
      }
    } else if(q){
      var res=d4Check({parts:q.parts},r.a);
      h+=k2Parts4(m,u,r,res);
    }
    if(q){
      h+='<div class="k2-why"><b class="k2-sub">根拠（与件の流れ）</b><ul class="k2-ul">'+q.basis.map(function(b){return '<li>'+b[0]+'. '+esc((c.gist[b[0]-1]||''))+'：'+esc(b[1])+'</li>';}).join('')+'</ul>'
        +'<b class="k2-sub">出題の趣旨（要約）</b><p class="k2-p">'+esc(q.shushi)+'</p>'
        +'<b class="k2-sub">解説</b><div class="tx-sec k2-e">'+renderJ2(q.e)+'</div></div>';
    }
    var memo=r.m[u.k];if(memo)h+='<div class="k2-why"><b class="k2-sub">自分のメモ</b><p class="k2-p">'+esc(memo)+'</p></div>';
    h+='</div></section>';
  });
  return h;
}
/* AI採点（事例Ⅰ〜Ⅲ）：解答例・観点・根拠・趣旨を渡し、観点ごとに点を付けさせる */
function k2AiPrompt(m,c,u,r){
  var q=u.q,L=[];
  L.push('あなたは中小企業診断士の第2次試験（筆記）の採点者です。協会は採点基準を公表していないので、下の「採点の観点」を基準に、受験者の解答を観点ごとに採点してください。');
  L.push('');
  L.push('【事例】令和'+(m.y===1?'元':m.y)+'年度 '+K2J[m.j]+'（'+c.theme+'）');
  L.push('【与件の流れ（要約）】'+c.gist.map(function(g,i){return (i+1)+'. '+g;}).join(' / '));
  L.push('【設問】'+u.h+'（配点'+u.pts+'点）：'+q.ask);
  L.push('【出題の趣旨（要約）】'+q.shushi);
  L.push('【与件の根拠】'+q.basis.map(function(b){return b[0]+'. '+(c.gist[b[0]-1]||'')+'：'+b[1];}).join(' / '));
  L.push('【解答例】');
  q.fields.forEach(function(f){L.push('・'+f.label+'（'+f.limit+'字以内）：'+q.model[f.k]);});
  L.push('【採点の観点（合計'+u.pts+'点）】');
  q.points.forEach(function(p,i){var f=k2Fld(u,p.f);L.push((i+1)+'. ['+(f?f.label:'')+'] '+p.t+'（'+p.w+'点）');});
  L.push('【受験者の解答】');
  u.f.forEach(function(f){var s=r.a[f.key]||'',n=k2Len(s);L.push('・'+f.label+'（'+f.limit+'字以内）：'+(s?'「'+s+'」（'+n+'字'+(n>f.limit?'、字数超過':'')+'）':'（未記入）'));});
  L.push('');
  L.push('採点のしかた：');
  L.push('・観点ごとに、受験者の解答の [ ] の欄に同じ意味の要素があれば配点どおり、不十分（あいまい、根拠が弱い、因果が欠ける）なら一部、なければ0点。言い回しが解答例と違っても、意味が同じなら認める。');
  L.push('・設問の条件（観点・時制・対象）から外れた内容、与件にない内容には点を付けない。');
  L.push('・字数を超えた欄の観点は0点にする。');
  L.push('・解答例にない要素でも、与件の根拠があって設問の条件に合うものは、feedback で触れる（点は観点の範囲で付ける）。');
  L.push('');
  L.push('次の形の JSON だけを返す（コードブロックなし）：{"pts":[{"i":観点の番号,"got":その観点の得点（0〜配点の整数）,"why":"判断の理由（30字程度）"}],"feedback":"良い点と、次に直す点（100字程度）"}');
  return L.join('\n');
}
function k2ParseAi(txt,u,r){
  var o=null;try{o=JSON.parse(txt);}catch(e){var mm=txt.match(/\{[\s\S]*\}/);if(mm){try{o=JSON.parse(mm[0]);}catch(e2){}}}
  if(!o||!Array.isArray(o.pts))throw new Error('採点の結果を読み取れませんでした。もう一度試してください');
  var P=u.q.points,got=P.map(function(){return 0;}),why=P.map(function(){return '';}),over={};
  u.f.forEach(function(f){if(k2Len(r.a[f.key])>f.limit)over[f.k]=1;});
  o.pts.forEach(function(x){var i=Math.round(Number(x&&x.i))-1;if(i>=0&&i<P.length){var g=Math.round(Number(x.got));got[i]=isFinite(g)?Math.max(0,Math.min(P[i].w,g)):0;why[i]=String(x.why||'').slice(0,120);}});
  P.forEach(function(p,i){if(over[p.f]){got[i]=0;why[i]='字数を超えた欄（0点）';}});
  return {got:got,why:why,score:got.reduce(function(a,b){return a+b;},0),feedback:String(o.feedback||'').slice(0,500),at:Date.now(),model:AI_MODEL};
}
/* パソコンの広い画面：保存した問題PDFを左に並べる（この端末の中だけで開く。IndexedDB に事例ごとに覚える） */
var K2DB=null;
function k2Db(){if(!K2DB)K2DB=new Promise(function(res,rej){try{var q=indexedDB.open('shindan2-pdf',1);q.onupgradeneeded=function(){q.result.createObjectStore('pdf');};q.onsuccess=function(){res(q.result);};q.onerror=function(){rej(q.error);};}catch(e){rej(e);}});return K2DB;}
function k2PdfPut(id,file){return k2Db().then(function(db){return new Promise(function(res,rej){var tx=db.transaction('pdf','readwrite');tx.objectStore('pdf').put({name:file.name,blob:file},id);tx.oncomplete=function(){res();};tx.onerror=function(){rej(tx.error);};});});}
function k2PdfGet(id){return k2Db().then(function(db){return new Promise(function(res){var tx=db.transaction('pdf','readonly'),q=tx.objectStore('pdf').get(id);q.onsuccess=function(){res(q.result||null);};q.onerror=function(){res(null);};});}).catch(function(){return null;});}
function k2PdfDel(id){return k2Db().then(function(db){return new Promise(function(res){var tx=db.transaction('pdf','readwrite');tx.objectStore('pdf').delete(id);tx.oncomplete=function(){res();};tx.onerror=function(){res();};});}).catch(function(){});}
function k2PdfShow(id,o){if(UI.k2Pdf&&UI.k2Pdf.url)URL.revokeObjectURL(UI.k2Pdf.url);UI.k2Pdf=o&&o.blob?{id:id,name:o.name||'問題.pdf',url:URL.createObjectURL(o.blob)}:{id:id};k2Side(true);}
function k2Side(force){
  var on=UI.stage==='s2'&&UI.tab2==='jkako'&&!!UI.k2Id,side=$('#k2side');
  document.body.classList.toggle('k2w',on);
  if(!side)return;
  if(!on){if(side.dataset.id){side.innerHTML='';side.dataset.id='';}return;}
  var wide=!window.matchMedia||window.matchMedia('(min-width:1100px)').matches;   // 狭い画面では左の欄は出ないので、PDF も開かない
  var m=DATA2.k2&&DATA2.k2.by[UI.k2Id],p=UI.k2Pdf&&UI.k2Pdf.id===UI.k2Id?UI.k2Pdf:null,key=UI.k2Id+'|'+(p&&p.url||'')+'|'+wide;
  if(!m||(!force&&side.dataset.id===key))return;
  if(!wide){side.innerHTML='';side.dataset.id=key;return;}
  side.dataset.id=key;
  side.innerHTML=p&&p.url?'<iframe class="k2-if" title="問題（保存したPDF）" src="'+esc(p.url)+'"></iframe><div class="k2-sbar"><span class="fine">'+esc(p.name)+'（この端末の中だけで表示）</span><label class="linkbtn">別のPDF<input type="file" class="k2pdf" accept="application/pdf,.pdf" hidden></label><button class="linkbtn" type="button" data-act="k2-pdf-del">外す</button></div>'
    :'<div class="k2-empty"><p class="lead">令和'+(m.y===1?'元':m.y)+'年度 '+K2J[m.j]+'の問題</p><p class="fine">協会の問題PDFを保存してから選ぶと、ここに並べて表示します。PDFはこの端末の中だけで開き、どこにも送りません（次に開いたときも表示します）。</p>'
      +'<div class="k2-links"><a class="btn ghost small" href="'+esc(m.pdf)+'" target="_blank" rel="noopener">問題（協会のPDF）を開く</a><label class="btn small primary">保存したPDFを選ぶ<input type="file" class="k2pdf" accept="application/pdf,.pdf" hidden></label></div></div>';
}
function k2Open(id){
  var m=DATA2.k2&&DATA2.k2.by[id];if(!m)return;
  UI.k2Id=id;UI.k2Grading={};$('#main').scrollTop=0;
  var need=[loadJText()];if(m.has)need.push(loadK2C(id));if(m.j>3)need.push(loadJ4());
  Promise.all(need).catch(function(){toast('解答例を読み込めませんでした。つながる所で開き直してください');}).then(function(){render();});
  if(!UI.k2Pdf||UI.k2Pdf.id!==id){if(UI.k2Pdf&&UI.k2Pdf.url)URL.revokeObjectURL(UI.k2Pdf.url);UI.k2Pdf={id:id};k2PdfGet(id).then(function(o){if(UI.k2Id===id&&o)k2PdfShow(id,o);});}
  render();
}
window.addEventListener('resize',function(){if(UI.k2Id)k2Side();});
