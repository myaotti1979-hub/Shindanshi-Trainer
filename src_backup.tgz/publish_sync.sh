#!/bin/sh
# pwa の中身をリポジトリへ写す（コミットと push は別）。
# 模擬試験のセットは、mock.json に載っている検証済みのものだけを写す。作成・検証中の下書き（data/m_*_*.json）は写さない
set -e
B=/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad
R=/home/claude/shindanshi-trainer
cd "$B/pwa"
# 安全装置：公開版より古い本体や、解説の図が減った演習で上書きしない（2026-11-19 に図の抜けた演習を見つけた）
python3 - "$R" <<'PY'
import json,re,sys,os
R=sys.argv[1]
ver=lambda p: int(re.search(r"APP_VER='v(\d+)'",open(p,encoding='utf-8').read()).group(1))
if ver('index.html')<ver(R+'/index.html'): sys.exit('作業フォルダの index.html が公開版より古い（先にリポジトリの変更を戻す）')
for s in ['keizai','zaimu','kigyo','unei','homu','joho','chusho']:
    n=lambda p: sum(1 for q in json.load(open(p,encoding='utf-8'))['questions'] if q.get('x'))
    a,b=n('data/q_%s.json'%s),n(R+'/data/q_%s.json'%s)
    if a<b: sys.exit('q_%s.json の解説の図が公開版より少ない（%d < %d）。rebuild_qb_only.sh を確かめる'%(s,a,b))
for f in os.listdir(R+'/data'):
    if re.fullmatch(r'j.*\.json',f) and not os.path.exists('data/'+f): sys.exit('2次のデータ '+f+' が作業フォルダにない')
# 2次：niji/build.py の公開用（DRAFT なし）で作ったもので、載っている id がすべて niji/verified.json にあること
V=json.load(open('../niji/verified.json',encoding='utf-8'))
def need(kind,ids,f):
    bad=[i for i in ids if i not in set(V.get(kind,[]))]
    if bad: sys.exit('2次の %s に、検証が済んでいない id がある：%s'%(f,' '.join(bad[:5])))
for f in ['j_common','j1','j2','j3','j4_text','j_exercise','j4_drill']:
    d=json.load(open('data/%s.json'%f,encoding='utf-8'))
    if d.get('draft'): sys.exit('2次の %s.json が下書き（DRAFT=1 で作った）。python3 niji/build.py で作り直す'%f)
    if f=='j_exercise': need('ex',[c['id'] for c in d['cases']],f)
    elif f=='j4_drill': need('drill',[p['id'] for p in d['problems']],f)
    else: need('text',[s['id'] for c in d['chapters'] for s in c['sections']],f)
# 過去問：一覧（k2.json）と中身（k2-r0Y-J.json）は公開用のビルドで作ったもの。中身があるのは検証済みの事例だけ
k=json.load(open('data/k2.json',encoding='utf-8'))
if k.get('draft'): sys.exit('2次の k2.json が下書き（DRAFT=1 で作った）。python3 niji/build.py で作り直す')
if len(k['cases'])!=24: sys.exit('2次の k2.json の事例の数が24でない')
has=[c['id'] for c in k['cases'] if c.get('has')]
need('kako',has,'k2')
for f in os.listdir('data'):
    m=re.fullmatch(r'(k2-r0[1-6]-[1-4])\.json',f)
    if not m: continue
    if m.group(1) not in has: sys.exit('2次の過去問 %s は一覧で中身なしなのに、ファイルがある（古い下書き？）'%f)
    if json.load(open('data/'+f,encoding='utf-8')).get('draft'): sys.exit('2次の過去問 %s が下書き'%f)
# テキストの場所（tx_anchor.json）は、テキスト・演習・模試を作り直したあとに作り直す（古いと、場所が節の見出しに戻る）
import glob
ta=os.path.getmtime('data/tx_anchor.json') if os.path.exists('data/tx_anchor.json') else 0
new=[f for f in glob.glob('data/t_*.json')+glob.glob('data/q_*.json')+glob.glob('data/m_*_*.json') if os.path.getmtime(f)>ta+1]
if new: sys.exit('data/tx_anchor.json が古い（%s などのあとに作っていない）。python3 build_anchor.py を動かす'%os.path.basename(new[0]))
print('安全装置：OK')
PY
EX=$(python3 -c "
import json,glob,os,sys
S=json.load(open('data/mock.json'))['sets']
d=[k for k,v in S.items() if v.get('draft')]
if d: sys.exit('mock.json に下書きのセットが載っている（DRAFT=1 で作った？）: '+' '.join(d))
L={v['file'] for v in S.values()}
for f in sorted(glob.glob('data/m_*_*.json')):
    if os.path.basename(f) not in L: print('--exclude=./'+f)
")
tar cf - --exclude=.git --exclude=_prev.html --exclude=_figprev.html $EX . | (cd "$R" && tar xf -)
cd "$R"
python3 -c "
import json,glob,os
L={v['file'] for v in json.load(open('data/mock.json'))['sets'].values()}
for f in sorted(glob.glob('data/m_*_*.json')):
    if os.path.basename(f) not in L: os.remove(f); print('リポジトリから消した', f)
print('写したセット:', ' '.join(sorted(L)) or 'なし')
"
