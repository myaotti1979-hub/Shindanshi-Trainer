# 【追加】の2つの書き方に対応して本文に挿入する
#  A: 【追加】「X」の(行の)後に(、次の行として)「Y」  B: 【追加】Y（「X」の後）
import json, re, sys, glob
review, idxs = sys.argv[1], [int(i) for i in sys.argv[2].split(',')]
files = sorted(glob.glob('text/homu_p1*.py'))
src = {f: open(f, encoding='utf-8').read() for f in files}
for i in idxs:
    fx = json.load(open(review))[i]['fix']
    body = fx.split('【追加】', 1)[1]
    m = re.match(r'\s*「(.+?)」の(行の)?後に(、次の行として)?「(.+)」\s*$', body, re.S)
    if m:
        anc, newline, y = m.group(1), bool(m.group(2) or m.group(3)), m.group(4)
    else:
        m = re.search(r'^(.*)（「(.+?)」の後）\s*$', body, re.S)
        anc, newline, y = m.group(2), True, m.group(1)
    hit = [f for f in files if src[f].count(anc) == 1]
    assert len(hit) == 1 and sum(src[f].count(anc) for f in files) == 1, (i, anc)
    s = src[hit[0]]; k = s.find(anc) + len(anc)
    if not newline:
        s = s[:k] + y + s[k:]
    else:
        e = s.find('\n', k)
        lines = y.strip('\n').split('\n')
        if lines[0].startswith('**'): lines = [''] + lines
        s = s[:e] + '\n' + '\n'.join(lines) + s[e:]
    src[hit[0]] = s
    print(i, 'ok', 'newline' if newline else 'inline', anc[:24])
for f in files:
    open(f, 'w', encoding='utf-8').write(src[f])
