/* ---------- 端末間の同期（Firebase：Google ログイン＋Firestore） ---------- */
// 記録の合わせ方
// ・演習の記録（srs）：問題ごとに、最後に解いた時刻（last）が新しいほう
// ・過去問・模擬試験の結果：id で合わせる（どちらの端末の結果も残す）
// ・報告（flags）：報告した時刻と、演習に戻した時刻（flagDel）の新しいほう
// ・設定：変えた時刻（settingsAt）が新しいほう。同じならクラウドのほう
// ・学習時間（days）：端末ごとに保存して合計する（二重に数えない・消えない）。ほかの端末の分は daysX
// ・実行中の模擬試験（mockRun）とタイマーは、その端末だけ
// 保存先：users/{uid}/sync/state（j に上の記録の JSON）、users/{uid}/days/{端末のid}（j に学習時間の JSON）
// ルール：ログインした本人だけが users/{uid} の下を読み書きできる（Firestore のセキュリティルール）
var FB_CFG={apiKey:'AIzaSyD8VO0NT190-oLpS3qwiKtaAIc-EfzBk0c',authDomain:'shindannshi-app.firebaseapp.com',projectId:'shindannshi-app',storageBucket:'shindannshi-app.firebasestorage.app',messagingSenderId:'582946048152',appId:'1:582946048152:web:5bc45f4a859137e501a8ed'};
var FB_URL='https://www.gstatic.com/firebasejs/12.19.0/';
var SYNC={mod:null,loading:null,user:null,busy:false,again:false,last:0,err:'',ask:null,t:0};
function lsGet(k){try{return localStorage.getItem(STORE+k);}catch(e){return null;}}
function lsSet(k,v){try{if(v==null)localStorage.removeItem(STORE+k);else localStorage.setItem(STORE+k,v);}catch(e){}}
function devId(){var d=lsGet('-dev');if(!d){d=uid('d');lsSet('-dev',d);}return d;}
function devName(){var u=navigator.userAgent||'';return /Android/i.test(u)?'Android':/iPhone|iPad/i.test(u)?'iPhone・iPad':/Windows/i.test(u)?'Windows':/Macintosh/i.test(u)?'Mac':'この端末';}
function dayRec(k){var o={min:0,ans:0,cor:0,nw:0},L=[ST.days];Object.keys(ST.daysX||{}).forEach(function(d){L.push(ST.daysX[d]);});L.forEach(function(D){var v=D&&D[k];if(v){o.min+=v.min||0;o.ans+=v.ans||0;o.cor+=v.cor||0;o.nw+=v.nw||0;}});return o;}
function allDayKeys(){var m={},L=[ST.days];Object.keys(ST.daysX||{}).forEach(function(d){L.push(ST.daysX[d]);});L.forEach(function(D){Object.keys(D||{}).forEach(function(k){m[k]=1;});});return Object.keys(m);}
function syncPart(S){return JSON.parse(JSON.stringify({srs:S.srs||{},past:S.past||[],mock:S.mock||[],flags:S.flags||{},flagDel:S.flagDel||{},settings:S.settings||{},settingsAt:S.settingsAt||0}));}
function mergeSync(L,R){
  L=L||{};if(!R)return syncPart(L);
  var o={srs:{},past:[],mock:[],flags:{},flagDel:{},settings:{},settingsAt:0},ls=L.srs||{},rs=R.srs||{};
  Object.keys(ls).concat(Object.keys(rs)).forEach(function(k){if(o.srs.hasOwnProperty(k))return;var a=ls[k],b=rs[k];
    o.srs[k]=!a?b:!b?a:((a.last||0)>(b.last||0)||((a.last||0)===(b.last||0)&&(a.reps||0)>(b.reps||0)))?a:b;});
  function rk(r){return r.id||[r.s,r.y,r.r,r.at].join('|');}
  function uni(x,y){var m={},out=[];(x||[]).concat(y||[]).forEach(function(r){if(!r)return;var k=rk(r);if(m[k])return;m[k]=1;out.push(r);});return out.sort(function(p,q){return (p.at||0)-(q.at||0);});}
  o.past=uni(L.past,R.past);o.mock=uni(L.mock,R.mock);
  var lf=L.flags||{},rf=R.flags||{},ld=L.flagDel||{},rd=R.flagDel||{},fk={};
  function fat(x){return x?(x.at||1):0;}
  [lf,rf,ld,rd].forEach(function(m){Object.keys(m).forEach(function(k){fk[k]=1;});});
  Object.keys(fk).forEach(function(k){var fa=Math.max(fat(lf[k]),fat(rf[k])),da=Math.max(ld[k]||0,rd[k]||0);if(fa>da)o.flags[k]={at:fa};if(da)o.flagDel[k]=da;});
  var la=L.settingsAt||0,ra=R.settingsAt||0;
  if(la>ra){o.settings=L.settings||{};o.settingsAt=la;}else{o.settings=R.settings||L.settings||{};o.settingsAt=ra;}
  return JSON.parse(JSON.stringify(o));
}
function putSync(mg){ST.srs=mg.srs||{};ST.past=mg.past||[];ST.mock=mg.mock||[];ST.flags=mg.flags||{};ST.flagDel=mg.flagDel||{};ST.settings=Object.assign({},DEF,mg.settings||{});ST.settingsAt=mg.settingsAt||0;}
function fbLoad(){
  if(SYNC.mod)return Promise.resolve(SYNC.mod);
  if(SYNC.loading)return SYNC.loading;
  var imp=function(u){try{return (new Function('u','return import(u)'))(u);}catch(e){return Promise.reject(e);}};
  SYNC.loading=Promise.all([imp(FB_URL+'firebase-app.js'),imp(FB_URL+'firebase-auth.js'),imp(FB_URL+'firebase-firestore-lite.js')]).then(function(m){
    var app=m[0].initializeApp(FB_CFG),auth=m[1].getAuth(app);
    SYNC.mod={A:m[1],F:m[2],auth:auth,db:m[2].getFirestore(app)};
    m[1].onAuthStateChanged(auth,function(u){var was=SYNC.user;SYNC.user=u||null;if(u){lsSet('-sync','1');if(!was||was.uid!==u.uid)syncNow();}schedRender();});
    return SYNC.mod;
  },function(e){SYNC.loading=null;throw e;});
  return SYNC.loading;
}
function syncSoon(ms){if(!SYNC.user)return;clearTimeout(SYNC.t);SYNC.t=setTimeout(function(){syncNow();},ms||30000);}
function syncErr(e){var c=(e&&e.code)||'';
  return c==='auth/popup-blocked'?'ログインの画面を開けませんでした（ポップアップを許可してください）'
    :c==='auth/unauthorized-domain'?'このアドレスからはログインできません'
    :(c==='auth/network-request-failed'||c==='unavailable')?'通信できませんでした。つながったときに同期します'
    :c==='permission-denied'?'同期の権限がありません。ログインし直してください'
    :'同期できませんでした（'+String(c||(e&&e.message)||e).slice(0,60)+'）';}
// mode：なし＝ふつうの同期、'merge'＝はじめての同期で「合わせる」、'cloud'＝はじめての同期で「クラウドの記録にする」
function syncNow(mode){
  clearTimeout(SYNC.t);
  var M=SYNC.mod,u=SYNC.user;if(!M||!u)return Promise.resolve();
  if(SYNC.busy){SYNC.again=true;return Promise.resolve();}
  if(navigator.onLine===false){SYNC.err='オフラインです。つながったときに同期します';schedRender();return Promise.resolve();}
  SYNC.busy=true;SYNC.err='';schedRender();saveNow();
  var F=M.F,dv=devId(),ref=F.doc(M.db,'users',u.uid,'sync','state'),first=lsGet('-synced')!==u.uid;
  var hasLocal=Object.keys(ST.srs).length||ST.past.length||ST.mock.length||Object.keys(ST.days).length;
  var chk=(first&&!mode)?F.getDoc(ref).then(function(s){return s.exists()?s.data():null;}):Promise.resolve(null);
  return chk.then(function(rem){
    if(rem&&hasLocal){SYNC.ask={at:rem.at||0};return;}
    var mine=syncPart(ST);
    return F.runTransaction(M.db,function(tx){return tx.get(ref).then(function(s){
      var R=null;if(s.exists()){try{R=JSON.parse(s.data().j||'null');}catch(e){R=null;}}
      var cloud=mode==='cloud'&&!!R,mg=mergeSync(cloud?syncPart({}):mine,R);
      tx.set(ref,{v:1,j:JSON.stringify(mg),at:Date.now(),dev:dv});return {mg:mg,cloud:cloud};});
    }).then(function(r){
      if(r.cloud){putSync(r.mg);ST.days={};}else putSync(mergeSync(syncPart(ST),r.mg));
      saveNow();
      return F.setDoc(F.doc(M.db,'users',u.uid,'days',dv),{j:JSON.stringify(ST.days),at:Date.now(),name:devName()});
    }).then(function(){return F.getDocs(F.collection(M.db,'users',u.uid,'days'));}).then(function(qs){
      var X={};qs.forEach(function(d){if(d.id===dv)return;try{X[d.id]=JSON.parse(d.data().j||'{}')||{};}catch(e){}});
      ST.daysX=X;SYNC.ask=null;SYNC.last=Date.now();lsSet('-synced',u.uid);lsSet('-last',String(SYNC.last));saveNow();
    });
  }).catch(function(e){SYNC.err=syncErr(e);}).then(function(){
    SYNC.busy=false;schedRender();if(SYNC.again){SYNC.again=false;syncSoon(2000);}
  });
}
function syncLogin(){
  var M=SYNC.mod;
  if(!M){toast('準備しています…');fbLoad().then(function(){toast('準備ができました。もう一度押してください');schedRender();},function(){toast('通信できる場所で、もう一度試してください');});return;}
  SYNC.err='';
  M.A.signInWithPopup(M.auth,new M.A.GoogleAuthProvider()).then(function(){lsSet('-sync','1');toast('ログインしました。同期します');},function(e){
    var c=(e&&e.code)||'';if(c==='auth/popup-closed-by-user'||c==='auth/cancelled-popup-request')return;SYNC.err=syncErr(e);schedRender();});
}
function syncLogout(){var M=SYNC.mod;if(!M)return;M.A.signOut(M.auth).then(function(){lsSet('-sync',null);lsSet('-synced',null);SYNC.user=null;SYNC.ask=null;SYNC.err='';toast('ログアウトしました。記録はこの端末に残ります');schedRender();});}
function fmtWhen(t){var d=new Date(t);return (d.getMonth()+1)+'月'+d.getDate()+'日 '+('0'+d.getHours()).slice(-2)+':'+('0'+d.getMinutes()).slice(-2);}
function viewSync(){
  var u=SYNC.user,h='<section class="sec"><div class="sec-h"><span>端末間の同期</span></div>';
  if(!SYNC.mod&&!SYNC.loading&&navigator.onLine!==false)fbLoad().then(schedRender,function(){});
  if(!u){
    h+='<p class="fine">Google でログインすると、スマホとパソコンで学習記録（演習・過去問・模擬試験の結果、学習時間、設定）がそろいます。記録は、あなたの Google アカウントだけが読み書きできる場所（Firebase）に保存されます。</p>'
     +'<div class="row-act"><button class="btn small primary" type="button" data-act="sync-login">Google でログインして同期</button></div>';
  }else{
    var last=SYNC.last||Number(lsGet('-last'))||0;
    h+='<p class="fine">ログイン中：'+esc(u.email||'')+'<br>'+(SYNC.busy?'同期しています…':last?'最後の同期：'+fmtWhen(last):'まだ同期していません')+'（この端末：'+esc(devName())+'）。記録は、解いたあとやアプリを開いたときに自動で同期します。</p>'
     +'<div class="row-act"><button class="btn small" type="button" data-act="sync-now"'+(SYNC.busy?' disabled':'')+'>今すぐ同期</button><button class="btn small ghost" type="button" data-act="sync-logout">ログアウト</button></div>';
    if(SYNC.ask)h+='<div class="confirm"><span>クラウドにも記録があります（'+(SYNC.ask.at?fmtWhen(SYNC.ask.at)+'に更新':'更新の日時は不明')+'）。この端末の記録とどうしますか。</span>'
     +'<div class="row-act"><button class="btn small primary" type="button" data-act="sync-merge">合わせる</button><button class="btn small ghost" type="button" data-act="sync-cloud">クラウドの記録にする</button></div>'
     +'<span class="fine">ふつうは「合わせる」です。この端末の記録が、別の端末から「読み込む」で移したものなら「クラウドの記録にする」を選んでください（学習時間を二重に数えないため。この端末だけの記録は消えます）。</span></div>';
  }
  if(SYNC.err)h+='<p class="err">'+esc(SYNC.err)+'</p>';
  return h+'</section>';
}
document.addEventListener('visibilitychange',function(){if(!SYNC.user)return;if(document.visibilityState==='hidden')syncNow();else syncSoon(1500);});
window.addEventListener('online',function(){if(SYNC.user)syncSoon(1000);});

