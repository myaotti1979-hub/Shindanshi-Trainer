const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
const URL='http://127.0.0.1:8765/';
(async()=>{
  const browser=await chromium.launch();const out={};
  for(const scheme of ['light','dark']){
    const ctx=await browser.newContext({viewport:{width:400,height:860},deviceScaleFactor:1,colorScheme:scheme,serviceWorkers:'block'});
    const p=await ctx.newPage();
    await p.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
    const errs=[];p.on('pageerror',e=>errs.push('PAGEERR '+e.message));
    await p.goto(URL+'index.html');await p.waitForTimeout(700);
    await p.click('[data-act=tab][data-tab=drill]');await p.waitForTimeout(100);
    out[scheme+'_subjLine']=await p.$eval('.subj-m',e=>e.textContent);
    await p.click('[data-act=open-syl][data-s=kigyo]');await p.waitForTimeout(100);
    if(scheme==='light'){await p.screenshot({path:B+'/shots/x1-syl.png'});}
    await p.click('[data-act=open-text][data-ch="kigyo.1.2"]');await p.waitForTimeout(150);
    await p.screenshot({path:B+`/shots/x2-reader-${scheme}.png`});
    out[scheme+'_sections']=await p.$$eval('#reader .tx-sec',els=>els.length);
    out[scheme+'_ovf']=await p.evaluate(()=>{const d=document.documentElement;return [d.scrollWidth,d.clientWidth];});
    // navigate next chapter
    await p.click('[data-act=rd-go]');await p.waitForTimeout(80);
    out[scheme+'_nextTitle']=await p.$eval('#reader .p-title',e=>e.textContent);
    await p.click('[data-act=rd-close]');
    // session -> text link
    await p.click('[data-act=drill-group][data-g="kigyo.1.2"]');await p.waitForTimeout(100);
    await p.click('[data-act=pick][data-v="1"]');await p.click('[data-act=conf][data-c=sure]');
    const hasLink=await p.$('[data-act=open-text][data-sec]');out[scheme+'_linkInReveal']=!!hasLink;
    if(hasLink){await hasLink.click();await p.waitForTimeout(150);out[scheme+'_hl']=await p.$eval('#reader .tx-hl h3',e=>e.textContent).catch(()=>null);await p.screenshot({path:B+`/shots/x3-fromsess-${scheme}.png`});await p.click('#reader [data-act=rd-close]');await p.waitForTimeout(60);out[scheme+'_backToSess']=!(await p.$eval('#sess',e=>e.hidden));}
    out[scheme+'_errs']=errs;
    await ctx.close();
  }
  console.log(JSON.stringify(out,null,1));await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
