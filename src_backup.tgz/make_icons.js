const { chromium } = require('playwright');
const OUT='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/pwa/icons/';
const svg=(bg)=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
<rect width="512" height="512" fill="${bg}"/>
<g stroke="#E6A79D" stroke-width="14" fill="none">
<ellipse cx="146" cy="244" rx="42" ry="68"/>
<ellipse cx="366" cy="244" rx="42" ry="68"/>
</g>
<ellipse cx="256" cy="244" rx="49" ry="75" fill="#2A2F34"/>
<path d="M120 378H392" stroke="#AE4A3E" stroke-width="12" stroke-linecap="round"/>
</svg>`;
(async()=>{
  const b=await chromium.launch();
  for(const [name,size] of [['icon-512.png',512],['icon-192.png',192],['icon-maskable-512.png',512],['apple-touch-icon.png',180]]){
    const p=await b.newPage({viewport:{width:size,height:size},deviceScaleFactor:1});
    await p.setContent(`<html><body style="margin:0">${svg('#FAF7F6').replace('width="512" height="512"',`width="${size}" height="${size}"`)}</body></html>`);
    await p.screenshot({path:OUT+name,clip:{x:0,y:0,width:size,height:size}});
    await p.close();
  }
  await b.close();
})();
