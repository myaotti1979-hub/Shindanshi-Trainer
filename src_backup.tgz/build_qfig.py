# 演習の解説に図表を付ける。text/qx_*.py の QX = {問題ID: 本文（テキストと同じ書き方。[[図:名前]] で図）} を
# pwa/data/q_*.json の各問題の "x" に入れる（図は SVG に展開）。何度実行しても同じ結果になる
import sys, os, glob, json, re, importlib.util
B = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(B, 'pwa', 'data')
sys.path.insert(0, os.path.join(B, 'text'))


def load(f):
    spec = importlib.util.spec_from_file_location(os.path.basename(f)[:-3], f)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


FIG = {}
for f in sorted(glob.glob(os.path.join(B, 'text', 'fig_*.py'))):
    if os.path.basename(f).startswith('fig_mk_'):
        continue   # 模擬試験の図（build_mock.py が使う）
    m = load(f)
    dup = set(FIG) & set(m.FIG)
    if dup:
        sys.exit('重複した図の名前: %s' % sorted(dup))
    FIG.update(m.FIG)
QX = {}
for f in sorted(glob.glob(os.path.join(B, 'text', 'qx_*.py'))):
    m = load(f)
    dup = set(QX) & set(m.QX)
    if dup:
        sys.exit('重複した問題ID: %s' % sorted(dup))
    QX.update(m.QX)
PH = re.compile(r'^\[\[図:([^\]]+)\]\]$')


def expand(src, qid):
    out = []
    for ln in src.strip().split('\n'):
        mm = PH.match(ln.strip())
        if mm:
            name = mm.group(1)
            if name not in FIG:
                sys.exit('%s: 図がない: %s' % (qid, name))
            out.append(FIG[name])
        elif '[[図:' in ln:
            sys.exit('%s: [[図:…]] は独立した行に書く: %s' % (qid, ln))
        else:
            out.append(ln)
    return '\n'.join(out)


seen = set()
tot = 0
for f in sorted(glob.glob(os.path.join(D, 'q_*.json'))):
    d = json.load(open(f, encoding='utf-8'))
    n = 0
    for q in d['questions']:
        if q['id'] in QX:
            q['x'] = expand(QX[q['id']], q['id'])
            seen.add(q['id'])
            n += 1
        elif 'xsrc' in q:
            q['x'] = expand(q.pop('xsrc'), q['id'])
            n += 1
        else:
            q.pop('x', None)
        if 'fsrc' in q:
            q['fig'] = expand(q.pop('fsrc'), q['id'])
    json.dump(d, open(f, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print('%s: %d問中 %d問に図表' % (os.path.basename(f), len(d['questions']), n))
    tot += n
miss = set(QX) - seen
if miss:
    sys.exit('問題が見つからないID: %s' % sorted(miss))
print('合計', tot)
