// 「記録」タブの同期の欄を、スマホの幅で撮る（Firebase は読み込めなくても欄は出る）
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 400, height: 860 }, deviceScaleFactor: 1 });
  const errs = [];
  p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://127.0.0.1:8765/index.html');
  await p.waitForTimeout(1500);
  await p.click('[data-act="tab"][data-tab="log"]').catch(() => {});
  await p.waitForTimeout(1200);
  const el = await p.$('[data-act="sync-login"]');
  if (el) await el.scrollIntoViewIfNeeded();
  await p.waitForTimeout(300);
  await p.screenshot({ path: 'shots/sync_log.png' });
  const ov = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  console.log(JSON.stringify({ login: !!el, errs, ov }));
  await b.close();
})();
