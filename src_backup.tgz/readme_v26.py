# README を v26 に更新する（公開した模擬試験のセットは mock.json から数える）
import json, re
B = '/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/pwa/'
p = B + 'README.md'
s = open(p, encoding='utf-8').read()
M = json.load(open(B + 'data/mock.json', encoding='utf-8'))
SN = dict(keizai='経済学・経済政策', zaimu='財務・会計', kigyo='企業経営理論', unei='運営管理', homu='経営法務', joho='経営情報システム', chusho='中小企業経営・中小企業政策')
by = {}
for k in M['sets']:
    sub, r = k.rsplit('-', 1)
    by.setdefault(int(r), []).append(sub)
order = list(SN)
lines = []
for r in sorted(by):
    subs = [x for x in order if x in by[r]]
    lines.append('第%d回：%s' % (r, '・'.join(SN[x] for x in subs) if len(subs) < 7 else '7科目すべて'))
n = len(M['sets'])
s = s.replace('# 診断士1次トレーナー v25', '# 診断士1次トレーナー v26')
s = s.replace('## 収録内容（v25）', '## 収録内容（v26）')
s = s.replace('## 現在の到達状況（v25）', '## 現在の到達状況（v26）')
row = ('| 模擬試験 | 7科目×7回（49セット）を、本試験と同じ番号・配点・問題数・時間で作成中。公開は、作成とは別の担当の検証と直しが終わったセットだけ（v26 で %dセット：%s）。'
       '番号・配点は令和6・5・4年度、論点は令和6〜元年度・平成30年度の本試験を手本にし、各問題に手本の問題と難しさの見込み（A 基本〜D 難）を付けた。全問の解説に図表 |\n') % (n, '、'.join(lines))
anchor = '| 完了判定 | 科目ごとに「練習」と「初見」の2条件で判定（下記） |\n'
assert anchor in s
if '| 模擬試験 |' not in s:
    s = s.replace(anchor, row + anchor)
row2 = ('| 模擬試験の検証 | 作成とは別の担当が全問を検証（正答がちょうど1つか、計算は誤りの選択肢の作り方まで検算、2027年8月の本試験の時点の法令・制度・統計を一次資料で確認、手本の本試験の問題と問い方・手間・難しさを比較）。'
        'v26 で公開した%dセット・711問を検証し、正答の誤りは0件。直しは fix 44問・易しすぎ（easy）129問・細かすぎ（hard）1問で、すべて直してから公開した。'
        '易しすぎの主な理由（常識や「逆」「だけ」で消せる誤りの肢、リード文や図が答えを言っている、選択肢の並びだけで正答が当たる組み合わせ）は作り方の決まりに加え、組み合わせの問題は検査のプログラムで「並びで当たらない」ことを確かめたセットだけを公開する |\n') % n
anchor2 = '| 到達判定 | 実装済み |\n'
assert anchor2 in s
if '| 模擬試験の検証 |' not in s:
    s = s.replace(anchor2, row2 + anchor2)
old = re.search(r'模擬試験は、日程と受験の仕組みを用意し、問題を第1回（2026年12月26日・27日）から順に作成・検証して公開します（公開前の科目は「準備中」と表示）。', s)
if old:
    s = s.replace(old.group(0), '模擬試験は、第1回（2026年12月26日・27日）の7科目と、検証が済んだ第2回以降の%dセットを公開しました（まだのセットは「準備中」と表示）。' % (n - 7))
open(p, 'w', encoding='utf-8').write(s)
print(n, lines)
