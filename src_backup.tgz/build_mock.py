# 模擬試験の問題を作る：mock/m_<科目>_<回>.py → pwa/data/m_<科目>_<回>.json と pwa/data/mock.json
# ・公開するのは、全問が検証済み（mock/verified.json に問題IDがある）セットだけ。DRAFT=1 で下書きも出す
# ・MOCKDIR=別のフォルダ で、そのフォルダの問題から作る（画面の確認用）
# 問題のファイルの書き方は mock/GUIDE.md
import os, sys, json, glob, re, hashlib, importlib.util
B = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(B, 'pwa', 'data')
MD = os.environ.get('MOCKDIR') or os.path.join(B, 'mock')
DRAFT = os.environ.get('DRAFT') == '1'
sys.path.insert(0, os.path.join(B, 'text'))

# 日程：第1回は2026年12月、以後毎月の最終の土日（本試験と同じく、土曜に4科目・日曜に3科目）
# 第0回：今の実力の判定用（2026-11-17 利用者の要望）。問題数と時間は本試験の半分、難しさは同じ。得点はアプリで100点満点に換算する
ROUNDS = [(0, '2026-11-21', '2026-11-22'), (1, '2026-12-26', '2026-12-27'), (2, '2027-01-30', '2027-01-31'), (3, '2027-02-27', '2027-02-28'), (4, '2027-03-27', '2027-03-28'),
          (5, '2027-04-24', '2027-04-25'), (6, '2027-05-29', '2027-05-30'), (7, '2027-06-26', '2027-06-27')]
SUBJ = ['keizai', 'zaimu', 'kigyo', 'unei', 'homu', 'joho', 'chusho']
MIN = {'keizai': 60, 'zaimu': 60, 'kigyo': 90, 'unei': 90, 'homu': 60, 'joho': 60, 'chusho': 90}
PAIRS = ['aとb', 'aとc', 'aとd', 'bとc', 'bとd', 'cとd']
LET = 'abcd'


def hx(s):
    return hashlib.sha1(s.encode()).hexdigest()


def load(f):
    spec = importlib.util.spec_from_file_location(os.path.basename(f)[:-3], f)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


# ONLY=<科目> でその科目の全回、ONLY=<科目>_<回> でその回だけを作る（作成中の確認用。mock.json とほかのファイルには触らない）
ONLY = os.environ.get('ONLY')
OS, OR = (ONLY.split('_') + [None])[:2] if ONLY else (None, None)
# 模擬試験の図：第1回は text/fig_mk_<科目>.py、第2回以降は text/fig_mk_<科目>_<回>.py
def mkfig_of(bn):
    m = re.fullmatch(r'fig_mk_([a-z]+)(?:_(\d))?\.py', bn)
    return (m.group(1), m.group(2) or '1') if m else None


FIG, FIGERR = {}, []
for f in sorted(glob.glob(os.path.join(B, 'text', 'fig_*.py'))):
    bn = os.path.basename(f)
    mk = mkfig_of(bn)
    # 1科目（1回）だけ作るときは、ほかの科目・回の模擬試験の図（作成中のことがある）は読まない
    if mk and ONLY and (mk[0] != OS or (OR and mk[1] != OR)):
        continue
    try:
        m = load(f)
    except BaseException as ex:
        if not mk:
            raise
        # 模擬試験の図のファイルが作成中で読めないときは、その回のセットが作れないだけにする
        FIGERR.append('%s（%s）' % (bn, str(ex)[:120]))
        print('図のファイルが読めない（作成中？）:', bn, str(ex)[:200])
        continue
    dup = set(FIG) & set(m.FIG)
    if dup:
        sys.exit('重複した図の名前: %s' % sorted(dup))
    FIG.update(m.FIG)
PH = re.compile(r'^\[\[図:([^\]]+)\]\]$')


def expand(src, qid):
    out = []
    for ln in (src or '').strip().split('\n'):
        mm = PH.match(ln.strip())
        if mm:
            if mm.group(1) not in FIG:
                sys.exit('%s: 図がない: %s' % (qid, mm.group(1)))
            out.append(FIG[mm.group(1)])
        elif '[[図:' in ln:
            sys.exit('%s: [[図:…]] は独立した行に書く: %s' % (qid, ln))
        else:
            out.append(ln)
    return '\n'.join(out)


SYL = json.load(open(os.path.join(D, 'syllabus.json'), encoding='utf-8'))
ITEMS = {it['id'] for s in SYL['subjects'] for p in s['parts'] for g in p['groups'] for it in g['items']}
VER = set(json.load(open(os.path.join(B, 'mock', 'verified.json'), encoding='utf-8'))) if os.path.exists(os.path.join(B, 'mock', 'verified.json')) else set()


def relabel(s, mp):
    def one(p):
        p = re.sub(r'(?<![A-Za-z0-9_.\-=+*/^])([a-d])(?![A-Za-z0-9_.\-=+*/^])', lambda m: mp[m.group(1)], p)
        return re.sub(r'(?<![A-Za-z0-9_.\-])([a-d])と([a-d])(?![A-Za-z0-9_.\-])', lambda m: 'と'.join(sorted(m.groups())), p)
    parts = re.split(r'(\[\[図:[^\]]+\]\])', s or '')
    return ''.join(p if p.startswith('[[図:') else one(p) for p in parts)


def pair_combo(qid, x, t):
    """記述a～dの組み合わせの問題を、正答が t 番目に来るように、記述の記号だけを付け替える。
    作成者が決めた解答群の形（どの記述を判断すると正答が決まるか）はそのまま保つ（記号の置き換えで写すだけ）。
    t 番目にできないときは、できる位置のうちハッシュで選ぶ。できなければ None"""
    import itertools
    ch0, ce0, stm = list(x['ch']), list(x.get('ce') or []), list(x.get('stm') or [])
    if len(stm) != 4 or not all(c in PAIRS for c in ch0) or len(ce0) != len(ch0):
        return None
    cands = []
    for perm in itertools.permutations(LET):
        mp = dict(zip(LET, perm))
        newp = ['と'.join(sorted(mp[L] for L in p.split('と'))) for p in ch0]
        order = sorted(range(len(ch0)), key=lambda k: PAIRS.index(newp[k]))
        cands.append((order.index(x['a']), mp, order, [newp[k] for k in order]))
    hit = [c for c in cands if c[0] == t] or cands
    a, mp, order, ch = min(hit, key=lambda c: hx(qid + '#' + ''.join(c[1][L] for L in LET)))
    new = [None] * 4
    for i, L in enumerate(LET):
        new[LET.index(mp[L])] = stm[i]
    ce = [relabel(ce0[k], mp) for k in order]
    return new, ch, a, ce, mp


def build_set(f):
    m = load(f)
    s, r = m.META['s'], m.META['r']
    assert s in SUBJ and 0 <= r <= 7, f
    LEAD = getattr(m, 'LEAD', {})
    items, nos, pts = [], set(), 0
    # 正答の位置をそろえる：並べ替えてよい問題を、選択肢の数ごとに、出題順に区切ってその中で位置が重ならないようにする
    pools = {}
    for x in m.Q:
        n = len(x['ch'])
        movable = not x.get('keep')
        if movable:
            pools.setdefault(n, []).append(x['no'])
    target = {}
    for n, lst in pools.items():
        for i, no in enumerate(lst):
            b = i // n
            order = sorted(range(n), key=lambda j: hx('%s|%d|%d|%d|%d' % (s, r, n, b, j)))
            target[no] = order[i % n]
    pos = {}
    for x in m.Q:
        no = str(x['no'])
        qid = 'm%d-%s-%s' % (r, s, no)
        assert no not in nos, (qid, '番号の重複')
        nos.add(no)
        assert x['p'] in (2, 3, 4), (qid, x['p'])
        pts += x['p']
        assert x.get('t') in ITEMS, (qid, '細目', x.get('t'))
        assert x.get('lv') in ('A', 'B', 'C', 'D'), (qid, '難しさ lv')
        assert re.fullmatch(r'20\d\d-\d+(-\d+)?', str(x.get('model', ''))), (qid, '手本 model')
        ch, ce, a = list(x['ch']), list(x['ce']), x['a']
        assert 4 <= len(ch) <= 5 and len(ce) == len(ch) and 0 <= a < len(ch), qid
        assert ce[a].startswith('○') and all(c.startswith('×') for i, c in enumerate(ce) if i != a), (qid, '注の○×')
        assert len(set(ch)) == len(ch), (qid, '選択肢の重複')
        assert 'どれか。' in x['q'] or 'どれか' in x['q'], (qid, '問い方')
        stm = list(x.get('stm') or [])
        e, xs, fs = x['e'], x.get('x') or '', x.get('f') or ''
        if no in target:
            pc = pair_combo(qid, x, target[no]) if stm else None
            if pc:
                stm, ch, a, ce, mp = pc
                e, xs, fs = relabel(e, mp), relabel(xs, mp), relabel(fs, mp)
            elif all(c not in PAIRS for c in ch):
                t = target[no]
                rest = sorted([k for k in range(len(ch)) if k != a], key=lambda k: hx(qid + '|' + ch[k]))
                order = rest[:t] + [a] + rest[t:]
                ch, ce, a = [ch[k] for k in order], [ce[k] for k in order], order.index(a)
        it = {'no': no, 'p': x['p'], 'id': qid, 't': x['t'], 'lv': x['lv'], 'type': 'combo' if stm else 'single', 'q': x['q'], 'ch': ch, 'a': a, 'ce': ce, 'e': e}
        if stm:
            it['stm'] = stm
        if x.get('lead'):
            assert x['lead'] in LEAD, (qid, 'リード文がない', x['lead'])
            it['lead'] = expand(LEAD[x['lead']], qid)
        if fs:
            it['fig'] = expand(fs, qid)
        if xs:
            it['x'] = expand(xs, qid)
        pos.setdefault(len(ch), []).append(a)
        items.append(it)
    # 第0回は本試験の半分（合計46〜54点。アプリで100点満点に換算する）
    assert (pts == 100) if r else (46 <= pts <= 54), (f, '配点の合計', pts)
    ok = all(it['id'] in VER for it in items)
    # 選択肢の並びだけで正答が分かる組み合わせの問題（combo_scan.py）があるセットは出さない
    import combo_scan
    guess = [it['no'] for it in items if (combo_scan.scan_item(it) or [[]])[0]]
    if guess:
        print('  %s 第%d回：並びで正答が分かる組み合わせ %d問（%s）' % (s, r, len(guess), ' '.join(guess)))
        ok = False
    return s, r, items, ok, pos


out_sets, built, fails = {}, [], []
for f in sorted(glob.glob(os.path.join(MD, 'm_*_*.py'))):
    bn = os.path.basename(f)
    if ONLY and not (bn == 'm_%s_%s.py' % (OS, OR) if OR else bn.startswith('m_%s_' % OS)):
        continue
    try:
        s, r, items, ok, pos = build_set(f)
    except BaseException as ex:
        # 1つの回が作成中で壊れていても、ほかの回は作る（最後に失敗をまとめて知らせる）
        msg = ex.args[0] if isinstance(ex, AssertionError) and ex.args else ex
        fails.append(bn)
        print('×', bn, '作れない：', msg)
        continue
    if not (ok or DRAFT):
        print('%s 第%d回：%d問（未検証があるので出さない）' % (s, r, len(items)))
        continue
    fn = 'm_%s_%d.json' % (s, r)
    json.dump({'s': s, 'r': r, 'min': MIN[s] if r else MIN[s] // 2, 'items': items}, open(os.path.join(D, fn), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    se = {'file': fn, 'n': len(items), 'ready': True, 'draft': not ok}
    actual_min = MIN[s] if r else MIN[s] // 2
    if actual_min != MIN[s]:
        se['min'] = actual_min
    out_sets['%s-%d' % (s, r)] = se
    dist = ' '.join('%d択:%s' % (n, ''.join('アイウエオ'[i] + str(v.count(i)) for i in range(n))) for n, v in sorted(pos.items()))
    lvd = ' '.join('%s%d' % (L, sum(1 for it in items if it['lv'] == L)) for L in 'ABCD')
    print('%s 第%d回：%d問%s　正答の位置 %s　難しさ %s' % (s, r, len(items), '' if ok else '（下書き）', dist, lvd))
    built.append(fn)
if ONLY:
    sys.exit(1 if fails else 0)
# 公開しないセットのファイル（ONLY=… で作った作成・検証中の下書き）は消さない（検証の担当が画面を撮るのに使う）。
# リポジトリへは publish_sync.sh が mock.json に載っているセットだけを写す
json.dump({'ver': 1, 'rounds': [{'r': r, 'sat': a, 'sun': b} for r, a, b in ROUNDS], 'sets': out_sets},
          open(os.path.join(D, 'mock.json'), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print('mock.json：%d回・公開%dセット' % (len(ROUNDS), len(out_sets)))
if fails:
    print('作れなかったセット：', ' '.join(fails), '／読めなかった図：', ' '.join(FIGERR) or 'なし')
    sys.exit(2)
