# 模擬試験の問題を作る：mock/m_<科目>_<回>.py → pwa/data/m_<科目>_<回>.json と pwa/data/mock.json
# ・公開するのは、全問が検証済み（mock/verified.json に問題IDがある）セットだけ。DRAFT=1 で下書きも出す
# ・MOCKDIR=別のフォルダ で、そのフォルダの問題から作る（画面の確認用）
# 問題のファイルの書き方は mock/GUIDE.md
import os, sys, json, glob, re, hashlib, importlib.util
B = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(B, 'pwa', 'data')
MD = os.environ.get('MOCKDIR') or os.path.join(B, 'mock')
DRAFT = os.environ.get('DRAFT') == '1'
sys.path.insert(0, os.path.join(B, 'text'))

# 日程：第1回は2026年12月、以後毎月の最終の土日（本試験と同じく、土曜に4科目・日曜に3科目）
# 第0回：今の実力の判定用（2026-11-17 利用者の要望）。問題数と時間は本試験の半分、難しさは同じ。得点はアプリで100点満点に換算する
ROUNDS = [(0, '2026-11-21', '2026-11-22'), (1, '2026-12-26', '2026-12-27'), (2, '2027-01-30', '2027-01-31'), (3, '2027-02-27', '2027-02-28'), (4, '2027-03-27', '2027-03-28'),
          (5, '2027-04-24', '2027-04-25'), (6, '2027-05-29', '2027-05-30'), (7, '2027-06-26', '2027-06-27')]
SUBJ = ['keizai', 'zaimu', 'kigyo', 'unei', 'homu', 'joho', 'chusho']
MIN = {'keizai': 60, 'zaimu': 60, 'kigyo': 90, 'unei': 90, 'homu': 60, 'joho': 60, 'chusho': 90}
PAIRS = ['aとb', 'aとc', 'aとd', 'bとc', 'bとd', 'cとd']
LET = 'abcd'
# 第1〜4回は、本試験の半分（前半）と残りの半分（後半。約2週間後）に分けて出す（2026-11-23 利用者の決定）
HALF = {1, 2, 3, 4}
# 正誤の組み合わせの記述ごとの理由（mock/sx.json。問題IDごとに「正：…」「誤：…」）。解答群を作り直すときの注に使う
SXF = os.path.join(B, 'mock', 'sx.json')
SX = json.load(open(SXF, encoding='utf-8')) if os.path.exists(SXF) else {}
PTRE = re.compile(r'([a-e])[：:]\s*(正|誤)')
LET5 = 'abcde'


def hx(s):
    return hashlib.sha1(s.encode()).hexdigest()


def load(f):
    spec = importlib.util.spec_from_file_location(os.path.basename(f)[:-3], f)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


# ONLY=<科目> でその科目の全回、ONLY=<科目>_<回> でその回だけを作る（作成中の確認用。mock.json とほかのファイルには触らない）
ONLY = os.environ.get('ONLY')
OS, OR = (ONLY.split('_') + [None])[:2] if ONLY else (None, None)
# 模擬試験の図：第1回は text/fig_mk_<科目>.py、第2回以降は text/fig_mk_<科目>_<回>.py
def mkfig_of(bn):
    m = re.fullmatch(r'fig_mk_([a-z]+)(?:_(\d))?\.py', bn)
    return (m.group(1), m.group(2) or '1') if m else None


FIG, FIGERR = {}, []
for f in sorted(glob.glob(os.path.join(B, 'text', 'fig_*.py'))):
    bn = os.path.basename(f)
    mk = mkfig_of(bn)
    # 1科目（1回）だけ作るときは、ほかの科目・回の模擬試験の図（作成中のことがある）は読まない
    if mk and ONLY and (mk[0] != OS or (OR and mk[1] != OR)):
        continue
    try:
        m = load(f)
    except BaseException as ex:
        if not mk:
            raise
        # 模擬試験の図のファイルが作成中で読めないときは、その回のセットが作れないだけにする
        FIGERR.append('%s（%s）' % (bn, str(ex)[:120]))
        print('図のファイルが読めない（作成中？）:', bn, str(ex)[:200])
        continue
    dup = set(FIG) & set(m.FIG)
    if dup:
        sys.exit('重複した図の名前: %s' % sorted(dup))
    FIG.update(m.FIG)
PH = re.compile(r'^\[\[図:([^\]]+)\]\]$')


def expand(src, qid):
    out = []
    for ln in (src or '').strip().split('\n'):
        mm = PH.match(ln.strip())
        if mm:
            if mm.group(1) not in FIG:
                sys.exit('%s: 図がない: %s' % (qid, mm.group(1)))
            out.append(FIG[mm.group(1)])
        elif '[[図:' in ln:
            sys.exit('%s: [[図:…]] は独立した行に書く: %s' % (qid, ln))
        else:
            out.append(ln)
    return '\n'.join(out)


SYL = json.load(open(os.path.join(D, 'syllabus.json'), encoding='utf-8'))
ITEMS = {it['id'] for s in SYL['subjects'] for p in s['parts'] for g in p['groups'] for it in g['items']}
VER = set(json.load(open(os.path.join(B, 'mock', 'verified.json'), encoding='utf-8'))) if os.path.exists(os.path.join(B, 'mock', 'verified.json')) else set()


def relabel(s, mp):
    def one(p):
        p = re.sub(r'(?<![A-Za-z0-9_.\-=+*/^])([a-d])(?![A-Za-z0-9_.\-=+*/^])', lambda m: mp[m.group(1)], p)
        return re.sub(r'(?<![A-Za-z0-9_.\-])([a-d])と([a-d])(?![A-Za-z0-9_.\-])', lambda m: 'と'.join(sorted(m.groups())), p)
    parts = re.split(r'(\[\[図:[^\]]+\]\])', s or '')
    return ''.join(p if p.startswith('[[図:') else one(p) for p in parts)


def pair_combo(qid, x, t):
    """記述a～dの組み合わせの問題を、正答が t 番目に来るように、記述の記号だけを付け替える。
    作成者が決めた解答群の形（どの記述を判断すると正答が決まるか）はそのまま保つ（記号の置き換えで写すだけ）。
    t 番目にできないときは、できる位置のうちハッシュで選ぶ。できなければ None"""
    import itertools
    ch0, ce0, stm = list(x['ch']), list(x.get('ce') or []), list(x.get('stm') or [])
    if len(stm) != 4 or not all(c in PAIRS for c in ch0) or len(ce0) != len(ch0):
        return None
    cands = []
    for perm in itertools.permutations(LET):
        mp = dict(zip(LET, perm))
        newp = ['と'.join(sorted(mp[L] for L in p.split('と'))) for p in ch0]
        order = sorted(range(len(ch0)), key=lambda k: PAIRS.index(newp[k]))
        cands.append((order.index(x['a']), mp, order, [newp[k] for k in order]))
    hit = [c for c in cands if c[0] == t] or cands
    a, mp, order, ch = min(hit, key=lambda c: hx(qid + '#' + ''.join(c[1][L] for L in LET)))
    new = [None] * 4
    for i, L in enumerate(LET):
        new[LET.index(mp[L])] = stm[i]
    ce = [relabel(ce0[k], mp) for k in order]
    return new, ch, a, ce, mp


import itertools
from functools import lru_cache


def lexkey(p):
    return tuple(0 if b else 1 for b in p)


@lru_cache(None)
def templates(n, k):
    """記述 n 個・選択肢 k 個の正誤の組の型。どの肢を正答にしても同じ条件を満たすもの（正答を型のどの肢に置いても、
    多数決・少数派・違いの合計で選ぶやり方が、でたらめと同じ確率でしか当たらないようにするため）：
    どの記述も肢によって正誤が分かれる／どの肢も記述1つの正誤だけでは決まらない／星形（ある肢がほかのすべてと1か所だけ違う）でない／
    枝の偏り（ある記述の正誤で分けた3つ以上の肢で、ほかの記述の正誤が変わらない）がない。枝の偏りのない型がなければ、その条件だけ外す"""
    keys = range(n)
    allp = list(itertools.product((True, False), repeat=n))

    def ok(S, strict):
        for c in keys:
            if len({p[c] for p in S}) == 1:
                return False
        for u in S:
            for c in keys:
                if not any(v != u and v[c] == u[c] for v in S):
                    return False
        for u in S:
            if all(sum(a != b for a, b in zip(u, v)) == 1 for v in S if v != u):
                return False
        if strict:
            for x in keys:
                for val in (True, False):
                    br = [p for p in S if p[x] == val]
                    if len(br) >= 3 and any(len({p[y] for p in br}) == 1 for y in keys if y != x):
                        return False
        return True
    T = [S for S in itertools.combinations(allp, k) if ok(S, True)]
    return T or [S for S in itertools.combinations(allp, k) if ok(S, False)]


def pat_combo(qid, x, uidx):
    """正誤の組み合わせ（a：正 b：誤 …）の解答群を、型から作り直す。正答は型の uidx 番目の肢の位置に置く（正誤の入れ替えで写す）。
    注は、正答の肢は元の注、ほかの肢は記述ごとの理由（mock/sx.json）から組み立てる。理由がなければ作り直さない（None）"""
    ch0, stm = list(x['ch']), list(x.get('stm') or [])
    n, k = len(stm), len(ch0)
    keys = LET5[:n]
    P0 = [dict(PTRE.findall(c)) for c in ch0]
    if not (3 <= n <= 5 and all(set(p) == set(keys) for p in P0)):
        return None
    sx = SX.get(qid)
    if not sx:
        return None
    assert len(sx) == n, (qid, '記述ごとの理由の数')
    T = tuple(P0[x['a']][L] == '正' for L in keys)
    for j, L in enumerate(keys):
        v, _, why = sx[j].partition('：')
        assert v in ('正', '誤') and why.strip(), (qid, '理由の形', L)
        assert (v == '正') == T[j], (qid, '理由の正誤が正答と合わない', L)
    tl = templates(n, k)
    S0 = sorted(tl[int(hx(qid + '#tpl'), 16) % len(tl)], key=lexkey)
    u = S0[uidx % k]
    flip = tuple(a != b for a, b in zip(u, T))
    S2 = sorted([tuple(b != f for b, f in zip(p, flip)) for p in S0], key=lexkey)
    a = S2.index(T)
    ch = ['\u3000'.join('%s：%s' % (L, '正' if p[j] else '誤') for j, L in enumerate(keys)) for p in S2]
    ce = []
    for p in S2:
        if p == T:
            ce.append(x['ce'][x['a']])
            continue
        parts = ['%sは%s（%s）' % (L, '正しい' if T[j] else '誤り', sx[j].partition('：')[2].strip().rstrip('。')) for j, L in enumerate(keys) if p[j] != T[j]]
        ce.append('× ' + '、'.join(parts))
    return ch, a, ce


def sel_combo(qid, x, t):
    """記号の組（aとb …）の解答群を作り直す。除く組は、正答以外の5つから均等に選ぶ（正答の補集合の組も含める。
    含めないと、正答が「3回ずつ出る記号の組」に決してならず、それを除けば当たる逆の偏りになる）。注は「× cは誤り」の形で作り直す"""
    ch0, ce0, stm = list(x['ch']), list(x.get('ce') or []), list(x.get('stm') or [])
    if len(stm) != 4 or not all(c in PAIRS for c in ch0) or len(ce0) != len(ch0):
        return None
    ans = ch0[x['a']]
    suf = None
    for c in ce0:
        m = re.fullmatch(r'× [a-d](?:と[a-d])?(.*)', c)
        if m:
            suf = m.group(1)
            break
    if suf is None:
        return None
    omit = min([p for p in PAIRS if p != ans], key=lambda p: hx(qid + '#omit#' + p))
    ch1 = [p for p in PAIRS if p != omit]
    ce1 = [ce0[x['a']] if p == ans else '× ' + 'と'.join(L for L in p.split('と') if L not in ans.split('と')) + suf for p in ch1]
    return pair_combo(qid, dict(x, ch=ch1, ce=ce1, a=ch1.index(ans)), t)


SEL2PAT = re.compile(r'のうち、(?:正しい|適切な)ものの組み?合わせとして')


def sel_to_pat(q, ch, a):
    """記号の組の問題を、正誤の組み合わせの形で出す（本試験の形の割合に近づける）。肢の正誤の組は、記号の組をそのまま写す"""
    T = tuple(L in ch[a].split('と') for L in LET)
    pats = sorted([tuple(L in p.split('と') for L in LET) for p in ch], key=lexkey)
    ch2 = ['\u3000'.join('%s：%s' % (L, '正' if p[j] else '誤') for j, L in enumerate(LET)) for p in pats]
    ce2 = ['○' if p == T else '× ' + '、'.join(x for x in ('と'.join(L for j, L in enumerate(LET) if p[j] != T[j] and T[j]) + 'は正しい', 'と'.join(L for j, L in enumerate(LET) if p[j] != T[j] and not T[j]) + 'は誤り') if not x.startswith('は')) for p in pats]
    return SEL2PAT.sub('の正誤の組み合わせとして', q), ch2, pats.index(T), ce2


def build_set(f):
    m = load(f)
    s, r = m.META['s'], m.META['r']
    assert s in SUBJ and 0 <= r <= 7, f
    LEAD = getattr(m, 'LEAD', {})
    items, nos, pts = [], set(), 0
    # 正答の位置をそろえる：並べ替えてよい問題を、選択肢の数ごとに、出題順に区切ってその中で位置が重ならないようにする
    pools = {}
    for x in m.Q:
        n = len(x['ch'])
        movable = not x.get('keep')
        if movable:
            pools.setdefault(n, []).append(x['no'])
    target = {}
    for n, lst in pools.items():
        for i, no in enumerate(lst):
            b = i // n
            order = sorted(range(n), key=lambda j: hx('%s|%d|%d|%d|%d' % (s, r, n, b, j)))
            target[no] = order[i % n]
    pos = {}
    for x in m.Q:
        no = str(x['no'])
        qid = 'm%d-%s-%s' % (r, s, no)
        assert no not in nos, (qid, '番号の重複')
        nos.add(no)
        assert x['p'] in (2, 3, 4), (qid, x['p'])
        pts += x['p']
        assert x.get('t') in ITEMS, (qid, '細目', x.get('t'))
        assert x.get('lv') in ('A', 'B', 'C', 'D'), (qid, '難しさ lv')
        assert re.fullmatch(r'20\d\d-\d+(-\d+)?', str(x.get('model', ''))), (qid, '手本 model')
        ch, ce, a = list(x['ch']), list(x['ce']), x['a']
        assert 4 <= len(ch) <= 5 and len(ce) == len(ch) and 0 <= a < len(ch), qid
        assert ce[a].startswith('○') and all(c.startswith('×') for i, c in enumerate(ce) if i != a), (qid, '注の○×')
        assert len(set(ch)) == len(ch), (qid, '選択肢の重複')
        assert 'どれか。' in x['q'] or 'どれか' in x['q'], (qid, '問い方')
        stm = list(x.get('stm') or [])
        e, xs, fs = x['e'], x.get('x') or '', x.get('f') or ''
        q, repat = x['q'], False
        if r >= 1 and stm and all(c in PAIRS for c in ch):
            pc = sel_combo(qid, x, target.get(no, a))
            if pc:
                stm, ch, a, ce, mp = pc
                e, xs, fs = relabel(e, mp), relabel(xs, mp), relabel(fs, mp)
                repat = True
                if SEL2PAT.search(q) and int(hx(qid + '#asPat'), 16) % 10 < 3:
                    q, ch, a, ce = sel_to_pat(q, ch, a)
        elif r >= 1 and stm:
            uidx = PATI.setdefault((s, r), 0)
            order = sorted(range(len(ch)), key=lambda j: hx('%s|%d|pat|%d|%d' % (s, r, uidx // len(ch), j)))
            pc = pat_combo(qid, x, order[uidx % len(ch)])
            if pc:
                PATI[(s, r)] += 1
                ch, a, ce = pc
                e = re.sub(r'[^。]*正答(?:は|が)(?:1つに|一つに)?決まる。', '', e)
                repat = True
        if repat:
            pass
        elif no in target:
            pc = pair_combo(qid, x, target[no]) if stm else None
            if pc:
                stm, ch, a, ce, mp = pc
                e, xs, fs = relabel(e, mp), relabel(xs, mp), relabel(fs, mp)
            elif all(c not in PAIRS for c in ch):
                t = target[no]
                rest = sorted([k for k in range(len(ch)) if k != a], key=lambda k: hx(qid + '|' + ch[k]))
                order = rest[:t] + [a] + rest[t:]
                ch, ce, a = [ch[k] for k in order], [ce[k] for k in order], order.index(a)
        it = {'no': no, 'p': x['p'], 'id': qid, 't': x['t'], 'lv': x['lv'], 'type': 'combo' if stm else 'single', 'q': q, 'ch': ch, 'a': a, 'ce': ce, 'e': e}
        if repat:
            REPAT.add(qid)
        if stm:
            it['stm'] = stm
        if x.get('lead'):
            assert x['lead'] in LEAD, (qid, 'リード文がない', x['lead'])
            it['lead'] = expand(LEAD[x['lead']], qid)
        if fs:
            it['fig'] = expand(fs, qid)
        if xs:
            it['x'] = expand(xs, qid)
        pos.setdefault(len(ch), []).append(a)
        items.append(it)
    # 第0回は本試験の半分（合計46〜54点。アプリで100点満点に換算する）
    assert (pts == 100) if r else (46 <= pts <= 54), (f, '配点の合計', pts)
    for it in items:
        assert it['ce'][it['a']].startswith('○') and all(c.startswith('×') for i, c in enumerate(it['ce']) if i != it['a']), (it['id'], '注の○×（作り直し後）')
        assert len(set(it['ch'])) == len(it['ch']), (it['id'], '選択肢の重複（作り直し後）')
    ok = all(it['id'] in VER for it in items)
    # 選択肢の並びだけで正答が分かる組み合わせの問題（combo_scan.py）があるセットは出さない
    import combo_scan
    # 解答群を型から作り直した組み合わせ（REPAT）は、多数決などで当たる確率を全体ででたらめと同じにしているので、1問ずつの判定から外す
    guess = [it['no'] for it in items if it['id'] not in REPAT and (combo_scan.scan_item(it) or [[]])[0]]
    if guess:
        print('  %s 第%d回：並びで正答が分かる組み合わせ %d問（%s）' % (s, r, len(guess), ' '.join(guess)))
        ok = False
    return s, r, items, ok, pos


def split_half(items, s, r):
    """第1〜4回：問題番号の単位（設問がある問題と、同じリード文の問題は同じ単位）で、前半と後半に分ける。
    出題順に、配点の少ないほうへ入れる（同じくらいなら交互）。そのあと、近い位置の単位を入れ替えて、D・C・組み合わせの数と配点をそろえる。
    各半分の配点は 44〜56点。問題番号は半分ごとに1から振り直す"""
    units, where = [], {}
    for it in items:
        base = it['no'].split('-')[0]
        key = ('L', it['lead']) if it.get('lead') else ('N', base)
        k2 = ('N', base)
        idx = where.get(key, where.get(k2))
        if idx is None:
            idx = len(units)
            units.append([])
        where[key] = where[k2] = idx
        units[idx].append(it)
    asg, pts, last = [], [0, 0], 1
    for u in units:
        p = sum(it['p'] for it in u)
        if abs(pts[0] - pts[1]) <= 2:
            h = 1 - last
        else:
            h = 0 if pts[0] < pts[1] else 1
        asg.append(h)
        pts[h] += p
        last = h

    # 2026-11-23：前半と後半で難しさがそろうように、近い位置（3つ以内）の単位どうしを入れ替える。
    # D（難）・C（やや難）・組み合わせの数・配点の差が小さくなる入れ替えだけを、決まった順で行う（作るたびに同じ結果になる）
    def cnt(u, f):
        return sum(1 for it in u if f(it))

    def maj(it):
        # 組み合わせの問題で、多数決（記述ごとに多いほうの正誤に合う選択肢）が当たる確率
        try:
            return bias(it)[0] if it.get('stm') else 0.0
        except Exception:
            return 0.0

    MJ = [sum(it['p'] * maj(it) for it in u) for u in units]

    def cost(a):
        P, D, C, K, E = [0, 0], [0, 0], [0, 0], [0, 0], [0.0, 0.0]
        for u, h, mj in zip(units, a, MJ):
            P[h] += sum(it['p'] for it in u)
            D[h] += cnt(u, lambda it: it.get('lv') == 'D')
            C[h] += cnt(u, lambda it: it.get('lv') == 'C')
            K[h] += cnt(u, lambda it: bool(it.get('stm')))
            E[h] += mj
        if not all(44 <= x <= 56 for x in P):
            return None
        # E：多数決で取れる配点の見込み。半分ずつで知識なしの得点がそろうようにする
        return 3 * abs(D[0] - D[1]) + abs(C[0] - C[1]) + 2 * abs(K[0] - K[1]) + 0.5 * abs(P[0] - P[1]) + abs(E[0] - E[1])

    cur = cost(asg)
    for _ in range(60):
        best = None
        for i in range(len(units)):
            for j in range(i + 1, min(len(units), i + 4)):
                if asg[i] == asg[j]:
                    continue
                b = list(asg)
                b[i], b[j] = b[j], b[i]
                c = cost(b)
                if c is not None and (cur is None or c < cur - 1e-9) and (best is None or c < best[0] - 1e-9):
                    best = (c, b)
        if best is None:
            break
        cur, asg = best
    halves, pts = ([], []), [0, 0]
    for u, h in zip(units, asg):
        halves[h].append(u)
        pts[h] += sum(it['p'] for it in u)
    out = []
    for h in (0, 1):
        assert 44 <= pts[h] <= 56, ('%s 第%d回：半分の配点' % (s, r), pts)
        lst, n = [], 0
        for u in halves[h]:
            bases = []
            for it in u:
                b = it['no'].split('-')[0]
                if b not in bases:
                    bases.append(b)
            mp = {}
            for b in bases:
                n += 1
                mp[b] = str(n)
            for it in u:
                parts = it['no'].split('-')
                lst.append(dict(it, no='-'.join([mp[parts[0]]] + parts[1:])))
        out.append(lst)
    return out


def addd(ymd_, d):
    import datetime as _dt
    return (_dt.date.fromisoformat(ymd_) + _dt.timedelta(days=d)).isoformat()


import datetime as _dt0
NOW = _dt0.datetime.now(_dt0.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
PREV = {}
try:
    PREV = json.load(open(os.path.join(D, 'mock.json'), encoding='utf-8')).get('sets', {})
except Exception:
    PREV = {}


def rev_of(key, fn, body):
    """前に作ったファイルと中身が同じなら、前の rev のまま。違えば今の時刻（この時刻より前に受けた記録は、問題ごとの見直しを出さない）"""
    old = PREV.get(key) or {}
    try:
        prev = json.load(open(os.path.join(D, fn), encoding='utf-8'))
        same = old.get('file') == fn and json.dumps(prev.get('items'), ensure_ascii=False, sort_keys=True) == json.dumps(body.get('items'), ensure_ascii=False, sort_keys=True) and prev.get('min') == body.get('min')
    except Exception:
        same = False
    return old.get('rev') if same else NOW


PATI, REPAT, BIAS = {}, set(), {}


def bias(it):
    ch = it['ch']
    if all(c in PAIRS for c in ch):
        keys = list(LET)
        pats = [{L: (L in c.split('と')) for L in keys} for c in ch]
    else:
        pats = [dict((L, v == '正') for L, v in PTRE.findall(c)) for c in ch]
        keys = sorted(pats[0])
    k, maj = len(pats), {}
    for L in keys:
        t = sum(1 for p in pats if p[L])
        maj[L] = True if t > k - t else False if k - t > t else None
    ag = [sum(1 for L in keys if maj[L] is not None and p[L] == maj[L]) for p in pats]
    top = [i for i in range(k) if ag[i] == max(ag)]
    low = [i for i in range(k) if ag[i] == min(ag)]
    return (1 / len(top) if it['a'] in top else 0.0), (1 / len(low) if it['a'] in low else 0.0)
out_sets, built, fails = {}, [], []
for f in sorted(glob.glob(os.path.join(MD, 'm_*_*.py'))):
    bn = os.path.basename(f)
    if ONLY and not (bn == 'm_%s_%s.py' % (OS, OR) if OR else bn.startswith('m_%s_' % OS)):
        continue
    try:
        s, r, items, ok, pos = build_set(f)
    except BaseException as ex:
        # 1つの回が作成中で壊れていても、ほかの回は作る（最後に失敗をまとめて知らせる）
        msg = ex.args[0] if isinstance(ex, AssertionError) and ex.args else ex
        fails.append(bn)
        print('×', bn, '作れない：', msg)
        continue
    if not (ok or DRAFT):
        print('%s 第%d回：%d問（未検証があるので出さない）' % (s, r, len(items)))
        continue
    BIAS.setdefault(s, []).extend(bias(it) for it in items if it['id'] in REPAT)
    parts = [(r, 'm_%s_%d.json' % (s, r), items, MIN[s] if r else MIN[s] // 2)]
    if r in HALF:
        h1, h2 = split_half(items, s, r)
        parts = [(r, 'm_%s_%d.json' % (s, r), h1, MIN[s] // 2), (r + 0.5, 'm_%s_%db.json' % (s, r), h2, MIN[s] // 2)]
    for rk, fn, its, mn in parts:
        body = {'s': s, 'r': rk, 'min': mn, 'items': its}
        key = '%s-%s' % (s, rk)
        rv = rev_of(key, fn, body)
        json.dump(body, open(os.path.join(D, fn), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
        se = {'file': fn, 'n': len(its), 'ready': True, 'draft': not ok}
        if mn != MIN[s]:
            se['min'] = mn
        if rv:
            se['rev'] = rv
        out_sets[key] = se
    dist = ' '.join('%d択:%s' % (n, ''.join('アイウエオ'[i] + str(v.count(i)) for i in range(n))) for n, v in sorted(pos.items()))
    lvd = ' '.join('%s%d' % (L, sum(1 for it in items if it['lv'] == L)) for L in 'ABCD')
    print('%s 第%d回：%d問%s　正答の位置 %s　難しさ %s' % (s, r, len(items), '' if ok else '（下書き）', dist, lvd))
    built.append(fn)
if ONLY:
    sys.exit(1 if fails else 0)
# 公開しないセットのファイル（ONLY=… で作った作成・検証中の下書き）は消さない（検証の担当が画面を撮るのに使う）。
# リポジトリへは publish_sync.sh が mock.json に載っているセットだけを写す
RJ = []
for r, a, b in ROUNDS:
    if r in HALF:
        RJ.append({'r': r, 'sat': a, 'sun': b, 'half': 1})
        RJ.append({'r': r + 0.5, 'sat': addd(a, 14), 'sun': addd(b, 14), 'half': 2})
    else:
        RJ.append({'r': r, 'sat': a, 'sun': b})
# 作り直した組み合わせで、知識なしの選び方（多数決・少数派）が当たる確率（科目ごと。でたらめは約2割）
for s_ in SUBJ:
    v = BIAS.get(s_)
    if v:
        print('組み合わせの作り直し %s：%d問　多数決で当たる %.0f%%・少数派で当たる %.0f%%' % (s_, len(v), 100 * sum(x[0] for x in v) / len(v), 100 * sum(x[1] for x in v) / len(v)))
json.dump({'ver': 1, 'rounds': RJ, 'sets': out_sets},
          open(os.path.join(D, 'mock.json'), 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print('mock.json：%d回・公開%dセット' % (len(ROUNDS), len(out_sets)))
if fails:
    print('作れなかったセット：', ' '.join(fails), '／読めなかった図：', ' '.join(FIGERR) or 'なし')
    sys.exit(2)
