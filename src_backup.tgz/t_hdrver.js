// ヘッダーに版が出ることと、はみ出さないことを確かめる（スマホとパソコンの幅）
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const out = {};
  for (const [name, w, h] of [['phone', 360, 760], ['phone400', 400, 860], ['pc', 1280, 800]]) {
    const p = await b.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 1 });
    const errs = []; p.on('pageerror', e => errs.push(String(e)));
    await p.goto('http://127.0.0.1:8765/index.html'); await p.waitForTimeout(1500);
    out[name] = await p.evaluate(() => ({ ver: (document.querySelector('#hdr .ver') || {}).textContent || null, sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, hdrH: document.querySelector('#hdr').getBoundingClientRect().height }));
    out[name].errs = errs;
    if (name === 'phone') await p.screenshot({ path: 'shots/hdr_ver_phone.png', clip: { x: 0, y: 0, width: w, height: 130 } });
    await p.close();
  }
  console.log(JSON.stringify(out));
  await b.close();
})();
