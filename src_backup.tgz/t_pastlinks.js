// 過去問タブの年度ごとのリンクを撮る。node t_pastlinks.js 名前 [light|dark]
const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const name=process.argv[2]||'pl',scheme=process.argv[3]||'light';
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:400,height:860},deviceScaleFactor:2,locale:'ja-JP',timezoneId:'Asia/Tokyo',colorScheme:scheme});
  const page=await ctx.newPage();await page.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  const errs=[];page.on('pageerror',e=>errs.push(e.message));
  await ctx.addInitScript(()=>{try{if(!sessionStorage.getItem('inj')){localStorage.setItem('shindan1-tab','past');sessionStorage.setItem('inj','1');}}catch(e){}});
  await page.goto('http://127.0.0.1:8765/index.html');await page.waitForTimeout(900);
  await page.click('[data-act=scroll][data-to=pyr]');await page.waitForTimeout(600);
  await page.screenshot({path:B+'/shots/'+name+'-links.png'});
  const info=await page.evaluate(()=>{const d=document.documentElement;const links=[...document.querySelectorAll('#pyr a.lk')].map(a=>a.href);return {sw:d.scrollWidth,cw:d.clientWidth,n:links.length,first:links.slice(0,3),sai:links.filter(h=>h.includes('sai')).slice(0,2),years:document.querySelectorAll('#pyr li.pyr').length};});
  console.log(JSON.stringify({info,errs}));
  await browser.close();
})();
