# テキストのソース（text/<科目>_p*.py の T 辞書）から data/t_<科目>.json を作る
# 使い方: python3 build_text.py kigyo [ver]
import json, sys, glob, importlib.util, os
B = os.path.dirname(os.path.abspath(__file__))
s = sys.argv[1]
ver = int(sys.argv[2]) if len(sys.argv) > 2 else 1

T = {}
for f in sorted(glob.glob(os.path.join(B, 'text', s + '_p*.py'))):
    if '.before' in f:
        continue
    spec = importlib.util.spec_from_file_location(os.path.basename(f)[:-3], f)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    dup = set(T) & set(m.T)
    if dup:
        sys.exit('重複した節: %s' % sorted(dup))
    T.update(m.T)

syl = json.load(open(os.path.join(B, 'pwa/data/syllabus.json'), encoding='utf-8'))
subj = [x for x in syl['subjects'] if x['k'] == s][0]
known = set()
chapters = []
for p in subj['parts']:
    for g in p['groups']:
        secs = []
        for it in g['items']:
            known.add(it['id'])
            if it['id'] in T:
                title, content = T[it['id']]
                secs.append({'id': it['id'], 'title': title, 'content': content.strip()})
        if secs:
            chapters.append({'id': g['id'], 'title': g['n'], 'part': p['n'], 'sections': secs})

unknown = sorted(set(T) - known)
if unknown:
    sys.exit('論点表にない節: %s' % unknown)

# 書式の点検: 囲みの見出しは行頭のみ、太字の対応
for c in chapters:
    for sec in c['sections']:
        for ln in sec['content'].split('\n'):
            for tag in ('【事例】', '【試験のポイント】', '【ひっかけ注意】'):
                if tag in ln and not ln.startswith(tag):
                    sys.exit('囲みの見出しが行頭にない: %s %s' % (sec['id'], ln[:40]))
            if ln.count('**') % 2:
                sys.exit('太字の記号が対応していない: %s %s' % (sec['id'], ln[:40]))

out = {'s': s, 'ver': ver, 'chapters': chapters}
path = os.path.join(B, 'pwa/data/t_%s.json' % s)
json.dump(out, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
n = sum(len(c['sections']) for c in chapters)
chars = sum(len(x['content']) for c in chapters for x in c['sections'])
print('%s: %d章 %d節 %d字 -> %s' % (s, len(chapters), n, chars, path))
