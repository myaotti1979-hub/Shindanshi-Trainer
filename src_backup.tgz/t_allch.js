const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:375,height:760},deviceScaleFactor:1,serviceWorkers:'block'});
  const p=await ctx.newPage();
  await p.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  const errs=[];p.on('pageerror',e=>errs.push(e.message));
  await p.goto('http://127.0.0.1:8765/index.html');await p.waitForTimeout(800);
  await p.click('[data-act=tab][data-tab=drill]');await p.waitForTimeout(100);
  await p.click('[data-act=open-syl][data-s='+(process.argv[2]||'kigyo')+']');await p.waitForTimeout(150);
  const chs=await p.$$eval('[data-act=open-text][data-ch]',els=>els.map(e=>e.getAttribute('data-ch')));
  const bad=[];let total=0;
  for(const ch of chs){
    await p.click(`[data-act=open-text][data-ch="${ch}"]`);await p.waitForTimeout(120);
    const m=await p.evaluate(()=>{const r=document.querySelector('#reader');const d=document.documentElement;
      const wide=[...r.querySelectorAll('*')].filter(e=>!e.closest('.tx-fig')&&e.getBoundingClientRect().right>window.innerWidth+1).length;
      return {sw:d.scrollWidth,cw:d.clientWidth,wide,secs:r.querySelectorAll('.tx-sec').length,raw:(r.innerText.match(/\*\*|【置換|【追加】/g)||[]).length};});
    total+=m.secs; if(m.sw>m.cw||m.wide||m.raw) bad.push([ch,m]);
    if(ch===(process.argv[3]||'kigyo.2.8')){await p.evaluate((id)=>{document.getElementById(id).scrollIntoView();}, process.argv[4]||'sec-kigyo-2-8-5');await p.waitForTimeout(80);await p.screenshot({path:B+'/shots/chk-'+(process.argv[2]||'kigyo')+'.png'});}
    await p.click('[data-act=rd-close]');await p.waitForTimeout(60);
  }
  console.log(JSON.stringify({chapters:chs.length,total,bad,errs}));
  await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
