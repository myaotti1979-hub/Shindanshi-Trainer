const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
const URL='http://127.0.0.1:8765/';
(async()=>{
  const browser=await chromium.launch();
  const out={};
  const ctx=await browser.newContext({viewport:{width:400,height:860},deviceScaleFactor:1,locale:'ja-JP',timezoneId:'Asia/Tokyo',colorScheme:'light'});
  const page=await ctx.newPage();
  await page.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  const errs=[];page.on('pageerror',e=>errs.push('PAGEERR '+e.message));page.on('console',m=>{if(m.type()==='error')errs.push('console '+m.text())});
  await page.goto(URL+'index.html');await page.waitForTimeout(800);
  const ovf=async()=>page.evaluate(()=>{const d=document.documentElement;const bad=[];document.querySelectorAll('body *').forEach(el=>{const r=el.getBoundingClientRect();if(r.width>0&&r.right>d.clientWidth+1&&!el.closest('.chartbox')&&!el.closest('.pgrid'))bad.push((el.className||el.tagName)+':'+Math.round(r.right));});return {sw:d.scrollWidth,cw:d.clientWidth,bad:bad.slice(0,6)};});
  out.today=await page.$eval('#view',e=>e.innerText.slice(0,120));
  out.ovfToday=await ovf();
  await page.screenshot({path:B+'/shots/p1-today.png'});
  // installability via CDP
  await page.reload();await page.waitForTimeout(1200);
  const cdp=await ctx.newCDPSession(page);
  const inst=await cdp.send('Page.getInstallabilityErrors');out.installErrors=inst.installabilityErrors;
  const man=await cdp.send('Page.getAppManifest');out.manifestErrors=man.errors;out.manifestUrl=man.url;
  out.swControlled=await page.evaluate(()=>!!navigator.serviceWorker.controller);
  // session
  await page.click('[data-act=go][data-n="10"]');await page.waitForTimeout(150);
  await page.click('[data-act=pick][data-v="1"]');await page.click('[data-act=conf][data-c=sure]');
  await page.screenshot({path:B+'/shots/p2-reveal.png'});
  for(let i=0;i<40;i++){if(await page.$('[data-act=s-done]'))break;if(await page.$('[data-act=next]')){await page.click('[data-act=next]');continue;}await page.click('[data-act=pick][data-v="'+(i%3?1:0)+'"]');await page.click('[data-act=conf][data-c=unsure]');}
  await page.click('[data-act=s-done]');await page.waitForTimeout(600);
  out.stateAfterSession=await page.evaluate(()=>{const s=JSON.parse(localStorage.getItem('shindan1'));return {srs:Object.keys(s.srs).length,days:s.days};});
  // drill tab + syllabus
  await page.click('[data-act=tab][data-tab=drill]');await page.waitForTimeout(100);
  await page.screenshot({path:B+'/shots/p3-drill.png'});
  out.ovfDrill=await ovf();
  await page.click('[data-act=open-syl][data-s=kigyo]');await page.waitForTimeout(100);
  await page.setViewportSize({width:400,height:1600});
  await page.screenshot({path:B+'/shots/p4-syllabus.png'});
  out.ovfSyl=await ovf();
  await page.setViewportSize({width:400,height:860});
  // past grid
  await page.click('[data-act=tab][data-tab=past]');await page.waitForTimeout(100);
  await page.setViewportSize({width:400,height:1500});
  await page.screenshot({path:B+'/shots/p5-past.png'});
  out.ovfPast=await ovf();
  out.pastGridWidth=await page.$eval('.pgrid table',t=>[t.scrollWidth,t.parentElement.clientWidth]);
  await page.setViewportSize({width:400,height:860});
  // open 2024 zaimu sheet and mark answers from key partially
  await page.click('[data-act=open-sheet][data-s=zaimu][data-y="2024"]');await page.waitForTimeout(100);
  await page.screenshot({path:B+'/shots/p6-sheet.png'});
  const key=await page.evaluate(()=>fetch('data/past.json').then(r=>r.json()).then(p=>p.years.find(e=>e.y===2024).subjects.zaimu.items));
  for(let i=0;i<key.length;i++){const it=key[i];const l=i<16?it.a:(it.a==='ア'?'イ':'ア');await page.click(`[data-act=ms-mark][data-n="${it.n}"][data-l="${l}"]`);}
  await page.click('[data-act=ms-score]');await page.waitForTimeout(100);
  out.sheetScore=await page.$eval('.score b',e=>e.textContent);
  out.expected=key.slice(0,16).reduce((a,it)=>a+it.p,0);
  await page.screenshot({path:B+'/shots/p7-result.png'});
  await page.click('[data-act=tab-judge]');await page.waitForTimeout(100);
  // manual entry for 2021 zaimu and 2023 chusho (no key)
  await page.selectOption('#mn-s','zaimu');await page.selectOption('#mn-y','2021');await page.fill('#mn-p','72');await page.click('form[data-form=manual] button[type=submit]');
  await page.waitForTimeout(80);
  await page.setViewportSize({width:400,height:1700});
  await page.screenshot({path:B+'/shots/p8-judge.png'});
  out.ovfJudge=await ovf();
  out.judgeText=await page.$eval('#view',e=>e.innerText.slice(0,400));
  await page.setViewportSize({width:400,height:860});
  // reserved year gate
  await page.click('[data-act=tab][data-tab=past]');await page.click('[data-act=open-sheet][data-s=zaimu][data-y="2026"]');await page.waitForTimeout(80);
  out.gate=await page.$eval('#msheet',e=>e.innerText.slice(0,40));
  await page.click('[data-act=ms-close]');
  // no-key cell
  await page.click('[data-act=open-sheet][data-s=chusho][data-y="2021"]');await page.waitForTimeout(120);
  out.noKeyTab=await page.evaluate(()=>[document.querySelector('.tab[aria-current]').innerText,document.getElementById('mn-s').value,document.getElementById('mn-y').value]);
  // log tab
  await page.click('[data-act=tab][data-tab=log]');await page.waitForTimeout(80);
  await page.setViewportSize({width:400,height:1500});
  await page.screenshot({path:B+'/shots/p9-log.png'});
  out.ovfLog=await ovf();
  // offline reload
  await ctx.setOffline(true);
  await page.reload();await page.waitForTimeout(800);
  out.offline=await page.$eval('#view',e=>e.innerText.slice(0,60));
  await ctx.setOffline(false);
  out.errs=errs;
  // fixture: mc + combo rendering
  const ctx2=await browser.newContext({viewport:{width:400,height:860},deviceScaleFactor:1,colorScheme:'dark'});
  const p2=await ctx2.newPage();
  await p2.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  await p2.route('**/data/q_kigyo.json',async r=>{const res=await r.fetch();const j=await res.json();j.questions=[
    {id:'t-mc',type:'mc',t:'kigyo.1.3.3',q:'テスト用の単答問題。最も適切なものはどれか。',ch:['選択肢アの記述','選択肢イの記述','選択肢ウの記述','選択肢エの記述'],a:2,e:'解説',ce:['アの解説','イの解説','ウの解説','エの解説'],st:'ok',n:1},
    {id:'t-cb',type:'combo',t:'kigyo.1.3.3',q:'次の記述a〜dのうち、正しいものの組み合わせとして、最も適切なものはどれか。',stm:['記述aの文','記述bの文','記述cの文','記述dの文'],ch:['aとb','aとc','bとd','cとd'],a:1,e:'解説',st:'ok',n:2}
  ];await r.fulfill({response:res,json:j});});
  await p2.goto(URL+'index.html');await p2.waitForTimeout(600);
  await p2.evaluate(()=>{localStorage.setItem('shindan1',JSON.stringify({v:1,settings:{active:['kigyo']},srs:{},days:{},past:[],flags:{},timer:null}));});
  await p2.reload();await p2.waitForTimeout(600);
  await p2.click('[data-act=go][data-n="10"]');await p2.waitForTimeout(100);
  const first=await p2.$eval('.s-q',e=>e.textContent);
  await p2.click('[data-act=pick][data-v="1"]');await p2.click('[data-act=conf][data-c=sure]');
  await p2.screenshot({path:B+'/shots/d1-mc.png'});
  await p2.click('[data-act=next]');await p2.waitForTimeout(80);
  await p2.screenshot({path:B+'/shots/d2-combo.png'});
  out.fixtureFirst=first.slice(0,12);
  await browser.close();
  console.log(JSON.stringify(out,null,1));
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
