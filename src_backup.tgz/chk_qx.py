# 演習の解説の図が展開されているかを確かめる（xsrc/fsrcが残っていない・[[図:]]が残っていない・xに<svg>がある）
import json,glob
tot=0;nosvg=[];bad=[];left=[];nx=0
for f in sorted(glob.glob('pwa/data/q_*.json')):
    d=json.load(open(f,encoding='utf-8'))
    qs=d['questions']
    n=0;sv=0
    for q in qs:
        n+=1
        if 'xsrc' in q or 'fsrc' in q: bad.append(q.get('id'))
        for k in ('x','f'):
            if q.get(k) and '[[図:' in q[k]: left.append((q.get('id'),k))
        if q.get('x'):
            if '<svg' in q['x']: sv+=1
            else: nosvg.append(q.get('id'))
    tot+=n
    print(f, n, 'x with svg', sv)
print('total',tot,'x without svg',len(nosvg),nosvg[:8],'xsrc/fsrc',len(bad),'unexpanded',left[:8])
