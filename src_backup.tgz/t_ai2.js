// AI採点（2次の記述式演習）を、偽の Anthropic API で確かめる
// 使い方：node t_ai2.js   （pwa/ を自分で配信する。API は page.route で差し替える）
const http = require('http'), fs = require('fs'), path = require('path'), assert = require('assert');
const S = '/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/';
const ROOT = S + 'pwa';
const srv = http.createServer((q, r) => {
  const u = decodeURIComponent(q.url.split('?')[0]);
  const f = path.join(ROOT, u === '/' ? 'index.html' : u);
  try { const d = fs.readFileSync(f); const t = f.endsWith('.json') ? 'application/json' : f.endsWith('.js') ? 'text/javascript' : f.endsWith('.png') ? 'image/png' : 'text/html'; r.writeHead(200, { 'Content-Type': t + '; charset=utf-8' }); r.end(d); }
  catch (e) { r.writeHead(404); r.end('nf'); }
});
const GOOD = { score: 14, grade: 'B', feedback: '強みは書けている。弱みに権限の集中が足りない。', keywords_hit: ['熟練職人/手作り'], keywords_miss: ['権限集中/意思決定の遅さ'] };

srv.listen(0, async () => {
  const port = srv.address().port, URL0 = 'http://127.0.0.1:' + port + '/';
  const { chromium } = require('playwright');
  const b = await chromium.launch();
  const errs = [];
  async function page(mode) {
    const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: 'block' });
    await ctx.addInitScript(() => { try { localStorage.setItem('shindan2-aikey', 'sk-ant-test'); localStorage.setItem('shindan1-stage', 's2'); } catch (e) {} });
    const p = await ctx.newPage();
    p.on('pageerror', e => errs.push(mode + ': ' + e.message));
    const log = [];
    p.__delay = 0;
    await p.route('https://api.anthropic.com/**', async (route) => {
      if (p.__delay) { const d = p.__delay; p.__delay = 0; await new Promise(r => setTimeout(r, d)); }
      const req = route.request(), url = req.url(), body = req.postData() ? JSON.parse(req.postData()) : null, h = req.headers();
      log.push({ url, body, h });
      const json = (st, o) => route.fulfill({ status: st, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(o) });
      if (url.endsWith('/v1/models?limit=100')) return json(200, { data: [{ id: 'claude-opus-6' }, { id: 'claude-sonnet-6' }, { id: 'claude-sonnet-5-5' }] });
      if (mode === 'retired' && body && body.model === 'claude-sonnet-5-5') return json(404, { type: 'error', error: { type: 'not_found_error', message: 'model: claude-sonnet-5-5' } });
      if (mode === 'badkey') return json(401, { type: 'error', error: { type: 'authentication_error', message: 'invalid x-api-key' } });
      return json(200, { content: [{ type: 'thinking', thinking: '', signature: 'sig' }, { type: 'text', text: JSON.stringify(GOOD) }], stop_reason: 'end_turn' });
    });
    await p.goto(URL0);
    await p.waitForTimeout(1200);
    await p.click('[data-stage="s2"]');
    await p.click('[data-tab="jex"]');
    await p.waitForTimeout(500);
    await p.click('[data-act="ex-open"]');
    await p.waitForTimeout(300);
    return { p, ctx, log };
  }
  async function answerAndGrade(p) {
    const tas = p.locator('.ex-ta');
    await tas.nth(0).fill('熟練職人の手作り製法と、地元で長年培ったブランド力である。');
    await tas.nth(1).fill('技術の属人化で、後継者の育成が遅れている。');
    await p.click('[data-act="ex-grade"]');
    await p.waitForTimeout(800);
  }

  // 1. ふつうに採点：既定のモデル、考える過程のあとの本文を読む
  {
    const { p, ctx, log } = await page('ok');
    await answerAndGrade(p);
    const m = log.filter(x => x.url.endsWith('/v1/messages'));
    assert(m.length >= 1, 'API を呼んでいない');
    assert.strictEqual(m[0].body.model, 'claude-sonnet-5-5', 'モデルが Sonnet 5.5 でない');
    assert(m[0].body.max_tokens >= 2000, 'max_tokens が小さい');
    assert(!('temperature' in m[0].body), 'temperature を送っている');
    assert.strictEqual(m[0].h['x-api-key'], 'sk-ant-test');
    assert.strictEqual(m[0].h['anthropic-version'], '2023-06-01');
    const sc = await p.locator('#exq1 .ex-score').textContent();
    assert.strictEqual(sc.trim(), '14', '採点の結果が出ない');
    const saved = await p.evaluate(() => JSON.parse(localStorage.getItem('shindan2')).ex['ex1-01'][1].grade);
    assert.strictEqual(saved.score, 14); assert(saved.at > 0, '採点の時刻がない');
    await p.screenshot({ path: S + 'v47_ai_ok.png', fullPage: false });
    // 2. 書き直すと前の採点が消え、採点し直せる
    await p.locator('#exq1 .ex-ta').nth(0).fill('熟練職人の手作り製法と、地元での高い知名度である。');
    await p.click('body', { position: { x: 5, y: 5 } });
    await p.waitForTimeout(300);
    assert.strictEqual(await p.locator('#exq1 .ex-score').count(), 0, '書き直しても前の採点が残っている');
    const g2 = await p.evaluate(() => JSON.parse(localStorage.getItem('shindan2')).ex['ex1-01'][1].grade);
    assert(!g2, '保存された前の採点が残っている');
    await p.click('[data-act="ex-grade"]'); await p.waitForTimeout(800);
    assert.strictEqual((await p.locator('#exq1 .ex-score').textContent()).trim(), '14', '採点し直せない');
    // 3. 書いている途中に採点の結果が届いて描き直しが起きても、書いている欄は消えない
    await p.locator('#exq1 .ex-ta').nth(0).fill('熟練職人の手作り製法と、地元での長年のブランド力である。');
    p.__delay = 1500;
    await p.click('[data-act="ex-grade"]');
    const ta = p.locator('#exq2 .ex-ta').nth(0);
    await ta.click(); await ta.press('End'); await ta.type('追記');
    await p.waitForTimeout(2200);
    const still = await p.evaluate(() => document.activeElement && document.activeElement.classList.contains('ex-ta'));
    assert(still, '描き直しで書いている欄から外れた');
    assert(/追記$/.test(await ta.inputValue()), '書いた文字が消えた');
    await p.click('body', { position: { x: 5, y: 5 } }); await p.waitForTimeout(300);
    assert.strictEqual((await p.locator('#exq1 .ex-score').textContent()).trim(), '14', '欄を離れたあとに採点の結果が出ない');
    console.log('1〜3 採点・書き直し・書いている途中の描き直し：ok');
    await ctx.close();
  }
  // 4. モデルの提供が終わっていたら、一覧から新しい Sonnet を選び直してやり直す
  {
    const { p, ctx, log } = await page('retired');
    await answerAndGrade(p);
    const m = log.filter(x => x.url.endsWith('/v1/messages')).map(x => x.body.model);
    assert.deepStrictEqual(m.slice(0, 2), ['claude-sonnet-5-5', 'claude-sonnet-6'], '選び直していない：' + m.join(','));
    assert.strictEqual(await p.evaluate(() => localStorage.getItem('shindan2-aimodel')), 'claude-sonnet-6', '選んだモデルを覚えていない');
    assert.strictEqual((await p.locator('#exq1 .ex-score').textContent()).trim(), '14');
    console.log('4 提供が終わったモデルの選び直し：ok');
    await ctx.close();
  }
  // 5. キーが違うときは、分かる言葉で知らせる
  {
    const { p, ctx } = await page('badkey');
    await answerAndGrade(p);
    const t = await p.locator('#toast, .toast').first().textContent().catch(() => '');
    assert(/APIキーが正しくありません/.test(t), 'キーの誤りの知らせが出ない：' + t);
    assert.strictEqual(await p.locator('#exq1 .ex-score').count(), 0);
    console.log('5 キーの誤りの知らせ：ok');
    await ctx.close();
  }
  await b.close(); srv.close();
  const bad = errs.filter(e => !/ERR_FAILED|fonts/.test(e));
  if (bad.length) { console.error('ページのエラー', bad); process.exit(1); }
  console.log('すべて ok');
});
