import json, os
B=os.path.dirname(os.path.abspath(__file__))  # 写しの中で実行しても、その写しに書く
P=B+"/pwa/data/past.json"
syl=json.load(open(B+"/pwa/data/syllabus.json",encoding="utf-8"))
items={it["id"] for s in syl["subjects"] for p in s["parts"] for g in p["groups"] for it in g["items"]}
T={
(2024,"zaimu"):{"1":"zaimu.1.1.3","2":"zaimu.1.2.2","3":"zaimu.1.2.2","4":"zaimu.1.2.2","5":"zaimu.1.2.1","6":"zaimu.1.2.2","7":"zaimu.1.2.3","8":"zaimu.1.2.5","9":"zaimu.1.3.2","10":"zaimu.1.4.2","11":"zaimu.1.5.1","12-1":"zaimu.1.5.2","12-2":"zaimu.1.5.2","13":"zaimu.1.7.1","14":"zaimu.1.7.2","15":"zaimu.1.7.3","16":"zaimu.1.10.1","17":"zaimu.1.8.2","18":"zaimu.1.8.1","19":"zaimu.1.9.2","20":"zaimu.1.9.1","21":"zaimu.1.10.1","22":"zaimu.1.10.2","23":"zaimu.1.10.3","24":"zaimu.1.11.2"},
(2024,"kigyo"):{"1":"kigyo.1.1.3","2":"kigyo.1.1.5","3":"kigyo.1.2.2","4":"kigyo.1.2.3","5":"kigyo.1.2.5","6":"kigyo.1.2.4","7":"kigyo.1.3.1","8":"kigyo.1.3.2","9":"kigyo.1.4.2","10":"kigyo.1.4.2","11":"kigyo.1.5.2","12":"kigyo.1.6.1","13":"kigyo.1.4.3","14":"kigyo.2.1.3","15":"kigyo.2.3.1","16":"kigyo.2.4.1","17":"kigyo.2.5.1","18":"kigyo.2.4.2","19":"kigyo.2.4.2","20":"kigyo.2.5.2","21":"kigyo.2.6.4","22":"kigyo.2.7.3","23":"kigyo.2.7.4","24":"kigyo.2.8.1","25":"kigyo.2.8.1","26":"kigyo.2.8.1","27":"kigyo.2.8.1","28":"kigyo.3.6.3","29":"kigyo.3.2.3","30":"kigyo.3.6.3","31":"kigyo.3.4.5","32":"kigyo.3.9.5","33":"kigyo.3.9.5","34":"kigyo.3.10.4","35":"kigyo.3.10.2","36":"kigyo.3.5.2","37":"kigyo.3.8.5","38-1":"kigyo.3.7.1","38-2":"kigyo.3.7.3","39":"kigyo.3.3.2","40":"kigyo.3.3.2"},
(2024,"unei"):{"1":"unei.1.2.5","2":"unei.1.2.9","3":"unei.1.2.10","4":"unei.1.2.6","5":"unei.1.2.8","6":"unei.1.3.1","7-1":"unei.1.5.5","7-2":"unei.1.5.5","8":"unei.1.4.2","9":"unei.1.4.5","10":"unei.1.2.2","11":"unei.1.4.4","12":"unei.1.4.4","13":"unei.1.5.1","14":"unei.1.5.2","15":"unei.1.5.3","16":"unei.1.3.2","17":"unei.1.5.4","18":"unei.1.4.5","19":"unei.1.5.5","20":"unei.1.2.3","21":"unei.1.5.6","22":"unei.2.1.3","23":"unei.2.1.1","24":"unei.2.1.1","25":"unei.2.1.1","26":"unei.2.1.3","27":"unei.2.2.1","28":"unei.2.2.4","29":"unei.2.2.5","30":"unei.2.2.1","31":"unei.2.2.1","32":"unei.2.2.3","33":"unei.2.3.1","34":"unei.2.3.1","35":"unei.2.3.2","36":"unei.2.3.2","37":"unei.2.3.3","38":"unei.2.3.3","39":"unei.2.4.2","40":"unei.2.4.3","41":"unei.2.4.1","42":"unei.2.4.1","43":"unei.2.4.1"},
}
past=json.load(open(P,encoding="utf-8"))
for (y,s),m in T.items():
    e=[x for x in past["years"] if x["y"]==y][0]
    its=e["subjects"][s]["items"]
    ns=[i["n"] for i in its]
    assert set(ns)==set(m), (y,s,set(ns)^set(m))
    for i in its:
        assert m[i["n"]] in items,(y,s,i["n"],m[i["n"]])
        i["t"]=m[i["n"]]
json.dump(past,open(P,"w",encoding="utf-8"),ensure_ascii=False,separators=(",",":"))
print("tagged", sum(len(m) for m in T.values()))
