
(function(){
'use strict';
document.documentElement.lang='ja';

/* ---------- constants ---------- */
const SUBJ=[
  {k:'keizai',n:'経済学・経済政策',sh:'経済',tg:55,vol:5},
  {k:'zaimu',n:'財務・会計',sh:'財務',tg:80,vol:5},
  {k:'kigyo',n:'企業経営理論',sh:'企業',tg:65,vol:5},
  {k:'unei',n:'運営管理',sh:'運営',tg:60,vol:10},
  {k:'homu',n:'経営法務',sh:'法務',tg:65,vol:10},
  {k:'joho',n:'経営情報システム',sh:'情報',tg:60,vol:5},
  {k:'chusho',n:'中小企業経営・政策',sh:'中小',tg:65,vol:10}
];
const SN={}; SUBJ.forEach(s=>{SN[s.k]=s;});
const TOPICS={
  keizai:['国民経済計算と経済指標','45度線分析と乗数','IS-LMモデル','AD-AS・物価と失業','財政政策と金融政策','国際経済と為替','経済成長','消費者行動','生産者行動と費用','市場均衡と余剰','弾力性','不完全競争とゲーム理論','市場の失敗'],
  zaimu:['簿記と財務諸表','会計基準','キャッシュフロー計算書','原価計算','経営分析','CVP分析','投資の経済性計算','資本コスト','企業価値と株式評価','資本構成と配当政策','ポートフォリオとリスク','デリバティブと為替'],
  kigyo:['経営戦略の基礎','成長戦略と多角化','競争戦略','経営資源とVRIO','イノベーションと技術経営','組織構造','モチベーション','リーダーシップ','組織文化・組織学習・組織変革','人的資源管理','労働関連法規','マーケティングの基礎とSTP','製品・価格・チャネル・プロモーション','消費者行動とデジタルマーケティング'],
  unei:['生産形態と生産方式','工場レイアウト','生産計画と統制','在庫管理と発注方式','IE（工程分析・作業測定）','品質管理','設備保全','生産情報システム','店舗立地と関連法規','店舗施設とレイアウト','商品計画と予算','物流','販売流通情報システム'],
  homu:['会社法（設立・機関・株式）','組織再編','民法（契約・債権・相続）','特許権・実用新案権','意匠権・商標権','著作権','不正競争防止法','独占禁止法と取引の適正化','倒産処理','英文契約・国際取引','資本市場と金融商品取引法'],
  joho:['ハードウェア','ソフトウェアとOS','アルゴリズムとプログラミング','データベースとSQL','ネットワーク','セキュリティ','システム開発手法','プロジェクト管理','経営戦略と情報システム','統計・データ分析','AIと新技術'],
  chusho:['中小企業の定義','中小企業白書：動向と統計','中小企業白書：テーマ分析','小規模企業白書','創業・事業承継の支援','金融支援','税制','経営基盤の強化と認定制度','取引の適正化','共済制度と小規模企業の支援']
};
const DEF={wdMin:60,weMin:180,newPerDay:15,exam1:'2027-08-07',exam2:'2027-10-24',active:['kigyo','unei','zaimu'],start:'2026-11-09'};
const YEARS=[[2026,'令和8'],[2025,'令和7'],[2024,'令和6'],[2023,'令和5'],[2022,'令和4'],[2021,'令和3'],[2020,'令和2'],[2019,'令和元'],[2018,'平成30'],[2017,'平成29']];
const DAY=864e5;
const PAST_URL='https://www.jf-cmca.jp/contents/010_c_/shikenmondai.html';
const ICON_O='<svg viewBox="0 0 40 40" width="40" height="40" aria-hidden="true"><circle cx="20" cy="20" r="13" fill="none" stroke="currentColor" stroke-width="4"/></svg>';
const ICON_X='<svg viewBox="0 0 40 40" width="40" height="40" aria-hidden="true"><path d="M10 10L30 30M30 10L10 30" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/></svg>';

/* ---------- helpers ---------- */
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad=n=>String(n).padStart(2,'0');
const ymd=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const todayKey=()=>ymd(new Date());
const parseYmd=s=>{const p=String(s||'').split('-').map(Number);return new Date(p[0],(p[1]||1)-1,p[2]||1);};
const startOfDay=t=>{const d=new Date(t);d.setHours(0,0,0,0);return d.getTime();};
const endOfToday=()=>{const d=new Date();d.setHours(23,59,59,999);return d.getTime();};
const daysUntil=s=>Math.round((parseYmd(s).getTime()-startOfDay(Date.now()))/DAY);
const fmtH=min=>(Math.round((min||0)/6)/10).toFixed(1);
const md=d=>(d.getMonth()+1)+'/'+d.getDate();
const yearLabel=y=>{const f=YEARS.find(x=>x[0]===+y);return f?f[1]+'年度':y+'年度';};
const cl=(x,a,b)=>Math.min(b,Math.max(a,x));
function fmtClock(ms){const s=Math.max(0,Math.floor(ms/1000));const h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;return h?h+':'+pad(m)+':'+pad(x):pad(m)+':'+pad(x);}
function lsGet(k){try{return localStorage.getItem(k);}catch(e){return null;}}
function lsSet(k,v){try{if(v==null)localStorage.removeItem(k);else localStorage.setItem(k,v);}catch(e){}}

/* ---------- FSRS-4.5 scheduler ---------- */
const W=[0.4872,1.4003,3.7145,13.8206,5.1618,1.2298,0.8975,0.031,1.6474,0.1367,1.0461,2.1072,0.0793,0.3246,1.587,0.2272,2.8755];
const DECAY=-0.5,FACTOR=19/81,RET=0.9,MAXI=60;
const d0=g=>cl(W[4]-(g-3)*W[5],1,10);
function fsrs(prev,g,now){
  let s,d;
  if(!prev||!prev.st){s=W[g-1];d=d0(g);}
  else{
    const t=Math.max(0,(now-(prev.last||now))/DAY);
    const r=Math.pow(1+FACTOR*t/prev.st,DECAY);
    if(g===1){s=W[11]*Math.pow(prev.df,-W[12])*(Math.pow(prev.st+1,W[13])-1)*Math.exp((1-r)*W[14]);s=Math.min(s,prev.st);}
    else{s=prev.st*(1+Math.exp(W[8])*(11-prev.df)*Math.pow(prev.st,-W[9])*(Math.exp((1-r)*W[10])-1)*(g===2?W[15]:1));}
    d=cl(W[7]*d0(4)+(1-W[7])*(prev.df-W[6]*(g-3)),1,10);
  }
  s=Math.max(0.1,s);
  let due;
  if(g===1){due=now+10*60000;}
  else{const iv=cl(Math.round(s/FACTOR*(Math.pow(RET,1/DECAY)-1)),1,MAXI);due=startOfDay(now)+iv*DAY+4*3600000;}
  return {st:+s.toFixed(4),df:+d.toFixed(4),last:now,due:due,reps:((prev&&prev.reps)||0)+1,lapses:((prev&&prev.lapses)||0)+(g===1&&prev&&prev.st?1:0)};
}

/* ---------- state ---------- */
const S={db:null,sample:null,sampleOff:false,mode:'connecting',slow:false,dead:false,parts:{},
  cards:new Map(),srs:new Map(),days:new Map(),mocks:new Map(),settings:Object.assign({},DEF),got:{},
  tab:lsGet('sd1-tab')||'today',sess:null,timer:null,toastT:0,lastAdd:null,armDel:null,dirty:false,
  gen:{s:'kigyo',t:'',custom:'',n:'5',state:'idle',items:[],msg:''},
  mockDraft:{s:'zaimu',y:'2025',p:''},setDraft:null,verify:{}};
if(!['today','cards','sim','log'].includes(S.tab)) S.tab='today';
{const t=Number(lsGet('sd1-timer'));if(t>0&&Date.now()-t<12*3600000)S.timer=t;else lsSet('sd1-timer',null);}

/* ---------- storage: claude db, or this browser as a fallback ---------- */
const COLLS=['cards','days','mocks','settings'];
const Local={data:{cards:{},srs:{},days:{},mocks:{},settings:{}},subs:{},
  load(){const j=lsGet('sd1-local');if(j){try{Object.assign(this.data,JSON.parse(j));}catch(e){}}},
  save(){lsSet('sd1-local',JSON.stringify(this.data));},
  rows(c){return Object.keys(this.data[c]||{}).map(id=>({id:id,v:this.data[c][id]}));},
  watch(c,f){(this.subs[c]=this.subs[c]||[]).push(f);setTimeout(()=>f(this.rows(c)),0);},
  emit(c){(this.subs[c]||[]).forEach(f=>f(this.rows(c)));},
  set(c,id,v){(this.data[c]=this.data[c]||{})[id]=v;this.save();this.emit(c);return Promise.resolve();},
  del(c,id){if(this.data[c])delete this.data[c][id];this.save();this.emit(c);return Promise.resolve();}
};
const Remote={
  watch(c,f,onErr){
    if(c==='settings') return S.db.doc('settings/main').onSnapshot(sn=>f(sn.exists?[{id:'main',v:sn.data()}]:[]),onErr);
    return S.db.collection(c).limit(1000).onSnapshot(sn=>f(sn.docs.map(d=>({id:d.id,v:d.data()}))),onErr);
  },
  /* one listener per subject keeps each window under the 1,000-document query limit */
  watchCards(f,onErr){
    SUBJ.forEach(s=>{S.db.collection('cards').where('s','==',s.k).limit(1000).onSnapshot(sn=>f(s.k,sn.docs.map(d=>({id:d.id,v:d.data()}))),onErr);});
  },
  set(c,id,v){return S.db.doc(c+'/'+id).set(v);},
  del(c,id){return S.db.doc(c+'/'+id).delete();}
};
const store=()=>S.mode==='remote'?Remote:Local;
const queues=new Map();
function write(key,fn){
  const p=(queues.get(key)||Promise.resolve()).then(fn).catch(err=>{console.warn(err);toast(dbErr(err));});
  queues.set(key,p);return p;
}
function mapOf(c){return c==='cards'?S.cards:c==='days'?S.days:c==='mocks'?S.mocks:null;}
/* a card's review schedule lives on the card itself (field r); S.srs is the derived index */
function put(c,id,v){
  if(c==='settings')S.settings=Object.assign({},DEF,v);
  else{const m=mapOf(c);if(m)m.set(id,v);if(c==='cards'){if(v.r)S.srs.set(id,v.r);else S.srs.delete(id);}}
  return write(c+'/'+id,()=>store().set(c,id,v));
}
function remove(c,id){const m=mapOf(c);if(m)m.delete(id);if(c==='cards')S.srs.delete(id);return write(c+'/'+id,()=>store().del(c,id));}
function onRows(c,rows){
  if(c==='cards'){onCardRows('all',rows);return;}
  if(c==='settings'){const r=rows.find(x=>x.id==='main');S.settings=Object.assign({},DEF,r?r.v:{});}
  else{const m=new Map();rows.forEach(r=>m.set(r.id,r.v));if(c==='days')S.days=m;else S.mocks=m;}
  S.got[c]=true;schedRender();
}
function onCardRows(part,rows){
  S.parts[part]=rows;
  const m=new Map(),r=new Map();
  Object.keys(S.parts).forEach(k=>S.parts[k].forEach(x=>{m.set(x.id,x.v);if(x.v&&x.v.r)r.set(x.id,x.v.r);}));
  S.cards=m;S.srs=r;
  if(S.mode!=='remote'||Object.keys(S.parts).length>=SUBJ.length)S.got.cards=true;
  schedRender();
}
function dbErr(e){const c=e&&e.code;
  if(c==='quota_exceeded')return '保存容量の上限に達しました。不要なカードを削除してください';
  if(c==='revoked'||c==='not_granted'||c==='invalid_argument')return '保存できませんでした。アプリを開き直してください';
  return '保存に失敗しました。通信状況を確認してください';}
function sampleErr(e){const c=e&&e.code;
  if(['not_granted','sampling_disabled','not_declared','capability_disabled','capability_removed'].includes(c)){S.sampleOff=true;return 'このアプリからClaudeを使えない設定になっています';}
  if(c==='rate_limited')return '利用が混み合っています。少し時間をおいて試してください';
  if(c==='refused')return 'この内容では作成できませんでした。論点を変えて試してください';
  if(c==='invalid_json'||c==='empty_completion')return '結果を読み取れませんでした。もう一度試してください';
  if(c==='session_expired')return 'サインインし直してください';
  return '通信に失敗しました。もう一度試してください';}

/* ---------- derived numbers ---------- */
function weekStart(t){const x=new Date(t);x.setHours(0,0,0,0);x.setDate(x.getDate()-(x.getDay()+6)%7);return x;}
function weekStats(back){
  const s=weekStart(Date.now());s.setDate(s.getDate()-7*back);
  let min=0;const days=[];
  for(let i=0;i<7;i++){const d=new Date(s);d.setDate(s.getDate()+i);const v=S.days.get(ymd(d))||{};min+=v.min||0;days.push({d:d,min:v.min||0});}
  return {start:s,min:min,days:days};
}
const weeklyTarget=()=>S.settings.wdMin*5+S.settings.weMin*2;
function counts(){
  const eod=endOfToday();let due=0,avail=0;
  S.cards.forEach((c,id)=>{if(c.flag)return;const r=S.srs.get(id);if(r){if(r.due<=eod)due++;}else if(S.settings.active.includes(c.s))avail++;});
  const td=S.days.get(todayKey())||{};const quota=Math.max(0,S.settings.newPerDay-(td.nw||0));
  return {due:due,avail:avail,newToday:Math.min(quota,avail)};
}
function weakTopics(n){
  const m={};
  S.srs.forEach((r,id)=>{const c=S.cards.get(id);if(!c||c.flag)return;const k=c.s+'|'+c.t;const o=m[k]||(m[k]={s:c.s,t:c.t,att:0,cor:0,cw:0});o.att+=r.att||0;o.cor+=r.cor||0;o.cw+=r.cw||0;});
  return Object.keys(m).map(k=>m[k]).filter(o=>o.att>=3).map(o=>Object.assign(o,{acc:Math.round(o.cor/o.att*100)}))
    .filter(o=>o.acc<80||o.cw>0).sort((a,b)=>(a.acc-b.acc)||(b.cw-a.cw)).slice(0,n);
}
function subjStats(k){
  let tot=0,lr=0,due=0,att=0,cor=0;const eod=endOfToday();
  S.cards.forEach((c,id)=>{if(c.s!==k||c.flag)return;tot++;const r=S.srs.get(id);if(r){lr++;if(r.due<=eod)due++;att+=r.att||0;cor+=r.cor||0;}});
  return {tot:tot,lr:lr,due:due,acc:att?Math.round(cor/att*100):null};
}
function estimates(){
  const by={};S.mocks.forEach(m=>{(by[m.s]=by[m.s]||[]).push(m);});
  return SUBJ.map(s=>{const ms=(by[s.k]||[]).slice().sort((a,b)=>(b.at||0)-(a.at||0));const rec=ms.slice(0,2);
    return {s:s,n:ms.length,est:rec.length?Math.round(rec.reduce((a,m)=>a+m.sc,0)/rec.length):null,cardAcc:subjStats(s.k).acc};});
}

/* ---------- rendering ---------- */
let rq=0;
function schedRender(){if(rq)return;rq=requestAnimationFrame(()=>{rq=0;render();});}
function render(){
  renderHeader();
  const mb=$('#modebar');
  if(S.dead){mb.textContent='データとの接続が切れました。アプリを開き直してください。';mb.hidden=false;}
  else if(S.mode==='local'){mb.textContent='この端末のブラウザにだけ保存しています。claude.aiかClaudeアプリで開くと、学習記録が同期されます。';mb.hidden=false;}
  else mb.hidden=true;
  const v=$('#view');const ae=document.activeElement;
  if(ae&&v.contains(ae)&&(ae.tagName==='TEXTAREA'||(ae.tagName==='INPUT'&&ae.type!=='checkbox'))){S.dirty=true;}
  else{
    const fid=ae&&v.contains(ae)?ae.id:'';
    v.innerHTML=S.tab==='cards'?viewCards():S.tab==='sim'?viewSim():S.tab==='log'?viewLog():viewToday();
    S.dirty=false;
    if(fid){const n=document.getElementById(fid);if(n)n.focus({preventScroll:true});}
  }
  document.querySelectorAll('.tab').forEach(b=>{if(b.dataset.tab===S.tab)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
}
function renderHeader(){
  const st=S.settings;const d1=daysUntil(st.exam1),d2=daysUntil(st.exam2);
  const w=weekStats(0);const tg=weeklyTarget();
  $('#hdr').innerHTML='<div class="cd"><span class="cd-l">1次試験まで</span><b class="cd-n">'+Math.max(0,d1)+'</b><span class="cd-u">日</span><span class="cd-sub">2次筆記まで '+Math.max(0,d2)+'日（日程は仮置き）</span></div>'
   +'<div class="wk"><div class="wk-t"><span>今週</span><b>'+fmtH(w.min)+'</b><span>/ '+fmtH(tg)+' 時間</span></div><div class="meter" role="meter" aria-label="今週の学習時間" aria-valuemin="0" aria-valuemax="'+tg+'" aria-valuenow="'+w.min+'"><i style="width:'+(tg?Math.min(100,w.min/tg*100):0)+'%"></i></div></div>';
}
function loading(){return '<p class="fine">'+(S.slow||S.dead?'データに接続できません。通信状況を確認して、アプリを開き直してください。':'読み込んでいます…')+'</p>';}

function viewToday(){
  if(!S.got.cards)return loading();
  if(!S.cards.size)return '<section class="sheet"><div class="sec-h"><span>今日の演習</span></div><p class="lead">カードがまだありません。</p><p class="fine">「カード」タブで論点を選んでAIに問題を作らせるか、Claudeとの会話で「カードを追加して」と頼んでください。</p><button class="btn primary" type="button" data-act="tab" data-tab="cards">カードを作る</button></section>';
  const c=counts();const td=S.days.get(todayKey())||{};const total=c.due+c.newToday;const weak=weakTopics(3);
  const act=S.settings.active.map(k=>SN[k]?SN[k].sh:k).join('・')||'なし';
  let h='<section class="sheet" aria-labelledby="h-today"><div class="sec-h" id="h-today"><span>今日の演習</span></div>'
   +'<div class="dueRow"><div class="stat"><span class="k">復習</span><span class="v">'+c.due+'<small>枚</small></span></div><div class="stat"><span class="k">新しいカード</span><span class="v">'+c.newToday+'<small>枚</small></span></div></div>';
  if(total){h+='<div class="go"><button class="btn primary" type="button" data-act="go" data-n="10">5分<small>10問</small></button><button class="btn" type="button" data-act="go" data-n="30">15分<small>30問</small></button><button class="btn" type="button" data-act="go" data-n="60">30分<small>60問</small></button></div>';}
  else{h+='<p class="note">今日の分は終わりました。</p>'+(c.avail?'':'<p class="fine">学習中の科目の新しいカードが残っていません。「カード」タブでAIに問題を作らせてください。</p>')+'<button class="btn ghost" type="button" data-act="ahead">先取りで10問</button>';}
  h+='<p class="fine">今日 '+(td.ans||0)+'問・正答率 '+(td.ans?Math.round((td.cor||0)/td.ans*100):0)+'%・学習中：'+esc(act)+'</p></section>';
  if(weak.length){h+='<section class="sec"><div class="sec-h"><span>苦手な論点</span></div><ul class="list">'+weak.map(w=>'<li class="weak"><div class="weak-t"><b>'+esc(w.t)+'</b><span>'+esc(SN[w.s]?SN[w.s].n:w.s)+'・正答率'+w.acc+'%'+(w.cw?'・自信を持って誤答'+w.cw+'回':'')+'</span></div><button class="btn small" type="button" data-act="weak" data-s="'+esc(w.s)+'" data-t="'+esc(w.t)+'">10問</button></li>').join('')+'</ul></section>';}
  h+='<section class="sec"><div class="sec-h"><span>学習タイマー</span></div><div class="timer"><span class="tface" id="tface">'+(S.timer?fmtClock(Date.now()-S.timer):'00:00')+'</span>'
   +(S.timer?'<button class="btn primary" type="button" data-act="t-stop">止めて記録</button>':'<button class="btn" type="button" data-act="t-start">計測を始める</button>')+'</div>'
   +'<div class="addrow"><span class="fine">テキストや講義で学んだ時間を足す</span><button class="btn small ghost" type="button" data-act="add-min" data-m="15">+15分</button><button class="btn small ghost" type="button" data-act="add-min" data-m="30">+30分</button><button class="btn small ghost" type="button" data-act="add-min" data-m="60">+60分</button></div></section>';
  h+='<section class="sec"><div class="sec-h"><span>今週の7日間</span></div>'+weekBubbles()+'</section>';
  return h;
}
function weekBubbles(){
  const w=weekStats(0);const names=['月','火','水','木','金','土','日'];const tk=todayKey();const st=S.settings;
  return '<div class="week7">'+w.days.map((d,i)=>{const tg=i<5?st.wdMin:st.weMin;const lv=d.min<=0?'':(d.min>=tg?'full':'part');
    return '<div class="d7'+(ymd(d.d)===tk?' today':'')+'"><span class="bub sm '+lv+'" aria-hidden="true"></span><span class="d7-n">'+names[i]+'</span><span class="d7-m">'+(d.min?d.min+'分':'—')+'</span></div>';}).join('')+'</div>';
}

function viewCards(){
  if(!S.got.cards)return loading();
  let h='<section class="sec"><div class="sec-h"><span>科目ごとのカード</span></div><p class="fine">「学習中」の科目から、新しいカードが1日'+S.settings.newPerDay+'枚まで出ます。復習はすべての科目から出ます。</p><div class="subjs">';
  SUBJ.forEach(s=>{const x=subjStats(s.k);const on=S.settings.active.includes(s.k);
    h+='<div class="subj"><div class="subj-n">'+esc(s.n)+'</div><div class="subj-m">'+x.tot+'枚・学習済み'+x.lr+'・今日の復習'+x.due+'</div><div class="subj-a"><span class="acc" title="正答率">'+(x.acc==null?'—':x.acc+'%')+'</span><button class="toggle'+(on?' on':'')+'" type="button" data-act="toggle-active" data-s="'+s.k+'" aria-pressed="'+on+'">'+(on?'学習中':'休止中')+'</button></div></div>';});
  h+='</div></section>'+genPanel();
  const fl=[];S.cards.forEach((c,id)=>{if(c.flag)fl.push([id,c]);});
  if(fl.length)h+='<section class="sec"><div class="sec-h"><span>報告したカード</span></div><p class="fine">演習から外しています。確認して戻すか、削除してください。</p><ul class="list">'+fl.map(x=>flagItem(x[0],x[1])).join('')+'</ul></section>';
  return h;
}
function genPanel(){
  if(!S.sample||S.sampleOff)return '<section class="sec"><div class="sec-h"><span>AIで問題を追加</span></div><p class="fine">'+(S.sampleOff?'このアプリからClaudeを使えない設定になっています。':'Claudeに接続できると、論点を選んで問題を作れます。')+'Claudeとの会話で「カードを追加して」と頼むこともできます。</p></section>';
  const g=S.gen;const tps=TOPICS[g.s]||[];
  let h='<section class="sec" aria-labelledby="h-gen"><div class="sec-h" id="h-gen"><span>AIで問題を追加</span></div><form class="genform" data-form="gen"><div class="grid2">'
   +'<label class="field" for="g-s">科目<select id="g-s" data-bind="gen.s">'+SUBJ.map(s=>'<option value="'+s.k+'"'+(g.s===s.k?' selected':'')+'>'+esc(s.n)+'</option>').join('')+'</select></label>'
   +'<label class="field" for="g-n">問題数<select id="g-n" data-bind="gen.n">'+['5','10'].map(n=>'<option value="'+n+'"'+(g.n===n?' selected':'')+'>'+n+'問</option>').join('')+'</select></label></div>'
   +'<label class="field" for="g-t">論点<select id="g-t" data-bind="gen.t"><option value="">選んでください</option>'+tps.map(t=>'<option value="'+esc(t)+'"'+(g.t===t?' selected':'')+'>'+esc(t)+'</option>').join('')+'<option value="__custom"'+(g.t==='__custom'?' selected':'')+'>自分で入力する</option></select></label>';
  if(g.t==='__custom')h+='<label class="field" for="g-c">論点を入力<input id="g-c" type="text" data-bind="gen.custom" value="'+esc(g.custom)+'" placeholder="例：ナッシュ均衡と囚人のジレンマ" maxlength="60"></label>';
  h+='<button class="btn primary" type="submit"'+(g.state==='loading'?' disabled':'')+'>'+(g.state==='loading'?'作成中…':'問題を作る')+'</button></form>';
  if(g.state==='loading')h+='<p class="fine">Claudeが問題を作っています。30秒ほどかかることがあります。</p>';
  if(g.state==='error')h+='<p class="err">'+esc(g.msg)+'</p>';
  if(g.items.length){const k=g.items.filter(x=>x.keep).length;
    h+='<ul class="list">'+g.items.map((x,i)=>'<li class="gi"><label class="gi-l" for="gk'+i+'"><input type="checkbox" id="gk'+i+'" data-act="gen-keep" data-i="'+i+'"'+(x.keep?' checked':'')+'><span class="gi-a" aria-label="正解">'+(x.a?'○':'×')+'</span><span class="gi-q">'+esc(x.q)+'<small>'+esc(x.e)+'</small></span></label></li>').join('')+'</ul>'
     +'<div class="row2"><button class="btn ghost" type="button" data-act="gen-clear">破棄する</button><button class="btn primary" type="button" data-act="gen-add"'+(k?'':' disabled')+'>選んだ'+k+'枚を追加</button></div>'
     +'<p class="fine">AIが作った問題は誤りを含むことがあります。違和感があれば、演習中に「誤りを報告」してください。</p>';}
  return h+'</section>';
}
function flagItem(id,c){
  const v=S.verify[id];
  let h='<li class="fl"><div class="fl-q"><span class="gi-a">'+(c.a?'○':'×')+'</span><span>'+esc(c.q)+'<small>'+esc(c.e)+'</small></span></div>';
  if(v){
    if(v.state==='loading')h+='<p class="fine">Claudeが確認しています…</p>';
    else if(v.state==='error')h+='<p class="err">'+esc(v.msg)+'</p>';
    else h+='<div class="verdict '+v.verdict+'"><b>'+(v.verdict==='ok'?'問題なしと判断しました':v.verdict==='fix'?'修正が必要と判断しました':'判断できませんでした')+'</b><p>'+esc(v.reason)+'</p>'+(v.verdict==='fix'&&v.q?'<p class="fixq"><span class="gi-a">'+(v.a?'○':'×')+'</span><span>'+esc(v.q)+'<small>'+esc(v.e)+'</small></span></p>':'')+'</div>';
  }
  h+='<div class="row-act">';
  if(S.sample&&!S.sampleOff&&!(v&&v.state==='loading'))h+='<button class="linkbtn" type="button" data-act="verify" data-id="'+esc(id)+'">AIで確認</button>';
  if(v&&v.verdict==='fix'&&v.q)h+='<button class="linkbtn" type="button" data-act="applyfix" data-id="'+esc(id)+'">修正して戻す</button>';
  h+='<button class="linkbtn" type="button" data-act="unflag" data-id="'+esc(id)+'">このまま戻す</button><button class="linkbtn danger" type="button" data-act="delcard" data-id="'+esc(id)+'">'+(S.armDel===id?'もう一度押すと削除':'削除')+'</button></div></li>';
  return h;
}

function viewSim(){
  const ests=estimates();const meas=ests.filter(x=>x.est!=null);const all=meas.length===SUBJ.length;
  const total=meas.reduce((a,x)=>a+x.est,0);const pess=meas.reduce((a,x)=>a+Math.max(0,x.est-x.s.vol),0);
  const low=meas.filter(x=>x.est<40);
  let pill,head;
  if(!meas.length){pill='<span class="pill mute">未計測</span>';head='過去問を解いて科目ごとに点数を記録すると、合否を判定します。';}
  else if(low.length){pill='<span class="pill bad">足切りあり</span>';head=low.map(x=>x.s.n).join('・')+'が40点未満です。';}
  else if(!all){pill='<span class="pill mute">'+(SUBJ.length-meas.length)+'科目が未計測</span>';head='計測済み'+meas.length+'科目の合計です。全科目そろうと判定します。';}
  else if(total>=420){pill='<span class="pill good">合格圏</span>';head='合格基準の420点を'+(total-420)+'点上回っています。';}
  else{pill='<span class="pill warn">あと'+(420-total)+'点</span>';head='合格基準の420点まであと'+(420-total)+'点です。';}
  let h='<section class="sheet" aria-labelledby="h-sim"><div class="sec-h" id="h-sim"><span>合否シミュレーター</span></div>'
   +'<div class="simhead"><div class="simbig"><b>'+(meas.length?total:'—')+'</b><span>'+(all||!meas.length?'/ 700点':'点（'+meas.length+'科目の合計）')+'</span></div>'+pill+'</div><p class="lead">'+esc(head)+'</p>';
  if(all){const pl=meas.some(x=>x.est-x.s.vol<40);h+='<p class="fine">難化した年を想定（運営管理・経営法務・中小企業経営は−10点、ほかは−5点）すると'+pess+'点で、'+(pess>=420&&!pl?'合格基準を満たします。':'合格基準に届きません。')+'</p>';}
  h+='<div class="simrows">'+ests.map(simRow).join('')+'</div>'
   +'<div class="legend"><span><i class="lg cut"></i>足切り 40点</span><span><i class="lg pass"></i>科目合格 60点</span><span><i class="lg tgt"></i>あなたの目標点</span></div>';
  const nx=nextUp(ests);if(nx)h+='<p class="nextup"><b>次に上げる科目：</b>'+esc(nx)+'</p>';
  h+='</section>'+mockForm()+mockList();
  return h;
}
function simRow(x){
  const e=x.est;
  return '<div class="sim-row"><span class="sim-n">'+esc(x.s.sh)+'</span><div class="track" role="img" aria-label="'+esc(x.s.n)+'：'+(e==null?'未計測':e+'点')+'、目標'+x.s.tg+'点">'
   +(e!=null?'<span class="fill'+(e<40?' low':'')+'" style="width:'+cl(e,0,100)+'%"></span>':'<span class="na">未計測</span>')
   +'<span class="cut" style="left:40%"></span><span class="pass" style="left:60%"></span><span class="tgt" style="left:'+x.s.tg+'%"></span></div><span class="sim-v">'+(e==null?'—':e)+'</span></div>'
   +'<div class="sim-sub">'+esc(x.s.n)+'・'+(x.n?'過去問'+x.n+'回（直近2回の平均）':'過去問の記録なし')+(x.cardAcc!=null?'・カード正答率'+x.cardAcc+'%':'')+'</div>';
}
function nextUp(ests){
  const un=ests.filter(x=>x.est==null).sort((a,b)=>(S.settings.active.includes(b.s.k)?1:0)-(S.settings.active.includes(a.s.k)?1:0));
  const low=ests.filter(x=>x.est!=null&&x.est<40).sort((a,b)=>a.est-b.est);
  if(low.length)return low[0].s.n+'（40点の足切りを越えるのが最優先）';
  if(un.length)return un[0].s.n+'の過去問を1年分解いて記録する';
  const g=ests.map(x=>({x:x,g:x.s.tg-x.est})).sort((a,b)=>b.g-a.g)[0];
  return g.g>0?g.x.s.n+'（目標まであと'+g.g+'点）':'全科目が目標点に届いています。苦手な論点の復習を続けてください。';
}
function mockForm(){
  const m=S.mockDraft;
  return '<section class="sec" aria-labelledby="h-mock"><div class="sec-h" id="h-mock"><span>過去問の点数を記録</span></div>'
   +'<p class="fine">公式サイトの<a href="'+PAST_URL+'" target="_blank" rel="noopener">過去問と正解（PDF）</a>で解いて自己採点し、科目ごとに記録します。</p>'
   +'<form class="grid3" data-form="mock"><label class="field" for="m-s">科目<select id="m-s" data-bind="mockDraft.s">'+SUBJ.map(s=>'<option value="'+s.k+'"'+(m.s===s.k?' selected':'')+'>'+esc(s.n)+'</option>').join('')+'</select></label>'
   +'<label class="field" for="m-y">年度<select id="m-y" data-bind="mockDraft.y">'+YEARS.map(y=>'<option value="'+y[0]+'"'+(String(m.y)===String(y[0])?' selected':'')+'>'+y[1]+'年度</option>').join('')+'</select></label>'
   +'<label class="field" for="m-p">点数<input id="m-p" type="number" inputmode="numeric" min="0" max="100" step="1" data-bind="mockDraft.p" value="'+esc(m.p)+'" placeholder="0〜100"></label>'
   +'<button class="btn primary span" type="submit">記録する</button></form></section>';
}
function mockList(){
  const arr=[];S.mocks.forEach((m,id)=>arr.push([id,m]));
  if(!arr.length)return '';
  arr.sort((a,b)=>(b[1].at||0)-(a[1].at||0));
  return '<section class="sec"><div class="sec-h"><span>記録した点数</span></div><ul class="list">'+arr.slice(0,20).map(x=>{const id=x[0],m=x[1];
    return '<li class="mk"><span class="mk-s">'+esc(SN[m.s]?SN[m.s].n:m.s)+'</span><span class="mk-y">'+esc(yearLabel(m.y))+'・'+md(new Date(m.at||Date.now()))+'に記録</span><b class="mk-p">'+m.sc+'点</b><button class="linkbtn danger" type="button" data-act="mock-del" data-id="'+esc(id)+'">'+(S.armDel===id?'もう一度押すと削除':'削除')+'</button></li>';}).join('')+'</ul></section>';
}

function viewLog(){
  const st=S.settings;const tg=weeklyTarget();
  const weeks=[];for(let i=7;i>=0;i--)weeks.push(weekStats(i));
  let all=0,ans=0,cor=0;S.days.forEach(v=>{all+=v.min||0;ans+=v.ans||0;cor+=v.cor||0;});
  const el=Math.max(1/7,(Date.now()-parseYmd(st.start||DEF.start).getTime())/(7*DAY));const plan=Math.round(tg*el);
  const d=S.setDraft||draftOf(st);
  return '<section class="sec"><div class="sec-h"><span>週ごとの学習時間</span></div>'+weekChart(weeks,tg)
   +'<div class="kpis"><div class="stat"><span class="k">累計</span><span class="v">'+fmtH(all)+'<small>時間</small></span><span class="fine">計画どおりなら '+fmtH(plan)+'時間</span></div><div class="stat"><span class="k">解いた問題</span><span class="v">'+ans+'<small>問</small></span><span class="fine">正答率 '+(ans?Math.round(cor/ans*100):0)+'%</span></div></div></section>'
   +'<section class="sec" aria-labelledby="h-set"><div class="sec-h" id="h-set"><span>設定</span></div><form class="setform" data-form="settings"><div class="grid2">'
   +'<label class="field" for="s-wd">平日の目標（分）<input id="s-wd" type="number" inputmode="numeric" min="0" max="600" data-bind="setDraft.wdMin" value="'+esc(d.wdMin)+'"></label>'
   +'<label class="field" for="s-we">休日の目標（分）<input id="s-we" type="number" inputmode="numeric" min="0" max="900" data-bind="setDraft.weMin" value="'+esc(d.weMin)+'"></label>'
   +'<label class="field" for="s-np">新しいカード（枚/日）<input id="s-np" type="number" inputmode="numeric" min="0" max="100" data-bind="setDraft.newPerDay" value="'+esc(d.newPerDay)+'"></label><span></span>'
   +'<label class="field" for="s-e1">1次試験日<input id="s-e1" type="date" data-bind="setDraft.exam1" value="'+esc(d.exam1)+'"></label>'
   +'<label class="field" for="s-e2">2次筆記試験日<input id="s-e2" type="date" data-bind="setDraft.exam2" value="'+esc(d.exam2)+'"></label></div>'
   +'<button class="btn primary" type="submit">保存する</button></form>'
   +'<p class="fine">今の目標は週'+fmtH(tg)+'時間です。1年合格の目安は週16時間（平日105分・休日210分）。試験日は2027年度の公式発表（例年3〜4月）で直してください。</p></section>'
   +'<section class="sec"><div class="sec-h"><span>データ</span></div><p class="fine">'+(S.mode==='remote'?'学習記録はこのアプリのデータベースに保存されています。Claudeとの会話で、弱点の分析や計画の見直しを頼めます。':'この端末のブラウザにだけ保存しています。claude.aiかClaudeアプリで開くと、学習記録が同期されます。')+'</p></section>';
}
function weekChart(weeks,tg){
  const VW=320,VH=150,L=8,R=8,T=20,B=24;
  const max=Math.max(tg*1.25,60,...weeks.map(w=>w.min));
  const bw=(VW-L-R)/weeks.length;const yv=v=>T+(VH-T-B)*(1-v/max);
  let bars='';
  weeks.forEach((w,i)=>{const x=L+i*bw+bw*.2,ww=bw*.6,hh=(VH-T-B)*(w.min/max);const cur=i===weeks.length-1;
    bars+='<rect x="'+x.toFixed(1)+'" y="'+(VH-B-hh).toFixed(1)+'" width="'+ww.toFixed(1)+'" height="'+Math.max(0,hh).toFixed(1)+'" rx="2" class="bar'+(cur?' cur':'')+'"><title>'+md(w.start)+'の週：'+fmtH(w.min)+'時間</title></rect>'
     +'<text x="'+(x+ww/2).toFixed(1)+'" y="'+(VH-8)+'" text-anchor="middle" class="ax">'+md(w.start)+'</text>'
     +(w.min?'<text x="'+(x+ww/2).toFixed(1)+'" y="'+(VH-B-hh-4).toFixed(1)+'" text-anchor="middle" class="val">'+fmtH(w.min)+'</text>':'');});
  const ty=yv(tg);
  return '<div class="chartbox"><svg viewBox="0 0 '+VW+' '+VH+'" role="img" aria-label="直近8週の学習時間。目標は週'+fmtH(tg)+'時間">'+bars
   +'<line x1="'+L+'" x2="'+(VW-R)+'" y1="'+ty.toFixed(1)+'" y2="'+ty.toFixed(1)+'" class="tline"/><text x="'+L+'" y="'+(ty-5).toFixed(1)+'" class="ax">目標 '+fmtH(tg)+'時間</text>'
   +'<line x1="'+L+'" x2="'+(VW-R)+'" y1="'+(VH-B)+'" y2="'+(VH-B)+'" class="base"/></svg></div>';
}

/* ---------- drill session ---------- */
function acc(id){const r=S.srs.get(id);return r&&r.att?r.cor/r.att:0;}
function interleave(ids){
  const by={};ids.forEach(id=>{const s=(S.cards.get(id)||{}).s;(by[s]=by[s]||[]).push(id);});
  const keys=Object.keys(by);const out=[];let last=null;
  while(out.length<ids.length){keys.sort((a,b)=>by[b].length-by[a].length);const k=keys.find(x=>by[x].length&&x!==last)||keys.find(x=>by[x].length);out.push(by[k].shift());last=k;}
  return out;
}
function buildQueue(n,filter,ahead){
  const eod=endOfToday();const pool=[];
  S.cards.forEach((c,id)=>{if(!c.flag&&(!filter||filter(c)))pool.push([id,c]);});
  let q=pool.filter(x=>{const r=S.srs.get(x[0]);return r&&r.due<=eod;}).sort((a,b)=>S.srs.get(a[0]).due-S.srs.get(b[0]).due).slice(0,n).map(x=>x[0]);
  if(q.length<n){
    const td=S.days.get(todayKey())||{};
    const quota=(filter||ahead)?n:Math.max(0,S.settings.newPerDay-(td.nw||0));
    const fresh=pool.filter(x=>!S.srs.get(x[0])&&(filter||S.settings.active.includes(x[1].s))).sort((a,b)=>(a[1].n||0)-(b[1].n||0));
    q=q.concat(fresh.slice(0,Math.min(quota,n-q.length)).map(x=>x[0]));
  }
  if(q.length<n&&(filter||ahead)){
    const rest=pool.filter(x=>{const r=S.srs.get(x[0]);return r&&r.due>eod;}).sort((a,b)=>filter?acc(a[0])-acc(b[0]):S.srs.get(a[0]).due-S.srs.get(b[0]).due);
    q=q.concat(rest.slice(0,n-q.length).map(x=>x[0]));
  }
  return interleave(q);
}
function startSession(n,filter,ahead){
  const q=buildQueue(n,filter,ahead);
  if(!q.length){toast('今出せるカードがありません');return;}
  S.sess={q:q,i:0,phase:'answer',pick:null,res:[],t0:Date.now(),requeued:{},newCount:0,explain:null,confirmEnd:false};
  $('#sess').hidden=false;renderSession();
}
function renderSession(){
  const s=S.sess;const el=$('#sess');
  if(!s){el.hidden=true;el.innerHTML='';return;}
  if(s.phase==='done'){el.innerHTML=sessDone(s);return;}
  const id=s.q[s.i];const c=S.cards.get(id);
  if(!c){s.i++;if(s.i>=s.q.length)finishSession();else renderSession();return;}
  const rev=s.phase==='reveal';const ok=rev&&s.pick===c.a;
  const dots=s.q.map((_,i)=>'<i class="'+(i<s.res.length?(s.res[i].ok?'ok':'ng'):(i===s.i?'cur':''))+'"></i>').join('');
  const prog=s.q.length>24?'<div class="sbar" aria-hidden="true"><i style="width:'+Math.round(s.res.length/s.q.length*100)+'%"></i></div>':'<div class="dots" aria-hidden="true">'+dots+'</div>';
  let h='<div class="s-top gut"><button class="icon" type="button" data-act="s-close" aria-label="演習を終える">×</button>'+prog+'<span class="s-count">'+(s.i+1)+'<small>/'+s.q.length+'</small></span></div>';
  if(s.confirmEnd)h+='<div class="endbar gut"><span>ここまでの結果を記録して終わりますか？</span><button class="btn small primary" type="button" data-act="s-end">終わる</button><button class="btn small ghost" type="button" data-act="s-continue">続ける</button></div>';
  h+='<div class="s-scroll"><div class="s-body gut"><div class="s-meta"><span class="chip">'+esc(SN[c.s]?SN[c.s].n:c.s)+'</span><span class="s-topic">'+esc(c.t||'')+'</span>'+(c.src==='ai'?'<span class="chip ai">AI作成</span>':'')+'</div>'
   +'<p class="s-q">'+esc(c.q)+'</p><div class="ox" role="group" aria-label="解答">';
  [true,false].forEach(v=>{const on=s.pick===v;const ans=rev&&c.a===v;
    h+='<button class="bub big'+(on?' on':'')+(ans?' ans':'')+'" type="button" data-act="pick" data-v="'+(v?1:0)+'"'+(s.phase!=='answer'?' disabled':'')+' aria-pressed="'+on+'" aria-label="'+(v?'正しい（○）':'誤り（×）')+'">'+(v?ICON_O:ICON_X)+'</button>';});
  h+='</div>';
  if(s.phase==='conf')h+='<div class="confwrap"><p class="conf-q">自信はどのくらい？</p><div class="conf"><button class="btn" type="button" data-act="conf" data-c="sure">確信</button><button class="btn" type="button" data-act="conf" data-c="unsure">迷った</button><button class="btn" type="button" data-act="conf" data-c="guess">勘</button></div></div>';
  if(rev){
    h+='<div class="res '+(ok?'ok':'ng')+'" aria-live="polite"><div class="res-h">'+(ok?'正解':'不正解')+'<span class="res-a">正しくは '+(c.a?'○':'×')+'</span></div><p>'+esc(c.e)+'</p>';
    if(s.explain){h+='<div class="explain" id="explain">'+(s.explain.text?esc(s.explain.text):'考えています…')+'</div>'+(s.explain.state==='error'?'<p class="err">'+esc(s.explain.msg)+'</p>':'');}
    h+='<div class="res-act">';
    if(S.sample&&!S.sampleOff&&!s.explain)h+='<button class="linkbtn" type="button" data-act="explain">AIにもっと詳しく聞く</button>';
    if(s.explain&&s.explain.state==='loading')h+='<button class="linkbtn" type="button" data-act="explain-stop">止める</button>';
    h+=c.flag?'<span class="fine">報告済み（演習から外しました）</span>':'<button class="linkbtn" type="button" data-act="flag">誤りを報告</button>';
    h+='</div></div>';
  }
  h+='</div></div><div class="s-foot gut">'+(rev?'<button class="btn primary wide" type="button" data-act="next">次へ</button>':'<p class="fine center">'+(s.phase==='answer'?'正しければ○、誤りなら×':'自信を選ぶと答え合わせ')+'</p>')+'</div>';
  el.innerHTML=h;
}
function sessDone(s){
  const seen={};const wrong=[];let uniq=0,ok1=0,rt=0,rtOk=0;
  s.res.forEach(r=>{if(!seen[r.id]){seen[r.id]=1;uniq++;if(r.ok)ok1++;else{const c=S.cards.get(r.id);if(c)wrong.push(c);}}else{rt++;if(r.ok)rtOk++;}});
  let h='<div class="s-top gut"><span class="s-title">演習の結果</span></div><div class="s-scroll"><div class="s-body gut">';
  if(!uniq)h+='<p class="lead">記録した解答はありません。</p>';
  else{h+='<div class="score"><b>'+ok1+'</b><span>/ '+uniq+'問 正解</span></div><p class="fine">'+(rt?'間違えた'+rt+'問をもう一度出題し'+(rtOk?'、そのうち'+rtOk+'問を正解しました。':'ました。'):'')+(s.sum&&s.sum.mins?s.sum.mins+'分を学習時間に記録しました。':'学習タイマーで計測中のため、演習時間は別に記録していません。')+'</p>';
    h+=wrong.length?'<section class="sec"><div class="sec-h"><span>間違えたカード</span></div><ul class="list">'+wrong.map(c=>'<li class="wr"><span class="wr-a" aria-hidden="true">'+(c.a?'○':'×')+'</span><span class="wr-b">'+esc(c.q)+'<small>正しくは'+(c.a?'○':'×')+'。'+esc(c.e)+'</small></span></li>').join('')+'</ul></section>':'<p class="lead">全問正解です。</p>';}
  h+='</div></div><div class="s-foot two gut"><button class="btn ghost" type="button" data-act="s-done">閉じる</button><button class="btn primary" type="button" data-act="s-more">続けて10問</button></div>';
  return h;
}
function pick(v){const s=S.sess;if(!s||s.phase!=='answer')return;s.pick=v;s.phase='conf';renderSession();}
function answerConf(conf){
  const s=S.sess;if(!s||s.phase!=='conf')return;
  const id=s.q[s.i];const c=S.cards.get(id);if(!c)return;
  const ok=s.pick===c.a;const g=!ok?1:conf==='sure'?3:conf==='unsure'?2:1;
  const prev=S.srs.get(id);const now=Date.now();
  const rec=Object.assign(fsrs(prev,g,now),{att:((prev&&prev.att)||0)+1,cor:((prev&&prev.cor)||0)+(ok?1:0),cw:((prev&&prev.cw)||0)+(!ok&&conf==='sure'?1:0),lc:conf});
  if(!prev)s.newCount++;
  put('cards',id,Object.assign({},c,{r:rec}));
  s.res.push({id:id,ok:ok});
  if(!ok&&!s.requeued[id]){s.requeued[id]=1;s.q.push(id);}
  s.phase='reveal';s.explain=null;renderSession();
}
function nextCard(){
  const s=S.sess;if(!s)return;
  if(s.explain&&s.explain.ctl){try{s.explain.ctl.abort();}catch(e){}}
  s.i++;s.pick=null;s.explain=null;s.confirmEnd=false;
  if(s.i>=s.q.length)finishSession();else{s.phase='answer';renderSession();const sc=$('#sess .s-scroll');if(sc)sc.scrollTop=0;}
}
function finishSession(){
  const s=S.sess;if(!s)return;
  if(s.explain&&s.explain.ctl){try{s.explain.ctl.abort();}catch(e){}}
  const n=s.res.length;const cor=s.res.filter(r=>r.ok).length;
  const mins=(n&&!S.timer)?Math.max(1,Math.round((Date.now()-s.t0)/60000)):0;
  if(n)bumpDay({min:mins,ans:n,cor:cor,nw:s.newCount});
  s.sum={mins:mins};s.phase='done';renderSession();schedRender();
}
function bumpDay(d){
  const k=todayKey();const cur=S.days.get(k)||{};
  put('days',k,{min:Math.max(0,(cur.min||0)+(d.min||0)),ans:(cur.ans||0)+(d.ans||0),cor:(cur.cor||0)+(d.cor||0),nw:(cur.nw||0)+(d.nw||0)});
}

/* ---------- Claude features ---------- */
async function aiExplain(){
  const s=S.sess;if(!s||!S.sample)return;
  const id=s.q[s.i];const c=S.cards.get(id);if(!c)return;
  const ctl=new AbortController();const ex={state:'loading',text:'',ctl:ctl};s.explain=ex;renderSession();
  const p='中小企業診断士の第1次試験の受験生に向けて、次の○×問題を解説してください。\n\n科目：'+(SN[c.s]?SN[c.s].n:c.s)+'\n論点：'+(c.t||'')+'\n問題文：'+c.q+'\n正解：'+(c.a?'○（正しい文）':'×（誤った文）')+'\n登録済みの解説：'+c.e
   +'\n\n次の3つを、見出しや記号を使わず、3つの短い段落、合計300字程度にまとめてください。\n1つ目：正解の根拠。\n2つ目：本試験での問われ方や、よくあるひっかけの型。\n3つ目：一緒に覚えるとよい関連知識。\n登録済みの解説に誤りがあると考える場合は、最初の段落の冒頭でそのことをはっきり指摘してください。';
  try{
    await S.sample(p,{signal:ctl.signal,onText:u=>{if(S.sess!==s||s.explain!==ex)return;ex.text=u.text;const e=document.getElementById('explain');if(e)e.textContent=u.text;}});
    if(s.explain===ex){ex.state='done';if(S.sess===s)renderSession();}
  }catch(e){
    if(e&&e.code==='cancelled')return;
    if(s.explain===ex){ex.state='error';ex.text=(e&&e.text)||ex.text;ex.msg=sampleErr(e);if(S.sess===s)renderSession();}
  }
}
async function aiGenerate(){
  const g=S.gen;if(!S.sample||g.state==='loading')return;
  if(document.activeElement&&document.activeElement.blur)document.activeElement.blur();
  const topic=g.t==='__custom'?String(g.custom||'').trim():g.t;
  if(!topic){toast('論点を選ぶか入力してください');return;}
  const ex=[];S.cards.forEach(c=>{if(c.s===g.s)ex.push('・'+c.q);});
  const n=Number(g.n)||5;
  const p='中小企業診断士の第1次試験対策用に、○×で答える問題を'+n+'問作ってください。\n\n科目：'+SN[g.s].n+'\n論点：'+topic
   +'\n\n条件：\n- 本試験の選択肢で実際に問われる知識を、1文（40〜90字）の日本語の文にする。\n- 正しい文（○）と誤った文（×）をおおむね半々にする。誤った文は、用語の入れ替え、数値や条件の誤り、主体の取り違えなど、本試験に多いひっかけにする。\n- 解説（e）は120字以内で、正しい内容と根拠を書く。誤った文では、どこが誤りかを明示する。\n- 学説や定義が定まっている内容に限る。法令・制度は、すでに施行されていて2027年度の本試験でも通用する内容に限り、改正の有無が不確かなものや、自信のない細かい数値は出題しない。\n- 次の既存の問題と内容が重ならないようにする。\n'+(ex.slice(-40).join('\n')||'（なし）')
   +'\n\nJSONだけで答えてください。形式：{"cards":[{"q":"問題文","a":true,"e":"解説"}]}（aは正しい文ならtrue、誤った文ならfalse）';
  g.state='loading';g.items=[];g.msg='';render();
  try{
    const r=await S.sample.json(p,{cache:false});
    const arr=r&&Array.isArray(r.cards)?r.cards:Array.isArray(r)?r:[];
    g.items=arr.filter(x=>x&&typeof x.q==='string'&&typeof x.a==='boolean'&&typeof x.e==='string'&&x.q.trim().length>=8).slice(0,12)
      .map(x=>({q:x.q.trim().slice(0,200),a:x.a,e:x.e.trim().slice(0,300),keep:true,t:topic}));
    if(g.items.length)g.state='done';else{g.state='error';g.msg='問題を読み取れませんでした。もう一度試してください';}
  }catch(e){g.state='error';g.msg=sampleErr(e);}
  render();
}
function addGenerated(){
  const g=S.gen;const keep=g.items.filter(x=>x.keep);if(!keep.length)return;
  let n=0;S.cards.forEach(c=>{if((c.n||0)>n)n=c.n;});
  keep.forEach((x,i)=>{const id='ai'+Date.now().toString(36)+i+Math.random().toString(36).slice(2,5);
    put('cards',id,{s:g.s,t:x.t,q:x.q,a:x.a,e:x.e,src:'ai',ok:false,n:n+1+i,at:Date.now()});});
  let note='';
  if(!S.settings.active.includes(g.s)){put('settings','main',Object.assign({},S.settings,{active:SUBJ.map(s=>s.k).filter(k=>k===g.s||S.settings.active.includes(k))}));note='（'+SN[g.s].sh+'を学習中にしました）';}
  toast(keep.length+'枚を追加しました'+note);
  g.items=[];g.state='idle';render();
}
async function aiVerify(id){
  const c=S.cards.get(id);if(!c||!S.sample)return;
  S.verify[id]={state:'loading'};render();
  const p='次の○×問題（中小企業診断士 第1次試験の対策用）について、登録されている正解と解説が正しいかを検証してください。\n\n科目：'+(SN[c.s]?SN[c.s].n:c.s)+'\n論点：'+(c.t||'')+'\n問題文：'+c.q+'\n登録されている正解：'+(c.a?'○（正しい文）':'×（誤った文）')+'\n解説：'+c.e
   +'\n\n判断の基準：定まった学説・定義と、現在施行されている法令に照らす。確信が持てない場合は unclear とする。\n\nJSONだけで答えてください。形式：{"verdict":"ok","reason":"判断の理由（150字以内）","q":"修正後の問題文","a":true,"e":"修正後の解説（120字以内）"}\nverdictは ok（問題なし）、fix（修正が必要）、unclear（判断できない）のいずれか。q・a・eは fix のときだけ入れる。';
  try{
    const r=await S.sample.json(p,{cache:false});
    const v={state:'done',verdict:['ok','fix','unclear'].includes(r&&r.verdict)?r.verdict:'unclear',reason:String((r&&r.reason)||'').slice(0,300)};
    if(v.verdict==='fix'&&r&&typeof r.q==='string'&&typeof r.a==='boolean'&&typeof r.e==='string'){v.q=r.q.slice(0,200);v.a=r.a;v.e=r.e.slice(0,300);}
    S.verify[id]=v;
  }catch(e){S.verify[id]={state:'error',msg:sampleErr(e)};}
  render();
}

/* ---------- small actions ---------- */
function toast(msg,undo){
  const t=$('#toast');t.innerHTML='<span>'+esc(msg)+'</span>'+(undo?'<button class="linkbtn inv" type="button" data-act="undo-add">取り消す</button>':'');
  t.hidden=false;clearTimeout(S.toastT);S.toastT=setTimeout(()=>{t.hidden=true;},undo?6000:2800);
}
function armDelete(id){S.armDel=id;clearTimeout(S.armT);S.armT=setTimeout(()=>{if(S.armDel===id){S.armDel=null;render();}},4000);render();}
function toggleActive(k){
  const a=S.settings.active.includes(k)?S.settings.active.filter(x=>x!==k):S.settings.active.concat([k]);
  put('settings','main',Object.assign({},S.settings,{active:SUBJ.map(s=>s.k).filter(x=>a.includes(x))}));render();
}
function addMock(){
  const m=S.mockDraft;const raw=String(m.p==null?'':m.p).trim();const p=Number(raw);
  if(raw===''||!Number.isFinite(p)||p<0||p>100){toast('点数は0〜100で入力してください');return;}
  const sc=Math.round(p);put('mocks','m'+Date.now().toString(36),{s:m.s,y:Number(m.y),sc:sc,at:Date.now()});
  m.p='';const el=document.getElementById('m-p');if(el){el.value='';el.blur();}
  toast(SN[m.s].n+'を'+sc+'点で記録しました');render();
}
function saveSettings(){
  const d=S.setDraft||{};const st=S.settings;
  const num=(v,lo,hi,df)=>{const x=Math.round(Number(v));return Number.isFinite(x)&&x>=lo&&x<=hi?x:df;};
  const dt=(v,df)=>/^\d{4}-\d{2}-\d{2}$/.test(String(v||''))?v:df;
  put('settings','main',Object.assign({},st,{wdMin:num(d.wdMin,0,600,st.wdMin),weMin:num(d.weMin,0,900,st.weMin),newPerDay:num(d.newPerDay,0,100,st.newPerDay),exam1:dt(d.exam1,st.exam1),exam2:dt(d.exam2,st.exam2)}));
  S.setDraft=null;if(document.activeElement&&document.activeElement.blur)document.activeElement.blur();
  toast('設定を保存しました');render();
}
function draftOf(st){return {wdMin:String(st.wdMin),weMin:String(st.weMin),newPerDay:String(st.newPerDay),exam1:st.exam1,exam2:st.exam2};}
function setBind(path,val){const p=path.split('.');if(p[0]==='setDraft'&&!S.setDraft)S.setDraft=draftOf(S.settings);const o=S[p[0]];if(o)o[p[1]]=val;}

/* ---------- events ---------- */
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-act]');if(!b||b.disabled)return;
  const a=b.dataset.act;const s=S.sess;
  switch(a){
    case 'tab':S.tab=b.dataset.tab;lsSet('sd1-tab',S.tab);S.setDraft=null;$('#main').scrollTop=0;render();break;
    case 'go':startSession(Number(b.dataset.n)||10);break;
    case 'ahead':startSession(10,null,true);break;
    case 'weak':{const sk=b.dataset.s,tp=b.dataset.t;startSession(10,c=>c.s===sk&&c.t===tp);break;}
    case 't-start':S.timer=Date.now();lsSet('sd1-timer',String(S.timer));render();break;
    case 't-stop':{const m=Math.round((Date.now()-S.timer)/60000);S.timer=null;lsSet('sd1-timer',null);if(m>=1){bumpDay({min:m});toast(m+'分を記録しました');}else toast('1分未満のため記録しませんでした');render();break;}
    case 'add-min':{const m=Number(b.dataset.m)||0;bumpDay({min:m});S.lastAdd={m:m,at:Date.now()};toast(m+'分を記録しました',true);render();break;}
    case 'undo-add':if(S.lastAdd&&Date.now()-S.lastAdd.at<10000){bumpDay({min:-S.lastAdd.m});S.lastAdd=null;toast('取り消しました');render();}break;
    case 'pick':pick(b.dataset.v==='1');break;
    case 'conf':answerConf(b.dataset.c);break;
    case 'next':nextCard();break;
    case 's-close':if(!s)break;if(s.phase==='done'||!s.res.length){S.sess=null;renderSession();render();}else{s.confirmEnd=true;renderSession();}break;
    case 's-end':finishSession();break;
    case 's-continue':if(s){s.confirmEnd=false;renderSession();}break;
    case 's-done':S.sess=null;renderSession();render();break;
    case 's-more':S.sess=null;renderSession();startSession(10,null,counts().due+counts().newToday===0);render();break;
    case 'explain':aiExplain();break;
    case 'explain-stop':if(s&&s.explain&&s.explain.ctl){s.explain.ctl.abort();s.explain.state='done';renderSession();}break;
    case 'flag':{if(!s)break;const id=s.q[s.i];const c=S.cards.get(id);if(c){put('cards',id,Object.assign({},c,{flag:true,flagAt:Date.now()}));toast('報告しました。「カード」タブで確認できます');renderSession();}break;}
    case 'toggle-active':toggleActive(b.dataset.s);break;
    case 'gen-clear':S.gen.items=[];S.gen.state='idle';render();break;
    case 'gen-add':addGenerated();break;
    case 'verify':aiVerify(b.dataset.id);break;
    case 'applyfix':{const id=b.dataset.id;const c=S.cards.get(id);const v=S.verify[id];if(c&&v&&v.q){const nc=Object.assign({},c,{q:v.q,a:v.a,e:v.e,flag:false,ok:false,fixedAt:Date.now()});delete nc.r;put('cards',id,nc);delete S.verify[id];toast('修正して演習に戻しました');render();}break;}
    case 'unflag':{const id=b.dataset.id;const c=S.cards.get(id);if(c){put('cards',id,Object.assign({},c,{flag:false}));delete S.verify[id];toast('演習に戻しました');render();}break;}
    case 'delcard':{const id=b.dataset.id;if(S.armDel!==id){armDelete(id);break;}S.armDel=null;remove('cards',id);delete S.verify[id];toast('削除しました');render();break;}
    case 'mock-del':{const id=b.dataset.id;if(S.armDel!==id){armDelete(id);break;}S.armDel=null;remove('mocks',id);toast('削除しました');render();break;}
  }
});
document.addEventListener('change',e=>{
  const t=e.target;
  if(t.dataset&&t.dataset.act==='gen-keep'){const it=S.gen.items[Number(t.dataset.i)];if(it)it.keep=t.checked;render();return;}
  const b=t.dataset&&t.dataset.bind;if(!b)return;
  setBind(b,t.value);
  if(t.tagName==='SELECT'){if(b==='gen.s')S.gen.t='';render();}
});
document.addEventListener('input',e=>{const t=e.target;const b=t.dataset&&t.dataset.bind;if(b&&t.tagName!=='SELECT')setBind(b,t.value);});
document.addEventListener('focusout',()=>{setTimeout(()=>{if(S.dirty)render();},0);});
document.addEventListener('submit',e=>{
  const f=e.target;const k=f.dataset&&f.dataset.form;if(!k)return;e.preventDefault();
  if(k==='gen')aiGenerate();else if(k==='mock')addMock();else if(k==='settings')saveSettings();
});
document.addEventListener('keydown',e=>{
  const s=S.sess;if(!s||$('#sess').hidden)return;
  if(e.target.closest&&e.target.closest('input,select,textarea'))return;
  const k=e.key.toLowerCase();
  if(s.phase==='answer'){if(k==='o')pick(true);else if(k==='x')pick(false);}
  else if(s.phase==='conf'){if(k==='1')answerConf('sure');else if(k==='2')answerConf('unsure');else if(k==='3')answerConf('guess');}
  else if(s.phase==='reveal'&&k==='enter'){e.preventDefault();nextCard();}
});
setInterval(()=>{if(S.timer){const f=document.getElementById('tface');if(f)f.textContent=fmtClock(Date.now()-S.timer);}},1000);
setInterval(()=>{renderHeader();},60000);

/* ---------- boot ---------- */
async function boot(){
  render();
  const C=window.claude;
  const useCap=name=>(C&&typeof C.use==='function')?C.use(name).catch(()=>null):Promise.resolve(null);
  setTimeout(()=>{if(!S.got.cards){S.slow=true;render();}},10000);
  const caps=await Promise.all([useCap('db'),useCap('sample')]);
  S.sample=caps[1]||null;
  if(caps[0]){
    S.db=caps[0];S.mode='remote';
    const onErr=err=>{console.warn(err);S.dead=true;schedRender();};
    try{
      Remote.watchCards(onCardRows,onErr);
      ['days','mocks','settings'].forEach(c=>Remote.watch(c,rows=>onRows(c,rows),onErr));
    }catch(err){console.warn(err);S.dead=true;}
  }else{
    S.mode='local';Local.load();COLLS.forEach(c=>Local.watch(c,rows=>onRows(c,rows)));
  }
  render();
}
boot();
})();
