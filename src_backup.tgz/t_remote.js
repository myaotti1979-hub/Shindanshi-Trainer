const { chromium } = require('playwright');
const fs=require('fs');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
const seed=JSON.parse(fs.readFileSync(B+'/seed/local.json','utf8'));
(async()=>{
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:400,height:900},deviceScaleFactor:1,locale:'ja-JP',timezoneId:'Asia/Tokyo'});
  await ctx.addInitScript(seed=>{
    const data={cards:{},days:{},mocks:{},settings:{}};Object.assign(data.cards,seed.cards);data.settings.main=seed.settings.main;
    const subs=[];let nsub=0;
    const snapDoc=(id,v)=>({id,exists:v!==undefined,data:()=>v,metadata:{fromCache:false,hasPendingWrites:false}});
    const fireAll=()=>setTimeout(()=>subs.forEach(f=>f()),10);
    function q(coll,filters,lim){return {
      where(f,op,val){return q(coll,filters.concat([[f,op,val]]),lim);},
      limit(n){return q(coll,filters,n);},
      onSnapshot(next,err){nsub++;const fire=()=>{const rows=Object.keys(data[coll]||{}).sort().map(id=>[id,data[coll][id]]).filter(([id,v])=>filters.every(([f,op,val])=>v[f]===val)).slice(0,lim||1e9);next({docs:rows.map(([id,v])=>snapDoc(id,v)),size:rows.length,empty:!rows.length,metadata:{fromCache:false,hasPendingWrites:false}});};subs.push(fire);setTimeout(fire,20);return()=>{};},
      doc(id){return docRef(coll,id);}};}
    function docRef(coll,id){return {id,
      set:async v=>{(data[coll]=data[coll]||{})[id]=JSON.parse(JSON.stringify(v));fireAll();},
      delete:async()=>{if(data[coll])delete data[coll][id];fireAll();},
      onSnapshot(next){nsub++;const fire=()=>next(snapDoc(id,data[coll]&&data[coll][id]));subs.push(fire);setTimeout(fire,20);return()=>{};}};}
    const db={collection:c=>q(c,[],0),doc:p=>{const [c,id]=p.split('/');return docRef(c,id);}};
    const sample=async(input,opts)=>{const t='正解の根拠のテスト段落です。'.repeat(4);if(opts&&opts.onText){opts.onText({text:t.slice(0,10),delta:t.slice(0,10)});await new Promise(r=>setTimeout(r,60));opts.onText({text:t,delta:t.slice(10)});}return {text:t,truncated:false};};
    sample.json=async(input)=>{window.__lastPrompt=input;if(input.includes('検証してください'))return {verdict:'fix',reason:'テストの判断理由です。',q:'修正後の問題文のテストです。',a:true,e:'修正後の解説のテストです。'};return {cards:[{q:'テスト問題その1。これは正しい文です。',a:true,e:'解説1'},{q:'テスト問題その2。これは誤った文です。',a:false,e:'解説2'},{q:'短',a:true,e:'x'}]};};
    window.__mock={data,nsub:()=>nsub,fire:fireAll};
    window.claude={use:async n=>n==='db'?db:n==='sample'?sample:null};
  },seed);
  const page=await ctx.newPage();
  await page.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  const errs=[];page.on('pageerror',e=>errs.push('PAGEERR '+e.message));page.on('console',m=>{if(m.type()==='error'||m.type()==='warning')errs.push(m.type()+' '+m.text())});
  await page.goto('file://'+B+'/site/index.html');await page.waitForTimeout(400);
  const out={};
  out.nsub=await page.evaluate(()=>window.__mock.nsub());
  out.todayText=await page.$eval('#view',el=>el.innerText.slice(0,60));
  out.bannerHidden=await page.$eval('#modebar',el=>el.hidden);
  await page.click('[data-act=go][data-n="30"]');await page.waitForTimeout(100);
  out.qlen=await page.$eval('.s-count',el=>el.innerText);
  out.prog=await page.evaluate(()=>document.querySelector('.sbar')?'bar':document.querySelector('.dots')?'dots':'none');
  await page.click('[data-act=pick][data-v="1"]');await page.click('[data-act=conf][data-c=sure]');
  await page.click('[data-act=explain]');await page.waitForTimeout(250);
  out.explain=await page.$eval('#explain',el=>el.innerText.slice(0,20));
  await page.screenshot({path:B+'/shots/r1-explain.png'});
  await page.click('[data-act=flag]');await page.waitForTimeout(80);
  out.flagged=await page.evaluate(()=>Object.entries(window.__mock.data.cards).filter(([k,v])=>v.flag).map(([k,v])=>[k,!!v.r]));
  await page.click('[data-act=next]');
  await page.click('[data-act=pick][data-v="0"]');await page.click('[data-act=conf][data-c=guess]');
  await page.click('[data-act=s-close]');await page.click('[data-act=s-end]');await page.waitForTimeout(80);
  await page.screenshot({path:B+'/shots/r2-done.png'});
  await page.click('[data-act=s-done]');
  out.days=await page.evaluate(()=>window.__mock.data.days);
  await page.click('[data-act=tab][data-tab=cards]');await page.waitForTimeout(80);
  await page.selectOption('#g-s','keizai');await page.selectOption('#g-t','IS-LMモデル');
  await page.click('form[data-form=gen] button[type=submit]');await page.waitForTimeout(150);
  out.genItems=await page.$$eval('.gi',els=>els.length);
  await page.setViewportSize({width:400,height:1700});
  await page.screenshot({path:B+'/shots/r3-gen.png'});
  await page.click('[data-act=gen-add]');await page.waitForTimeout(120);
  out.afterAdd=await page.evaluate(()=>{const c=Object.values(window.__mock.data.cards);return {total:c.length,ai:c.filter(x=>x.src==='ai').map(x=>[x.s,x.t,x.n]),active:window.__mock.data.settings.main.active};});
  out.promptHasExisting=await page.evaluate(()=>window.__lastPrompt.includes('流動性のわな'));
  const fid=out.flagged[0]&&out.flagged[0][0];
  await page.click('[data-act=verify][data-id="'+fid+'"]');await page.waitForTimeout(120);
  await page.screenshot({path:B+'/shots/r4-verify.png'});
  await page.click('[data-act=applyfix][data-id="'+fid+'"]');await page.waitForTimeout(120);
  out.fixed=await page.evaluate(id=>window.__mock.data.cards[id],fid);
  const aid=await page.evaluate(()=>Object.keys(window.__mock.data.cards).find(k=>k.startsWith('ai')));
  await page.evaluate(id=>{const c=Object.assign({},window.__mock.data.cards[id],{flag:true});window.__mock.data.cards[id]=c;window.__mock.fire();},aid);
  await page.waitForTimeout(80);
  out.flagList=await page.$$eval('.fl',els=>els.length);
  if(out.flagList){await page.click('[data-act=delcard][data-id="'+aid+'"]');await page.waitForTimeout(40);out.armed=await page.$eval('[data-act=delcard][data-id="'+aid+'"]',el=>el.innerText);await page.click('[data-act=delcard][data-id="'+aid+'"]');await page.waitForTimeout(80);out.deleted=await page.evaluate(id=>!(id in window.__mock.data.cards),aid);}
  out.errs=errs;
  console.log(JSON.stringify(out,null,1));
  await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
