const http = require('http'), fs = require('fs'), path = require('path');
const srv = http.createServer((q,r)=>{
  let f = path.join('.', q.url==='/'?'index.html':q.url);
  try{const d=fs.readFileSync(f);const t=f.endsWith('.json')?'application/json':f.endsWith('.js')?'text/javascript':'text/html';r.writeHead(200,{'Content-Type':t+'; charset=utf-8'});r.end(d);}
  catch(e){r.writeHead(404);r.end('Not found');}
});
srv.listen(0, async()=>{
  const port = srv.address().port;
  const {chromium} = require('playwright');
  const b = await chromium.launch();
  const p = await b.newPage({viewport:{width:390,height:844},deviceScaleFactor:2});
  const SS = '/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/';

  await p.goto('http://localhost:'+port+'/');
  await p.waitForTimeout(2000);
  await p.click('[data-stage="s2"]');
  await p.waitForTimeout(1000);
  // Click 演習 tab
  await p.click('[data-tab="jex"]');
  await p.waitForTimeout(1000);
  await p.screenshot({path: SS+'v37_ex_list.png'});

  // Open first exercise
  await p.click('[data-act="ex-open"]');
  await p.waitForTimeout(500);
  await p.screenshot({path: SS+'v37_ex_yoken.png'});

  // Scroll to see questions
  await p.evaluate(()=>window.scrollBy(0,800));
  await p.waitForTimeout(300);
  await p.screenshot({path: SS+'v37_ex_q1.png'});

  // Type an answer
  const ta = await p.locator('.ex-ta').first();
  await ta.fill('熟練職人の手作り製法と地元ブランド力が強みである。');
  await p.waitForTimeout(300);
  await p.screenshot({path: SS+'v37_ex_typed.png'});

  // Scroll down more and submit
  await p.evaluate(()=>window.scrollTo(0, document.body.scrollHeight));
  await p.waitForTimeout(300);
  await p.click('[data-act="ex-submit"]');
  await p.waitForTimeout(500);
  await p.screenshot({path: SS+'v37_ex_model.png'});

  // Scroll to see model answer
  await p.evaluate(()=>window.scrollBy(0,400));
  await p.waitForTimeout(300);
  await p.screenshot({path: SS+'v37_ex_model2.png'});

  await b.close();
  srv.close();
  console.log('Done');
});
