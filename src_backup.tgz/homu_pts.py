# 経営法務の過去問調査から、細目ごとの論点を短く出す。引数: 細目ID（カンマ区切り）
import json, sys
items = []
for f in ['review/past_homu_a.json', 'review/past_homu_b.json', 'review/past_homu_c.json']:
    try:
        items += json.load(open(f))
    except Exception as e:
        print('skip', f, e)
want = sys.argv[1].split(',')
for x in sorted(items, key=lambda x: (x['year'], int(x['q']) if str(x['q']).isdigit() else 0)):
    if x['item'] in want:
        print('###', x['item'], x['year'], 'Q' + str(x['q']) + (('-' + x['sub']) if x.get('sub') else ''), x['topic'], '正解', x['answer'], '|', x.get('law', ''))
        for p in x['points']:
            print('  -', p)
        if x.get('note'):
            print('  note:', x['note'])
