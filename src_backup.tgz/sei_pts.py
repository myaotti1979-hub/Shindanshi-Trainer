# 中小企業政策の制度（src_chusho_seisaku2026.json）を細目ごとに出す。引数: 細目ID [最大文字数]
import json, sys
want = sys.argv[1].split(','); mx = int(sys.argv[2]) if len(sys.argv) > 2 else 600
d = json.load(open('review/src_chusho_seisaku2026.json'))
for x in d:
    if x['item'] in want:
        print('■', x['topic'])
        for k in ('law', 'target', 'requirements', 'support', 'period', 'changes'):
            v = x.get(k)
            if v: print('  %s: %s' % (k, str(v)[:mx]))
