// 模擬試験のアラートの状態（当日・未完了・時間切れ）を確かめる。node t_mock2.js
const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
async function run(name,day,state,scheme){
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:400,height:860},deviceScaleFactor:2,locale:'ja-JP',timezoneId:'Asia/Tokyo',colorScheme:scheme||'light'});
  await ctx.clock.install({time:new Date(day+'T09:00:00+09:00')});
  const page=await ctx.newPage();await page.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  const errs=[];page.on('pageerror',e=>errs.push(e.message));
  await ctx.addInitScript(st=>{try{if(!sessionStorage.getItem('inj')){if(st)localStorage.setItem('shindan1',JSON.stringify(st));localStorage.setItem('shindan1-tab','today');sessionStorage.setItem('inj','1');}}catch(e){}},state);
  await page.goto('http://127.0.0.1:8765/index.html');await page.waitForTimeout(1200);
  await page.screenshot({path:B+'/shots/'+name+'.png'});
  const info=await page.evaluate(()=>({alert:(document.querySelector('.malert')||{}).className,head:(document.querySelector('.malert-h b')||{}).textContent,tabs:[...document.querySelectorAll('.tab')].map(t=>t.className)}));
  // 受験中の状態なら、開いて時間切れの提出を確かめる
  let after=null;
  if(state&&state.mockRun){await page.click('.malert [data-act=mk-open]');await page.waitForTimeout(1500);after=await page.evaluate(()=>{const s=JSON.parse(localStorage.getItem('shindan1'));return {mock:s.mock.length,run:s.mockRun,phase:document.querySelector('#mock .score')?'result':'other'};});await page.screenshot({path:B+'/shots/'+name+'-after.png'});}
  console.log(name,JSON.stringify({info,after,errs}));
  await browser.close();
}
(async()=>{
  const base={v:1,settings:{wdMin:60,weMin:180,newPerDay:15,exam1:'2027-08-07',exam2:'2027-10-24',active:['kigyo','unei','zaimu'],start:'2026-11-09'},srs:{},days:{},past:[],flags:{},timer:null,mock:[],mockRun:null};
  await run('mk-day1','2026-12-26',base);
  await run('mk-over','2026-12-29',Object.assign({},base,{mock:[{id:'m1',r:1,s:'keizai',at:Date.parse('2026-12-26T10:00:00+09:00'),score:64,ok:16,total:25,ans:{},mins:58}]}));
  await run('mk-soon','2026-12-21',base);
  const t0=Date.parse('2026-12-26T09:00:00+09:00')-61*60000;
  await run('mk-timeout','2026-12-26',Object.assign({},base,{mockRun:{s:'keizai',r:1,t0:t0,ans:{'1':0,'2':1},flag:{},i:2}}));
  await run('mk-over-dark','2026-12-29',base,'dark');
})();
