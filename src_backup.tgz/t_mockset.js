// 模擬試験のセットの各問題を、解説の画面（正答・各選択肢の注・解説・図）で撮る。DRAFT=1 で作ったセットに使う
// node t_mockset.js <科目> <回> [番号の範囲 例: 1-10] → shots/mk-<科目>-<回>-<番号>.png と JSON
const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const s=process.argv[2],r=+process.argv[3],rg=process.argv[4]||'';
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:400,height:860},deviceScaleFactor:2,locale:'ja-JP',timezoneId:'Asia/Tokyo'});
  const page=await ctx.newPage();await page.route(/fonts\.(googleapis|gstatic)\.com/,x=>x.abort());
  const errs=[];page.on('pageerror',e=>errs.push(e.message));
  await page.goto('http://127.0.0.1:8765/index.html?chk=1');await page.waitForTimeout(1200);
  const n=await page.evaluate(async([s,r])=>{const j=await (await fetch('data/m_'+s+'_'+r+'.json?t='+Date.now(),{cache:'no-store'})).json();window.__chk.DATA.mset[s+'-'+r]=j;return j.items.length;},[s,r]);
  let lo=0,hi=n-1;if(rg){const p=rg.split('-').map(Number);lo=p[0]-1;hi=(p[1]||p[0])-1;}
  const out=[];
  for(let i=lo;i<=hi&&i<n;i++){
    const info=await page.evaluate(([s,r,i])=>{const C=window.__chk;C.UI.mock={s:s,r:r,phase:'review',i:i,att:{ans:{},score:0,ok:0,total:0,at:Date.now(),mins:0}};C.renderMock();
      const el=document.querySelector('#mock .p-scroll');const it=C.DATA.mset[s+'-'+r].items[i];
      const d=document.documentElement;const bad=[];document.querySelectorAll('#mock *').forEach(e=>{const b=e.getBoundingClientRect();if(b.width>0&&b.right>d.clientWidth+1&&!e.closest('.fig')&&!e.closest('.res-x .tbl'))bad.push((e.className&&e.className.baseVal!==undefined?e.className.baseVal:e.className)||e.tagName);});
      return {no:it.no,id:it.id,figs:document.querySelectorAll('#mock svg').length,h:el?el.scrollHeight:0,bad:[...new Set(bad)].slice(0,5)};},[s,r,i]);
    await page.setViewportSize({width:400,height:Math.min(6000,info.h+140)});await page.waitForTimeout(120);
    await page.screenshot({path:B+'/shots/mk-'+s+'-'+r+'-'+String(info.no).replace('/','_')+'.png'});
    await page.setViewportSize({width:400,height:860});
    out.push(info);
  }
  console.log(JSON.stringify({set:s+'-'+r,n,out,errs}));
  await browser.close();
})();
