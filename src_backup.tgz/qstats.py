# 演習問題の集計（README 用）：科目ごとの問題数（形式別）、問題のある細目の数、解説に図表がある問題の数
import json, os
B = os.path.dirname(os.path.abspath(__file__))
S = [('keizai', '経済学・経済政策'), ('zaimu', '財務・会計'), ('kigyo', '企業経営理論'), ('unei', '運営管理'), ('homu', '経営法務'), ('joho', '経営情報システム'), ('chusho', '中小企業経営・中小企業政策')]
tot = {'n': 0, 'tf': 0, 'single': 0, 'combo': 0, 'x': 0, 'cov': 0, 'sec': 0}
for s, nm in S:
    q = json.load(open(B + '/pwa/data/q_%s.json' % s))['questions']
    t = json.load(open(B + '/pwa/data/t_%s.json' % s))
    secs = [sec['id'] for ch in t['chapters'] for sec in ch['sections']]
    cov = len(set(x['t'] for x in q) & set(secs))
    c = {k: sum(1 for x in q if x['type'] == k) for k in ('tf', 'single', 'combo')}
    nx = sum(1 for x in q if x.get('x'))
    print('%s %d問（○×%d・単答%d・組み合わせ%d）解説の図%d 細目%d/%d' % (nm, len(q), c['tf'], c['single'], c['combo'], nx, cov, len(secs)))
    for k, v in (('n', len(q)), ('x', nx), ('cov', cov), ('sec', len(secs))):
        tot[k] += v
    for k in c:
        tot[k] += c[k]
print('合計 %d問（○×%d・単答%d・組み合わせ%d）解説の図%d 細目%d/%d' % (tot['n'], tot['tf'], tot['single'], tot['combo'], tot['x'], tot['cov'], tot['sec']))
