# 演習を書くための下調べ：科目の細目ごとに、既存の問題数、試験のポイント・ひっかけ注意、図の名前を出す
# 使い方: python3 qplan.py 科目 [細目IDの接頭辞] [full]
import json, sys, re, glob, importlib.util, os
s = sys.argv[1]; pre = sys.argv[2] if len(sys.argv) > 2 else ''; full = 'full' in sys.argv
B = os.path.dirname(os.path.abspath(__file__))
t = json.load(open(B + '/pwa/data/t_%s.json' % s))
q = json.load(open(B + '/pwa/data/q_%s.json' % s))['questions']
cnt = {}
for x in q: cnt[x['t']] = cnt.get(x['t'], 0) + 1
qb = {}
for f in sorted(glob.glob(B + '/qbank/q_%s_*.py' % s)):
    sp = importlib.util.spec_from_file_location('m', f); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    for x in m.Q: qb[x['t']] = qb.get(x['t'], 0) + 1
src = {}
for f in sorted(glob.glob(B + '/text/%s_p*.py' % s)):
    sp = importlib.util.spec_from_file_location('m', f); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    src.update(m.T)
for ch in t['chapters']:
    for sec in ch['sections']:
        sid = sec['id']
        if not sid.startswith(pre): continue
        c = src.get(sid, ('', ''))[1]
        figs = re.findall(r'\[\[図:([^\]]+)\]\]', c)
        pts = [l for l in c.split('\n') if l.startswith(('【試験のポイント】', '【ひっかけ注意】'))]
        print('■ %s %s  既存%d問 新規%d問' % (sid, sec['title'], cnt.get(sid, 0), qb.get(sid, 0)))
        print('  図:', ' '.join(figs))
        if full:
            print(c)
        else:
            for l in pts: print('  ' + l)
