# 論点表の細目のID と名前の一覧。python3 itemlist.py keizai
import json, sys, os
B = os.path.dirname(os.path.abspath(__file__))
syl = json.load(open(os.path.join(B, 'pwa', 'data', 'syllabus.json'), encoding='utf-8'))
k = sys.argv[1] if len(sys.argv) > 1 else ''
for s in syl['subjects']:
    if k and s['k'] != k:
        continue
    for p in s['parts']:
        for g in p['groups']:
            print('## %s %s' % (g['id'], g['n']))
            for it in g['items']:
                print('   %-18s %s' % (it['id'], it['n']))
