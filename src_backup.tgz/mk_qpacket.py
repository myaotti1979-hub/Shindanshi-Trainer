# 本試験形式の演習の検証用の資料を作る
# 使い方: python3 mk_qpacket.py 科目 開始番号 終了番号 出力ファイル
# 出力: 問題ごとに、細目、問題文、問題の図（名前と、画面の写しのパス）、選択肢（書いた順。正答に★）、各選択肢の注、解説、解説の図の名前と説明
import sys, os, glob, importlib.util, re, json
B = os.path.dirname(os.path.abspath(__file__))
s, a, b, out = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
Q = []
for f in sorted(glob.glob(B + '/qbank/q_%s_*.py' % s)):
    sp = importlib.util.spec_from_file_location('m', f); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    for x in m.Q:
        x = dict(x); x['_file'] = os.path.basename(f); Q.append(x)
syl = json.load(open(B + '/pwa/data/t_%s.json' % s))
title = {}
for ch in syl['chapters']:
    for sec in ch['sections']:
        title[sec['id']] = sec['title']
LT = 'アイウエオ'
L = ['# 本試験形式の演習の検証（%s %d～%d）' % (s, a, b), '',
     '各問の「画面」は、アプリで誤答を1つ選んだ後の表示の写し（選択肢の並びはアプリの並べ替え後。正答は緑の枠）。', '組み合わせ問題は、アプリでは記述a～dの並びと解答群が入れ替わり、解説の中の記号も付け替わる（記述の中身と真偽は同じ）。このファイルは書いた順で示す。', '']
for x in Q:
    n = int(x['id'].split('-')[1])
    if not (a <= n <= b):
        continue
    L.append('## %s（%s %s、ファイル %s）' % (x['id'], x['t'], title.get(x['t'], ''), x['_file']))
    L.append('形式：%s' % {'single': '単答（最も適切なもの）', 'combo': '組み合わせ', 'tf': '○×'}[x['type']])
    L.append('問題：' + x['q'])
    if x.get('f'):
        L.append('問題の図：' + ' '.join(re.findall(r'\[\[図:([^\]]+)\]\]', x['f'])))
    if x['type'] == 'combo':
        for i, t in enumerate(x['stm']):
            L.append('  %s %s' % ('abcde'[i], t))
    if x['type'] != 'tf':
        for i, c in enumerate(x['ch']):
            L.append('  %s%s %s' % ('★' if i == x['a'] else '　', LT[i], c))
            if x.get('ce'):
                L.append('      注：' + x['ce'][i])
    else:
        L.append('  正答：' + ('○' if x['a'] else '×'))
    L.append('解説：' + x['e'])
    if x.get('x'):
        for ln in x['x'].strip().split('\n'):
            mm = re.match(r'^\[\[図:([^\]]+)\]\]$', ln.strip())
            L.append(('解説の図：' + mm.group(1)) if mm else ('解説の図の説明：' + ln.replace('【図】', '')))
    if x.get('ref'):
        L.append('根拠：' + x['ref'])
    shots = sorted(glob.glob(B + '/shots/qb-*-%s.png' % x['id']), key=os.path.getmtime)
    L.append('画面：' + (shots[-1] if shots else '（なし）'))
    L.append('')
open(out, 'w', encoding='utf-8').write('\n'.join(L))
print(out, sum(1 for l in L if l.startswith('## ')), '問')
