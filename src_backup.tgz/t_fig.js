const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const browser=await chromium.launch();
  for(const scheme of ['light','dark']){
  const ctx=await browser.newContext({viewport:{width:375,height:760},deviceScaleFactor:1,serviceWorkers:'block',colorScheme:scheme});
  const p=await ctx.newPage();
  await p.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  const errs=[];p.on('pageerror',e=>errs.push(e.message));
  await p.goto('http://127.0.0.1:8765/index.html');await p.waitForTimeout(800);
  await p.click('[data-act=tab][data-tab=drill]');await p.waitForTimeout(100);
  await p.click('[data-act=open-syl][data-s=keizai]');await p.waitForTimeout(150);
  await p.click('[data-act=open-text][data-ch="'+(process.argv[2]||'keizai.1.2')+'"]');await p.waitForTimeout(200);
  const n=await p.$$eval('#reader figure.tx-fig svg',e=>e.length);
  await p.evaluate((i)=>{const f=document.querySelectorAll('#reader figure.tx-fig');if(f[i])f[i].scrollIntoView();}, +(process.argv[3]||0));await p.waitForTimeout(100);
  await p.screenshot({path:B+'/shots/fig-'+(process.argv[2]||'')+'-'+(process.argv[3]||0)+'-'+scheme+'.png'});
  const ov=await p.evaluate(()=>[document.documentElement.scrollWidth,document.documentElement.clientWidth]);
  console.log(scheme,'figs',n,'ovf',ov,'errs',errs);
  await ctx.close();}
  await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
