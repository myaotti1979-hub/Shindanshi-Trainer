# 点検用の資料を作る：節の本文の [[図:名前]] を、その図のソース（text/fig_*.py の定義部分）に置き換える
# 使い方: python3 mk_packet.py 出力.md 節ID[,節ID...] [問題ID範囲の接頭辞（例 kigyo-3,kigyo-4,kigyo-5）]
import sys, glob, re, importlib.util, os, json
B = os.path.dirname(os.path.abspath(__file__))
out, secs = sys.argv[1], sys.argv[2].split(',')
qpre = sys.argv[3].split(',') if len(sys.argv) > 3 else []
src = {}
for f in sorted(glob.glob(os.path.join(B, 'text', 'fig_*.py'))):
    lines = open(f, encoding='utf-8').read().split('\n')
    i = 0
    while i < len(lines):
        m = re.match(r"^FIG\['([^']+)'\]\s*=", lines[i])
        if m:
            j = i + 1
            while j < len(lines) and lines[j].startswith((' ', '\t')):
                j += 1
            body = '\n'.join(lines[i:j])
            fm = re.match(r"^FIG\['[^']+'\]\s*=\s*(_\w+)\(\)\s*$", lines[i])
            if fm:  # 関数で描く図は関数の定義も付ける
                fn = fm.group(1)
                k = next((n for n, l in enumerate(lines) if l.startswith('def %s(' % fn)), None)
                if k is not None:
                    e = k + 1
                    while e < len(lines) and (lines[e].startswith((' ', '\t')) or lines[e] == ''):
                        e += 1
                    body = '\n'.join(lines[k:e]).rstrip() + '\n\n' + body
            src[m.group(1)] = (os.path.basename(f), body)
            i = j
        else:
            i += 1
T = {}
for f in sorted(glob.glob(os.path.join(B, 'text', '*_p*.py'))):
    if '.before' in f:
        continue
    spec = importlib.util.spec_from_file_location('m', f)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    T.update(m.T)
o = []
for sid in secs:
    title, body = T[sid]
    o.append('# %s %s\n' % (sid, title))
    for ln in body.split('\n'):
        mm = re.match(r'^\[\[図:([^\]]+)\]\]$', ln.strip())
        if mm:
            f, s = src[mm.group(1)]
            o.append('〔図 %s（%s）〕\n```python\n%s\n```' % (mm.group(1), f, s))
        else:
            o.append(ln)
    o.append('')
if qpre:
    QX = {}
    for f in sorted(glob.glob(os.path.join(B, 'text', 'qx_*.py'))):
        spec = importlib.util.spec_from_file_location('m', f)
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        QX.update(m.QX)
    for f in sorted(glob.glob(os.path.join(B, 'pwa', 'data', 'q_*.json'))):
        for q in json.load(open(f, encoding='utf-8'))['questions']:
            if any(q['id'].startswith(p) for p in qpre):
                o.append('## %s（論点 %s）正解：%s\n問題：%s\n解説：%s' % (q['id'], q['t'], '○' if q['a'] else '×', q['q'], q['e']))
                for ln in QX.get(q['id'], '').split('\n'):
                    mm = re.match(r'^\[\[図:([^\]]+)\]\]$', ln.strip())
                    if mm:
                        f2, s = src[mm.group(1)]
                        o.append('〔解説の図 %s（%s）〕\n```python\n%s\n```' % (mm.group(1), f2, s))
                    elif ln:
                        o.append('解説の図の説明：' + ln)
                o.append('')
open(out, 'w', encoding='utf-8').write('\n'.join(o))
print(out, len('\n'.join(o)))
