// 本試験形式の演習を表示して、誤答を選んだ後の画面全体を撮る。
// 引数: 問題ID（カンマ区切り。keizai-101..122 の形も可） 出力名 [light|dark] [ページ]
// 問題データ（q_科目.json）を、指定した問題だけに絞って配信し、10問ずつ演習を開く
// 出力: shots/qb-<出力名>-<ID>.png と、はみ出し・エラーの一覧（JSON）
const { chromium } = require('playwright');
const fs=require('fs');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const [spec,name,scheme='light',page='index.html']=process.argv.slice(2);
  let ids=[];
  for(const part of spec.split(',')){
    const m=part.match(/^([a-z]+)-(\d+)\.\.(\d+)$/);
    if(m){for(let i=+m[2];i<=+m[3];i++)ids.push(m[1]+'-'+i);}else ids.push(part);
  }
  const subj=ids[0].split('-')[0];
  const all=JSON.parse(fs.readFileSync(B+'/pwa/data/q_'+subj+'.json','utf8'));
  const browser=await chromium.launch();
  const out=[];const errs=[];
  for(let k=0;k<ids.length;k+=10){
    const part=ids.slice(k,k+10);
    const d=Object.assign({},all,{questions:all.questions.filter(q=>part.includes(q.id))});
    for(const id of part)if(!d.questions.find(q=>q.id===id))out.push({id,missing:true});
    const ctx=await browser.newContext({viewport:{width:390,height:3200},deviceScaleFactor:1,serviceWorkers:'block',colorScheme:scheme,locale:'ja-JP'});
    const p=await ctx.newPage();
    await p.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
    await p.route(new RegExp('data/q_'+subj+'\\.json'),r=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(d)}));
    p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
    await p.goto('http://127.0.0.1:8765/'+page);await p.waitForTimeout(1000);
    await p.click('[data-act=tab][data-tab=drill]');await p.waitForTimeout(100);
    await p.click('[data-act=open-syl][data-s='+subj+']');await p.waitForTimeout(150);
    await p.click('[data-act=drill-subj][data-s='+subj+']');await p.waitForTimeout(200);
    for(let i=0;i<part.length;i++){
      if(!await p.$('[data-act=pick]'))break;
      const n=await p.$$eval('[data-act=pick]',b=>b.length);
      // 正答の位置は画面からは分からないので、1番目（○×なら○）を選ぶ
      await p.click('[data-act=pick][data-v="'+(n===2?1:0)+'"]');
      if(await p.$('[data-act=conf]')){await p.click('[data-act=conf][data-c=sure]');}
      await p.waitForTimeout(120);
      const info=await p.evaluate(()=>{const dd=document.documentElement;const body=document.querySelector('#sess .p-body');
        const bad=[...body.querySelectorAll('*')].filter(e=>!e.closest('svg')&&e.getBoundingClientRect().right>dd.clientWidth+1).map(e=>e.className||e.tagName).slice(0,5);
        const m=(body.innerText.match(/問題番号 ([a-z]+-\d+)/)||[])[1];
        return {id:m,figs:body.querySelectorAll('svg').length,bad,ce:body.querySelectorAll('.ce').length,stm:body.querySelectorAll('.stmts p').length,
                draft:!!body.querySelector('.chip.draft')};});
      const el=await p.$('#sess .p-body');const path=B+'/shots/qb-'+name+'-'+info.id+'.png';await el.screenshot({path});
      out.push(Object.assign({path},info));
      if(!await p.$('[data-act=next]'))break;await p.click('[data-act=next]');await p.waitForTimeout(120);
    }
    await ctx.close();
  }
  console.log(JSON.stringify({out,errs}));
  await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
