// 模擬試験の結果：レーダーチャート・所要時間・受験の記録を確かめる（UI で1科目を受けて提出する）
const http=require('http'),fs=require('fs'),path=require('path');
const ROOT=process.argv[2],OUT=process.argv[3]||'/tmp/mock_radar';fs.mkdirSync(OUT,{recursive:true});
const srv=http.createServer((q,r)=>{const u=decodeURIComponent(q.url.split('?')[0]),f=path.join(ROOT,u==='/'?'index.html':u);try{const d=fs.readFileSync(f);r.writeHead(200,{'Content-Type':(f.endsWith('.json')?'application/json':f.endsWith('.js')?'text/javascript':'text/html')+'; charset=utf-8'});r.end(d);}catch(e){r.writeHead(404);r.end('nf');}});
srv.listen(0,'127.0.0.1',async()=>{
  const {chromium}=require('playwright');const b=await chromium.launch();const res={};
  for(const [subj,dark] of [['joho',false],['kigyo',true],['chusho',false]]){
    const ctx=await b.newContext({viewport:{width:390,height:844},colorScheme:dark?'dark':'light',serviceWorkers:'block'});
    const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
    await p.goto('http://127.0.0.1:'+srv.address().port+'/');await p.waitForTimeout(1200);
    await p.click('[data-act="tab"][data-tab="past"]');await p.waitForTimeout(400);
    await p.click(`[data-act="mk-open"][data-s="${subj}"][data-r="0"]`);await p.waitForTimeout(800);
    await p.click('[data-act="mk-start"]');await p.waitForTimeout(300);
    // 全問：1問ごとに選ぶ（i が偶数ならア、奇数ならイ）
    for(let i=0;i<60;i++){
      const picks=await p.$$('#mock [data-act="mk-pick"]');if(!picks.length)break;
      await picks[i%2].click();await p.waitForTimeout(40);
      const nx=await p.$('#mock [data-act="mk-next"]');if(!nx)break;await nx.click();await p.waitForTimeout(40);
    }
    await p.click('#mock [data-act="mk-list"]');await p.waitForTimeout(200);
    await p.click('#mock [data-act="mk-confirm"]');await p.waitForTimeout(200);
    await p.click('#mock [data-act="mk-submit"]');await p.waitForTimeout(600);
    const info=await p.evaluate(()=>{const el=document.getElementById('mock');const sc=el.querySelector('.p-scroll');
      return {radars:el.querySelectorAll('svg.radar').length,labs:el.querySelectorAll('.rd-lab.go').length,bars:el.querySelectorAll('.rd-bar').length,time:(el.querySelector('.m-time')||{}).textContent,
        over:sc?sc.scrollWidth>sc.clientWidth+1:false,svgOver:[...el.querySelectorAll('svg.radar')].filter(s=>s.getBoundingClientRect().right>window.innerWidth+1).length};});
    // 画面全体を撮る
    const h=await p.evaluate(()=>{const sc=document.querySelector('#mock .p-scroll');return sc?sc.scrollHeight+200:1500;});
    await p.setViewportSize({width:390,height:Math.min(h,9000)});await p.waitForTimeout(200);
    await p.screenshot({path:path.join(OUT,subj+(dark?'_dark':'')+'.png')});
    await p.setViewportSize({width:390,height:844});
    // レーダーの論点名を押すと演習が始まる
    const lab=await p.$('#mock .rd-lab.go, #mock .rd-bar[data-act]');
    if(lab){await lab.click();await p.waitForTimeout(600);}
    info.sessOpen=await p.evaluate(()=>!document.getElementById('sess').hidden);
    // 一覧の表：得点の下に所要時間、受験の記録
    await p.evaluate(()=>{const s=document.getElementById('sess');if(!s.hidden){const c=s.querySelector('[data-act="sess-close"],[data-act="end"],[data-act="quit"]');}});
    await ctx.close();
    info.errors=errs;res[subj]=info;
  }
  // 一覧と記録（別の画面）
  {
    const ctx=await b.newContext({viewport:{width:390,height:844},serviceWorkers:'block'});const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
    await p.goto('http://127.0.0.1:'+srv.address().port+'/');await p.waitForTimeout(1200);
    await p.click('[data-act="tab"][data-tab="past"]');await p.waitForTimeout(300);
    await p.click('[data-act="mk-open"][data-s="homu"][data-r="0"]');await p.waitForTimeout(800);await p.click('[data-act="mk-start"]');await p.waitForTimeout(300);
    await p.click('#mock [data-act="mk-list"]');await p.waitForTimeout(200);await p.click('#mock [data-act="mk-confirm"]');await p.waitForTimeout(200);await p.click('#mock [data-act="mk-submit"]');await p.waitForTimeout(500);
    await p.click('#mock [data-act="mk-tab"]');await p.waitForTimeout(500);
    const info=await p.evaluate(()=>({cell:(document.querySelector('[data-act="mk-open"][data-s="homu"][data-r="0"]')||{}).textContent,rec:document.querySelectorAll('.mrec tbody tr').length,recTxt:(document.querySelector('.mrec tbody tr')||{}).textContent,over:document.documentElement.scrollWidth>window.innerWidth+1}));
    const h=await p.evaluate(()=>document.getElementById('main').scrollHeight+260);await p.setViewportSize({width:390,height:Math.min(h,9000)});await p.waitForTimeout(150);
    await p.screenshot({path:path.join(OUT,'list.png')});
    info.errors=errs;res.list=info;await ctx.close();
  }
  await b.close();srv.close();console.log(JSON.stringify(res,null,1));
});
