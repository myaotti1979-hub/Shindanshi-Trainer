const { chromium } = require('playwright');
const fs=require('fs');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
const local=fs.readFileSync(B+'/seed/local.json','utf8');
(async()=>{
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:400,height:860},deviceScaleFactor:1});
  await ctx.addInitScript(l=>{try{localStorage.setItem('sd1-local',l);}catch(e){}},local);
  const page=await ctx.newPage();
  await page.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  await page.goto('file://'+B+'/site/index.html');await page.waitForTimeout(300);
  await page.click('[data-act=go][data-n="10"]');await page.waitForTimeout(100);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.bub.big')].map(b=>{const s=b.querySelector('svg');const br=b.getBoundingClientRect(),sr=s.getBoundingClientRect();const cs=getComputedStyle(b);return {b:[br.x,br.y,br.width,br.height],s:[sr.x,sr.y,sr.width,sr.height],disp:cs.display,pad:cs.padding,lh:cs.lineHeight,border:cs.borderWidth,boxSizing:cs.boxSizing};}));
  console.log(JSON.stringify(r));
  await browser.close();
})();
