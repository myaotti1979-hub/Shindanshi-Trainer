# 長い縦長の画像を、高さ H ごとに切って横に並べる。引数: 入力 出力 [H]
import sys
from PIL import Image
im = Image.open(sys.argv[1]).convert('RGB')
H = int(sys.argv[3]) if len(sys.argv) > 3 else 1400
n = (im.height + H - 1) // H
out = Image.new('RGB', (n * (im.width + 10), min(H, im.height)), 'white')
for i in range(n):
    out.paste(im.crop((0, i * H, im.width, min(im.height, (i + 1) * H))), (i * (im.width + 10), 0))
out.save(sys.argv[2])
print(sys.argv[2], out.size)
