const { chromium } = require('playwright');
const fs=require('fs');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
const local=fs.readFileSync(B+'/seed/local.json','utf8');
(async()=>{
  const browser=await chromium.launch();
  async function mk(scheme,h){
    const ctx=await browser.newContext({viewport:{width:400,height:h||860},deviceScaleFactor:1,colorScheme:scheme,locale:'ja-JP',timezoneId:'Asia/Tokyo'});
    await ctx.addInitScript(l=>{try{if(!localStorage.getItem('sd1-local'))localStorage.setItem('sd1-local',l);}catch(e){}},local);
    const page=await ctx.newPage();
    await page.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
    const errs=[];page.on('pageerror',e=>errs.push('PAGEERR '+e.message));page.on('console',m=>{if(m.type()==='error'||m.type()==='warning')errs.push(m.type()+' '+m.text())});
    await page.goto('file://'+B+'/site/index.html');
    await page.waitForTimeout(400);
    return {ctx,page,errs};
  }
  const ovf=async p=>p.evaluate(()=>{const d=document.documentElement;const bad=[];document.querySelectorAll('#app *').forEach(el=>{const r=el.getBoundingClientRect();if(r.right>d.clientWidth+1&&r.width>0&&!el.closest('.chartbox'))bad.push((el.className||el.tagName)+':'+Math.round(r.right));});return {sw:d.scrollWidth,cw:d.clientWidth,bad:bad.slice(0,8)};});
  const {page,errs}=await mk('light');
  const out={};
  await page.screenshot({path:B+'/shots/t1-today.png'});
  out.today=await ovf(page);
  await page.click('[data-act=go][data-n="10"]');await page.waitForTimeout(150);
  await page.screenshot({path:B+'/shots/t2-q.png'});
  await page.click('[data-act=pick][data-v="1"]');
  await page.screenshot({path:B+'/shots/t3-conf.png'});
  await page.click('[data-act=conf][data-c=sure]');
  await page.screenshot({path:B+'/shots/t4-reveal.png'});
  out.sess=await ovf(page);
  let steps=0;
  for(let i=0;i<80;i++){
    if(await page.$('[data-act=s-done]'))break;
    if(await page.$('[data-act=next]')){await page.click('[data-act=next]');continue;}
    await page.click('[data-act=pick][data-v="'+(i%4===0?0:1)+'"]');
    await page.click('[data-act=conf][data-c='+['sure','unsure','guess'][i%3]+']');steps++;
  }
  await page.screenshot({path:B+'/shots/t5-done.png'});
  await page.click('[data-act=s-done]');await page.waitForTimeout(100);
  await page.screenshot({path:B+'/shots/t6-today-after.png'});
  out.local=await page.evaluate(()=>{const d=JSON.parse(localStorage.getItem('sd1-local'));const withR=Object.values(d.cards).filter(c=>c.r);return {days:d.days,withR:withR.length,sampleR:withR[0]&&withR[0].r};});
  await page.setViewportSize({width:400,height:1900});
  await page.click('[data-act=tab][data-tab=cards]');await page.waitForTimeout(100);
  await page.screenshot({path:B+'/shots/t7-cards.png'});
  out.cards=await ovf(page);
  await page.click('[data-act=tab][data-tab=sim]');await page.waitForTimeout(100);
  await page.selectOption('#m-s','zaimu');await page.selectOption('#m-y','2025');await page.fill('#m-p','72');await page.click('form[data-form=mock] button[type=submit]');
  await page.selectOption('#m-s','keizai');await page.fill('#m-p','38');await page.click('form[data-form=mock] button[type=submit]');
  await page.waitForTimeout(100);
  await page.screenshot({path:B+'/shots/t8-sim.png'});
  out.sim=await ovf(page);
  await page.click('[data-act=tab][data-tab=log]');await page.waitForTimeout(100);
  await page.click('[data-act=tab][data-tab=today]');await page.click('[data-act=add-min][data-m="30"]');
  await page.click('[data-act=tab][data-tab=log]');await page.waitForTimeout(100);
  await page.fill('#s-wd','105');await page.fill('#s-we','210');await page.click('form[data-form=settings] button[type=submit]');await page.waitForTimeout(100);
  await page.screenshot({path:B+'/shots/t9-log.png'});
  out.log=await ovf(page);
  out.settings=await page.evaluate(()=>JSON.parse(localStorage.getItem('sd1-local')).settings.main);
  // dark
  const d=await mk('dark');
  await d.page.screenshot({path:B+'/shots/d1-today.png'});
  await d.page.click('[data-act=go][data-n="10"]');await d.page.click('[data-act=pick][data-v="0"]');await d.page.click('[data-act=conf][data-c=unsure]');
  await d.page.screenshot({path:B+'/shots/d2-reveal.png'});
  await d.page.click('[data-act=s-close]');await d.page.waitForTimeout(80);
  await d.page.screenshot({path:B+'/shots/d3-endbar.png'});
  await d.page.click('[data-act=s-end]');await d.page.waitForTimeout(80);
  await d.page.click('[data-act=s-done]');
  await d.page.setViewportSize({width:400,height:1500});
  await d.page.click('[data-act=tab][data-tab=sim]');await d.page.waitForTimeout(80);
  await d.page.screenshot({path:B+'/shots/d4-sim.png'});
  out.steps=steps;out.errs=errs.concat(d.errs);
  console.log(JSON.stringify(out,null,1));
  await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
