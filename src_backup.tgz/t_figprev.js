// 下見用ページの図表を1つずつ写す。引数: 出力名 [light|dark]
const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const [name,scheme='light']=process.argv.slice(2);
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:390,height:900},deviceScaleFactor:1,colorScheme:scheme});
  const p=await ctx.newPage();
  await p.goto('http://127.0.0.1:8765/_figprev.html');await p.waitForTimeout(800);
  const secs=await p.$$('section.pv');const shots=[];let i=0;
  for(const s of secs){const path=B+'/shots/pv-'+name+'-'+(i++)+'.png';await s.screenshot({path});shots.push(path);}
  console.log(JSON.stringify(shots));
  await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
