// 章ごとの演習の解説の図表を確かめる。引数: 科目 章ID 出力名 [light|dark] [問題数]
const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const [s,g,name,scheme='light',nmax='10']=process.argv.slice(2);
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,serviceWorkers:'block',colorScheme:scheme,locale:'ja-JP'});
  const p=await ctx.newPage();
  await p.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
  await p.goto('http://127.0.0.1:8765/index.html');await p.waitForTimeout(1000);
  await p.click('[data-act=tab][data-tab=drill]');await p.waitForTimeout(100);
  await p.click('[data-act=open-syl][data-s='+s+']');await p.waitForTimeout(150);
  await p.click('[data-act=drill-group][data-g="'+g+'"]');await p.waitForTimeout(200);
  const shots=[];const ovf=[];
  for(let i=0;i<+nmax;i++){
    if(!await p.$('[data-act=pick]'))break;
    await p.click('[data-act=pick][data-v="1"]');await p.click('[data-act=conf][data-c=sure]');await p.waitForTimeout(120);
    const info=await p.evaluate(()=>{const r=document.querySelector('.res');const sc=document.querySelector('#sess .p-scroll')||document.querySelector('.p-scroll');
      const d=document.documentElement;const bad=[...document.querySelectorAll('.res *')].filter(e=>!e.closest('.tx-fig')&&e.getBoundingClientRect().right>d.clientWidth+1).length;
      return {id:(document.querySelector('.res .fine:last-child')||{}).innerText,figs:r?r.querySelectorAll('svg').length:0,bad};});
    ovf.push(info);
    const el=await p.$('.res');const path=B+'/shots/qx-'+name+'-'+i+'.png';await el.screenshot({path});shots.push(path);
    if(!await p.$('[data-act=next]'))break;await p.click('[data-act=next]');await p.waitForTimeout(120);
  }
  console.log(JSON.stringify({shots,ovf,errs}));
  await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
