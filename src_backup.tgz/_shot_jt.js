const http=require('http'),fs=require('fs'),path=require('path');
const R=path.resolve('pwa'),SEC=process.argv[2],OUT=process.argv[3];
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]),f=path.join(R,u==='/'?'index.html':u);try{const d=fs.readFileSync(f);r.writeHead(200,{'Content-Type':f.endsWith('.json')?'application/json':'text/html; charset=utf-8'});r.end(d);}catch(e){r.writeHead(404);r.end();}});
srv.listen(0,async()=>{const {chromium}=require('playwright');const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},serviceWorkers:'block'});
await ctx.addInitScript(()=>{try{localStorage.setItem('shindan1-stage','s2');}catch(e){}});const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('http://127.0.0.1:'+srv.address().port+'/');await p.waitForTimeout(800);await p.click('[data-tab="jtext"]');await p.waitForTimeout(400);
await p.click(`[data-act="jt-sec"][data-sec="${SEC}"]`);await p.waitForTimeout(300);
const h=await p.evaluate(()=>document.getElementById('main').scrollHeight+200);await p.setViewportSize({width:390,height:Math.min(h,9000)});await p.waitForTimeout(150);
await p.screenshot({path:OUT});const over=await p.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+1);console.log('over',over,'errs',JSON.stringify(errs));await b.close();srv.close();});
