// 同期のしくみ（index.html の「端末間の同期」の段）を、偽の Firestore で確かめる
// 使い方：node t_sync.js
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const B = '/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad/';
const html = fs.readFileSync(B + 'pwa/index.html', 'utf8');
const a = html.indexOf('/* ---------- 端末間の同期'), z = html.indexOf('/* ---------- 起動');
assert(a > 0 && z > a, '同期の段が見つからない');
const code = html.slice(a, z);

// 偽の Firestore（全端末で共有するクラウド）
const cloud = {};
function snap(path) { const d = cloud[path]; return { id: path.split('/').pop(), exists: () => !!d, data: () => JSON.parse(JSON.stringify(d)) }; }
const F = {
  doc: (db, ...p) => ({ path: p.join('/') }),
  collection: (db, ...p) => ({ path: p.join('/') }),
  getDoc: async (r) => snap(r.path),
  setDoc: async (r, d) => { cloud[r.path] = JSON.parse(JSON.stringify(d)); },
  getDocs: async (c) => { const out = Object.keys(cloud).filter(k => k.startsWith(c.path + '/') && k.slice(c.path.length + 1).indexOf('/') < 0).map(snap); return { forEach: f => out.forEach(f) }; },
  runTransaction: async (db, fn) => { const w = []; const tx = { get: async r => snap(r.path), set: (r, d) => w.push([r.path, d]) }; const res = await fn(tx); w.forEach(([p, d]) => { cloud[p] = JSON.parse(JSON.stringify(d)); }); return res; },
};

// 端末を1台つくる（それぞれ別の localStorage と ST）
function device(name, ua, st, st2) {
  const ls = {};
  const ctx = {
    console, JSON, Math, Date, Object, Promise, Number, String, setTimeout: () => 0, clearTimeout: () => {},
    navigator: { userAgent: ua, onLine: true },
    localStorage: { getItem: k => (k in ls ? ls[k] : null), setItem: (k, v) => { ls[k] = String(v); }, removeItem: k => { delete ls[k]; } },
    document: { addEventListener() {}, visibilityState: 'visible' }, window: { addEventListener() {} },
    STORE: 'shindanshi-v1', DEF: { wdMin: 60, weMin: 180, newPerDay: 20, active: ['zaimu'] },
    uid: p => p + Math.random().toString(36).slice(2, 8), saveNow() {}, schedRender() {}, toast() {}, esc: s => String(s),
  };
  ctx.ST = Object.assign({ v: 1, settings: { wdMin: 60 }, srs: {}, days: {}, past: [], flags: {}, timer: null, mock: [], mockRun: null, flagDel: {}, daysX: {}, settingsAt: 0 }, st);
  ctx.ST2 = Object.assign({ ex: {}, dr: {}, log: {}, j4: {} }, JSON.parse(JSON.stringify(st2 || {})));
  vm.createContext(ctx);
  vm.runInContext(code, ctx);
  vm.runInContext("SYNC.mod={F:__F,db:{}};SYNC.user={uid:'U1',email:'me@example.com'};", Object.assign(ctx, { __F: F }));
  ctx.name = name;
  return ctx;
}
const run = (d, mode) => vm.runInContext('syncNow(' + (mode ? JSON.stringify(mode) : '') + ')', d);
const get = (d, expr) => JSON.parse(vm.runInContext('JSON.stringify(' + expr + ')', d) || 'null');
const dayOf = (d, k) => get(d, 'dayRec(' + JSON.stringify(k) + ')');

(async () => {
  // 1. スマホ（先に使っていた）：記録をクラウドに上げる
  const A = device('A', 'Mozilla/5.0 (Linux; Android 14)', {
    srs: { q1: { last: 100, reps: 2, att: 2, cor: 1 }, q5: { last: 90, reps: 1 } },
    past: [{ id: 'p1', s: 'zaimu', y: 2021, at: 10, score: 64 }],
    mock: [{ id: 'm1', s: 'keizai', r: 1, at: 20, score: 60 }],
    days: { '2026-11-10': { min: 30, ans: 10, cor: 8, nw: 5 } },
    flags: { q9: { at: 50 } }, settings: { wdMin: 60 },
  });
  await run(A);
  assert(cloud['users/U1/sync/state'], 'クラウドに記録がない');
  assert.strictEqual(vm.runInContext('SYNC.err', A), '');
  console.log('1 スマホの記録を上げた：ok');

  // 2. パソコン（別の記録あり）：はじめての同期は「どうしますか」を聞く
  const Bd = device('B', 'Mozilla/5.0 (Windows NT 10.0)', {
    srs: { q1: { last: 200, reps: 3, att: 3, cor: 2 }, q2: { last: 150, reps: 1 } },
    past: [{ id: 'p2', s: 'kigyo', y: 2022, at: 30, score: 55 }],
    days: { '2026-11-10': { min: 20, ans: 5, cor: 4, nw: 2 }, '2026-11-11': { min: 10, ans: 0, cor: 0, nw: 0 } },
    settings: { wdMin: 90 },
  });
  await run(Bd);
  assert(vm.runInContext('SYNC.ask', Bd), '確認が出ない');
  assert.deepStrictEqual(Object.keys(get(Bd, 'ST.srs')).sort(), ['q1', 'q2'], '確認の前に記録が変わった');
  console.log('2 パソコンのはじめての同期で確認が出る：ok');

  // 3. 「合わせる」
  await run(Bd, 'merge');
  const SB = get(Bd, 'ST');
  assert.strictEqual(SB.srs.q1.last, 200, 'q1 の復習の予定は新しいほう');
  assert.deepStrictEqual([SB.srs.q1.att, SB.srs.q1.cor, SB.srs.q1.reps], [5, 3, 5], 'はじめての同期では、両方の端末で解いた回数を足す');
  assert(SB.srs.q2 && SB.srs.q5, 'q2・q5 がそろう');
  assert.deepStrictEqual(SB.past.map(x => x.id), ['p1', 'p2']);
  assert.deepStrictEqual(SB.mock.map(x => x.id), ['m1']);
  assert(SB.flags.q9, '報告が残る');
  assert.strictEqual(SB.settings.wdMin, 60, '設定は同じ時刻ならクラウドのほう');
  assert.deepStrictEqual(dayOf(Bd, '2026-11-10'), { min: 50, ans: 15, cor: 12, nw: 7 }, '同じ日の学習時間は足す');
  assert.strictEqual(dayOf(Bd, '2026-11-11').min, 10);
  assert.strictEqual(vm.runInContext('SYNC.ask', Bd), null);
  console.log('3 「合わせる」：ok');

  // 4. スマホがもう一度同期すると、パソコンの分がそろう（二重には数えない）
  await run(A); await run(A);
  const SA = get(A, 'ST');
  assert.strictEqual(SA.srs.q1.last, 200);
  assert.strictEqual(SA.srs.q1.att, 5, '何度同期しても回数は増えない');
  assert(SA.srs.q2);
  assert.deepStrictEqual(dayOf(A, '2026-11-10'), { min: 50, ans: 15, cor: 12, nw: 7 }, '何度同期しても足し算は同じ');
  console.log('4 2台目の記録が1台目にそろう：ok');

  // 5. パソコンで報告を戻す → スマホでも戻る
  vm.runInContext("delete ST.flags.q9;ST.flagDel.q9=300;", Bd);
  await run(Bd); await run(A);
  assert(!vm.runInContext('ST.flags.q9', A), '戻した報告がスマホでも戻る');
  console.log('5 報告を戻したことがそろう：ok');

  // 6. スマホで設定を変える → パソコンにも
  vm.runInContext("ST.settings.wdMin=120;ST.settingsAt=400;", A);
  await run(A); await run(Bd);
  assert.strictEqual(vm.runInContext('ST.settings.wdMin', Bd), 120);
  console.log('6 設定の変更がそろう：ok');

  // 7. 同期中に解いた記録は消えない
  const p = run(Bd);
  vm.runInContext("ST.srs.q7={last:500,reps:1};", Bd);
  await p;
  assert(vm.runInContext('ST.srs.q7', Bd), '同期中の記録が消えた');
  await run(Bd); await run(A);
  assert(vm.runInContext('ST.srs.q7', A));
  console.log('7 同期の途中で解いた記録も残る：ok');

  // 8. 3台目（前に書き出し・読み込みで移した記録＝スマホと同じ）：「クラウドの記録にする」で二重に数えない
  const C = device('C', 'Mozilla/5.0 (Macintosh)', JSON.parse(JSON.stringify({ srs: SA.srs, past: SA.past, mock: SA.mock, days: SA.days, settings: SA.settings })));
  await run(C);
  assert(vm.runInContext('SYNC.ask', C));
  await run(C, 'cloud');
  assert.deepStrictEqual(get(C, 'ST.days'), {}, 'この端末の学習時間は消える');
  assert.deepStrictEqual(dayOf(C, '2026-11-10'), { min: 50, ans: 15, cor: 12, nw: 7 }, '二重に数えない');
  assert.strictEqual(vm.runInContext('ST.srs.q1.last', C), 200);
  console.log('8 「クラウドの記録にする」：ok');

  // 9. 記録のない端末は、聞かずにクラウドの記録を受け取る
  const D = device('D', 'Mozilla/5.0 (Linux; Android 14)', {});
  await run(D);
  assert.strictEqual(vm.runInContext('SYNC.ask', D), null);
  assert(vm.runInContext('ST.srs.q2', D));
  console.log('9 記録のない端末：ok');

  // 11. 同期のあと、両方の端末で同じ問題を別々に解く → 回数は両方の分を足す
  await run(A); await run(Bd);
  const before = get(A, 'ST.srs.q2');
  vm.runInContext("ST.srs.q2=Object.assign({},ST.srs.q2,{last:600,att:ST.srs.q2.att+1||1,reps:(ST.srs.q2.reps||0)+1});", A);
  vm.runInContext("ST.srs.q2=Object.assign({},ST.srs.q2,{last:700,att:ST.srs.q2.att+1||1,reps:(ST.srs.q2.reps||0)+1});", Bd);
  await run(A); await run(Bd); await run(A); await run(Bd);
  for (const d of [A, Bd]) {
    const q2 = get(d, 'ST.srs.q2');
    assert.strictEqual(q2.last, 700, '復習の予定は新しいほう');
    assert.strictEqual(q2.att, (before.att || 0) + 2, '両方で解いた回数がどちらも残る');
    assert.strictEqual(q2.reps, (before.reps || 0) + 2);
  }
  console.log('11 両方で同じ問題を解いても回数が消えない：ok');

  // 12. v28 で同期した端末（前の同期の値がない）：二重に数えない
  const SA2 = get(A, 'ST');
  const E = device('E', 'Mozilla/5.0 (Windows NT 10.0)', { srs: SA2.srs, past: SA2.past, mock: SA2.mock, settings: SA2.settings });
  vm.runInContext("lsSet('-synced','U1');", E);
  await run(E);
  assert.strictEqual(vm.runInContext('SYNC.ask', E), null, '前に同期した端末には聞かない');
  assert.strictEqual(get(E, 'ST.srs.q2.att'), get(A, 'ST.srs.q2.att'), 'v28 からの切り替えで回数が倍にならない');
  console.log('12 v28 で同期した端末：ok');

  // 13. ログアウトして同じアカウントで入り直す：聞かれず、二重に数えない
  vm.runInContext("lsSet('-sync',null);", Bd);
  const q2b = get(Bd, 'ST.srs.q2.att');
  await run(Bd);
  assert.strictEqual(vm.runInContext('SYNC.ask', Bd), null);
  assert.strictEqual(get(Bd, 'ST.srs.q2.att'), q2b);
  console.log('13 入り直し：ok');

  // 14. 2次の記録：別々の設問の答えは両方そろう。採点の結果もそろう
  const C2 = 'users/U1/sync/s2';
  vm.runInContext("ST2.ex['ex1-01']={1:{ans:['強みはA'],at:1000,grade:{score:12,at:1100}}};ST2.log.a1={k:'dr',p:'d1',at:1000};ST2.j4.j1={att:2,cor:1,last:5};", A);
  vm.runInContext("ST2.ex['ex1-01']={2:{ans:['助言はB'],at:1200}};ST2.ex['ex2-01']={1:{ans:['C'],at:900}};ST2.log.b1={k:'dr',p:'d2',at:1300};ST2.j4.j1={att:1,cor:1,last:9};", Bd);
  await run(A); await run(Bd); await run(A);
  assert(cloud[C2], '2次の記録がクラウドにない');
  for (const d of [A, Bd]) {
    const e = get(d, 'ST2.ex');
    assert.strictEqual(e['ex1-01'][1].ans[0], '強みはA');
    assert.strictEqual(e['ex1-01'][1].grade.score, 12, '採点の結果もそろう');
    assert.strictEqual(e['ex1-01'][2].ans[0], '助言はB');
    assert.strictEqual(e['ex2-01'][1].ans[0], 'C');
    assert.deepStrictEqual(Object.keys(get(d, 'ST2.log')).sort(), ['a1', 'b1'], '解いた記録は両方残る');
    assert.deepStrictEqual(get(d, 'ST2.j4.j1'), { att: 2, cor: 1, last: 9 }, '旧形式の回数は多いほう');
  }
  console.log('14 2次の答案・採点・記録がそろう：ok');

  // 15. 片方で書き直す（前の採点は消える）→ 新しい答えがもう片方にも。古い採点は戻ってこない
  vm.runInContext("ST2.ex['ex1-01'][1]={ans:['強みはA2'],at:2000};", Bd);
  await run(Bd); await run(A); await run(Bd);
  for (const d of [A, Bd]) {
    const q = get(d, "ST2.ex['ex1-01'][1]");
    assert.strictEqual(q.ans[0], '強みはA2', '新しく書いたほうが残る');
    assert(!q.grade, '書き直す前の採点が戻ってこない');
  }
  console.log('15 書き直した答えがそろう：ok');

  // 16. 同じ答えを片方で採点 → もう片方にも採点の結果がそろう
  vm.runInContext("ST2.ex['ex1-01'][1].grade={score:15,at:2100};", A);
  await run(A); await run(Bd);
  assert.strictEqual(get(Bd, "ST2.ex['ex1-01'][1].grade.score"), 15);
  console.log('16 あとからの採点がそろう：ok');

  // 17. 同期の途中で書いた2次の答えは消えない
  const p2 = run(A);
  vm.runInContext("ST2.ex['ex3-01']={1:{ans:['途中'],at:3000}};", A);
  await p2;
  assert.strictEqual(get(A, "ST2.ex['ex3-01'][1].ans[0]"), '途中', '同期中の2次の答えが消えた');
  await run(A); await run(Bd);
  assert.strictEqual(get(Bd, "ST2.ex['ex3-01'][1].ans[0]"), '途中');
  console.log('17 同期の途中で書いた2次の答えも残る：ok');

  // 18. 「クラウドの記録にする」を選んでも、この端末の2次の答えは消さずに合わせる
  const S3 = get(A, 'ST');
  const G = device('G', 'Mozilla/5.0 (Macintosh)', { srs: S3.srs, past: S3.past, mock: S3.mock, days: { '2026-11-12': { min: 5 } }, settings: S3.settings }, { ex: { 'ex2-01': { 2: { ans: ['Gの答え'], at: 4000 } } } });
  await run(G);
  assert(vm.runInContext('SYNC.ask', G));
  await run(G, 'cloud');
  assert.strictEqual(get(G, "ST2.ex['ex2-01'][2].ans[0]"), 'Gの答え', 'この端末の2次の答えが消えた');
  assert.strictEqual(get(G, "ST2.ex['ex1-01'][1].ans[0]"), '強みはA2', 'クラウドの2次の答えも来る');
  await run(A);
  assert.strictEqual(get(A, "ST2.ex['ex2-01'][2].ans[0]"), 'Gの答え');
  console.log('18 「クラウドの記録にする」でも2次は合わせる：ok');

  // 10. オフラインでは何もしない
  vm.runInContext("navigator.onLine=false;", A);
  await run(A);
  assert(/オフライン/.test(vm.runInContext('SYNC.err', A)));
  console.log('10 オフライン：ok');
  console.log('すべて ok');
})().catch(e => { console.error('NG', e && e.stack || e); process.exit(1); });
