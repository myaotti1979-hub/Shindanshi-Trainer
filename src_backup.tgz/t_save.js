const { chromium } = require('playwright');
(async()=>{
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:400,height:860},serviceWorkers:'block'});
  const page=await ctx.newPage();
  await page.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  await page.goto('http://127.0.0.1:8765/index.html');await page.waitForTimeout(800);
  await page.click('[data-act=go][data-n="10"]');await page.waitForTimeout(150);
  for(let i=0;i<40;i++){if(await page.$('[data-act=s-done]'))break;if(await page.$('[data-act=next]')){await page.click('[data-act=next]');continue;}await page.click('[data-act=pick][data-v="1"]');await page.click('[data-act=conf][data-c=unsure]');}
  await page.click('[data-act=s-done]');
  const a=await page.evaluate(()=>{const s=JSON.parse(localStorage.getItem('shindan1')||'{}');return s.srs?Object.keys(s.srs).length:-1;});
  await page.waitForTimeout(700);
  const b=await page.evaluate(()=>{const s=JSON.parse(localStorage.getItem('shindan1')||'{}');return s.srs?Object.keys(s.srs).length:-1;});
  console.log('immediately',a,'after 700ms',b);
  await browser.close();
})();
