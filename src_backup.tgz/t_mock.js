// 模擬試験の画面を確かめる。node t_mock.js 名前 [light|dark] [日付YYYY-MM-DD]
const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const name=process.argv[2]||'mk',scheme=process.argv[3]||'light',day=process.argv[4]||null;
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:400,height:860},deviceScaleFactor:2,locale:'ja-JP',timezoneId:'Asia/Tokyo',colorScheme:scheme});
  if(day&&ctx.clock)await ctx.clock.install({time:new Date(day+'T09:00:00+09:00')});
  const page=await ctx.newPage();await page.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  const errs=[];page.on('pageerror',e=>errs.push(e.message));page.on('console',m=>{if(m.type()==='error'&&!/ERR_FAILED/.test(m.text()))errs.push('console '+m.text());});
  await ctx.addInitScript(()=>{try{if(!sessionStorage.getItem('inj')){localStorage.setItem('shindan1-tab','today');sessionStorage.setItem('inj','1');}}catch(e){}});
  await page.goto('http://127.0.0.1:8765/index.html');await page.waitForTimeout(1200);
  const ovf=async()=>page.evaluate(()=>{const d=document.documentElement;const bad=[];document.querySelectorAll('body *').forEach(el=>{const r=el.getBoundingClientRect();if(r.width>0&&r.right>d.clientWidth+1&&!el.closest('.pgrid')&&!el.closest('.fig'))bad.push((el.className||el.tagName)+':'+Math.round(r.right));});return {sw:d.scrollWidth,cw:d.clientWidth,bad:bad.slice(0,6)};});
  const shot=async f=>{await page.waitForTimeout(150);await page.screenshot({path:B+'/shots/'+name+'-'+f+'.png'});};
  const out={};
  await shot('1-today');out.today=await ovf();
  await page.click('.tab[data-tab=past]');await page.waitForTimeout(200);await shot('2-grid');out.grid=await ovf();
  await page.click('[data-act=mk-open][data-s=keizai][data-r="1"]');await page.waitForTimeout(500);await shot('3-intro');out.intro=await ovf();
  if(await page.$('[data-act=mk-early]')){await page.click('[data-act=mk-early]');await page.waitForTimeout(100);}
  await page.click('[data-act=mk-start]');await page.waitForTimeout(200);
  // 7問目（設問のある問題）まで答える
  for(let i=0;i<8;i++){const c=await page.$$('#mock [data-act=mk-pick]');if(c.length)await c[i%c.length].click();if(i===2)await page.click('[data-act=mk-flag]');await page.click('[data-act=mk-next]');}
  await shot('4-exam');out.exam=await ovf();
  await page.click('#mock .p-top [data-act=mk-list]');await page.waitForTimeout(150);await shot('5-list');out.list=await ovf();
  await page.click('[data-act=mk-confirm]');await page.waitForTimeout(100);await shot('6-confirm');
  await page.click('[data-act=mk-submit]');await page.waitForTimeout(200);await shot('7-result');out.result=await ovf();
  await page.click('[data-act=mk-rv][data-i="6"]');await page.waitForTimeout(200);await shot('8-review');out.review=await ovf();
  await page.click('.p-foot [data-act=mk-back]');await page.click('.p-foot [data-act=mk-close]');await page.waitForTimeout(150);
  await page.click('.tab[data-tab=judge]');await page.waitForTimeout(150);await shot('9-judge');
  await page.click('.tab[data-tab=today]');await page.waitForTimeout(150);await shot('10-today-after');
  out.state=await page.evaluate(()=>{const s=JSON.parse(localStorage.getItem('shindan1'));return {mock:s.mock.map(a=>({r:a.r,s:a.s,score:a.score,ok:a.ok,total:a.total})),run:s.mockRun};});
  out.errs=errs;console.log(JSON.stringify(out));
  await browser.close();
})();
