# 節の本文はそのままにして、図表の行を差し込んだ NEW を作る（set_sections.py と fcheck.py で使う）。
# 使い方: python3 ins_sections.py <E を定義した .py> <出力する NEW の .py> <科目>
#  E = {節ID: [(位置, 目印, 差し込む行), ...]}
#   位置: 'after'（目印を含む行の後に入れる）、'before'（前に入れる）、'replace'（目印を含む行を置き換える。'' なら消す）
#   目印は、その節の中でちょうど1行だけに含まれる文字列。差し込む行は \n で区切って複数書ける
import sys, os, glob, importlib.util
B = os.path.dirname(os.path.abspath(__file__))


def load(p):
    spec = importlib.util.spec_from_file_location(os.path.basename(p)[:-3].replace('.', '_'), p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


spec, outp, subj = sys.argv[1], sys.argv[2], sys.argv[3]
E = load(spec).E
src = {}
for f in sorted(glob.glob(os.path.join(B, 'text', subj + '_p*.py'))):
    if '.before' in f:
        continue
    stem = os.path.basename(f)[:-3]
    for k, (title, content) in load(f).T.items():
        src[k] = (stem, content)
out = ['NEW = {}', '']
err = 0
for k, edits in E.items():
    if k not in src:
        sys.exit('節がない: ' + k)
    stem, content = src[k]
    lines = content.split('\n')
    tags = [None] * len(lines)  # 元の行の番号（差し込んだ行は None）
    tags = list(range(len(lines)))
    for pos, mark, block in edits:
        hits = [i for i, ln in enumerate(lines) if tags[i] is not None and mark in ln]
        if len(hits) != 1:
            print('目印が%d行にある: %s 「%s」' % (len(hits), k, mark))
            err += 1
            continue
        i = hits[0]
        new = block.split('\n') if block else []
        if pos == 'after':
            j = i + 1
            while j < len(lines) and tags[j] is None:
                j += 1
            lines[j:j] = new
            tags[j:j] = [None] * len(new)
        elif pos == 'before':
            lines[i:i] = new
            tags[i:i] = [None] * len(new)
        elif pos == 'replace':
            lines[i:i + 1] = new
            tags[i:i + 1] = [None] * len(new)
        else:
            sys.exit('位置の指定が不正: ' + pos)
    body = '\n'.join(lines)
    assert '"""' not in body and '\\' not in body, k
    out.append("NEW['%s'] = ('%s', \"\"\"%s\"\"\")" % (k, stem, body))
    out.append('')
if err:
    sys.exit('エラー %d 件' % err)
open(outp, 'w', encoding='utf-8').write('\n'.join(out))
print('書き出し:', outp, len(E), '節')
