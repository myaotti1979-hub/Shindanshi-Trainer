# 節の本文を丸ごと置き換える。使い方: python3 set_sections.py <NEW を定義した .py>
#  NEW = {節ID: (ファイル名（text/ の下、拡張子なし）, 新しい本文)} 。題を変えるときは (ファイル名, 本文, 題)
import sys, os, importlib.util
B = os.path.dirname(os.path.abspath(__file__))

def load(f):
    spec = importlib.util.spec_from_file_location(os.path.basename(f)[:-3], f)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    head = open(f, encoding='utf-8').read().split('T = {}')[0]
    return m.T, head

def dump(f, T, head):
    out = [head.rstrip('\n') + '\nT = {}\n']
    for k, (title, content) in T.items():
        assert '"""' not in content and '\\' not in content, k
        out.append('T["%s"] = ("%s", """%s""")\n' % (k, title, content.strip('\n')))
    open(f, 'w', encoding='utf-8').write('\n'.join(out))

spec = importlib.util.spec_from_file_location('newsec', sys.argv[1])
ns = importlib.util.module_from_spec(spec); spec.loader.exec_module(ns)
byfile = {}
for k, v in ns.NEW.items():
    byfile.setdefault(v[0], []).append((k, v))
for f, items in byfile.items():
    path = os.path.join(B, 'text', f + '.py')
    T, head = load(path)
    for k, v in items:
        if k not in T:
            sys.exit('節がない: %s（%s）' % (k, f))
        title = v[2] if len(v) > 2 else T[k][0]
        T[k] = (title, v[1].strip('\n'))
    dump(path, T, head)
    print('更新:', f, [k for k, _ in items])
