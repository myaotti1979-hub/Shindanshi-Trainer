const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
(async()=>{
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:400,height:860},deviceScaleFactor:1,serviceWorkers:'block'});
  const p=await ctx.newPage();
  await p.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  await p.goto('http://127.0.0.1:8765/index.html');await p.waitForTimeout(700);
  await p.click('[data-act=tab][data-tab=drill]');await p.waitForTimeout(100);
  await p.click('[data-act=open-syl][data-s=kigyo]');await p.waitForTimeout(100);
  for(const ch of ['kigyo.1.6','kigyo.1.7']){
    await p.click(`[data-act=open-text][data-ch="${ch}"]`);await p.waitForTimeout(200);
    // scroll to specific section
    const id = ch==='kigyo.1.6' ? 'sec-kigyo-1-6-4' : 'sec-kigyo-1-7-1';
    await p.evaluate((id)=>{const el=document.getElementById(id);const sc=document.querySelector('#reader .p-body')||el.closest('.panel');el.scrollIntoView();},id);
    await p.waitForTimeout(100);
    await p.screenshot({path:B+`/shots/rev1-${ch}.png`});
    await p.click('[data-act=rd-close]');await p.waitForTimeout(100);
  }
  await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
