# 文字の検査：pwa/data/*.json と index.html の全文字が cp932 か euc_jis_2004 で表せるか（簡体字などの混入を防ぐ）。┅ — ² は許可
import glob, collections, sys
OK = set('┅—²')
bad = collections.Counter(); where = {}
files = sorted(glob.glob('pwa/data/*.json')) + ['pwa/index.html']
for f in files:
    s = open(f, encoding='utf-8').read()
    for ch in set(s):
        if ord(ch) < 128 or ch in OK: continue
        ok = False
        for enc in ('cp932', 'euc_jis_2004'):
            try: ch.encode(enc); ok = True; break
            except UnicodeEncodeError: pass
        if not ok:
            bad[ch] += s.count(ch); where.setdefault(ch, f)
print('files', len(files), 'bad chars', len(bad))
for ch, n in bad.most_common(30): print(repr(ch), hex(ord(ch)), n, where[ch])
