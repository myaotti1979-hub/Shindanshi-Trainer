# 複数の点検ファイルから選んだ指摘を、原本（text/*.py）に当てる
# 使い方: python3 apply_merge.py review/text_X.json:1,3,5 review/text_Y.json:2 [--dry]
#  fix の形：①図 名前（ファイル名）：【置換前】A【置換後】B　②【置換前】A【置換後】B（本文。どのファイルかは自動で探す）
#            ③【追加】（「X」の後）Y　④【追加】「X」の(行の)後に(、次の行として)「Y」　⑤【追加】Y（「X」の後）
#  文字列は原本でちょうど1回一致しないと止まる（何も書き込まない）
import json, re, sys, glob, os
B = os.path.dirname(os.path.abspath(__file__))
dry = '--dry' in sys.argv
specs = [a for a in sys.argv[1:] if not a.startswith('--')]
files = sorted(glob.glob(os.path.join(B, 'text', '*.py')))
src = {f: open(f, encoding='utf-8').read() for f in files}
def find_one(s):
    hits = [(f, src[f].count(s)) for f in files if s in src[f]]
    tot = sum(c for f, c in hits)
    if tot != 1: raise SystemExit('一致が%d件: %s' % (tot, s[:60]))
    return hits[0][0]
log = []
for spec in specs:
    path, idx = spec.rsplit(':', 1)
    R = json.load(open(os.path.join(B, path) if not path.startswith('/') else path, encoding='utf-8'))
    for i in [int(x) for x in idx.split(',')]:
        fx = R[i]['fix'].strip()
        tag = '%s#%d' % (os.path.basename(path), i)
        if '【置換前】' in fx and '【置換後】' in fx:
            old = fx.split('【置換前】', 1)[1].split('【置換後】', 1)[0]
            new = fx.split('【置換後】', 1)[1]
            # 図の指摘の末尾に注記がつくことがあるので、置換後の文字列はそのまま使う
            f = find_one(old)
            src[f] = src[f].replace(old, new)
            log.append((tag, 'replace', os.path.basename(f)))
        elif fx.startswith('【追加】'):
            body = fx[len('【追加】'):].strip('\n')
            m = re.match(r'^（「(.+?)」の後）\s*(.+)$', body, re.S)
            if m: anc, y, nl = m.group(1), m.group(2), True
            else:
                m = re.match(r'^「(.+?)」の(行の)?後に(、次の行として)?「(.+)」$', body, re.S)
                if m: anc, y, nl = m.group(1), m.group(4), bool(m.group(2) or m.group(3))
                else:
                    m = re.search(r'^(.*)（「(.+?)」の後）\s*$', body, re.S)
                    anc, y, nl = m.group(2), m.group(1), True
            f = find_one(anc)
            s = src[f]; k = s.find(anc) + len(anc)
            if nl:
                e = s.find('\n', k)
                lines = y.strip('\n').split('\n')
                if lines[0].startswith('**'): lines = [''] + lines
                s = s[:e] + '\n' + '\n'.join(lines) + s[e:]
            else:
                s = s[:k] + y + s[k:]
            src[f] = s
            log.append((tag, 'add', os.path.basename(f)))
        else:
            raise SystemExit('形式が分からない: %s %s' % (tag, fx[:60]))
for x in log: print(*x)
if not dry:
    for f in files:
        if src[f] != open(f, encoding='utf-8').read():
            open(f, 'w', encoding='utf-8').write(src[f])
    print('written')
