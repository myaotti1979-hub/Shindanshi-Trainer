// 「新しい版があります」の表示に、新しい版と今の版が出ることを確かめる
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 360, height: 760 }, serviceWorkers: 'block' });
  const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  // sw.js を新しい版として返す
  await p.route('**/sw.js', r => r.fulfill({ status: 200, contentType: 'text/javascript', body: "var VER = 'v31';" }));
  await p.goto('http://127.0.0.1:8765/index.html?chk=1'); await p.waitForTimeout(1200);
  await p.evaluate(() => { window.__chk.UI.swWaiting = { postMessage() {} }; });
  await p.click('[data-act="tab"][data-tab="log"]'); await p.waitForTimeout(800);
  await p.click('[data-act="tab"][data-tab="today"]'); await p.waitForTimeout(800);
  const t = await p.evaluate(() => { const n = document.querySelector('#note'); return n && !n.hidden ? n.textContent : null; });
  console.log(JSON.stringify({ note: t, errs }));
  await b.close();
})();
