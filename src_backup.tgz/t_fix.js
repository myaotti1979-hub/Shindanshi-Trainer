const { chromium } = require('playwright');
const B='/tmp/claude-0/-home-claude/2a531a48-7555-5cc8-b05a-a0eced613605/scratchpad';
const URL='http://127.0.0.1:8765/';
(async()=>{
  const browser=await chromium.launch();const out={};
  const ctx=await browser.newContext({viewport:{width:400,height:860},deviceScaleFactor:1,colorScheme:'dark',serviceWorkers:'block'});
  const p=await ctx.newPage();
  await p.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  const errs=[];p.on('pageerror',e=>errs.push('PAGEERR '+e.message));
  await p.route('**/data/q_kigyo.json',async r=>{const res=await r.fetch();const j=await res.json();j.questions=[
    {id:'t-mc',type:'mc',t:'kigyo.1.3.3',q:'テスト用の単答問題。最も適切なものはどれか。',ch:['選択肢アの記述','選択肢イの記述','選択肢ウの記述','選択肢エの記述'],a:2,e:'解説',ce:['アの解説','イの解説','ウの解説','エの解説'],ref:'テスト根拠',st:'ok',n:1},
    {id:'t-cb',type:'combo',t:'kigyo.1.3.3',q:'次の記述a〜dのうち、正しいものの組み合わせとして、最も適切なものはどれか。',stm:['記述aの文','記述bの文','記述cの文','記述dの文'],ch:['aとb','aとc','bとd','cとd'],a:1,e:'解説',st:'ok',n:2}
  ];await r.fulfill({response:res,json:j});});
  await p.addInitScript(()=>{if(!localStorage.getItem('shindan1'))localStorage.setItem('shindan1',JSON.stringify({v:1,settings:{active:['kigyo']},srs:{},days:{},past:[],flags:{},timer:null}));});
  await p.goto(URL+'index.html');await p.waitForTimeout(700);
  await p.click('[data-act=go][data-n="10"]');await p.waitForTimeout(100);
  out.first=await p.$eval('.s-q',e=>e.textContent.slice(0,12));
  await p.click('[data-act=pick][data-v="1"]');await p.click('[data-act=conf][data-c=sure]');
  await p.screenshot({path:B+'/shots/d1-mc.png'});
  await p.click('[data-act=next]');await p.waitForTimeout(80);
  await p.click('[data-act=pick][data-v="1"]');await p.click('[data-act=conf][data-c=guess]');
  await p.screenshot({path:B+'/shots/d2-combo.png'});
  for(let i=0;i<5;i++){if(await p.$('[data-act=s-done]'))break;if(await p.$('[data-act=next]')){await p.click('[data-act=next]');continue;}await p.click('[data-act=pick][data-v="2"]');await p.click('[data-act=conf][data-c=sure]');}
  await p.waitForTimeout(400);
  out.saved=await p.evaluate(()=>{const s=JSON.parse(localStorage.getItem('shindan1'));return {srs:Object.keys(s.srs),days:s.days};});
  await p.screenshot({path:B+'/shots/d3-done.png'});
  out.errs=errs;console.log(JSON.stringify(out,null,1));await browser.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1);});
